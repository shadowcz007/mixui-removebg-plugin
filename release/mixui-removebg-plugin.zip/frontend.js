// RemoveBGNode frontend bundle
var RemoveBGNode=(()=>{var o=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var n=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var u=(t,e)=>{for(var d in e)o(t,d,{get:e[d],enumerable:!0})},s=(t,e,d,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let a of n(e))!c.call(t,a)&&a!==d&&o(t,a,{get:()=>e[a],enumerable:!(r=m(e,a))||r.enumerable});return t};var x=t=>s(o({},"__esModule",{value:!0}),t);var i={};u(i,{default:()=>l});function f({data:t}){return React.createElement("div",{className:"text-center text-sm text-muted-foreground mt-2"},"\u7531shadow\u5236\u4F5C\u7684\u63D2\u4EF6\u793A\u4F8B")}var l=f;return x(i);})();

        // 提供模块导出兼容性
        if (typeof module !== 'undefined' && module.exports) {
          module.exports = { default: RemoveBGNode };
        }
        if (typeof exports !== 'undefined') {
          exports.default = RemoveBGNode;
        }
        // 确保组件函数在全局作用域中可用
        if (typeof globalThis !== 'undefined') {
          globalThis.RemoveBGNode = RemoveBGNode;
        }
      
