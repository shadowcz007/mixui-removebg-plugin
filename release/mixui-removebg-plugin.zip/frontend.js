// RemoveBGNode frontend bundle
var RemoveBGNode=(()=>{var i=Object.defineProperty;var n=Object.getOwnPropertyDescriptor;var r=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var s=(e,t)=>{for(var a in t)i(e,a,{get:t[a],enumerable:!0})},p=(e,t,a,l)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of r(t))!d.call(e,o)&&o!==a&&i(e,o,{get:()=>t[o],enumerable:!(l=n(t,o))||l.enumerable});return e};var c=e=>p(i({},"__esModule",{value:!0}),e);var h={};s(h,{default:()=>g});function x({data:e}){return React.createElement("div",{style:{padding:"12px",background:"linear-gradient(145deg, hsl(220, 15%, 14%), hsl(220, 15%, 16%))",border:"2px solid hsl(270, 50%, 40%)",borderRadius:"12px",width:"240px",color:"hsl(220, 8%, 92%)",boxShadow:"0 4px 20px rgba(0,0,0,0.6)"}},React.createElement(Handle,{type:"target",position:Position.Left,id:"image_base64",style:{background:"hsl(270, 50%, 40%)",border:"2px solid hsl(270, 50%, 40%)"}}),React.createElement("div",{style:{display:"flex",alignItems:"center",gap:"8px",marginBottom:"8px",fontWeight:"600",fontSize:"14px"}},React.createElement("div",{style:{width:"20px",height:"20px",background:"hsl(270, 50%, 40%)",borderRadius:"4px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"12px"}},"\u{1F9FC}"),e.label||"Remove Background"),React.createElement("div",{style:{fontSize:"12px",marginBottom:"8px",color:"hsl(220, 8%, 65%)"}},"\u8F93\u51FA\u683C\u5F0F: PNG"),React.createElement(Handle,{type:"source",position:Position.Right,id:"image_base64",style:{background:"hsl(270, 50%, 40%)",border:"2px solid hsl(270, 50%, 40%)"}}))}var g=x;return c(h);})();

        // 提供模块导出兼容性
        if (typeof module !== 'undefined' && module.exports) {
          module.exports = { default: RemoveBGNode };
        }
        if (typeof exports !== 'undefined') {
          exports.default = RemoveBGNode;
        }
        // 确保组件函数在全局作用域中可用
        if (typeof globalThis !== 'undefined') {
          globalThis.RemoveBGNode = RemoveBGNode;
        }
      
