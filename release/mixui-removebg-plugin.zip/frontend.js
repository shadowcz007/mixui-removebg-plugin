// RemoveBGNode frontend bundle
var RemoveBGNode=(()=>{var o=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var n=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var i=(e,t)=>{for(var s in t)o(e,s,{get:t[s],enumerable:!0})},m=(e,t,s,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of n(t))!c.call(e,a)&&a!==s&&o(e,a,{get:()=>t[a],enumerable:!(r=l(t,a))||r.enumerable});return e};var d=e=>m(o({},"__esModule",{value:!0}),e);var g={};i(g,{default:()=>u});function p({data:e}){return React.createElement("div",{className:"px-4 py-3 bg-gradient-node rounded-lg shadow-node relative group",style:{minWidth:"240px",minHeight:"120px"}},React.createElement("div",{className:"absolute left-0",style:{top:"60px"}},React.createElement(Handle,{type:"target",position:Position.Left,id:"image_base64",className:"!border-2",style:{backgroundColor:"hsl(212 100% 55%)",borderColor:"hsl(212 100% 55%)"}}),React.createElement("span",{className:"text-xs text-muted-foreground ml-4 whitespace-nowrap",style:{position:"absolute",left:"-50%",top:"50%",transform:"translateY(-80%)"}},"image_base64")),React.createElement("div",{className:"flex items-center gap-2 mb-3"},React.createElement("div",{className:"w-5 h-5 bg-purple-500 rounded flex items-center justify-center text-white text-xs"},"\u{1F9FC}"),React.createElement("span",{className:"font-medium text-sm text-foreground"},e.label||"Remove Background")),React.createElement("div",{className:"absolute right-0",style:{top:"60px"}},React.createElement(Handle,{type:"source",position:Position.Right,id:"image_base64",className:"!border-2",style:{backgroundColor:"hsl(212 100% 55%)",borderColor:"hsl(212 100% 55%)"}}),React.createElement("span",{className:"text-xs text-muted-foreground mr-4 whitespace-nowrap",style:{position:"absolute",right:"-50%",top:"50%",transform:"translateY(-80%)"}},"image_base64")))}var u=p;return d(g);})();

        // 提供模块导出兼容性
        if (typeof module !== 'undefined' && module.exports) {
          module.exports = { default: RemoveBGNode };
        }
        if (typeof exports !== 'undefined') {
          exports.default = RemoveBGNode;
        }
        // 确保组件函数在全局作用域中可用
        if (typeof globalThis !== 'undefined') {
          globalThis.RemoveBGNode = RemoveBGNode;
        }
      
