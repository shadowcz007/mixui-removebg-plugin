// RemoveBGNode frontend bundle
var RemoveBGNode=(()=>{var r=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var n=Object.prototype.hasOwnProperty;var c=(e,t)=>{for(var o in t)r(e,o,{get:t[o],enumerable:!0})},f=(e,t,o,m)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of d(t))!n.call(e,a)&&a!==o&&r(e,a,{get:()=>t[a],enumerable:!(m=u(t,a))||m.enumerable});return e};var x=e=>f(r({},"__esModule",{value:!0}),e);var N={};c(N,{default:()=>s});function l({data:e}){return React.createElement("div",{className:"text-center text-sm text-muted-foreground mt-2"},"PNG format output")}var s=l;return x(N);})();

        // 提供模块导出兼容性
        if (typeof module !== 'undefined' && module.exports) {
          module.exports = { default: RemoveBGNode };
        }
        if (typeof exports !== 'undefined') {
          exports.default = RemoveBGNode;
        }
        // 确保组件函数在全局作用域中可用
        if (typeof globalThis !== 'undefined') {
          globalThis.RemoveBGNode = RemoveBGNode;
        }
      
