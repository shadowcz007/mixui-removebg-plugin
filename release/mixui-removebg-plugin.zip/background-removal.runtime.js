var ImglyBackgroundRemoval=(()=>{var zo=Object.defineProperty;var mT=Object.getOwnPropertyDescriptor;var gT=Object.getOwnPropertyNames;var yT=Object.prototype.hasOwnProperty;var _T=(e,t,r)=>t in e?zo(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var Et=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof require<"u"?require:t)[r]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});var Jf=(e,t)=>()=>(e&&(t=e(e=0)),t);var np=(e,t)=>{for(var r in t)zo(e,r,{get:t[r],enumerable:!0})},vT=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of gT(t))!yT.call(e,a)&&a!==r&&zo(e,a,{get:()=>t[a],enumerable:!(i=mT(t,a))||i.enumerable});return e};var wT=e=>vT(zo({},"__esModule",{value:!0}),e);var Ao=(e,t,r)=>_T(e,typeof t!="symbol"?t+"":t,r);var cb={};np(cb,{InferenceSession:()=>yc,TRACE:()=>Ws,TRACE_FUNC_BEGIN:()=>nr,TRACE_FUNC_END:()=>qt,Tensor:()=>ar,default:()=>VC,env:()=>Ke,registerBackend:()=>Oi});var vr,mc,bT,$T,xT,kT,ee,qs,ST,Ko,Ts,jr,Oi,Yf,A_,O_,TT,R_,CT,sp,Vt,B_,Ke,IT,N_,M_,ET,Oo,D_,P_,U_,W_,V_,zT,Ei,Ns,op,q_,AT,j_,L_,OT,Nt,gc,ar,G_,Ws,up,nr,qt,F_,H_,RT,yc,BT,NT,MT,DT,PT,Z_,sr,_c,Q_,lp,dp,X_,UT,J_,pp,cp,Y_,em,WT,hp,tm,Bt,e0,Ro,rm,im,fp,am,mp,t0,gp,r0,vc,yp,Bo,Cs,_p,nm,sm,wc,lt,Mi,wt,Zo,Ve,bc,i0,VT,om,um,lm,dm,a0,qT,ta,zi,Ai,$c,Qo,xc,kc,tc,be,Sc,n0,pm,cm,hm,fm,Tc,mm,Ne,Dr,Cc,s0,Ic,vp,No,Mo,gm,ym,wp,rc,_m,o0,jT,vm,je,et,wm,ia,L,Xo,u0,l0,d0,Te,aa,Do,dt,xt,ye,Je,ic,ra,Fr,me,Is,K,he,p0,Ec,bm,c0,Ee,$m,bp,xm,km,Sm,Tm,Mt,h0,f0,Hr,Cm,Im,Em,zm,Am,Om,Rm,Bm,Nm,Mm,Yt,m0,g0,y0,_0,v0,w0,b0,$0,x0,k0,LT,er,Dm,Jo,ac,tr,Pm,Um,Wm,Vm,qm,jm,Lm,Gm,Fm,Hm,rr,S0,T0,C0,I0,E0,z0,A0,O0,R0,B0,zc,$p,N0,M0,nc,GT,Km,Po,Zm,Qm,Xm,Vs,Jm,D0,Ac,Ym,eg,tg,P0,FT,rg,ig,U0,HT,ag,Pe,W0,V0,q0,j0,L0,G0,F0,H0,K0,ng,Z0,Q0,X0,J0,Ds,Y0,Ho,ev,tv,rv,iv,av,nv,sv,ov,uv,lv,dv,pv,cv,hv,fv,mv,xp,gv,sc,oc,yv,_v,vv,sg,og,wv,Oc,ug,lg,bv,KT,dg,pg,ir,$v,xv,kv,Sv,Tv,Cv,Iv,Ev,zv,Av,ZT,cg,hg,fg,mg,Ov,Rv,QT,Ri,Bi,Ni,Rc,Di,ht,Bv,Bc,Nv,XT,Us,Nc,Mc,gg,yg,uc,kp,_g,lc,vg,Yo,Dc,wg,Mv,JT,bg,Sp,Es,$g,Tp,xg,Dv,Pv,YT,Uv,Wv,eC,kg,Uo,Sg,Wo,dc,Cp,Tg,Cg,pc,tC,Vv,rC,Ig,Eg,zg,Ip,qv,Ag,Ep,Og,jv,iC,Rg,Lv,Gv,aC,Bg,Ng,Mg,Fv,Hv,nC,Vo,zs,zp,Dg,Pg,Ug,Wg,Ap,Vg,Kv,Zv,sC,qg,Op,jg,Lg,Qv,oC,Gg,Xv,uC,Fg,Hg,Jv,Yv,lC,Kg,ew,tw,dC,Zg,Qg,rw,iw,pC,Xg,Jg,aw,nw,cC,Yg,ey,sw,ow,hC,_r,Mr,Si,Ti,ty,ry,iy,ay,ny,sy,oy,uy,uw,lw,fC,Tt,ly,dw,Rp,dy,Ps,pw,cw,py,cy,hy,fy,cc,hw,fw,mw,my,gy,Bp,gw,mC,Np,yy,_y,yw,gC,vy,wy,_w,yC,by,vw,_C,$y,xy,ky,ww,bw,vC,Sy,Ty,Cy,Iy,Ey,zy,Ay,Oy,$w,wC,As,Mp,Dp,Pp,Up,Ry,By,Wp,Vp,xw,kw,qp,Sw,Tw,jp,Cw,Iw,Ew,zw,bC,Ny,My,Aw,Ow,$C,Dy,Py,Rw,xC,Uy,Wy,Bw,Nw,kC,Vy,qy,jy,Lp,Ly,Gy,Fy,Hy,Ky,Zy,Qy,Xy,Gp,Jy,Yy,e_,t_,r_,Mw,Dw,SC,i_,a_,Pw,TC,n_,s_,Uw,CC,o_,Os,u_,Fp,l_,d_,Ww,Vw,IC,p_,c_,qw,jw,EC,Hp,h_,f_,m_,Lw,zC,g_,y_,Gw,AC,Fw,OC,Hw,RC,__,v_,w_,b_,Kw,BC,$_,Kp,x_,Zp,Qp,Xp,k_,Zw,NC,qo,S_,Qw,MC,Xw,jo,T_,Jw,DC,C_,Pc,Uc,Lr,I_,eu,Wc,Vc,Jp,qc,jc,Lc,eb,Gr,Wt,ea,Rs,Bs,Lo,Yp,Go,Ci,Ii,E_,tb,rb,ib,ab,nb,sb,ob,ub,ec,z_,lb,PC,db,hc,fc,pb,UC,WC,VC,hb=Jf(()=>{vr={};mc=Object.defineProperty,bT=Object.getOwnPropertyDescriptor,$T=Object.getOwnPropertyNames,xT=Object.prototype.hasOwnProperty,kT=(e=>typeof Et<"u"?Et:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof Et<"u"?Et:t)[r]}):e)(function(e){if(typeof Et<"u")return Et.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),ee=(e,t)=>()=>(e&&(t=e(e=0)),t),qs=(e,t)=>{for(var r in t)mc(e,r,{get:t[r],enumerable:!0})},ST=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of $T(t))!xT.call(e,a)&&a!==r&&mc(e,a,{get:()=>t[a],enumerable:!(i=bT(t,a))||i.enumerable});return e},Ko=e=>ST(mc({},"__esModule",{value:!0}),e),O_=ee(()=>{"use strict";Ts=new Map,jr=[],Oi=(e,t,r)=>{if(t&&typeof t.init=="function"&&typeof t.createInferenceSessionHandler=="function"){let i=Ts.get(e);if(i===void 0)Ts.set(e,{backend:t,priority:r});else{if(i.priority>r)return;if(i.priority===r&&i.backend!==t)throw new Error(`cannot register backend "${e}" using priority ${r}`)}if(r>=0){let a=jr.indexOf(e);a!==-1&&jr.splice(a,1);for(let s=0;s<jr.length;s++)if(Ts.get(jr[s]).priority<=r){jr.splice(s,0,e);return}jr.push(e)}return}throw new TypeError("not a valid backend")},Yf=async e=>{let t=Ts.get(e);if(!t)return"backend not found.";if(t.initialized)return t.backend;if(t.aborted)return t.error;{let r=!!t.initPromise;try{return r||(t.initPromise=t.backend.init(e)),await t.initPromise,t.initialized=!0,t.backend}catch(i){return r||(t.error=`${i}`,t.aborted=!0),t.error}finally{delete t.initPromise}}},A_=async e=>{let t=e.executionProviders||[],r=t.map(d=>typeof d=="string"?d:d.name),i=r.length===0?jr:r,a,s=[],o=new Set;for(let d of i){let p=await Yf(d);typeof p=="string"?s.push({name:d,err:p}):(a||(a=p),a===p&&o.add(d))}if(!a)throw new Error(`no available backend found. ERR: ${s.map(d=>`[${d.name}] ${d.err}`).join(", ")}`);for(let{name:d,err:p}of s)r.includes(d)&&console.warn(`removing requested execution provider "${d}" from session options because it is not available: ${p}`);let u=t.filter(d=>o.has(typeof d=="string"?d:d.name));return[a,new Proxy(e,{get:(d,p)=>p==="executionProviders"?u:Reflect.get(d,p)})]}}),TT=ee(()=>{"use strict";O_()}),CT=ee(()=>{"use strict";R_="1.21.0"}),B_=ee(()=>{"use strict";CT(),sp="warning",Vt={wasm:{},webgl:{},webgpu:{},versions:{common:R_},set logLevel(e){if(e!==void 0){if(typeof e!="string"||["verbose","info","warning","error","fatal"].indexOf(e)===-1)throw new Error(`Unsupported logging level: ${e}`);sp=e}},get logLevel(){return sp}},Object.defineProperty(Vt,"logLevel",{enumerable:!0})}),IT=ee(()=>{"use strict";B_(),Ke=Vt}),ET=ee(()=>{"use strict";N_=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let i=r.getContext("2d");if(i!=null){let a,s;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[3]):(a=e.dims[3],s=e.dims[2]);let o=t?.format!==void 0?t.format:"RGB",u=t?.norm,d,p;u===void 0||u.mean===void 0?d=[255,255,255,255]:typeof u.mean=="number"?d=[u.mean,u.mean,u.mean,u.mean]:(d=[u.mean[0],u.mean[1],u.mean[2],0],u.mean[3]!==void 0&&(d[3]=u.mean[3])),u===void 0||u.bias===void 0?p=[0,0,0,0]:typeof u.bias=="number"?p=[u.bias,u.bias,u.bias,u.bias]:(p=[u.bias[0],u.bias[1],u.bias[2],0],u.bias[3]!==void 0&&(p[3]=u.bias[3]));let m=s*a,f=0,g=m,v=m*2,_=-1;o==="RGBA"?(f=0,g=m,v=m*2,_=m*3):o==="RGB"?(f=0,g=m,v=m*2):o==="RBG"&&(f=0,v=m,g=m*2);for(let b=0;b<s;b++)for(let k=0;k<a;k++){let $=(e.data[f++]-p[0])*d[0],w=(e.data[g++]-p[1])*d[1],S=(e.data[v++]-p[2])*d[2],C=_===-1?255:(e.data[_++]-p[3])*d[3];i.fillStyle="rgba("+$+","+w+","+S+","+C+")",i.fillRect(k,b,1,1)}if("toDataURL"in r)return r.toDataURL();throw new Error("toDataURL is not supported")}else throw new Error("Can not access image data")},M_=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d"),i;if(r!=null){let a,s,o;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[1],o=e.dims[3]):(a=e.dims[3],s=e.dims[2],o=e.dims[1]);let u=t!==void 0&&t.format!==void 0?t.format:"RGB",d=t?.norm,p,m;d===void 0||d.mean===void 0?p=[255,255,255,255]:typeof d.mean=="number"?p=[d.mean,d.mean,d.mean,d.mean]:(p=[d.mean[0],d.mean[1],d.mean[2],255],d.mean[3]!==void 0&&(p[3]=d.mean[3])),d===void 0||d.bias===void 0?m=[0,0,0,0]:typeof d.bias=="number"?m=[d.bias,d.bias,d.bias,d.bias]:(m=[d.bias[0],d.bias[1],d.bias[2],0],d.bias[3]!==void 0&&(m[3]=d.bias[3]));let f=s*a;if(t!==void 0&&(t.format!==void 0&&o===4&&t.format!=="RGBA"||o===3&&t.format!=="RGB"&&t.format!=="BGR"))throw new Error("Tensor format doesn't match input tensor dims");let g=4,v=0,_=1,b=2,k=3,$=0,w=f,S=f*2,C=-1;u==="RGBA"?($=0,w=f,S=f*2,C=f*3):u==="RGB"?($=0,w=f,S=f*2):u==="RBG"&&($=0,S=f,w=f*2),i=r.createImageData(a,s);for(let I=0;I<s*a;v+=g,_+=g,b+=g,k+=g,I++)i.data[v]=(e.data[$++]-m[0])*p[0],i.data[_]=(e.data[w++]-m[1])*p[1],i.data[b]=(e.data[S++]-m[2])*p[2],i.data[k]=C===-1?255:(e.data[C++]-m[3])*p[3]}else throw new Error("Can not access image data");return i}}),zT=ee(()=>{"use strict";gc(),Oo=(e,t)=>{if(e===void 0)throw new Error("Image buffer must be defined");if(t.height===void 0||t.width===void 0)throw new Error("Image height and width must be defined");if(t.tensorLayout==="NHWC")throw new Error("NHWC Tensor layout is not supported yet");let{height:r,width:i}=t,a=t.norm??{mean:255,bias:0},s,o;typeof a.mean=="number"?s=[a.mean,a.mean,a.mean,a.mean]:s=[a.mean[0],a.mean[1],a.mean[2],a.mean[3]??255],typeof a.bias=="number"?o=[a.bias,a.bias,a.bias,a.bias]:o=[a.bias[0],a.bias[1],a.bias[2],a.bias[3]??0];let u=t.format!==void 0?t.format:"RGBA",d=t.tensorFormat!==void 0&&t.tensorFormat!==void 0?t.tensorFormat:"RGB",p=r*i,m=d==="RGBA"?new Float32Array(p*4):new Float32Array(p*3),f=4,g=0,v=1,_=2,b=3,k=0,$=p,w=p*2,S=-1;u==="RGB"&&(f=3,g=0,v=1,_=2,b=-1),d==="RGBA"?S=p*3:d==="RBG"?(k=0,w=p,$=p*2):d==="BGR"&&(w=0,$=p,k=p*2);for(let C=0;C<p;C++,g+=f,_+=f,v+=f,b+=f)m[k++]=(e[g]+o[0])/s[0],m[$++]=(e[v]+o[1])/s[1],m[w++]=(e[_]+o[2])/s[2],S!==-1&&b!==-1&&(m[S++]=(e[b]+o[3])/s[3]);return d==="RGBA"?new Nt("float32",m,[1,4,r,i]):new Nt("float32",m,[1,3,r,i])},D_=async(e,t)=>{let r=typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement,i=typeof ImageData<"u"&&e instanceof ImageData,a=typeof ImageBitmap<"u"&&e instanceof ImageBitmap,s=typeof e=="string",o,u=t??{},d=()=>{if(typeof document<"u")return document.createElement("canvas");if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(1,1);throw new Error("Canvas is not supported")},p=m=>typeof HTMLCanvasElement<"u"&&m instanceof HTMLCanvasElement||m instanceof OffscreenCanvas?m.getContext("2d"):null;if(r){let m=d();m.width=e.width,m.height=e.height;let f=p(m);if(f!=null){let g=e.height,v=e.width;if(t!==void 0&&t.resizedHeight!==void 0&&t.resizedWidth!==void 0&&(g=t.resizedHeight,v=t.resizedWidth),t!==void 0){if(u=t,t.tensorFormat!==void 0)throw new Error("Image input config format must be RGBA for HTMLImageElement");u.tensorFormat="RGBA",u.height=g,u.width=v}else u.tensorFormat="RGBA",u.height=g,u.width=v;f.drawImage(e,0,0),o=f.getImageData(0,0,v,g).data}else throw new Error("Can not access image data")}else if(i){let m,f;if(t!==void 0&&t.resizedWidth!==void 0&&t.resizedHeight!==void 0?(m=t.resizedHeight,f=t.resizedWidth):(m=e.height,f=e.width),t!==void 0&&(u=t),u.format="RGBA",u.height=m,u.width=f,t!==void 0){let g=d();g.width=f,g.height=m;let v=p(g);if(v!=null)v.putImageData(e,0,0),o=v.getImageData(0,0,f,m).data;else throw new Error("Can not access image data")}else o=e.data}else if(a){if(t===void 0)throw new Error("Please provide image config with format for Imagebitmap");let m=d();m.width=e.width,m.height=e.height;let f=p(m);if(f!=null){let g=e.height,v=e.width;return f.drawImage(e,0,0,v,g),o=f.getImageData(0,0,v,g).data,u.height=g,u.width=v,Oo(o,u)}else throw new Error("Can not access image data")}else{if(s)return new Promise((m,f)=>{let g=d(),v=p(g);if(!e||!v)return f();let _=new Image;_.crossOrigin="Anonymous",_.src=e,_.onload=()=>{g.width=_.width,g.height=_.height,v.drawImage(_,0,0,g.width,g.height);let b=v.getImageData(0,0,g.width,g.height);u.height=g.height,u.width=g.width,m(Oo(b.data,u))}});throw new Error("Input data provided is not supported - aborted tensor creation")}if(o!==void 0)return Oo(o,u);throw new Error("Input data provided is not supported - aborted tensor creation")},P_=(e,t)=>{let{width:r,height:i,download:a,dispose:s}=t,o=[1,i,r,4];return new Nt({location:"texture",type:"float32",texture:e,dims:o,download:a,dispose:s})},U_=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Nt({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:i,download:a,dispose:s})},W_=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Nt({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:i,download:a,dispose:s})},V_=(e,t,r)=>new Nt({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}),AT=ee(()=>{"use strict";Ei=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),Ns=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),op=!1,q_=()=>{if(!op){op=!0;let e=typeof BigInt64Array<"u"&&BigInt64Array.from,t=typeof BigUint64Array<"u"&&BigUint64Array.from,r=globalThis.Float16Array,i=typeof r<"u"&&r.from;e&&(Ei.set("int64",BigInt64Array),Ns.set(BigInt64Array,"int64")),t&&(Ei.set("uint64",BigUint64Array),Ns.set(BigUint64Array,"uint64")),i?(Ei.set("float16",r),Ns.set(r,"float16")):Ei.set("float16",Uint16Array)}}}),OT=ee(()=>{"use strict";gc(),j_=e=>{let t=1;for(let r=0;r<e.length;r++){let i=e[r];if(typeof i!="number"||!Number.isSafeInteger(i))throw new TypeError(`dims[${r}] must be an integer, got: ${i}`);if(i<0)throw new RangeError(`dims[${r}] must be a non-negative integer, got: ${i}`);t*=i}return t},L_=(e,t)=>{switch(e.location){case"cpu":return new Nt(e.type,e.data,t);case"cpu-pinned":return new Nt({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new Nt({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new Nt({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new Nt({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw new Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}),gc=ee(()=>{"use strict";ET(),zT(),AT(),OT(),Nt=class{constructor(e,t,r){q_();let i,a;if(typeof e=="object"&&"location"in e)switch(this.dataLocation=e.location,i=e.type,a=e.dims,e.location){case"cpu-pinned":{let o=Ei.get(i);if(!o)throw new TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);if(!(e.data instanceof o))throw new TypeError(`buffer should be of type ${o.name}`);this.cpuData=e.data;break}case"texture":{if(i!=="float32")throw new TypeError(`unsupported type "${i}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break}case"gpu-buffer":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break}case"ml-tensor":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint64"&&i!=="int8"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break}default:throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let o,u;if(typeof e=="string")if(i=e,u=r,e==="string"){if(!Array.isArray(t))throw new TypeError("A string tensor's data must be a string array.");o=t}else{let d=Ei.get(e);if(d===void 0)throw new TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t)){if(e==="float16"&&d===Uint16Array||e==="uint4"||e==="int4")throw new TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${d.name} as data.`);e==="uint64"||e==="int64"?o=d.from(t,BigInt):o=d.from(t)}else if(t instanceof d)o=t;else if(t instanceof Uint8ClampedArray)if(e==="uint8")o=Uint8Array.from(t);else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else if(e==="float16"&&t instanceof Uint16Array&&d!==Uint16Array)o=new globalThis.Float16Array(t.buffer,t.byteOffset,t.length);else throw new TypeError(`A ${i} tensor's data must be type of ${d}`)}else if(u=t,Array.isArray(e)){if(e.length===0)throw new TypeError("Tensor type cannot be inferred from an empty array.");let d=typeof e[0];if(d==="string")i="string",o=e;else if(d==="boolean")i="bool",o=Uint8Array.from(e);else throw new TypeError(`Invalid element type of data array: ${d}.`)}else if(e instanceof Uint8ClampedArray)i="uint8",o=Uint8Array.from(e);else{let d=Ns.get(e.constructor);if(d===void 0)throw new TypeError(`Unsupported type for tensor data: ${e.constructor}.`);i=d,o=e}if(u===void 0)u=[o.length];else if(!Array.isArray(u))throw new TypeError("A tensor's dims must be a number array");a=u,this.cpuData=o,this.dataLocation="cpu"}let s=j_(a);if(this.cpuData&&s!==this.cpuData.length&&!((i==="uint4"||i==="int4")&&Math.ceil(s/2)===this.cpuData.length))throw new Error(`Tensor's size(${s}) does not match data length(${this.cpuData.length}).`);this.type=i,this.dims=a,this.size=s}static async fromImage(e,t){return D_(e,t)}static fromTexture(e,t){return P_(e,t)}static fromGpuBuffer(e,t){return U_(e,t)}static fromMLTensor(e,t){return W_(e,t)}static fromPinnedBuffer(e,t,r){return V_(e,t,r)}toDataURL(e){return N_(this,e)}toImageData(e){return M_(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw new Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw new Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw new Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":{if(!this.downloader)throw new Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw new Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}}default:throw new Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw new Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if(this.dataLocation==="none")throw new Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw new Error("Cannot reshape a tensor that owns GPU resource.");return L_(this,e)}}}),G_=ee(()=>{"use strict";gc(),ar=Nt}),F_=ee(()=>{"use strict";B_(),Ws=(e,t)=>{(typeof Vt.trace>"u"?!Vt.wasm.trace:!Vt.trace)||console.timeStamp(`${e}::ORT::${t}`)},up=(e,t)=>{let r=new Error().stack?.split(/\r\n|\r|\n/g)||[],i=!1;for(let a=0;a<r.length;a++){if(i&&!r[a].includes("TRACE_FUNC")){let s=`FUNC_${e}::${r[a].trim().split(" ")[1]}`;t&&(s+=`::${t}`),Ws("CPU",s);return}r[a].includes("TRACE_FUNC")&&(i=!0)}},nr=e=>{(typeof Vt.trace>"u"?!Vt.wasm.trace:!Vt.trace)||up("BEGIN",e)},qt=e=>{(typeof Vt.trace>"u"?!Vt.wasm.trace:!Vt.trace)||up("END",e)}}),RT=ee(()=>{"use strict";O_(),G_(),F_(),H_=class K_{constructor(t){this.handler=t}async run(t,r,i){nr();let a={},s={};if(typeof t!="object"||t===null||t instanceof ar||Array.isArray(t))throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let o=!0;if(typeof r=="object"){if(r===null)throw new TypeError("Unexpected argument[1]: cannot be null.");if(r instanceof ar)throw new TypeError("'fetches' cannot be a Tensor");if(Array.isArray(r)){if(r.length===0)throw new TypeError("'fetches' cannot be an empty array.");o=!1;for(let p of r){if(typeof p!="string")throw new TypeError("'fetches' must be a string array or an object.");if(this.outputNames.indexOf(p)===-1)throw new RangeError(`'fetches' contains invalid output name: ${p}.`);a[p]=null}if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else{let p=!1,m=Object.getOwnPropertyNames(r);for(let f of this.outputNames)if(m.indexOf(f)!==-1){let g=r[f];(g===null||g instanceof ar)&&(p=!0,o=!1,a[f]=g)}if(p){if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else s=r}}else if(typeof r<"u")throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let p of this.inputNames)if(typeof t[p]>"u")throw new Error(`input '${p}' is missing in 'feeds'.`);if(o)for(let p of this.outputNames)a[p]=null;let u=await this.handler.run(t,a,s),d={};for(let p in u)if(Object.hasOwnProperty.call(u,p)){let m=u[p];m instanceof ar?d[p]=m:d[p]=new ar(m.type,m.data,m.dims)}return qt(),d}async release(){return this.handler.dispose()}static async create(t,r,i,a){nr();let s,o={};if(typeof t=="string"){if(s=t,typeof r=="object"&&r!==null)o=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(s=t,typeof r=="object"&&r!==null)o=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||typeof SharedArrayBuffer<"u"&&t instanceof SharedArrayBuffer){let m=t,f=0,g=t.byteLength;if(typeof r=="object"&&r!==null)o=r;else if(typeof r=="number"){if(f=r,!Number.isSafeInteger(f))throw new RangeError("'byteOffset' must be an integer.");if(f<0||f>=m.byteLength)throw new RangeError(`'byteOffset' is out of range [0, ${m.byteLength}).`);if(g=t.byteLength-f,typeof i=="number"){if(g=i,!Number.isSafeInteger(g))throw new RangeError("'byteLength' must be an integer.");if(g<=0||f+g>m.byteLength)throw new RangeError(`'byteLength' is out of range (0, ${m.byteLength-f}].`);if(typeof a=="object"&&a!==null)o=a;else if(typeof a<"u")throw new TypeError("'options' must be an object.")}else if(typeof i<"u")throw new TypeError("'byteLength' must be a number.")}else if(typeof r<"u")throw new TypeError("'options' must be an object.");s=new Uint8Array(m,f,g)}else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[u,d]=await A_(o),p=await u.createInferenceSessionHandler(s,d);return qt(),new K_(p)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}}}),BT=ee(()=>{"use strict";RT(),yc=H_}),NT=ee(()=>{"use strict"}),MT=ee(()=>{"use strict"}),DT=ee(()=>{"use strict"}),PT=ee(()=>{"use strict"}),Z_={};qs(Z_,{InferenceSession:()=>yc,TRACE:()=>Ws,TRACE_FUNC_BEGIN:()=>nr,TRACE_FUNC_END:()=>qt,Tensor:()=>ar,env:()=>Ke,registerBackend:()=>Oi});sr=ee(()=>{"use strict";TT(),IT(),BT(),G_(),NT(),MT(),F_(),DT(),PT()}),_c=ee(()=>{"use strict"}),Q_={};qs(Q_,{default:()=>X_});UT=ee(()=>{"use strict";eb(),Mi(),vc(),lp="ort-wasm-proxy-worker",dp=globalThis.self?.name===lp,dp&&(self.onmessage=e=>{let{type:t,in:r}=e.data;try{switch(t){case"init-wasm":wc(r.wasm).then(()=>{Pc(r).then(()=>{postMessage({type:t})},i=>{postMessage({type:t,err:i})})},i=>{postMessage({type:t,err:i})});break;case"init-ep":{let{epName:i,env:a}=r;Uc(a,i).then(()=>{postMessage({type:t})},s=>{postMessage({type:t,err:s})});break}case"copy-from":{let{buffer:i}=r,a=eu(i);postMessage({type:t,out:a});break}case"create":{let{model:i,options:a}=r;Wc(i,a).then(s=>{postMessage({type:t,out:s})},s=>{postMessage({type:t,err:s})});break}case"release":Vc(r),postMessage({type:t});break;case"run":{let{sessionId:i,inputIndices:a,inputs:s,outputIndices:o,options:u}=r;qc(i,a,s,o,new Array(o.length).fill(null),u).then(d=>{d.some(p=>p[3]!=="cpu")?postMessage({type:t,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:t,out:d},Lc([...s,...d]))},d=>{postMessage({type:t,err:d})});break}case"end-profiling":jc(r),postMessage({type:t});break;default:}}catch(i){postMessage({type:t,err:i})}}),X_=dp?null:e=>new Worker(e??Bt,{type:"module",name:lp})}),J_={};qs(J_,{default:()=>Y_});WT=ee(()=>{"use strict";cp=(pp=vr.url,async function(e={}){var t,r,i=e,a=new Promise((n,l)=>{t=n,r=l}),s=typeof window=="object",o=typeof WorkerGlobalScope<"u",u=o&&self.name?.startsWith("em-pthread");i.mountExternalData=(n,l)=>{n.startsWith("./")&&(n=n.substring(2)),(i.Bd||(i.Bd=new Map)).set(n,l)},i.unmountExternalData=()=>{delete i.Bd};var d=globalThis.SharedArrayBuffer??new WebAssembly.Memory({initial:0,maximum:0,shared:!0}).buffer.constructor;let p=()=>{let n=(c,h,y)=>(...x)=>{let T=it,A=h?.();x=c(...x);let O=h?.();return A!==O&&(c=O,y(A),h=y=null),it!=T?new Promise((P,j)=>{yi={resolve:P,reject:j}}):x},l=c=>async(...h)=>{try{if(i.Cd)throw Error("Session already started");let y=i.Cd={be:h[0],errors:[]},x=await c(...h);if(i.Cd!==y)throw Error("Session mismatch");i.Dd?.flush();let T=y.errors;if(0<T.length){let A=await Promise.all(T);if(A=A.filter(O=>O),0<A.length)throw Error(A.join(`
`))}return x}finally{i.Cd=null}};i._OrtCreateSession=n(i._OrtCreateSession,()=>i._OrtCreateSession,c=>i._OrtCreateSession=c),i._OrtRun=l(n(i._OrtRun,()=>i._OrtRun,c=>i._OrtRun=c)),i._OrtRunWithBinding=l(n(i._OrtRunWithBinding,()=>i._OrtRunWithBinding,c=>i._OrtRunWithBinding=c)),i._OrtBindInput=n(i._OrtBindInput,()=>i._OrtBindInput,c=>i._OrtBindInput=c),p=void 0};i.jsepInit=(n,l)=>{if(p?.(),n==="webgpu"){[i.Dd,i.Rd,i.Vd,i.Hd,i.Ud,i.hc,i.Wd,i.Zd,i.Sd,i.Td,i.Xd]=l;let c=i.Dd;i.jsepRegisterBuffer=(h,y,x,T)=>c.registerBuffer(h,y,x,T),i.jsepGetBuffer=h=>c.getBuffer(h),i.jsepCreateDownloader=(h,y,x)=>c.createDownloader(h,y,x),i.jsepOnCreateSession=h=>{c.onCreateSession(h)},i.jsepOnReleaseSession=h=>{c.onReleaseSession(h)},i.jsepOnRunStart=h=>c.onRunStart(h),i.$d=(h,y)=>{c.upload(h,y)}}else if(n==="webnn"){[i.Dd,i.Yd,i.Id,i.jsepEnsureTensor,i.Jd,i.jsepDownloadTensor]=l,i.jsepReleaseTensorId=i.Id,i.jsepUploadTensor=i.Jd;let c=i.Dd;i.jsepOnRunStart=h=>c.onRunStart(h),i.jsepOnRunEnd=c.onRunEnd.bind(c),i.jsepRegisterMLContext=(h,y)=>{c.registerMLContext(h,y)},i.jsepOnReleaseSession=h=>{c.onReleaseSession(h)},i.jsepCreateMLTensorDownloader=(h,y)=>c.createMLTensorDownloader(h,y),i.jsepRegisterMLTensor=(h,y,x,T)=>c.registerMLTensor(h,y,x,T),i.jsepCreateMLContext=h=>c.createMLContext(h),i.jsepRegisterMLConstant=(h,y,x,T,A)=>c.registerMLConstant(h,y,x,T,A,i.Bd),i.jsepRegisterGraphInput=c.registerGraphInput.bind(c),i.jsepIsGraphInput=c.isGraphInput.bind(c),i.jsepCreateTemporaryTensor=c.createTemporaryTensor.bind(c)}};var m,f,g=Object.assign({},i),v=(n,l)=>{throw l},_="";(s||o)&&(o?_=self.location.href:typeof document<"u"&&document.currentScript&&(_=document.currentScript.src),pp&&(_=pp),_=_.startsWith("blob:")?"":_.slice(0,_.replace(/[?#].*/,"").lastIndexOf("/")+1),o&&(f=n=>{var l=new XMLHttpRequest;return l.open("GET",n,!1),l.responseType="arraybuffer",l.send(null),new Uint8Array(l.response)}),m=async n=>{if(le(n))return new Promise((c,h)=>{var y=new XMLHttpRequest;y.open("GET",n,!0),y.responseType="arraybuffer",y.onload=()=>{y.status==200||y.status==0&&y.response?c(y.response):h(y.status)},y.onerror=h,y.send(null)});var l=await fetch(n,{credentials:"same-origin"});if(l.ok)return l.arrayBuffer();throw Error(l.status+" : "+l.url)});var b=console.log.bind(console),k=console.error.bind(console),$=b,w=k;Object.assign(i,g),g=null;var S,C,I,z,E,B,U,V,W,J,D,se,ue,F=i.wasmBinary,oe=!1,le=n=>n.startsWith("file://");function H(){return S.buffer!=z.buffer&&Ge(),z}function de(){return S.buffer!=z.buffer&&Ge(),E}function M(){return S.buffer!=z.buffer&&Ge(),B}function q(){return S.buffer!=z.buffer&&Ge(),U}function R(){return S.buffer!=z.buffer&&Ge(),V}function X(){return S.buffer!=z.buffer&&Ge(),W}function Ie(){return S.buffer!=z.buffer&&Ge(),J}function Fe(){return S.buffer!=z.buffer&&Ge(),ue}if(u){let n=function(l){try{var c=l.data,h=c.yd;if(h==="load"){let y=[];self.onmessage=x=>y.push(x),self.startWorker=()=>{postMessage({yd:"loaded"});for(let x of y)n(x);self.onmessage=n};for(let x of c.Od)i[x]&&!i[x].proxy||(i[x]=(...T)=>{postMessage({yd:"callHandler",Nd:x,args:T})},x=="print"&&($=i[x]),x=="printErr"&&(w=i[x]));S=c.he,Ge(),Ae(c.ie)}else if(h==="run"){ju(c.xd),bi(c.xd,0,0,1,0,0),Ta(),mi(c.xd),nt||(bn(),nt=!0);try{Lu(c.de,c.Fd)}catch(y){if(y!="unwind")throw y}}else c.target!=="setimmediate"&&(h==="checkMailbox"?nt&&Tr():h&&(w(`worker: received unknown command ${h}`),w(c)))}catch(y){throw $n(),y}};var De=n,Ae,nt=!1;w=function(...l){l=l.join(" "),console.error(l)},self.alert=function(...l){postMessage({yd:"alert",text:l.join(" "),fe:Br()})},self.onunhandledrejection=l=>{throw l.reason||l},self.onmessage=n}function Ge(){var n=S.buffer;i.HEAP8=z=new Int8Array(n),i.HEAP16=B=new Int16Array(n),i.HEAPU8=E=new Uint8Array(n),i.HEAPU16=U=new Uint16Array(n),i.HEAP32=V=new Int32Array(n),i.HEAPU32=W=new Uint32Array(n),i.HEAPF32=J=new Float32Array(n),i.HEAPF64=ue=new Float64Array(n),i.HEAP64=D=new BigInt64Array(n),i.HEAPU64=se=new BigUint64Array(n)}function kr(){u?startWorker(i):N.Bb()}u||(S=new WebAssembly.Memory({initial:256,maximum:65536,shared:!0}),Ge());var ti,Ht=0,Kt=null;function va(){if(--Ht==0&&Kt){var n=Kt;Kt=null,n()}}function st(n){throw w(n="Aborted("+n+")"),oe=!0,n=new WebAssembly.RuntimeError(n+". Build with -sASSERTIONS for more info."),r(n),n}function wa(){return{a:{Ta:qu,Va:Vu,W:Gu,la:Fu,b:Ku,u:Zu,R:Qu,Za:Xu,d:Ju,pb:za,g:Hu,T:Ra,Ga:Ba,lb:Ma,nb:Da,Ha:Pa,Ea:Ua,wb:Wa,Da:Va,pa:qa,mb:ja,jb:La,Fa:Ga,kb:Fa,Ma:Yu,za:tl,eb:rl,cb:al,ya:sl,V:ol,N:ul,db:ll,ma:gl,fb:yl,zb:_l,hb:vl,qb:wl,ab:bl,Aa:$l,yb:mi,Ja:xl,S:kl,Wa:Sl,$:Il,G:El,E:Al,m:ci,H:Ol,B:Nl,X:Ml,J:Dl,v:Pl,O:Ul,D:Wl,t:Vl,A:ql,z:jl,w:Ll,r:Gl,tb:Fl,ub:Hl,vb:Kl,rb:on,sb:un,bb:ln,Oa:Ql,La:Yl,y:ed,ja:td,Ba:rd,Ka:Xl,qa:id,Ia:ad,ib:nd,U:Zl,fa:sd,Sa:od,gb:ud,Qa:ld,Pa:dd,Ab:hn,Ca:fn,ob:si,aa:mn,oa:gn,xb:yn,na:_n,$a:Dd,ia:Qd,sa:tp,ga:Nd,da:jd,ua:Yd,p:Rd,e:yd,c:md,ea:Vd,f:_d,n:wd,k:Ed,Y:$d,ka:zd,j:Bd,wa:Wd,Ra:ap,ca:Kd,Ua:ip,P:qd,K:kd,_:Hd,Q:Md,Z:Xd,x:xd,l:gd,va:Fd,i:fd,h:bd,ra:rp,ta:ep,o:vd,q:Sd,s:Cd,I:Id,C:Od,L:Ad,xa:Ud,_a:Pd,F:Zd,Ya:Ld,ba:Jd,M:Td,Xa:Gd,ha:cd,a:S,Na:ni}}}var ri={1319426:()=>typeof wasmOffsetConverter<"u",1319483:(n,l,c,h,y)=>{if(i===void 0||!i.Bd)return 1;if((n=Oe(Number(n>>>0))).startsWith("./")&&(n=n.substring(2)),!(n=i.Bd.get(n)))return 2;if(l=Number(l>>>0),c=Number(c>>>0),h=Number(h>>>0),l+c>n.byteLength)return 3;try{let x=n.subarray(l,l+c);switch(y){case 0:de().set(x,h>>>0);break;case 1:i.$d(h,x);break;default:return 4}return 0}catch{return 4}},1320198:(n,l,c)=>{i.Jd(n,de().subarray(l>>>0,l+c>>>0))},1320261:()=>i.Yd(),1320302:n=>{i.Id(n)},1320338:()=>{i.Sd()},1320369:()=>{i.Td()},1320398:()=>{i.Xd()},1320423:n=>i.Rd(n),1320456:n=>i.Vd(n),1320488:(n,l,c)=>{i.Hd(Number(n),Number(l),Number(c),!0)},1320551:(n,l,c)=>{i.Hd(Number(n),Number(l),Number(c))},1320608:n=>{i.hc("Abs",n,void 0)},1320659:n=>{i.hc("Neg",n,void 0)},1320710:n=>{i.hc("Floor",n,void 0)},1320763:n=>{i.hc("Ceil",n,void 0)},1320815:n=>{i.hc("Reciprocal",n,void 0)},1320873:n=>{i.hc("Sqrt",n,void 0)},1320925:n=>{i.hc("Exp",n,void 0)},1320976:n=>{i.hc("Erf",n,void 0)},1321027:n=>{i.hc("Sigmoid",n,void 0)},1321082:(n,l,c)=>{i.hc("HardSigmoid",n,{alpha:l,beta:c})},1321161:n=>{i.hc("Log",n,void 0)},1321212:n=>{i.hc("Sin",n,void 0)},1321263:n=>{i.hc("Cos",n,void 0)},1321314:n=>{i.hc("Tan",n,void 0)},1321365:n=>{i.hc("Asin",n,void 0)},1321417:n=>{i.hc("Acos",n,void 0)},1321469:n=>{i.hc("Atan",n,void 0)},1321521:n=>{i.hc("Sinh",n,void 0)},1321573:n=>{i.hc("Cosh",n,void 0)},1321625:n=>{i.hc("Asinh",n,void 0)},1321678:n=>{i.hc("Acosh",n,void 0)},1321731:n=>{i.hc("Atanh",n,void 0)},1321784:n=>{i.hc("Tanh",n,void 0)},1321836:n=>{i.hc("Not",n,void 0)},1321887:(n,l,c)=>{i.hc("Clip",n,{min:l,max:c})},1321956:n=>{i.hc("Clip",n,void 0)},1322008:(n,l)=>{i.hc("Elu",n,{alpha:l})},1322066:n=>{i.hc("Gelu",n,void 0)},1322118:n=>{i.hc("Relu",n,void 0)},1322170:(n,l)=>{i.hc("LeakyRelu",n,{alpha:l})},1322234:(n,l)=>{i.hc("ThresholdedRelu",n,{alpha:l})},1322304:(n,l)=>{i.hc("Cast",n,{to:l})},1322362:n=>{i.hc("Add",n,void 0)},1322413:n=>{i.hc("Sub",n,void 0)},1322464:n=>{i.hc("Mul",n,void 0)},1322515:n=>{i.hc("Div",n,void 0)},1322566:n=>{i.hc("Pow",n,void 0)},1322617:n=>{i.hc("Equal",n,void 0)},1322670:n=>{i.hc("Greater",n,void 0)},1322725:n=>{i.hc("GreaterOrEqual",n,void 0)},1322787:n=>{i.hc("Less",n,void 0)},1322839:n=>{i.hc("LessOrEqual",n,void 0)},1322898:(n,l,c,h,y)=>{i.hc("ReduceMean",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323073:(n,l,c,h,y)=>{i.hc("ReduceMax",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323247:(n,l,c,h,y)=>{i.hc("ReduceMin",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323421:(n,l,c,h,y)=>{i.hc("ReduceProd",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323596:(n,l,c,h,y)=>{i.hc("ReduceSum",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323770:(n,l,c,h,y)=>{i.hc("ReduceL1",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323943:(n,l,c,h,y)=>{i.hc("ReduceL2",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324116:(n,l,c,h,y)=>{i.hc("ReduceLogSum",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324293:(n,l,c,h,y)=>{i.hc("ReduceSumSquare",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324473:(n,l,c,h,y)=>{i.hc("ReduceLogSumExp",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324653:n=>{i.hc("Where",n,void 0)},1324706:(n,l,c)=>{i.hc("Transpose",n,{perm:l?Array.from(R().subarray(Number(l)>>>0,Number(c)>>>0)):[]})},1324830:(n,l,c,h)=>{i.hc("DepthToSpace",n,{blocksize:l,mode:Oe(c),format:h?"NHWC":"NCHW"})},1324963:(n,l,c,h)=>{i.hc("DepthToSpace",n,{blocksize:l,mode:Oe(c),format:h?"NHWC":"NCHW"})},1325096:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe)=>{i.hc("ConvTranspose",n,{format:O?"NHWC":"NCHW",autoPad:l,dilations:[c],group:h,kernelShape:[y],pads:[x,T],strides:[A],wIsConst:()=>!!H()[P>>>0],outputPadding:j?Array.from(R().subarray(Number(j)>>>0,Number(Q)>>>0)):[],outputShape:ae?Array.from(R().subarray(Number(ae)>>>0,Number(we)>>>0)):[],activation:Oe(Xe)})},1325529:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("ConvTranspose",n,{format:A?"NHWC":"NCHW",autoPad:l,dilations:Array.from(R().subarray(Number(c)>>>0,2+(Number(c)>>>0)>>>0)),group:h,kernelShape:Array.from(R().subarray(Number(y)>>>0,2+(Number(y)>>>0)>>>0)),pads:Array.from(R().subarray(Number(x)>>>0,4+(Number(x)>>>0)>>>0)),strides:Array.from(R().subarray(Number(T)>>>0,2+(Number(T)>>>0)>>>0)),wIsConst:()=>!!H()[O>>>0],outputPadding:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],outputShape:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[],activation:Oe(we)})},1326190:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe)=>{i.hc("ConvTranspose",n,{format:O?"NHWC":"NCHW",autoPad:l,dilations:[c],group:h,kernelShape:[y],pads:[x,T],strides:[A],wIsConst:()=>!!H()[P>>>0],outputPadding:j?Array.from(R().subarray(Number(j)>>>0,Number(Q)>>>0)):[],outputShape:ae?Array.from(R().subarray(Number(ae)>>>0,Number(we)>>>0)):[],activation:Oe(Xe)})},1326623:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("ConvTranspose",n,{format:A?"NHWC":"NCHW",autoPad:l,dilations:Array.from(R().subarray(Number(c)>>>0,2+(Number(c)>>>0)>>>0)),group:h,kernelShape:Array.from(R().subarray(Number(y)>>>0,2+(Number(y)>>>0)>>>0)),pads:Array.from(R().subarray(Number(x)>>>0,4+(Number(x)>>>0)>>>0)),strides:Array.from(R().subarray(Number(T)>>>0,2+(Number(T)>>>0)>>>0)),wIsConst:()=>!!H()[O>>>0],outputPadding:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],outputShape:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[],activation:Oe(we)})},1327284:(n,l)=>{i.hc("GlobalAveragePool",n,{format:l?"NHWC":"NCHW"})},1327375:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("AveragePool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1327854:(n,l)=>{i.hc("GlobalAveragePool",n,{format:l?"NHWC":"NCHW"})},1327945:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("AveragePool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1328424:(n,l)=>{i.hc("GlobalMaxPool",n,{format:l?"NHWC":"NCHW"})},1328511:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("MaxPool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1328986:(n,l)=>{i.hc("GlobalMaxPool",n,{format:l?"NHWC":"NCHW"})},1329073:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("MaxPool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1329548:(n,l,c,h,y)=>{i.hc("Gemm",n,{alpha:l,beta:c,transA:h,transB:y})},1329652:n=>{i.hc("MatMul",n,void 0)},1329706:(n,l,c,h)=>{i.hc("ArgMax",n,{keepDims:!!l,selectLastIndex:!!c,axis:h})},1329814:(n,l,c,h)=>{i.hc("ArgMin",n,{keepDims:!!l,selectLastIndex:!!c,axis:h})},1329922:(n,l)=>{i.hc("Softmax",n,{axis:l})},1329985:(n,l)=>{i.hc("Concat",n,{axis:l})},1330045:(n,l,c,h,y)=>{i.hc("Split",n,{axis:l,numOutputs:c,splitSizes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1330201:n=>{i.hc("Expand",n,void 0)},1330255:(n,l)=>{i.hc("Gather",n,{axis:Number(l)})},1330326:(n,l)=>{i.hc("GatherElements",n,{axis:Number(l)})},1330405:(n,l)=>{i.hc("GatherND",n,{batch_dims:Number(l)})},1330484:(n,l,c,h,y,x,T,A,O,P,j)=>{i.hc("Resize",n,{antialias:l,axes:c?Array.from(R().subarray(Number(c)>>>0,Number(h)>>>0)):[],coordinateTransformMode:Oe(y),cubicCoeffA:x,excludeOutside:T,extrapolationValue:A,keepAspectRatioPolicy:Oe(O),mode:Oe(P),nearestMode:Oe(j)})},1330846:(n,l,c,h,y,x,T)=>{i.hc("Slice",n,{starts:l?Array.from(R().subarray(Number(l)>>>0,Number(c)>>>0)):[],ends:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[],axes:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[]})},1331110:n=>{i.hc("Tile",n,void 0)},1331162:(n,l,c)=>{i.hc("InstanceNormalization",n,{epsilon:l,format:c?"NHWC":"NCHW"})},1331276:(n,l,c)=>{i.hc("InstanceNormalization",n,{epsilon:l,format:c?"NHWC":"NCHW"})},1331390:n=>{i.hc("Range",n,void 0)},1331443:(n,l)=>{i.hc("Einsum",n,{equation:Oe(l)})},1331524:(n,l,c,h,y)=>{i.hc("Pad",n,{mode:l,value:c,pads:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1331667:(n,l,c,h,y,x)=>{i.hc("BatchNormalization",n,{epsilon:l,momentum:c,spatial:!!y,trainingMode:!!h,format:x?"NHWC":"NCHW"})},1331836:(n,l,c,h,y,x)=>{i.hc("BatchNormalization",n,{epsilon:l,momentum:c,spatial:!!y,trainingMode:!!h,format:x?"NHWC":"NCHW"})},1332005:(n,l,c)=>{i.hc("CumSum",n,{exclusive:Number(l),reverse:Number(c)})},1332102:(n,l,c)=>{i.hc("DequantizeLinear",n,{axis:l,blockSize:c})},1332192:(n,l,c,h,y)=>{i.hc("GridSample",n,{align_corners:l,mode:Oe(c),padding_mode:Oe(h),format:y?"NHWC":"NCHW"})},1332362:(n,l,c,h,y)=>{i.hc("GridSample",n,{align_corners:l,mode:Oe(c),padding_mode:Oe(h),format:y?"NHWC":"NCHW"})},1332532:(n,l)=>{i.hc("ScatterND",n,{reduction:Oe(l)})},1332617:(n,l,c,h,y,x,T,A,O)=>{i.hc("Attention",n,{numHeads:l,isUnidirectional:c,maskFilterValue:h,scale:y,doRotary:x,qkvHiddenSizes:T?Array.from(R().subarray(Number(A)>>>0,Number(A)+T>>>0)):[],pastPresentShareBuffer:!!O})},1332889:n=>{i.hc("BiasAdd",n,void 0)},1332944:n=>{i.hc("BiasSplitGelu",n,void 0)},1333005:n=>{i.hc("FastGelu",n,void 0)},1333061:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe,Jt)=>{i.hc("Conv",n,{format:Q?"NHWC":"NCHW",auto_pad:l,dilations:c?Array.from(R().subarray(Number(c)>>>0,Number(h)>>>0)):[],group:y,kernel_shape:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],pads:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],strides:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],w_is_const:()=>!!H()[Number(ae)>>>0],activation:Oe(we),activation_params:Xe?Array.from(Ie().subarray(Number(Xe)>>>0,Number(Jt)>>>0)):[]})},1333645:n=>{i.hc("Gelu",n,void 0)},1333697:(n,l,c,h,y,x,T,A,O)=>{i.hc("GroupQueryAttention",n,{numHeads:l,kvNumHeads:c,scale:h,softcap:y,doRotary:x,rotaryInterleaved:T,smoothSoftmax:A,localWindowSize:O})},1333914:(n,l,c,h)=>{i.hc("LayerNormalization",n,{axis:l,epsilon:c,simplified:!!h})},1334025:(n,l,c,h)=>{i.hc("LayerNormalization",n,{axis:l,epsilon:c,simplified:!!h})},1334136:(n,l,c,h,y,x)=>{i.hc("MatMulNBits",n,{k:l,n:c,accuracyLevel:h,bits:y,blockSize:x})},1334263:(n,l,c,h,y,x)=>{i.hc("MultiHeadAttention",n,{numHeads:l,isUnidirectional:c,maskFilterValue:h,scale:y,doRotary:x})},1334422:(n,l)=>{i.hc("QuickGelu",n,{alpha:l})},1334486:(n,l,c,h,y)=>{i.hc("RotaryEmbedding",n,{interleaved:!!l,numHeads:c,rotaryEmbeddingDim:h,scale:y})},1334625:(n,l,c)=>{i.hc("SkipLayerNormalization",n,{epsilon:l,simplified:!!c})},1334727:(n,l,c)=>{i.hc("SkipLayerNormalization",n,{epsilon:l,simplified:!!c})},1334829:(n,l,c,h)=>{i.hc("GatherBlockQuantized",n,{gatherAxis:l,quantizeAxis:c,blockSize:h})},1334950:n=>{i.Wd(n)},1334984:(n,l)=>i.Zd(Number(n),Number(l),i.Cd.be,i.Cd.errors)};function Vu(n,l,c){return en(async()=>{await i.Ud(Number(n),Number(l),Number(c))})}function qu(){return typeof wasmOffsetConverter<"u"}class ii{constructor(l){Ao(this,"name","ExitStatus");this.message=`Program terminated with exit(${l})`,this.status=l}}var ba=n=>{n.terminate(),n.onmessage=()=>{}},ai=[],$a=n=>{gt.length==0&&(Ia(),Ca(gt[0]));var l=gt.pop();if(!l)return 6;Zt.push(l),St[n.xd]=l,l.xd=n.xd;var c={yd:"run",de:n.ce,Fd:n.Fd,xd:n.xd};return l.postMessage(c,n.Ld),0},mt=0,xe=(n,l,...c)=>{for(var h=2*c.length,y=re(),x=xi(8*h),T=x>>>3,A=0;A<c.length;A++){var O=c[A];typeof O=="bigint"?(D[T+2*A]=1n,D[T+2*A+1]=O):(D[T+2*A]=0n,Fe()[T+2*A+1>>>0]=O)}return n=xn(n,0,h,x,l),Y(y),n};function ni(n){if(u)return xe(0,1,n);if(I=n,!(0<mt)){for(var l of Zt)ba(l);for(l of gt)ba(l);gt=[],Zt=[],St={},oe=!0}v(0,new ii(n))}function xa(n){if(u)return xe(1,0,n);si(n)}var si=n=>{if(I=n,u)throw xa(n),"unwind";ni(n)},gt=[],Zt=[],ka=[],St={},Sa=n=>{var l=n.xd;delete St[l],gt.push(n),Zt.splice(Zt.indexOf(n),1),n.xd=0,kn(l)};function Ta(){ka.forEach(n=>n())}var Ca=n=>new Promise(l=>{n.onmessage=y=>{var x=(y=y.data).yd;if(y.Ed&&y.Ed!=Br()){var T=St[y.Ed];T?T.postMessage(y,y.Ld):w(`Internal error! Worker sent a message "${x}" to target pthread ${y.Ed}, but that thread no longer exists!`)}else x==="checkMailbox"?Tr():x==="spawnThread"?$a(y):x==="cleanupThread"?Sa(St[y.ee]):x==="loaded"?(n.loaded=!0,l(n)):x==="alert"?alert(`Thread ${y.fe}: ${y.text}`):y.target==="setimmediate"?n.postMessage(y):x==="callHandler"?i[y.Nd](...y.args):x&&w(`worker sent an unknown command ${x}`)},n.onerror=y=>{throw w(`worker sent an error! ${y.filename}:${y.lineno}: ${y.message}`),y};var c,h=[];for(c of[])i.propertyIsEnumerable(c)&&h.push(c);n.postMessage({yd:"load",Od:h,he:S,ie:C})});function Ia(){var n=new Worker(vr.url.startsWith("file:")?new URL("ort.webgpu.bundle.min.mjs",vr.url):new URL(vr.url),{type:"module",workerData:"em-pthread",name:"em-pthread"});gt.push(n)}var ju=n=>{Ge();var l=X()[n+52>>>2>>>0];n=X()[n+56>>>2>>>0],Cn(l,l-n),Y(l)},Lu=(n,l)=>{mt=0,n=ki(n,l),0<mt?I=n:$i(n)},Sr=[];function Gu(n){var l=new oi(n>>>=0);if(H()[l.wd+12>>>0]==0){var c=1;H()[l.wd+12>>>0]=c}return c=0,H()[l.wd+13>>>0]=c,Sr.push(l),En(n),An(n)}var At=0,Fu=()=>{ie(0,0);var n=Sr.pop();In(n.Gd),At=0};class oi{constructor(l){this.Gd=l,this.wd=l-24}}function Hu(n){throw At||(At=n>>>0),At}var ui=n=>{var l=At;if(!l)return Xt(0),0;var c=new oi(l);X()[c.wd+16>>>2>>>0]=l;var h=X()[c.wd+4>>>2>>>0];if(!h)return Xt(0),l;for(var y of n){if(y===0||y===h)break;if(zn(y,h,c.wd+16))return Xt(y),l}return Xt(h),l};function Ku(){return ui([])}function Zu(n){return ui([n>>>0])}function Qu(n,l){return ui([n>>>0,l>>>0])}var Xu=()=>{var n=Sr.pop();n||st("no exception to throw");var l=n.Gd;if(H()[n.wd+13>>>0]==0){Sr.push(n);var c=1;H()[n.wd+13>>>0]=c,c=0,H()[n.wd+12>>>0]=c}throw At=l};function Ju(n,l,c){var h=new oi(n>>>=0);throw l>>>=0,c>>>=0,X()[h.wd+16>>>2>>>0]=0,X()[h.wd+4>>>2>>>0]=l,X()[h.wd+8>>>2>>>0]=c,At=n}function Ea(n,l,c,h){return u?xe(2,1,n,l,c,h):za(n,l,c,h)}function za(n,l,c,h){if(n>>>=0,c>>>=0,h>>>=0,d===void 0)return 6;var y=[];return u&&y.length===0?Ea(n,l>>>=0,c,h):(n={ce:c,xd:n,Fd:h,Ld:y},u?(n.yd="spawnThread",postMessage(n,y),0):$a(n))}var Aa=typeof TextDecoder<"u"?new TextDecoder:void 0,Oa=(n,l=0,c=NaN)=>{var h=(l>>>=0)+c;for(c=l;n[c]&&!(c>=h);)++c;if(16<c-l&&n.buffer&&Aa)return Aa.decode(n.buffer instanceof ArrayBuffer?n.subarray(l,c):n.slice(l,c));for(h="";l<c;){var y=n[l++];if(128&y){var x=63&n[l++];if((224&y)==192)h+=String.fromCharCode((31&y)<<6|x);else{var T=63&n[l++];65536>(y=(240&y)==224?(15&y)<<12|x<<6|T:(7&y)<<18|x<<12|T<<6|63&n[l++])?h+=String.fromCharCode(y):(y-=65536,h+=String.fromCharCode(55296|y>>10,56320|1023&y))}}else h+=String.fromCharCode(y)}return h},Oe=(n,l)=>(n>>>=0)?Oa(de(),n,l):"";function Ra(n,l,c){return u?xe(3,1,n,l,c):0}function Ba(n,l){if(u)return xe(4,1,n,l)}var Na=n=>{for(var l=0,c=0;c<n.length;++c){var h=n.charCodeAt(c);127>=h?l++:2047>=h?l+=2:55296<=h&&57343>=h?(l+=4,++c):l+=3}return l},Ot=(n,l,c)=>{var h=de();if(l>>>=0,0<c){var y=l;c=l+c-1;for(var x=0;x<n.length;++x){var T=n.charCodeAt(x);if(55296<=T&&57343>=T&&(T=65536+((1023&T)<<10)|1023&n.charCodeAt(++x)),127>=T){if(l>=c)break;h[l++>>>0]=T}else{if(2047>=T){if(l+1>=c)break;h[l++>>>0]=192|T>>6}else{if(65535>=T){if(l+2>=c)break;h[l++>>>0]=224|T>>12}else{if(l+3>=c)break;h[l++>>>0]=240|T>>18,h[l++>>>0]=128|T>>12&63}h[l++>>>0]=128|T>>6&63}h[l++>>>0]=128|63&T}}h[l>>>0]=0,n=l-y}else n=0;return n};function Ma(n,l){if(u)return xe(5,1,n,l)}function Da(n,l,c){if(u)return xe(6,1,n,l,c)}function Pa(n,l,c){return u?xe(7,1,n,l,c):0}function Ua(n,l){if(u)return xe(8,1,n,l)}function Wa(n,l,c){if(u)return xe(9,1,n,l,c)}function Va(n,l,c,h){if(u)return xe(10,1,n,l,c,h)}function qa(n,l,c,h){if(u)return xe(11,1,n,l,c,h)}function ja(n,l,c,h){if(u)return xe(12,1,n,l,c,h)}function La(n){if(u)return xe(13,1,n)}function Ga(n,l){if(u)return xe(14,1,n,l)}function Fa(n,l,c){if(u)return xe(15,1,n,l,c)}var Ha,yt,Yu=()=>st(""),rt=n=>{for(var l="";de()[n>>>0];)l+=Ha[de()[n++>>>0]];return l},li={},di={},el={};function ot(n,l,c={}){return function(h,y,x={}){var T=y.name;if(!h)throw new yt(`type "${T}" must have a positive integer typeid pointer`);if(di.hasOwnProperty(h)){if(x.Pd)return;throw new yt(`Cannot register type '${T}' twice`)}di[h]=y,delete el[h],li.hasOwnProperty(h)&&(y=li[h],delete li[h],y.forEach(A=>A()))}(n,l,c)}var Ka=(n,l,c)=>{switch(l){case 1:return c?h=>H()[h>>>0]:h=>de()[h>>>0];case 2:return c?h=>M()[h>>>1>>>0]:h=>q()[h>>>1>>>0];case 4:return c?h=>R()[h>>>2>>>0]:h=>X()[h>>>2>>>0];case 8:return c?h=>D[h>>>3]:h=>se[h>>>3];default:throw new TypeError(`invalid integer width (${l}): ${n}`)}};function tl(n,l,c){c>>>=0,ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:h=>h,toWireType:function(h,y){if(typeof y!="bigint"&&typeof y!="number")throw y=y===null?"null":(h=typeof y)=="object"||h==="array"||h==="function"?y.toString():""+y,new TypeError(`Cannot convert "${y}" to ${this.name}`);return typeof y=="number"&&(y=BigInt(y)),y},zd:_t,readValueFromPointer:Ka(l,c,l.indexOf("u")==-1),Ad:null})}var _t=8;function rl(n,l,c,h){ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:function(y){return!!y},toWireType:function(y,x){return x?c:h},zd:_t,readValueFromPointer:function(y){return this.fromWireType(de()[y>>>0])},Ad:null})}var pi=[],ut=[];function ci(n){9<(n>>>=0)&&--ut[n+1]==0&&(ut[n]=void 0,pi.push(n))}var He=n=>{if(!n)throw new yt("Cannot use deleted val. handle = "+n);return ut[n]},Qe=n=>{switch(n){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:let l=pi.pop()||ut.length;return ut[l]=n,ut[l+1]=1,l}};function hi(n){return this.fromWireType(X()[n>>>2>>>0])}var il={name:"emscripten::val",fromWireType:n=>{var l=He(n);return ci(n),l},toWireType:(n,l)=>Qe(l),zd:_t,readValueFromPointer:hi,Ad:null};function al(n){return ot(n>>>0,il)}var nl=(n,l)=>{switch(l){case 4:return function(c){return this.fromWireType(Ie()[c>>>2>>>0])};case 8:return function(c){return this.fromWireType(Fe()[c>>>3>>>0])};default:throw new TypeError(`invalid float width (${l}): ${n}`)}};function sl(n,l,c){c>>>=0,ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:h=>h,toWireType:(h,y)=>y,zd:_t,readValueFromPointer:nl(l,c),Ad:null})}function ol(n,l,c,h,y){if(n>>>=0,c>>>=0,l=rt(l>>>0),y===-1&&(y=4294967295),y=A=>A,h===0){var x=32-8*c;y=A=>A<<x>>>x}var T=l.includes("unsigned")?function(A,O){return O>>>0}:function(A,O){return O};ot(n,{name:l,fromWireType:y,toWireType:T,zd:_t,readValueFromPointer:Ka(l,c,h!==0),Ad:null})}function ul(n,l,c){function h(x){var T=X()[x>>>2>>>0];return x=X()[x+4>>>2>>>0],new y(H().buffer,x,T)}var y=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array][l];ot(n>>>=0,{name:c=rt(c>>>0),fromWireType:h,zd:_t,readValueFromPointer:h},{Pd:!0})}function ll(n,l){ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:function(c){for(var h,y=X()[c>>>2>>>0],x=c+4,T=x,A=0;A<=y;++A){var O=x+A;A!=y&&de()[O>>>0]!=0||(T=Oe(T,O-T),h===void 0?h=T:(h+="\0",h+=T),T=O+1)}return at(c),h},toWireType:function(c,h){h instanceof ArrayBuffer&&(h=new Uint8Array(h));var y=typeof h=="string";if(!(y||h instanceof Uint8Array||h instanceof Uint8ClampedArray||h instanceof Int8Array))throw new yt("Cannot pass non-string to std::string");var x=y?Na(h):h.length,T=Nr(4+x+1),A=T+4;if(X()[T>>>2>>>0]=x,y)Ot(h,A,x+1);else if(y)for(y=0;y<x;++y){var O=h.charCodeAt(y);if(255<O)throw at(T),new yt("String has UTF-16 code units that do not fit in 8 bits");de()[A+y>>>0]=O}else for(y=0;y<x;++y)de()[A+y>>>0]=h[y];return c!==null&&c.push(at,T),T},zd:_t,readValueFromPointer:hi,Ad(c){at(c)}})}var Za=typeof TextDecoder<"u"?new TextDecoder("utf-16le"):void 0,dl=(n,l)=>{for(var c=n>>1,h=c+l/2;!(c>=h)&&q()[c>>>0];)++c;if(32<(c<<=1)-n&&Za)return Za.decode(de().slice(n,c));for(c="",h=0;!(h>=l/2);++h){var y=M()[n+2*h>>>1>>>0];if(y==0)break;c+=String.fromCharCode(y)}return c},pl=(n,l,c)=>{if(c??(c=2147483647),2>c)return 0;var h=l;c=(c-=2)<2*n.length?c/2:n.length;for(var y=0;y<c;++y){var x=n.charCodeAt(y);M()[l>>>1>>>0]=x,l+=2}return M()[l>>>1>>>0]=0,l-h},cl=n=>2*n.length,hl=(n,l)=>{for(var c=0,h="";!(c>=l/4);){var y=R()[n+4*c>>>2>>>0];if(y==0)break;++c,65536<=y?(y-=65536,h+=String.fromCharCode(55296|y>>10,56320|1023&y)):h+=String.fromCharCode(y)}return h},fl=(n,l,c)=>{if(l>>>=0,c??(c=2147483647),4>c)return 0;var h=l;c=h+c-4;for(var y=0;y<n.length;++y){var x=n.charCodeAt(y);if(55296<=x&&57343>=x&&(x=65536+((1023&x)<<10)|1023&n.charCodeAt(++y)),R()[l>>>2>>>0]=x,(l+=4)+4>c)break}return R()[l>>>2>>>0]=0,l-h},ml=n=>{for(var l=0,c=0;c<n.length;++c){var h=n.charCodeAt(c);55296<=h&&57343>=h&&++c,l+=4}return l};function gl(n,l,c){if(n>>>=0,l>>>=0,c=rt(c>>>=0),l===2)var h=dl,y=pl,x=cl,T=A=>q()[A>>>1>>>0];else l===4&&(h=hl,y=fl,x=ml,T=A=>X()[A>>>2>>>0]);ot(n,{name:c,fromWireType:A=>{for(var O,P=X()[A>>>2>>>0],j=A+4,Q=0;Q<=P;++Q){var ae=A+4+Q*l;Q!=P&&T(ae)!=0||(j=h(j,ae-j),O===void 0?O=j:(O+="\0",O+=j),j=ae+l)}return at(A),O},toWireType:(A,O)=>{if(typeof O!="string")throw new yt(`Cannot pass non-string to C++ string type ${c}`);var P=x(O),j=Nr(4+P+l);return X()[j>>>2>>>0]=P/l,y(O,j+4,P+l),A!==null&&A.push(at,j),j},zd:_t,readValueFromPointer:hi,Ad(A){at(A)}})}function yl(n,l){ot(n>>>=0,{Qd:!0,name:l=rt(l>>>0),zd:0,fromWireType:()=>{},toWireType:()=>{}})}function _l(n){bi(n>>>0,!o,1,!s,131072,!1),Ta()}var fi=n=>{if(!oe)try{if(n(),!(0<mt))try{u?$i(I):si(I)}catch(l){l instanceof ii||l=="unwind"||v(0,l)}}catch(l){l instanceof ii||l=="unwind"||v(0,l)}};function mi(n){n>>>=0,typeof Atomics.ge=="function"&&(Atomics.ge(R(),n>>>2,n).value.then(Tr),n+=128,Atomics.store(R(),n>>>2,1))}var Tr=()=>{var n=Br();n&&(mi(n),fi(Tn))};function vl(n,l){(n>>>=0)==l>>>0?setTimeout(Tr):u?postMessage({Ed:n,yd:"checkMailbox"}):(n=St[n])&&n.postMessage({yd:"checkMailbox"})}var gi=[];function wl(n,l,c,h,y){for(l>>>=0,h/=2,gi.length=h,c=y>>>0>>>3,y=0;y<h;y++)gi[y]=D[c+2*y]?D[c+2*y+1]:Fe()[c+2*y+1>>>0];return(l?ri[l]:hd[n])(...gi)}var bl=()=>{mt=0};function $l(n){n>>>=0,u?postMessage({yd:"cleanupThread",ee:n}):Sa(St[n])}function xl(n){}var Cr=(n,l)=>{var c=di[n];if(c===void 0)throw n=wn(n),c=rt(n),at(n),new yt(`${l} has unknown type ${c}`);return c},Qa=(n,l,c)=>{var h=[];return n=n.toWireType(h,c),h.length&&(X()[l>>>2>>>0]=Qe(h)),n};function kl(n,l,c){return l>>>=0,c>>>=0,n=He(n>>>0),l=Cr(l,"emval::as"),Qa(l,c,n)}function Sl(n,l){return l>>>=0,n=He(n>>>0),(l=Cr(l,"emval::as")).toWireType(null,n)}var Ir=n=>{try{n()}catch(l){st(l)}},vt=0,it=null,Xa=0,Er=[],Ja={},Ya={},Tl=0,yi=null,Cl=[];function en(n){return function(l){if(!oe){if(vt===0){var c=!1,h=!1;l((y=0)=>{if(!oe&&(Xa=y,c=!0,h)){vt=2,Ir(()=>ks(it)),typeof MainLoop<"u"&&MainLoop.Md&&MainLoop.resume(),y=!1;try{var x=function(){var O=R()[it+8>>>2>>>0];return O=N[Ya[O]],--mt,O()}()}catch(O){x=O,y=!0}var T=!1;if(!it){var A=yi;A&&(yi=null,(y?A.reject:A.resolve)(x),T=!0)}if(y&&!T)throw x}}),h=!0,c||(vt=1,it=function(){var y=Nr(65548),x=y+12;X()[y>>>2>>>0]=x,X()[y+4>>>2>>>0]=x+65536,x=Er[0];var T=Ja[x];return T===void 0&&(T=Tl++,Ja[x]=T,Ya[T]=x),x=T,R()[y+8>>>2>>>0]=x,y}(),typeof MainLoop<"u"&&MainLoop.Md&&MainLoop.pause(),Ir(()=>$s(it)))}else vt===2?(vt=0,Ir(Ss),at(it),it=null,Cl.forEach(fi)):st(`invalid state: ${vt}`);return Xa}}(l=>{n().then(l)})}function Il(n){return n>>>=0,en(async()=>{var l=await He(n);return Qe(l)})}var zr=[];function El(n,l,c,h){return c>>>=0,h>>>=0,(n=zr[n>>>0])(null,l=He(l>>>0),c,h)}var zl={},Ar=n=>{var l=zl[n];return l===void 0?rt(n):l};function Al(n,l,c,h,y){return c>>>=0,h>>>=0,y>>>=0,(n=zr[n>>>0])(l=He(l>>>0),l[c=Ar(c)],h,y)}var tn=()=>typeof globalThis=="object"?globalThis:Function("return this")();function Ol(n){return(n>>>=0)==0?Qe(tn()):(n=Ar(n),Qe(tn()[n]))}var Rl=n=>{var l=zr.length;return zr.push(n),l},Bl=(n,l)=>{for(var c=Array(n),h=0;h<n;++h)c[h]=Cr(X()[l+4*h>>>2>>>0],"parameter "+h);return c},rn=(n,l)=>Object.defineProperty(l,"name",{value:n});function Nl(n,l,c){var h=(l=Bl(n,l>>>0)).shift();n--;var y=`return function (obj, func, destructorsRef, args) {
`,x=0,T=[];c===0&&T.push("obj");for(var A=["retType"],O=[h],P=0;P<n;++P)T.push("arg"+P),A.push("argType"+P),O.push(l[P]),y+=`  var arg${P} = argType${P}.readValueFromPointer(args${x?"+"+x:""});
`,x+=l[P].zd;return y+=`  var rv = ${c===1?"new func":"func.call"}(${T.join(", ")});
`,h.Qd||(A.push("emval_returnValue"),O.push(Qa),y+=`  return emval_returnValue(retType, destructorsRef, rv);
`),A.push(y+`};
`),n=function(j){var Q=Function;if(!(Q instanceof Function))throw new TypeError(`new_ called with constructor type ${typeof Q} which is not a function`);var ae=rn(Q.name||"unknownFunctionName",function(){});return ae.prototype=Q.prototype,ae=new ae,(j=Q.apply(ae,j))instanceof Object?j:ae}(A)(...O),c=`methodCaller<(${l.map(j=>j.name).join(", ")}) => ${h.name}>`,Rl(rn(c,n))}function Ml(n){return n=Ar(n>>>0),Qe(i[n])}function Dl(n,l){return l>>>=0,n=He(n>>>0),l=He(l),Qe(n[l])}function Pl(n){9<(n>>>=0)&&(ut[n+1]+=1)}function Ul(){return Qe([])}function Wl(n){n=He(n>>>0);for(var l=Array(n.length),c=0;c<n.length;c++)l[c]=n[c];return Qe(l)}function Vl(n){return Qe(Ar(n>>>0))}function ql(){return Qe({})}function jl(n){for(var l=He(n>>>=0);l.length;){var c=l.pop();l.pop()(c)}ci(n)}function Ll(n,l,c){l>>>=0,c>>>=0,n=He(n>>>0),l=He(l),c=He(c),n[l]=c}function Gl(n,l){return l>>>=0,n=(n=Cr(n>>>0,"_emval_take_value")).readValueFromPointer(l),Qe(n)}function Fl(n,l){n=-9007199254740992>n||9007199254740992<n?NaN:Number(n),l>>>=0,n=new Date(1e3*n),R()[l>>>2>>>0]=n.getUTCSeconds(),R()[l+4>>>2>>>0]=n.getUTCMinutes(),R()[l+8>>>2>>>0]=n.getUTCHours(),R()[l+12>>>2>>>0]=n.getUTCDate(),R()[l+16>>>2>>>0]=n.getUTCMonth(),R()[l+20>>>2>>>0]=n.getUTCFullYear()-1900,R()[l+24>>>2>>>0]=n.getUTCDay(),n=(n.getTime()-Date.UTC(n.getUTCFullYear(),0,1,0,0,0,0))/864e5|0,R()[l+28>>>2>>>0]=n}var an=n=>n%4==0&&(n%100!=0||n%400==0),nn=[0,31,60,91,121,152,182,213,244,274,305,335],sn=[0,31,59,90,120,151,181,212,243,273,304,334];function Hl(n,l){n=-9007199254740992>n||9007199254740992<n?NaN:Number(n),l>>>=0,n=new Date(1e3*n),R()[l>>>2>>>0]=n.getSeconds(),R()[l+4>>>2>>>0]=n.getMinutes(),R()[l+8>>>2>>>0]=n.getHours(),R()[l+12>>>2>>>0]=n.getDate(),R()[l+16>>>2>>>0]=n.getMonth(),R()[l+20>>>2>>>0]=n.getFullYear()-1900,R()[l+24>>>2>>>0]=n.getDay();var c=(an(n.getFullYear())?nn:sn)[n.getMonth()]+n.getDate()-1|0;R()[l+28>>>2>>>0]=c,R()[l+36>>>2>>>0]=-60*n.getTimezoneOffset(),c=new Date(n.getFullYear(),6,1).getTimezoneOffset();var h=new Date(n.getFullYear(),0,1).getTimezoneOffset();n=0|(c!=h&&n.getTimezoneOffset()==Math.min(h,c)),R()[l+32>>>2>>>0]=n}function Kl(n){n>>>=0;var l=new Date(R()[n+20>>>2>>>0]+1900,R()[n+16>>>2>>>0],R()[n+12>>>2>>>0],R()[n+8>>>2>>>0],R()[n+4>>>2>>>0],R()[n>>>2>>>0],0),c=R()[n+32>>>2>>>0],h=l.getTimezoneOffset(),y=new Date(l.getFullYear(),6,1).getTimezoneOffset(),x=new Date(l.getFullYear(),0,1).getTimezoneOffset(),T=Math.min(x,y);return 0>c?R()[n+32>>>2>>>0]=+(y!=x&&T==h):0<c!=(T==h)&&(y=Math.max(x,y),l.setTime(l.getTime()+6e4*((0<c?T:y)-h))),R()[n+24>>>2>>>0]=l.getDay(),c=(an(l.getFullYear())?nn:sn)[l.getMonth()]+l.getDate()-1|0,R()[n+28>>>2>>>0]=c,R()[n>>>2>>>0]=l.getSeconds(),R()[n+4>>>2>>>0]=l.getMinutes(),R()[n+8>>>2>>>0]=l.getHours(),R()[n+12>>>2>>>0]=l.getDate(),R()[n+16>>>2>>>0]=l.getMonth(),R()[n+20>>>2>>>0]=l.getYear(),n=l.getTime(),BigInt(isNaN(n)?-1:n/1e3)}function on(n,l,c,h,y,x,T){return u?xe(16,1,n,l,c,h,y,x,T):-52}function un(n,l,c,h,y,x){if(u)return xe(17,1,n,l,c,h,y,x)}var Qt={},Zl=()=>performance.timeOrigin+performance.now();function ln(n,l){if(u)return xe(18,1,n,l);if(Qt[n]&&(clearTimeout(Qt[n].id),delete Qt[n]),!l)return 0;var c=setTimeout(()=>{delete Qt[n],fi(()=>Sn(n,performance.timeOrigin+performance.now()))},l);return Qt[n]={id:c,ke:l},0}function Ql(n,l,c,h){n>>>=0,l>>>=0,c>>>=0,h>>>=0;var y=new Date().getFullYear(),x=new Date(y,0,1).getTimezoneOffset();y=new Date(y,6,1).getTimezoneOffset();var T=Math.max(x,y);X()[n>>>2>>>0]=60*T,R()[l>>>2>>>0]=+(x!=y),n=(l=A=>{var O=Math.abs(A);return`UTC${0<=A?"-":"+"}${String(Math.floor(O/60)).padStart(2,"0")}${String(O%60).padStart(2,"0")}`})(x),l=l(y),y<x?(Ot(n,c,17),Ot(l,h,17)):(Ot(n,h,17),Ot(l,c,17))}var Xl=()=>Date.now(),Jl=1;function Yl(n,l,c){if(!(0<=n&&3>=n))return 28;if(n===0)n=Date.now();else{if(!Jl)return 52;n=performance.timeOrigin+performance.now()}return D[c>>>0>>>3]=BigInt(Math.round(1e6*n)),0}var _i=[],dn=(n,l)=>{_i.length=0;for(var c;c=de()[n++>>>0];){var h=c!=105;l+=(h&=c!=112)&&l%8?4:0,_i.push(c==112?X()[l>>>2>>>0]:c==106?D[l>>>3]:c==105?R()[l>>>2>>>0]:Fe()[l>>>3>>>0]),l+=h?8:4}return _i};function ed(n,l,c){return n>>>=0,l=dn(l>>>0,c>>>0),ri[n](...l)}function td(n,l,c){return n>>>=0,l=dn(l>>>0,c>>>0),ri[n](...l)}var rd=()=>{};function id(n,l){return w(Oe(n>>>0,l>>>0))}var ad=()=>{throw mt+=1,"unwind"};function nd(){return 4294901760}var sd=()=>navigator.hardwareConcurrency;function od(){return st("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"),0}function ud(n){n>>>=0;var l=de().length;if(n<=l||4294901760<n)return!1;for(var c=1;4>=c;c*=2){var h=l*(1+.2/c);h=Math.min(h,n+100663296);e:{h=(Math.min(4294901760,65536*Math.ceil(Math.max(n,h)/65536))-S.buffer.byteLength+65535)/65536|0;try{S.grow(h),Ge();var y=1;break e}catch{}y=void 0}if(y)return!0}return!1}var Or=()=>(st("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"),0),Rt={},pn=n=>{n.forEach(l=>{var c=Or();c&&(Rt[c]=l)})};function ld(){var n=Error().stack.toString().split(`
`);return n[0]=="Error"&&n.shift(),pn(n),Rt.Kd=Or(),Rt.ae=n,Rt.Kd}function dd(n,l,c){if(n>>>=0,l>>>=0,Rt.Kd==n)var h=Rt.ae;else(h=Error().stack.toString().split(`
`))[0]=="Error"&&h.shift(),pn(h);for(var y=3;h[y]&&Or()!=n;)++y;for(n=0;n<c&&h[n+y];++n)R()[l+4*n>>>2>>>0]=Or();return n}var vi,wi={},cn=()=>{if(!vi){var n,l={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",_:"./this.program"};for(n in wi)wi[n]===void 0?delete l[n]:l[n]=wi[n];var c=[];for(n in l)c.push(`${n}=${l[n]}`);vi=c}return vi};function hn(n,l){if(u)return xe(19,1,n,l);n>>>=0,l>>>=0;var c=0;return cn().forEach((h,y)=>{var x=l+c;for(y=X()[n+4*y>>>2>>>0]=x,x=0;x<h.length;++x)H()[y++>>>0]=h.charCodeAt(x);H()[y>>>0]=0,c+=h.length+1}),0}function fn(n,l){if(u)return xe(20,1,n,l);n>>>=0,l>>>=0;var c=cn();X()[n>>>2>>>0]=c.length;var h=0;return c.forEach(y=>h+=y.length+1),X()[l>>>2>>>0]=h,0}function mn(n){return u?xe(21,1,n):52}function gn(n,l,c,h){return u?xe(22,1,n,l,c,h):52}function yn(n,l,c,h){return u?xe(23,1,n,l,c,h):70}var pd=[null,[],[]];function _n(n,l,c,h){if(u)return xe(24,1,n,l,c,h);l>>>=0,c>>>=0,h>>>=0;for(var y=0,x=0;x<c;x++){var T=X()[l>>>2>>>0],A=X()[l+4>>>2>>>0];l+=8;for(var O=0;O<A;O++){var P=de()[T+O>>>0],j=pd[n];P===0||P===10?((n===1?$:w)(Oa(j)),j.length=0):j.push(P)}y+=A}return X()[h>>>2>>>0]=y,0}function cd(n){return n>>>0}u||function(){for(var n=i.numThreads-1;n--;)Ia();ai.unshift(()=>{Ht++,function(l){u?l():Promise.all(gt.map(Ca)).then(l)}(()=>va())})}();for(var vn=Array(256),Rr=0;256>Rr;++Rr)vn[Rr]=String.fromCharCode(Rr);Ha=vn,yt=i.BindingError=class extends Error{constructor(n){super(n),this.name="BindingError"}},i.InternalError=class extends Error{constructor(n){super(n),this.name="InternalError"}},ut.push(0,1,void 0,1,null,1,!0,1,!1,1),i.count_emval_handles=()=>ut.length/2-5-pi.length;var N,hd=[ni,xa,Ea,Ra,Ba,Ma,Da,Pa,Ua,Wa,Va,qa,ja,La,Ga,Fa,on,un,ln,hn,fn,mn,gn,yn,_n];(async function(){function n(h,y){return N=h.exports,N=function(){var x=N,T={};for(let[A,O]of Object.entries(x))T[A]=typeof O=="function"?(...P)=>{Er.push(A);try{return O(...P)}finally{oe||(Er.pop(),it&&vt===1&&Er.length===0&&(vt=0,mt+=1,Ir(xs),typeof Fibers<"u"&&Fibers.le()))}}:O;return T}(),N=function(){var x=N,T=O=>P=>O(P)>>>0,A=O=>()=>O()>>>0;return(x=Object.assign({},x)).Cb=T(x.Cb),x.fc=A(x.fc),x.ic=T(x.ic),x.vc=T(x.vc),x.wc=A(x.wc),x.Ac=T(x.Ac),x}(),ka.push(N.jc),C=y,va(),N}Ht++;var l=wa();if(i.instantiateWasm)return new Promise(h=>{i.instantiateWasm(l,(y,x)=>{n(y,x),h(y.exports)})});if(u)return new Promise(h=>{Ae=y=>{var x=new WebAssembly.Instance(y,wa());h(n(x,y))}});ti??(ti=i.locateFile?i.locateFile?i.locateFile("ort-wasm-simd-threaded.jsep.wasm",_):_+"ort-wasm-simd-threaded.jsep.wasm":new URL("ort-wasm-simd-threaded.jsep.wasm",vr.url).href);try{var c=await async function(h){var y=ti;if(!F&&typeof WebAssembly.instantiateStreaming=="function"&&!le(y))try{var x=fetch(y,{credentials:"same-origin"});return await WebAssembly.instantiateStreaming(x,h)}catch(T){w(`wasm streaming compile failed: ${T}`),w("falling back to ArrayBuffer instantiation")}return async function(T,A){try{var O=await async function(P){if(!F)try{var j=await m(P);return new Uint8Array(j)}catch{}if(P==ti&&F)P=new Uint8Array(F);else{if(!f)throw"both async and sync fetching of the wasm failed";P=f(P)}return P}(T);return await WebAssembly.instantiate(O,A)}catch(P){w(`failed to asynchronously prepare wasm: ${P}`),st(P)}}(y,h)}(l);return n(c.instance,c.module)}catch(h){return r(h),Promise.reject(h)}})();var wn=n=>(wn=N.Cb)(n),bn=()=>(bn=N.Db)();i._OrtInit=(n,l)=>(i._OrtInit=N.Eb)(n,l),i._OrtGetLastError=(n,l)=>(i._OrtGetLastError=N.Fb)(n,l),i._OrtCreateSessionOptions=(n,l,c,h,y,x,T,A,O,P)=>(i._OrtCreateSessionOptions=N.Gb)(n,l,c,h,y,x,T,A,O,P),i._OrtAppendExecutionProvider=(n,l)=>(i._OrtAppendExecutionProvider=N.Hb)(n,l),i._OrtAddFreeDimensionOverride=(n,l,c)=>(i._OrtAddFreeDimensionOverride=N.Ib)(n,l,c),i._OrtAddSessionConfigEntry=(n,l,c)=>(i._OrtAddSessionConfigEntry=N.Jb)(n,l,c),i._OrtReleaseSessionOptions=n=>(i._OrtReleaseSessionOptions=N.Kb)(n),i._OrtCreateSession=(n,l,c)=>(i._OrtCreateSession=N.Lb)(n,l,c),i._OrtReleaseSession=n=>(i._OrtReleaseSession=N.Mb)(n),i._OrtGetInputOutputCount=(n,l,c)=>(i._OrtGetInputOutputCount=N.Nb)(n,l,c),i._OrtGetInputName=(n,l)=>(i._OrtGetInputName=N.Ob)(n,l),i._OrtGetOutputName=(n,l)=>(i._OrtGetOutputName=N.Pb)(n,l),i._OrtFree=n=>(i._OrtFree=N.Qb)(n),i._OrtCreateTensor=(n,l,c,h,y,x)=>(i._OrtCreateTensor=N.Rb)(n,l,c,h,y,x),i._OrtGetTensorData=(n,l,c,h,y)=>(i._OrtGetTensorData=N.Sb)(n,l,c,h,y),i._OrtReleaseTensor=n=>(i._OrtReleaseTensor=N.Tb)(n),i._OrtCreateRunOptions=(n,l,c,h)=>(i._OrtCreateRunOptions=N.Ub)(n,l,c,h),i._OrtAddRunConfigEntry=(n,l,c)=>(i._OrtAddRunConfigEntry=N.Vb)(n,l,c),i._OrtReleaseRunOptions=n=>(i._OrtReleaseRunOptions=N.Wb)(n),i._OrtCreateBinding=n=>(i._OrtCreateBinding=N.Xb)(n),i._OrtBindInput=(n,l,c)=>(i._OrtBindInput=N.Yb)(n,l,c),i._OrtBindOutput=(n,l,c,h)=>(i._OrtBindOutput=N.Zb)(n,l,c,h),i._OrtClearBoundOutputs=n=>(i._OrtClearBoundOutputs=N._b)(n),i._OrtReleaseBinding=n=>(i._OrtReleaseBinding=N.$b)(n),i._OrtRunWithBinding=(n,l,c,h,y)=>(i._OrtRunWithBinding=N.ac)(n,l,c,h,y),i._OrtRun=(n,l,c,h,y,x,T,A)=>(i._OrtRun=N.bc)(n,l,c,h,y,x,T,A),i._OrtEndProfiling=n=>(i._OrtEndProfiling=N.cc)(n),i._JsepOutput=(n,l,c)=>(i._JsepOutput=N.dc)(n,l,c),i._JsepGetNodeName=n=>(i._JsepGetNodeName=N.ec)(n);var Br=()=>(Br=N.fc)(),at=i._free=n=>(at=i._free=N.gc)(n),Nr=i._malloc=n=>(Nr=i._malloc=N.ic)(n),bi=(n,l,c,h,y,x)=>(bi=N.kc)(n,l,c,h,y,x),$n=()=>($n=N.lc)(),xn=(n,l,c,h,y)=>(xn=N.mc)(n,l,c,h,y),kn=n=>(kn=N.nc)(n),$i=n=>($i=N.oc)(n),Sn=(n,l)=>(Sn=N.pc)(n,l),Tn=()=>(Tn=N.qc)(),ie=(n,l)=>(ie=N.rc)(n,l),Xt=n=>(Xt=N.sc)(n),Cn=(n,l)=>(Cn=N.tc)(n,l),Y=n=>(Y=N.uc)(n),xi=n=>(xi=N.vc)(n),re=()=>(re=N.wc)(),In=n=>(In=N.xc)(n),En=n=>(En=N.yc)(n),zn=(n,l,c)=>(zn=N.zc)(n,l,c),An=n=>(An=N.Ac)(n),On=i.dynCall_iii=(n,l,c)=>(On=i.dynCall_iii=N.Bc)(n,l,c),Rn=i.dynCall_vi=(n,l)=>(Rn=i.dynCall_vi=N.Cc)(n,l),ki=i.dynCall_ii=(n,l)=>(ki=i.dynCall_ii=N.Dc)(n,l),Bn=i.dynCall_vii=(n,l,c)=>(Bn=i.dynCall_vii=N.Ec)(n,l,c),Nn=i.dynCall_iiii=(n,l,c,h)=>(Nn=i.dynCall_iiii=N.Fc)(n,l,c,h),Mn=i.dynCall_viii=(n,l,c,h)=>(Mn=i.dynCall_viii=N.Gc)(n,l,c,h),Dn=i.dynCall_iiiii=(n,l,c,h,y)=>(Dn=i.dynCall_iiiii=N.Hc)(n,l,c,h,y),Pn=i.dynCall_viiii=(n,l,c,h,y)=>(Pn=i.dynCall_viiii=N.Ic)(n,l,c,h,y),Un=i.dynCall_viiiiii=(n,l,c,h,y,x,T)=>(Un=i.dynCall_viiiiii=N.Jc)(n,l,c,h,y,x,T),Wn=i.dynCall_viiiiiii=(n,l,c,h,y,x,T,A)=>(Wn=i.dynCall_viiiiiii=N.Kc)(n,l,c,h,y,x,T,A),Vn=i.dynCall_ji=(n,l)=>(Vn=i.dynCall_ji=N.Lc)(n,l),qn=i.dynCall_v=n=>(qn=i.dynCall_v=N.Mc)(n),jn=i.dynCall_viiiii=(n,l,c,h,y,x)=>(jn=i.dynCall_viiiii=N.Nc)(n,l,c,h,y,x),Ln=i.dynCall_i=n=>(Ln=i.dynCall_i=N.Oc)(n),Gn=i.dynCall_fii=(n,l,c)=>(Gn=i.dynCall_fii=N.Pc)(n,l,c),Fn=i.dynCall_viiiiiiii=(n,l,c,h,y,x,T,A,O)=>(Fn=i.dynCall_viiiiiiii=N.Qc)(n,l,c,h,y,x,T,A,O),Hn=i.dynCall_viiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j)=>(Hn=i.dynCall_viiiiiiiiii=N.Rc)(n,l,c,h,y,x,T,A,O,P,j),Kn=i.dynCall_jiii=(n,l,c,h)=>(Kn=i.dynCall_jiii=N.Sc)(n,l,c,h),Zn=i.dynCall_dii=(n,l,c)=>(Zn=i.dynCall_dii=N.Tc)(n,l,c),Qn=i.dynCall_viiiiiiiii=(n,l,c,h,y,x,T,A,O,P)=>(Qn=i.dynCall_viiiiiiiii=N.Uc)(n,l,c,h,y,x,T,A,O,P),Xn=i.dynCall_viiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q)=>(Xn=i.dynCall_viiiiiiiiiii=N.Vc)(n,l,c,h,y,x,T,A,O,P,j,Q),Jn=i.dynCall_iiiiii=(n,l,c,h,y,x)=>(Jn=i.dynCall_iiiiii=N.Wc)(n,l,c,h,y,x),Yn=i.dynCall_iij=(n,l,c)=>(Yn=i.dynCall_iij=N.Xc)(n,l,c),es=i.dynCall_iiiiiiiiii=(n,l,c,h,y,x,T,A,O,P)=>(es=i.dynCall_iiiiiiiiii=N.Yc)(n,l,c,h,y,x,T,A,O,P),ts=i.dynCall_iiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j)=>(ts=i.dynCall_iiiiiiiiiii=N.Zc)(n,l,c,h,y,x,T,A,O,P,j),rs=i.dynCall_vij=(n,l,c)=>(rs=i.dynCall_vij=N._c)(n,l,c),is=i.dynCall_iiif=(n,l,c,h)=>(is=i.dynCall_iiif=N.$c)(n,l,c,h),as=i.dynCall_iiij=(n,l,c,h)=>(as=i.dynCall_iiij=N.ad)(n,l,c,h),ns=i.dynCall_fiii=(n,l,c,h)=>(ns=i.dynCall_fiii=N.bd)(n,l,c,h),ss=i.dynCall_viiiiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>(ss=i.dynCall_viiiiiiiiiiiii=N.cd)(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we),os=i.dynCall_vjiii=(n,l,c,h,y)=>(os=i.dynCall_vjiii=N.dd)(n,l,c,h,y),us=i.dynCall_vif=(n,l,c)=>(us=i.dynCall_vif=N.ed)(n,l,c),ls=i.dynCall_iiiiiii=(n,l,c,h,y,x,T)=>(ls=i.dynCall_iiiiiii=N.fd)(n,l,c,h,y,x,T),ds=i.dynCall_iiiij=(n,l,c,h,y)=>(ds=i.dynCall_iiiij=N.gd)(n,l,c,h,y),ps=i.dynCall_iiiiiiii=(n,l,c,h,y,x,T,A)=>(ps=i.dynCall_iiiiiiii=N.hd)(n,l,c,h,y,x,T,A),cs=i.dynCall_viiiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q,ae)=>(cs=i.dynCall_viiiiiiiiiiii=N.id)(n,l,c,h,y,x,T,A,O,P,j,Q,ae),hs=i.dynCall_diii=(n,l,c,h)=>(hs=i.dynCall_diii=N.jd)(n,l,c,h),fs=i.dynCall_jiiii=(n,l,c,h,y)=>(fs=i.dynCall_jiiii=N.kd)(n,l,c,h,y),ms=i.dynCall_viiij=(n,l,c,h,y)=>(ms=i.dynCall_viiij=N.ld)(n,l,c,h,y),gs=i.dynCall_fiiii=(n,l,c,h,y)=>(gs=i.dynCall_fiiii=N.md)(n,l,c,h,y),ys=i.dynCall_viiif=(n,l,c,h,y)=>(ys=i.dynCall_viiif=N.nd)(n,l,c,h,y),_s=i.dynCall_diiii=(n,l,c,h,y)=>(_s=i.dynCall_diiii=N.od)(n,l,c,h,y),vs=i.dynCall_viiid=(n,l,c,h,y)=>(vs=i.dynCall_viiid=N.pd)(n,l,c,h,y),ws=i.dynCall_iiiijii=(n,l,c,h,y,x,T)=>(ws=i.dynCall_iiiijii=N.qd)(n,l,c,h,y,x,T),bs=i.dynCall_iiiiiij=(n,l,c,h,y,x,T)=>(bs=i.dynCall_iiiiiij=N.rd)(n,l,c,h,y,x,T),$s=n=>($s=N.sd)(n),xs=()=>(xs=N.td)(),ks=n=>(ks=N.ud)(n),Ss=()=>(Ss=N.vd)();function fd(n,l,c){var h=re();try{Bn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function md(n,l,c){var h=re();try{return On(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function gd(n,l){var c=re();try{Rn(n,l)}catch(h){if(Y(c),h!==h+0)throw h;ie(1,0)}}function yd(n,l){var c=re();try{return ki(n,l)}catch(h){if(Y(c),h!==h+0)throw h;ie(1,0)}}function _d(n,l,c,h){var y=re();try{return Nn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function vd(n,l,c,h,y){var x=re();try{Pn(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function wd(n,l,c,h,y){var x=re();try{return Dn(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function bd(n,l,c,h){var y=re();try{Mn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function $d(n,l,c,h,y,x,T){var A=re();try{return ls(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function xd(n){var l=re();try{qn(n)}catch(c){if(Y(l),c!==c+0)throw c;ie(1,0)}}function kd(n,l,c){var h=re();try{return Yn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Sd(n,l,c,h,y,x){var T=re();try{jn(n,l,c,h,y,x)}catch(A){if(Y(T),A!==A+0)throw A;ie(1,0)}}function Td(n,l,c){var h=re();try{rs(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Cd(n,l,c,h,y,x,T){var A=re();try{Un(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function Id(n,l,c,h,y,x,T,A){var O=re();try{Wn(n,l,c,h,y,x,T,A)}catch(P){if(Y(O),P!==P+0)throw P;ie(1,0)}}function Ed(n,l,c,h,y,x){var T=re();try{return Jn(n,l,c,h,y,x)}catch(A){if(Y(T),A!==A+0)throw A;ie(1,0)}}function zd(n,l,c,h,y,x,T,A){var O=re();try{return ps(n,l,c,h,y,x,T,A)}catch(P){if(Y(O),P!==P+0)throw P;ie(1,0)}}function Ad(n,l,c,h,y,x,T,A,O,P){var j=re();try{Qn(n,l,c,h,y,x,T,A,O,P)}catch(Q){if(Y(j),Q!==Q+0)throw Q;ie(1,0)}}function Od(n,l,c,h,y,x,T,A,O){var P=re();try{Fn(n,l,c,h,y,x,T,A,O)}catch(j){if(Y(P),j!==j+0)throw j;ie(1,0)}}function Rd(n){var l=re();try{return Ln(n)}catch(c){if(Y(l),c!==c+0)throw c;ie(1,0)}}function Bd(n,l,c,h,y,x,T,A,O,P){var j=re();try{return es(n,l,c,h,y,x,T,A,O,P)}catch(Q){if(Y(j),Q!==Q+0)throw Q;ie(1,0)}}function Nd(n,l,c){var h=re();try{return Gn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Md(n,l,c,h){var y=re();try{return Kn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;return ie(1,0),0n}}function Dd(n,l,c){var h=re();try{return Zn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Pd(n,l,c,h,y,x,T,A,O,P,j,Q){var ae=re();try{Xn(n,l,c,h,y,x,T,A,O,P,j,Q)}catch(we){if(Y(ae),we!==we+0)throw we;ie(1,0)}}function Ud(n,l,c,h,y,x,T,A,O,P,j){var Q=re();try{Hn(n,l,c,h,y,x,T,A,O,P,j)}catch(ae){if(Y(Q),ae!==ae+0)throw ae;ie(1,0)}}function Wd(n,l,c,h,y,x,T,A,O,P,j){var Q=re();try{return ts(n,l,c,h,y,x,T,A,O,P,j)}catch(ae){if(Y(Q),ae!==ae+0)throw ae;ie(1,0)}}function Vd(n,l,c,h){var y=re();try{return is(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function qd(n,l,c,h){var y=re();try{return as(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function jd(n,l,c,h){var y=re();try{return ns(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function Ld(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we){var Xe=re();try{ss(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)}catch(Jt){if(Y(Xe),Jt!==Jt+0)throw Jt;ie(1,0)}}function Gd(n,l,c,h,y){var x=re();try{os(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Fd(n,l,c){var h=re();try{us(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Hd(n,l){var c=re();try{return Vn(n,l)}catch(h){if(Y(c),h!==h+0)throw h;return ie(1,0),0n}}function Kd(n,l,c,h,y){var x=re();try{return ds(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Zd(n,l,c,h,y,x,T,A,O,P,j,Q,ae){var we=re();try{cs(n,l,c,h,y,x,T,A,O,P,j,Q,ae)}catch(Xe){if(Y(we),Xe!==Xe+0)throw Xe;ie(1,0)}}function Qd(n,l,c,h){var y=re();try{return hs(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function Xd(n,l,c,h,y){var x=re();try{return fs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;return ie(1,0),0n}}function Jd(n,l,c,h,y){var x=re();try{ms(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Yd(n,l,c,h,y){var x=re();try{return gs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function ep(n,l,c,h,y){var x=re();try{ys(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function tp(n,l,c,h,y){var x=re();try{return _s(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function rp(n,l,c,h,y){var x=re();try{vs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function ip(n,l,c,h,y,x,T){var A=re();try{return ws(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function ap(n,l,c,h,y,x,T){var A=re();try{return bs(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}return i.stackSave=()=>re(),i.stackRestore=n=>Y(n),i.stackAlloc=n=>xi(n),i.setValue=function(n,l,c="i8"){switch(c.endsWith("*")&&(c="*"),c){case"i1":case"i8":H()[n>>>0]=l;break;case"i16":M()[n>>>1>>>0]=l;break;case"i32":R()[n>>>2>>>0]=l;break;case"i64":D[n>>>3]=BigInt(l);break;case"float":Ie()[n>>>2>>>0]=l;break;case"double":Fe()[n>>>3>>>0]=l;break;case"*":X()[n>>>2>>>0]=l;break;default:st(`invalid type for setValue: ${c}`)}},i.getValue=function(n,l="i8"){switch(l.endsWith("*")&&(l="*"),l){case"i1":case"i8":return H()[n>>>0];case"i16":return M()[n>>>1>>>0];case"i32":return R()[n>>>2>>>0];case"i64":return D[n>>>3];case"float":return Ie()[n>>>2>>>0];case"double":return Fe()[n>>>3>>>0];case"*":return X()[n>>>2>>>0];default:st(`invalid type for getValue: ${l}`)}},i.UTF8ToString=Oe,i.stringToUTF8=Ot,i.lengthBytesUTF8=Na,function n(){if(0<Ht)Kt=n;else if(u)t(i),kr();else{for(;0<ai.length;)ai.shift()(i);0<Ht?Kt=n:(i.calledRun=!0,oe||(kr(),t(i)))}}(),i.PTR_SIZE=4,a}),Y_=cp,em=globalThis.self?.name?.startsWith("em-pthread"),em&&cp()}),vc=ee(()=>{"use strict";_c(),hp=typeof location>"u"?void 0:location.origin,tm=()=>vr.url?.startsWith("file:")?new URL(new URL("ort.webgpu.bundle.min.mjs",vr.url).href,hp).href:vr.url,Bt=tm(),e0=()=>{if(Bt&&!Bt.startsWith("blob:"))return Bt.substring(0,Bt.lastIndexOf("/")+1)},Ro=(e,t)=>{try{let r=t??Bt;return(r?new URL(e,r):new URL(e)).origin===hp}catch{return!1}},rm=(e,t)=>{let r=t??Bt;try{return(r?new URL(e,r):new URL(e)).href}catch{return}},im=(e,t)=>`${t??"./"}${e}`,fp=async e=>{let t=await(await fetch(e,{credentials:"same-origin"})).blob();return URL.createObjectURL(t)},am=async e=>(await import(e)).default,mp=(UT(),Ko(Q_)).default,t0=async()=>{if(!Bt)throw new Error("Failed to load proxy worker: cannot determine the script source URL.");if(Ro(Bt))return[void 0,mp()];let e=await fp(Bt);return[e,mp(e)]},gp=(WT(),Ko(J_)).default,r0=async(e,t,r)=>{if(!e&&!t&&gp&&Bt&&Ro(Bt))return[void 0,gp];{let i="ort-wasm-simd-threaded.jsep.mjs",a=e??rm(i,t),s=r&&a&&!Ro(a,t),o=s?await fp(a):a??im(i,t);return[s?o:void 0,await am(o)]}}}),Mi=ee(()=>{"use strict";vc(),Bo=!1,Cs=!1,_p=!1,nm=()=>{if(typeof SharedArrayBuffer>"u")return!1;try{return typeof MessageChannel<"u"&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}},sm=()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}},wc=async e=>{if(Bo)return Promise.resolve();if(Cs)throw new Error("multiple calls to 'initializeWebAssembly()' detected.");if(_p)throw new Error("previous call to 'initializeWebAssembly()' failed.");Cs=!0;let t=e.initTimeout,r=e.numThreads;if(!sm())throw new Error("WebAssembly SIMD is not supported in the current environment.");let i=nm();r>1&&!i&&(typeof self<"u"&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let a=e.wasmPaths,s=typeof a=="string"?a:void 0,o=a?.mjs,u=o?.href??o,d=a?.wasm,p=d?.href??d,m=e.wasmBinary,[f,g]=await r0(u,s,r>1),v=!1,_=[];if(t>0&&_.push(new Promise(b=>{setTimeout(()=>{v=!0,b()},t)})),_.push(new Promise((b,k)=>{let $={numThreads:r};if(m)$.wasmBinary=m;else if(p||s)$.locateFile=w=>p??s+w;else if(u&&u.indexOf("blob:")!==0)$.locateFile=w=>new URL(w,u).href;else if(f){let w=e0();w&&($.locateFile=S=>w+S)}g($).then(w=>{Cs=!1,Bo=!0,yp=w,b(),f&&URL.revokeObjectURL(f)},w=>{Cs=!1,_p=!0,k(w)})})),await Promise.race(_),v)throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},lt=()=>{if(Bo&&yp)return yp;throw new Error("WebAssembly is not initialized yet.")}}),bc=ee(()=>{"use strict";Mi(),wt=(e,t)=>{let r=lt(),i=r.lengthBytesUTF8(e)+1,a=r._malloc(i);return r.stringToUTF8(e,a,i),t.push(a),a},Zo=(e,t,r,i)=>{if(typeof e=="object"&&e!==null){if(r.has(e))throw new Error("Circular reference in options");r.add(e)}Object.entries(e).forEach(([a,s])=>{let o=t?t+a:a;if(typeof s=="object")Zo(s,o+".",r,i);else if(typeof s=="string"||typeof s=="number")i(o,s.toString());else if(typeof s=="boolean")i(o,s?"1":"0");else throw new Error(`Can't handle extra config type: ${typeof s}`)})},Ve=e=>{let t=lt(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetLastError(a,a+i);let s=Number(t.getValue(a,i===4?"i32":"i64")),o=t.getValue(a+i,"*"),u=o?t.UTF8ToString(o):"";throw new Error(`${e} ERROR_CODE: ${s}, ERROR_MESSAGE: ${u}`)}finally{t.stackRestore(r)}}}),VT=ee(()=>{"use strict";Mi(),bc(),i0=e=>{let t=lt(),r=0,i=[],a=e||{};try{if(e?.logSeverityLevel===void 0)a.logSeverityLevel=2;else if(typeof e.logSeverityLevel!="number"||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw new Error(`log serverity level is not valid: ${e.logSeverityLevel}`);if(e?.logVerbosityLevel===void 0)a.logVerbosityLevel=0;else if(typeof e.logVerbosityLevel!="number"||!Number.isInteger(e.logVerbosityLevel))throw new Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);e?.terminate===void 0&&(a.terminate=!1);let s=0;return e?.tag!==void 0&&(s=wt(e.tag,i)),r=t._OrtCreateRunOptions(a.logSeverityLevel,a.logVerbosityLevel,!!a.terminate,s),r===0&&Ve("Can't create run options."),e?.extra!==void 0&&Zo(e.extra,"",new WeakSet,(o,u)=>{let d=wt(o,i),p=wt(u,i);t._OrtAddRunConfigEntry(r,d,p)!==0&&Ve(`Can't set a run config entry: ${o} - ${u}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseRunOptions(r),i.forEach(o=>t._free(o)),s}}}),qT=ee(()=>{"use strict";Mi(),bc(),om=e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"all":return 99;default:throw new Error(`unsupported graph optimization level: ${e}`)}},um=e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw new Error(`unsupported execution mode: ${e}`)}},lm=e=>{e.extra||(e.extra={}),e.extra.session||(e.extra.session={});let t=e.extra.session;t.use_ort_model_bytes_directly||(t.use_ort_model_bytes_directly="1"),e.executionProviders&&e.executionProviders.some(r=>(typeof r=="string"?r:r.name)==="webgpu")&&(e.enableMemPattern=!1)},dm=(e,t,r)=>{for(let i of t){let a=typeof i=="string"?i:i.name;switch(a){case"webnn":if(a="WEBNN",typeof i!="string"){let o=i?.deviceType;if(o){let u=wt("deviceType",r),d=wt(o,r);lt()._OrtAddSessionConfigEntry(e,u,d)!==0&&Ve(`Can't set a session config entry: 'deviceType' - ${o}.`)}}break;case"webgpu":if(a="JS",typeof i!="string"){let o=i;if(o?.preferredLayout){if(o.preferredLayout!=="NCHW"&&o.preferredLayout!=="NHWC")throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${o.preferredLayout}`);let u=wt("preferredLayout",r),d=wt(o.preferredLayout,r);lt()._OrtAddSessionConfigEntry(e,u,d)!==0&&Ve(`Can't set a session config entry: 'preferredLayout' - ${o.preferredLayout}.`)}}break;case"wasm":case"cpu":continue;default:throw new Error(`not supported execution provider: ${a}`)}let s=wt(a,r);lt()._OrtAppendExecutionProvider(e,s)!==0&&Ve(`Can't append execution provider: ${a}.`)}},a0=e=>{let t=lt(),r=0,i=[],a=e||{};lm(a);try{let s=om(a.graphOptimizationLevel??"all"),o=um(a.executionMode??"sequential"),u=typeof a.logId=="string"?wt(a.logId,i):0,d=a.logSeverityLevel??2;if(!Number.isInteger(d)||d<0||d>4)throw new Error(`log serverity level is not valid: ${d}`);let p=a.logVerbosityLevel??0;if(!Number.isInteger(p)||p<0||p>4)throw new Error(`log verbosity level is not valid: ${p}`);let m=typeof a.optimizedModelFilePath=="string"?wt(a.optimizedModelFilePath,i):0;if(r=t._OrtCreateSessionOptions(s,!!a.enableCpuMemArena,!!a.enableMemPattern,o,!!a.enableProfiling,0,u,d,p,m),r===0&&Ve("Can't create session options."),a.executionProviders&&dm(r,a.executionProviders,i),a.enableGraphCapture!==void 0){if(typeof a.enableGraphCapture!="boolean")throw new Error(`enableGraphCapture must be a boolean value: ${a.enableGraphCapture}`);let f=wt("enableGraphCapture",i),g=wt(a.enableGraphCapture.toString(),i);t._OrtAddSessionConfigEntry(r,f,g)!==0&&Ve(`Can't set a session config entry: 'enableGraphCapture' - ${a.enableGraphCapture}.`)}if(a.freeDimensionOverrides)for(let[f,g]of Object.entries(a.freeDimensionOverrides)){if(typeof f!="string")throw new Error(`free dimension override name must be a string: ${f}`);if(typeof g!="number"||!Number.isInteger(g)||g<0)throw new Error(`free dimension override value must be a non-negative integer: ${g}`);let v=wt(f,i);t._OrtAddFreeDimensionOverride(r,v,g)!==0&&Ve(`Can't set a free dimension override: ${f} - ${g}.`)}return a.extra!==void 0&&Zo(a.extra,"",new WeakSet,(f,g)=>{let v=wt(f,i),_=wt(g,i);t._OrtAddSessionConfigEntry(r,v,_)!==0&&Ve(`Can't set a session config entry: ${f} - ${g}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseSessionOptions(r)!==0&&Ve("Can't release session options."),i.forEach(o=>t._free(o)),s}}}),be=ee(()=>{"use strict";ta=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw new Error(`unsupported data type: ${e}`)}},zi=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw new Error(`unsupported data type: ${e}`)}},Ai=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],i=typeof t=="number"?t:t.reduce((a,s)=>a*s,1);return r>0?Math.ceil(i*r):void 0},$c=e=>{switch(e){case"float16":return typeof Float16Array<"u"&&Float16Array.from?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"bool":return Uint8Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw new Error(`unsupported type: ${e}`)}},Qo=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw new Error(`unsupported logging level: ${e}`)}},xc=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",kc=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint64"||e==="int8"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",tc=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw new Error(`unsupported data location: ${e}`)}}}),n0=ee(()=>{"use strict";_c(),Sc=async e=>{if(typeof e=="string")if(0)try{}catch(t){}else{let t=await fetch(e);if(!t.ok)throw new Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),i=r?parseInt(r,10):0;if(i<1073741824)return new Uint8Array(await t.arrayBuffer());{if(!t.body)throw new Error(`failed to load external data file: ${e}, no response body.`);let a=t.body.getReader(),s;try{s=new ArrayBuffer(i)}catch(u){if(u instanceof RangeError){let d=Math.ceil(i/65536);s=new WebAssembly.Memory({initial:d,maximum:d}).buffer}else throw u}let o=0;for(;;){let{done:u,value:d}=await a.read();if(u)break;let p=d.byteLength;new Uint8Array(s,o,p).set(d),o+=p}return new Uint8Array(s,0,i)}}else return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e)}}),Dr=ee(()=>{"use strict";be(),pm=["V","I","W","E","F"],cm=(e,t)=>{console.log(`[${pm[e]},${new Date().toISOString()}]${t}`)},Tc=(e,t)=>{hm=e,fm=t},mm=(e,t)=>{let r=Qo(e),i=Qo(hm);r>=i&&cm(r,typeof t=="function"?t():t)},Ne=(...e)=>{fm&&mm(...e)}}),s0=ee(()=>{"use strict";be(),Cc=(e,t)=>new($c(t))(e)}),Ic=ee(()=>{"use strict"}),jT=ee(()=>{"use strict";Dr(),Ic(),vp=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[12582912,10],[16777216,10],[26214400,15],[33554432,22],[44236800,2],[58982400,6],[67108864,6],[134217728,6],[167772160,6]]),No=[],Mo=e=>Math.ceil(Number(e)/16)*16,gm=e=>{for(let t=0;t<No.length;t++){let r=No[t];if(e<=r)return r}return Math.ceil(e/16)*16},ym=1,wp=()=>ym++,rc=async(e,t,r,i)=>{let a=Mo(r),s=e.device.createBuffer({size:a,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let o=e.getCommandEncoder();e.endComputePass(),o.copyBufferToBuffer(t,0,s,0,a),e.flush(),await s.mapAsync(GPUMapMode.READ);let u=s.getMappedRange();if(i){let d=i();return d.set(new Uint8Array(u,0,r)),d}else return new Uint8Array(u.slice(0,r))}finally{s.destroy()}},_m=class{constructor(e){this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersPending=[],this.capturedPendingBuffers=new Map;for(let[t]of vp)No.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[]);this.sessionCount=0}upload(e,t){let r=t.buffer,i=t.byteOffset,a=t.byteLength,s=Mo(a),o=this.storageCache.get(e);if(!o)throw new Error("gpu data for uploading does not exist");if(Number(o.originalSize)!==a)throw new Error(`inconsistent data size. gpu data size=${o.originalSize}, data size=${a}`);let u=this.backend.device.createBuffer({mappedAtCreation:!0,size:s,usage:GPUBufferUsage.MAP_WRITE|GPUBufferUsage.COPY_SRC}),d=u.getMappedRange();new Uint8Array(d).set(new Uint8Array(r,i,a)),u.unmap();let p=this.backend.device.createCommandEncoder();p.copyBufferToBuffer(u,0,o.gpuData.buffer,0,s),this.backend.device.queue.submit([p.finish()]),u.destroy(),Ne("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw new Error("source gpu data for memcpy does not exist");let i=this.storageCache.get(t);if(!i)throw new Error("destination gpu data for memcpy does not exist");if(r.originalSize!==i.originalSize)throw new Error("inconsistent source and destination gpu data size");let a=Mo(r.originalSize),s=this.backend.getCommandEncoder();this.backend.endComputePass(),s.copyBufferToBuffer(r.gpuData.buffer,0,i.gpuData.buffer,0,a)}registerExternalBuffer(e,t,r){let i;if(r){if(i=r[0],e===r[1])return Ne("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, buffer is the same, skip.`),i;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw new Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else i=wp();return this.storageCache.set(i,{gpuData:{id:i,type:0,buffer:e},originalSize:t}),Ne("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, registered.`),i}unregisterExternalBuffer(e){e!==void 0&&(this.storageCache.delete(e),Ne("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r=gm(e),i,a=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,s=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(a||s){let u=(a?this.freeBuffers:this.freeUniformBuffers).get(r);u?u.length>0?i=u.pop():i=this.backend.device.createBuffer({size:r,usage:t}):i=this.backend.device.createBuffer({size:r,usage:t})}else i=this.backend.device.createBuffer({size:r,usage:t});let o={id:wp(),type:0,buffer:i};return this.storageCache.set(o.id,{gpuData:o,originalSize:Number(e)}),Ne("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${o.id}`),o}get(e){return this.storageCache.get(e)?.gpuData}release(e){let t=typeof e=="bigint"?Number(e):e,r=this.storageCache.get(t);if(!r){if(this.storageCache.size===0)return 0;throw new Error("releasing data does not exist")}return Ne("verbose",()=>`[WebGPU] GpuDataManager.release(id=${t}), gpuDataId=${r.gpuData.id}`),this.storageCache.delete(t),this.buffersPending.push(r.gpuData.buffer),r.originalSize}async download(e,t){let r=this.storageCache.get(Number(e));if(!r)throw new Error("data does not exist");await rc(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){if(this.buffersPending.length!==0)if(this.backend.sessionStatus==="default"){for(let e of this.buffersPending){let t=vp.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e));for(let t of this.buffersPending)e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onCreateSession(){this.sessionCount+=1}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(r=>{r.destroy()}),this.capturedPendingBuffers.delete(e)),this.sessionCount-=1,this.sessionCount===0&&(Ne("warning",()=>"[WebGPU] Clearing webgpu buffer cache"),this.storageCache.forEach(r=>{r.gpuData.buffer.destroy()}),this.storageCache=new Map)}},o0=(...e)=>new _m(...e)}),et=ee(()=>{"use strict";vm=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},je=e=>new vm(e)}),Te=ee(()=>{"use strict";wm=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},ia=class{static calcShape(e,t,r=!1){let i=e.length,a=t.length;if(i===0)return t;if(a===0)return e;let s=Math.max(e.length,t.length),o=new Array(s);if(r){if(i<2||a<2)return;let u=wm.calcMatMulShape([e[i-2],e[i-1]],[t[a-2],t[a-1]]);if(u===void 0)return;[o[s-2],o[s-1]]=u}for(let u=r?3:1;u<=s;u++){let d=i-u<0?1:e[i-u],p=a-u<0?1:t[a-u];if(d!==p&&d>1&&p>1)return;let m=Math.max(d,p);if(d&&p)o[s-u]=Math.max(d,p);else{if(m>1)return;o[s-u]=0}}return o}static isValidBroadcast(e,t){let r=e.length,i=t.length;if(r>i)return!1;for(let a=1;a<=r;a++)if(e[r-a]!==1&&e[r-a]!==t[i-a])return!1;return!0}},L=class Fo{static size(t){return Fo.getSizeFromDimensionRange(t,0,t.length)}static convertShape(t,r=4){let i=t.length;if(i===0)return[];let a=new Array(i),s=i-1;for(;s>=0;){if(t[s]%r===0){a[s]=t[s]/r;break}if(r%t[s]!==0)throw new Error("cannot convert shape");a[s]=1,r/=t[s],s--}for(s--;s>=0;s--)a[s]=t[s];return a}static sizeFromDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return Fo.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return Fo.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(t,r,i){let a=1;for(let s=r;s<i;s++){if(t[s]<0)throw new Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");a*=Number(t[s])}return a}static computeStrides(t){let r=t.length;if(r===0)return[];if(r===1)return[1];let i=new Array(r);i[r-1]=1,i[r-2]=t[r-1];for(let a=r-3;a>=0;--a)i[a]=i[a+1]*t[a+1];return i}static normalizeAxis(t,r){if(t<-r&&t>=r)throw new Error("unsupported axis for this operation.");return t<0?t+r:t}static normalizeAxes(t,r){return t.map(i=>this.normalizeAxis(i,r??t.length))}static sortBasedOnPerm(t,r){return r?r.map(i=>t[i]):t.slice().reverse()}static padShape(t,r){let i=t.length;return t.map((a,s)=>a+r[s]+r[s+i])}static areEqual(t,r){return t.length!==r.length?!1:t.every((i,a)=>i===r[a])}},Xo=class Ms{static adjustPoolAttributes(t,r,i,a,s,o){if(!t&&i.length!==r.length-2)throw new Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(t)for(let u=0;u<r.length-2;u++)u>=i.length?i.push(r[u+2]):i[u]=r[u+2];for(let u=0;u<i.length;u++)if(u<a.length){if(a[u]<0)throw new Error("strides should be greater than or equal to 1")}else a.push(1);for(let u=0;u<i.length;u++)if(u<s.length){if(s[u]<0)throw new Error("dilations should be greater than or equal to 1")}else s.push(1);for(let u=0;u<i.length*2;u++)if(u<o.length){if(o[u]<0)throw new Error("pad should be greater than or equal to 1")}else o.push(0);for(let u=0;u<i.length;u++){if(i[u]<=0)throw new Error("kernel shapes need to be greater than 0");if(o[u]>=i[u]||o[u+i.length]>=i[u])throw new Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,i,a,s,o,u){if(u){if(s.length!==2*(t.length-2))throw new Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw new Error("length of strides should be the length of data dimensions");if(a.length!==t.length-2)throw new Error("length of kernel shapes should be the length of data dimensions");for(let d=0;d<t.length-2;d++)Ms.adjustPadAndReturnShape(t[d+(o?1:2)],r[d],i[d],a[d],s,d,d+t.length-2,u)}}static computePoolOutputShape(t,r,i,a,s,o,u){if(r.length<=0)throw new Error("input shape must be of size greater than 0");let d=[r[0],r[1]];return Ms.computeShapeHelper(t,r,d,i,a,s,o,u),d}static computeConvOutputShape(t,r,i,a,s,o,u){if(t.length<=0||r.length<=0)throw new Error("invalid input tensor dims or invalid filter tensor dims");let d=[t[0],r[0]];return Ms.computeShapeHelper(!1,t,d,i,a,s,o,u),d}static computeShapeHelper(t,r,i,a,s,o,u,d){if(t)for(let p=0;p<r.length-2;p++)i.push(1);else for(let p=0;p<r.length-2;p++)i.push(Ms.adjustPadAndReturnShape(r[p+2],a[p],s[p],o[p],u,p,p+r.length-2,d))}static adjustPadAndReturnShape(t,r,i,a,s,o,u,d){let p=i*(a-1)+1;if(d&&d!=="NOTSET")switch(d){case"VALID":return s[o]=0,s[u]=0,Math.floor((t-p)/r+1);case"SAME_LOWER":case"SAME_UPPER":if(i!==1)throw new Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let m=((t+r-1)/r-1)*r+a-t;return s[o]=Math.floor(d==="SAME_LOWER"?(m+1)/2:m/2),s[u]=m-s[o],Math.floor((t+m-a)/r+1)}default:throw new Error("Unsupported AutoPad type")}else return Math.floor((t+s[o]+s[u]-p)/r+1)}},u0=class{static getShapeOfGemmResult(e,t,r,i,a){if(e.length!==2||r.length!==2)throw new Error("shape need to be of size 2");let s,o,u;t?(s=e[1],o=e[0]):(s=e[0],o=e[1]);let d=-1;if(i?(u=r[0],d=1):(u=r[1],d=0),r[d]!==o)throw new Error("dimension mismatch");if(s<=0||u<=0||o<=0)throw new Error("invalid shape specified");if(a&&!ia.isValidBroadcast(a,[s,u]))throw new Error("gemm: invalid bias shape for broadcast");return[s,u,o]}},l0=-34028234663852886e22,d0=34028234663852886e22}),Ee=ee(()=>{"use strict";be(),Te(),aa=64,Do=(e,t)=>{if(t===3)throw new Error("vec3 has same alignment as vec4, use vec4 instead");switch(Number(e)){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(t!==4)throw new Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw new Error(`Unknown data type: ${e}`)}},dt=(e,t=1)=>{let r=Do(e,t);return typeof r=="string"?r:r[0]},xt=(e,t=1)=>{let r=Do(e,t);return typeof r=="string"?r:r[1]},ye=(...e)=>{let t=[];return e.forEach(r=>{r.length!==0&&t.push({type:12,data:r},{type:12,data:L.computeStrides(r)})}),t},Je=e=>e%4===0?4:e%2===0?2:1,ic=(e="f32",t,r="0")=>!t||t===1?`${e}(${r})`:`vec${t}<${e}>(${r})`,ra=(e,t,r)=>e==="f32"?r:t===1?`f32(${r})`:`vec${t}<f32>(${r})`,Fr=(e,t)=>t===4?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:t===2?`(${e}.x + ${e}.y)`:t===3?`(${e}.x + ${e}.y + ${e}.z)`:e,me=(e,t,r,i)=>e.startsWith("uniforms.")&&r>4?typeof t=="string"?i==="f16"?`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`:`${e}[(${t}) / 4][(${t}) % 4]`:i==="f16"?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`:r>1?`${e}[${t}]`:e,Is=(e,t,r,i,a)=>{let s=typeof r=="number",o=s?r:r.length,u=[...new Array(o).keys()],d=o<2?"u32":o<=4?`vec${o}<u32>`:`array<u32, ${o}>`,p=Do(t,a),m=typeof p=="string"?p:p[1],f=typeof p=="string"?p:p[0],g={indices:d,value:m,storage:f,tensor:t},v=M=>typeof M=="string"?M:`${M}u`,_={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},b=s?"uniforms.":"",k=`${b}${e}_shape`,$=`${b}${e}_strides`,w="";for(let M=0;M<o-1;M++)w+=`
    let dim${M} = current / ${me($,M,o)};
    let rest${M} = current % ${me($,M,o)};
    indices[${M}] = dim${M};
    current = rest${M};
    `;w+=`indices[${o-1}] = current;`;let S=o<2?"":`
  fn o2i_${e}(offset: u32) -> ${g.indices} {
    var indices: ${g.indices};
    var current = offset;
    ${w}
    return indices;
  }`,C=M=>(_.offsetToIndices=!0,o<2?M:`o2i_${e}(${M})`),I=[];if(o>=2)for(let M=o-1;M>=0;M--)I.push(`${me($,M,o)} * (indices[${M}])`);let z=o<2?"":`
  fn i2o_${e}(indices: ${g.indices}) -> u32 {
    return ${I.join("+")};
  }`,E=M=>(_.indicesToOffset=!0,o<2?M:`i2o_${e}(${M})`),B=(...M)=>o===0?"0u":`${g.indices}(${M.map(v).join(",")})`,U=(M,q)=>o<2?`${M}`:`${me(M,q,o)}`,V=(M,q,R)=>o<2?`${M}=${R};`:`${me(M,q,o)}=${R};`,W={},J=(M,q)=>{_.broadcastedIndicesToOffset=!0;let R=`${q.name}broadcastedIndicesTo${e}Offset`;if(R in W)return`${R}(${M})`;let X=[];for(let Ie=o-1;Ie>=0;Ie--){let Fe=q.indicesGet("outputIndices",Ie+q.rank-o);X.push(`${U($,Ie)} * (${Fe} % ${U(k,Ie)})`)}return W[R]=`fn ${R}(outputIndices: ${q.type.indices}) -> u32 {
             return ${X.length>0?X.join("+"):"0u"};
           }`,`${R}(${M})`},D=(M,q)=>(()=>{if(g.storage===g.value)return`${e}[${M}]=${q};`;if(g.storage==="vec2<u32>"&&g.value==="i32")return`${e}[${M}]=vec2<u32>(u32(${q}), select(0u, 0xFFFFFFFFu, ${q} < 0));`;if(g.storage==="vec2<u32>"&&g.value==="u32")return`${e}[${M}]=vec2<u32>(u32(${q}), 0u);`;if(g.storage==="u32"&&g.value==="vec4<bool>")return`${e}[${M}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${q}));`;throw new Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),se=M=>(()=>{if(g.storage===g.value)return`${e}[${M}]`;if(g.storage==="vec2<u32>"&&g.value==="i32")return`i32(${e}[${M}].x)`;if(g.storage==="vec2<u32>"&&g.value==="u32")return`u32(${e}[${M}].x)`;if(g.storage==="u32"&&g.value==="vec4<bool>")return`vec4<bool>(bool(${e}[${M}] & 0xFFu), bool(${e}[${M}] & 0xFF00u), bool(${e}[${M}] & 0xFF0000u), bool(${e}[${M}] & 0xFF000000u))`;throw new Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),ue=o<2?"":`
  fn get_${e}ByIndices(indices: ${g.indices}) -> ${m} {
    return ${se(`i2o_${e}(indices)`)};
  }`,F=o<2?"":(()=>{let M=u.map(R=>`d${R}: u32`).join(", "),q=u.map(R=>`d${R}`).join(", ");return`
  fn get_${e}(${M}) -> ${m} {
    return get_${e}ByIndices(${B(q)});
  }`})(),oe=(...M)=>{if(M.length!==o)throw new Error(`indices length must be ${o}`);let q=M.map(v).join(",");return o===0?se("0u"):o===1?se(q[0]):(_.get=!0,_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}(${q})`)},le=M=>o<2?se(M):(_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}ByIndices(${M})`),H=o<2?"":`
  fn set_${e}ByIndices(indices: ${g.indices}, value: ${m}) {
    ${D(`i2o_${e}(indices)`,"value")}
  }`,de=o<2?"":(()=>{let M=u.map(R=>`d${R}: u32`).join(", "),q=u.map(R=>`d${R}`).join(", ");return`
  fn set_${e}(${M}, value: ${m}) {
    set_${e}ByIndices(${B(q)}, value);
  }`})();return{impl:()=>{let M=[],q=!1;return _.offsetToIndices&&(M.push(S),q=!0),_.indicesToOffset&&(M.push(z),q=!0),_.broadcastedIndicesToOffset&&(Object.values(W).forEach(R=>M.push(R)),q=!0),_.set&&(M.push(de),q=!0),_.setByIndices&&(M.push(H),q=!0),_.get&&(M.push(F),q=!0),_.getByIndices&&(M.push(ue),q=!0),!s&&q&&M.unshift(`const ${k} = ${g.indices}(${r.join(",")});`,`const ${$} = ${g.indices}(${L.computeStrides(r).join(",")});`),M.join(`
`)},type:g,offsetToIndices:C,indicesToOffset:E,broadcastedIndicesToOffset:J,indices:B,indicesGet:U,indicesSet:V,set:(...M)=>{if(M.length!==o+1)throw new Error(`indices length must be ${o}`);let q=M[o];if(typeof q!="string")throw new Error("value must be string");let R=M.slice(0,o).map(v).join(",");return o===0?D("0u",q):o===1?D(R[0],q):(_.set=!0,_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}(${R}, ${q})`)},setByOffset:D,setByIndices:(M,q)=>o<2?D(M,q):(_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}ByIndices(${M}, ${q});`),get:oe,getByOffset:se,getByIndices:le,usage:i,name:e,strides:$,shape:k,rank:o}},K=(e,t,r,i=1)=>Is(e,t,r,"input",i),he=(e,t,r,i=1)=>Is(e,t,r,"output",i),p0=(e,t,r)=>Is(e,t,r,"atomicOutput",1),Ec=(e,t,r,i=1)=>Is(e,t,r,"internal",i),bm=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){return`if (global_idx >= ${typeof e=="number"?`${e}u`:e}) { return; }`}mainStart(e=aa){let t=typeof e=="number"?e:e[0],r=typeof e=="number"?1:e[1],i=typeof e=="number"?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||i>this.limits.maxComputeWorkgroupSizeZ)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*i>this.limits.maxComputeInvocationsPerWorkgroup)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let a=this.normalizedDispatchGroup[1]===1&&this.normalizedDispatchGroup[2]===1,s=a?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,o=a?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*i}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${i})
  fn main(${s}) {
    ${o}
  `}appendVariableUniforms(e){e.rank!==0&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if(e.usage==="internal")throw new Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r=e.usage==="input"?"read":"read_write",i=e.usage==="atomicOutput"?"atomic<i32>":e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${i}>;`}declareVariables(...e){return e.map(t=>this.declareVariable(t,this.variableIndex++)).join(`
`)}registerInternalVariable(e){if(e.usage!=="internal")throw new Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(t=>this.registerInternalVariable(t)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(this.uniforms.length===0)return"";let e=[];for(let{name:t,type:r,length:i}of this.uniforms)if(i&&i>4)r==="f16"?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(i/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(i/4)}>`);else{let a=i==null||i===1?r:`vec${i}<${r}>`;e.push(`${t}:${a}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join(`
`)+this.internalVariables.map(e=>e.impl()).join(`
`)}get variablesInfo(){if(this.uniforms.length===0)return;let e=t=>[12,10,1,6][["u32","f16","f32","i32"].indexOf(t)];return this.uniforms.map(t=>[e(t.type),t.length??1])}},c0=(e,t)=>new bm(e,t)}),Hr=ee(()=>{"use strict";be(),Te(),et(),Ee(),$m=(e,t)=>{if(!e||e.length!==1)throw new Error("Transpose requires 1 input.");if(t.length!==0&&t.length!==e[0].dims.length)throw new Error(`perm size ${t.length} does not match input rank ${e[0].dims.length}`)},bp=(e,t)=>t.length!==0?t:[...new Array(e).keys()].reverse(),xm=(e,t)=>L.sortBasedOnPerm(e,bp(e.length,t)),km=(e,t,r,i)=>{let a=`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let s=0;s<t;++s)a+=`a[${e[s]}]=i[${s}];`;return a+="return a;}"},Sm=(e,t)=>{let r=[],i=[];for(let a=0;a<e.length;++a)e[a]!==1&&r.push(e[a]),e[t[a]]!==1&&i.push(t[a]);return{newShape:r,newPerm:i}},Tm=(e,t)=>{let r=0;for(let i=0;i<e.length;++i)if(t[e[i]]!==1){if(e[i]<r)return!1;r=e[i]}return!0},Mt=(e,t)=>{let r=e.dataType,i=e.dims.length,a=bp(i,t),s=xm(e.dims,a),o=e.dims,u=s,d=i<2||Tm(a,e.dims),p;if(d)return p=_=>{let b=K("input",r,o,4),k=he("output",r,u,4);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,k)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    output[global_idx] = input[global_idx];
  }`},{name:"TransposeCopy",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let _=L.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64/4)},programUniforms:[{type:12,data:Math.ceil(_/4)}]}},getShaderSource:p};let{newShape:m,newPerm:f}=Sm(e.dims,a),g=L.areEqual(f,[2,3,1]),v=L.areEqual(f,[3,1,2]);if(m.length===2||g||v){o=g?[m[0],m[1]*m[2]]:v?[m[0]*m[1],m[2]]:m,u=[o[1],o[0]];let _=16;return p=b=>{let k=K("a",r,o.length),$=he("output",r,u.length);return`
  ${b.registerUniform("output_size","u32").declareVariables(k,$)}
  var<workgroup> tile : array<array<${$.type.value}, ${_+1}>, ${_}>;
  ${b.mainStart([_,_,1])}
    let stride = (uniforms.output_shape[1] - 1) / ${_} + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * ${_}u + local_id.x;
    let input_row = workgroup_id_x * ${_}u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${k.getByIndices(`${k.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * ${_}u + local_id.x;
    let output_row = workgroup_id_y * ${_}u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${$.setByIndices(`${$.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`},{name:"TransposeShared",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let b=L.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(u[1]/_),y:Math.ceil(u[0]/_)},programUniforms:[{type:12,data:b},...ye(o,u)]}},getShaderSource:p}}return p=_=>{let b=K("a",r,o.length),k=he("output",r,u.length);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,k)}

  ${km(a,i,b,k)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${k.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${k.setByOffset("global_idx",b.getByIndices("aIndices"))}
  }`},{name:"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let _=L.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},...ye(o,u)]}},getShaderSource:p}},h0=(e,t)=>{$m(e.inputs,t.perm),e.compute(Mt(e.inputs[0],t.perm))},f0=e=>je({perm:e.perm})}),LT=ee(()=>{"use strict";be(),Te(),Ee(),zc(),Hr(),Cm={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},Im={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},Em={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},zm={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},Am=(e,t)=>{let r=[];for(let i=t-e;i<t;++i)r.push(i);return r},Om=(e,t)=>{let r=[],i=e.length;for(let s=0;s<i;s++)t.indexOf(s)===-1&&r.push(e[s]);let a=t.map(s=>e[s]);return[r,a]},Rm=(e,t)=>{let r=e.length+t.length,i=[],a=0;for(let s=0;s<r;s++)t.indexOf(s)===-1?i.push(e[a++]):i.push(1);return i},Bm=(e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0},Nm=(e,t)=>{let r=[];if(!Bm(e,t)){for(let i=0;i<t;++i)e.indexOf(i)===-1&&r.push(i);e.forEach(i=>r.push(i))}return r},Mm=(e,t,r,i,a,s,o)=>{let u=r[0].dims,d=L.size(s),p=L.size(o),m=K("_A",r[0].dataType,u),f=he("output",a,s),g=64;d===1&&(g=256);let v=`
          var<workgroup> aBestValues : array<f32, ${g}>;
       `,_=b=>`
        ${b.registerUniform("reduceSize","u32").declareVariables(m,f)}
        ${v}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${b.mainStart(g)}

          let outputIndex = global_idx / ${g};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${Em[i]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${g}) {
           let candidate = f32(${m.getByOffset("offset + k")});
           bestValue = ${Cm[i]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${g}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${Im[i]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${f.setByOffset("outputIndex",`${i==="mean"?`${f.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${f.type.storage}(${zm[i]})`}`)};
         }
        }`;return{name:e,shaderCache:{hint:`${t};${g}`,inputDependencies:["type"]},getShaderSource:_,getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:d},programUniforms:[{type:12,data:p}]})}},Yt=(e,t,r,i)=>{let a=e.inputs.length===1?r:ac(e.inputs,r),s=a.axes;s.length===0&&!a.noopWithEmptyAxes&&(s=e.inputs[0].dims.map((v,_)=>_));let o=L.normalizeAxes(s,e.inputs[0].dims.length),u=o,d=e.inputs[0],p=Nm(u,e.inputs[0].dims.length);p.length>0&&(d=e.compute(Mt(e.inputs[0],p),{inputs:[0],outputs:[-1]})[0],u=Am(u.length,d.dims.length));let[m,f]=Om(d.dims,u),g=m;a.keepDims&&(g=Rm(m,o)),e.compute(Mm(t,a.cacheKey,[d],i,e.inputs[0].dataType,g,f),{inputs:[d]})},m0=(e,t)=>{Yt(e,"ReduceMeanShared",t,"mean")},g0=(e,t)=>{Yt(e,"ReduceL1Shared",t,"l1")},y0=(e,t)=>{Yt(e,"ReduceL2Shared",t,"l2")},_0=(e,t)=>{Yt(e,"ReduceLogSumExpShared",t,"logSumExp")},v0=(e,t)=>{Yt(e,"ReduceMaxShared",t,"max")},w0=(e,t)=>{Yt(e,"ReduceMinShared",t,"min")},b0=(e,t)=>{Yt(e,"ReduceProdShared",t,"prod")},$0=(e,t)=>{Yt(e,"ReduceSumShared",t,"sum")},x0=(e,t)=>{Yt(e,"ReduceSumSquareShared",t,"sumSquare")},k0=(e,t)=>{Yt(e,"ReduceLogSumShared",t,"logSum")}}),zc=ee(()=>{"use strict";be(),Te(),et(),Ee(),LT(),er=e=>{if(!e||e.length===0||e.length>2)throw new Error("Reduce op requires 1 or 2 inputs.");if(e.length===2&&e[1].dims.length!==1)throw new Error("Invalid axes input dims.")},Dm=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],Jo=(e,t,r,i,a,s,o=!1,u=!1)=>{let d=[],p=r[0].dims,m=p.length,f=L.normalizeAxes(a,m),g=!u&&f.length===0;p.forEach((b,k)=>{g||f.indexOf(k)>=0?o&&d.push(1):d.push(b)});let v=d.length,_=L.size(d);return{name:e,shaderCache:t,getShaderSource:b=>{let k=[],$=K("_A",r[0].dataType,m),w=he("output",s,v),S=i($,w,f),C=S[2];for(let I=0,z=0;I<m;I++)g||f.indexOf(I)>=0?(o&&z++,C=`for(var j${I}: u32 = 0; j${I} < ${p[I]}; j${I}++) {
                  ${S[2].includes("last_index")?`let last_index = j${I};`:""}
                  ${$.indicesSet("input_indices",I,`j${I}`)}
                  ${C}
                }`):(k.push(`${$.indicesSet("input_indices",I,w.indicesGet("output_indices",z))};`),z++);return`

        ${b.registerUniform("output_size","u32").declareVariables($,w)}

        ${b.mainStart()}
          ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${$.type.indices};
          let output_indices = ${w.offsetToIndices("global_idx")};

          ${k.join(`
`)}
          ${S[0]}       // init ops for reduce max/min
          ${S[1]}
          ${C}
          ${S[3]}
          ${S.length===4?w.setByOffset("global_idx","value"):S.slice(4).join(`
`)}
        }`},getRunData:()=>({outputs:[{dims:d,dataType:s}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},...ye(p,d)]})}},ac=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(i=>r.push(Number(i))),je({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},tr=(e,t,r,i)=>{let a=e.inputs,s=a.length===1?r:ac(a,r);e.compute(Jo(t,{hint:s.cacheKey,inputDependencies:["rank"]},[a[0]],s.noopWithEmptyAxes&&s.axes.length===0?Dm:i,s.axes,a[0].dataType,s.keepDims,s.noopWithEmptyAxes),{inputs:[0]})},Pm=(e,t)=>{er(e.inputs),tr(e,"ReduceLogSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,"value = log(value);"])},Um=(e,t)=>{er(e.inputs),tr(e,"ReduceL1",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += abs(${r.getByIndices("input_indices")});`,""])},Wm=(e,t)=>{er(e.inputs),tr(e,"ReduceL2",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"])},Vm=(e,t)=>{er(e.inputs),tr(e,"ReduceLogSumExp",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += exp(${r.getByIndices("input_indices")});`,"value = log(value);"])},qm=(e,t)=>{er(e.inputs),tr(e,"ReduceMax",t,(r,i,a)=>{let s=[];for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&s.push(r.indicesSet("input_indices",o,0));return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = max(value, ${r.getByIndices("input_indices")});`,""]})},jm=(e,t)=>{er(e.inputs),tr(e,"ReduceMean",t,(r,i,a)=>{let s=1;for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&(s*=e.inputs[0].dims[o]);return["var sum = f32(0);","",`sum += f32(${r.getByIndices("input_indices")});`,`let value = ${i.type.value}(sum / ${s});`]})},Lm=(e,t)=>{er(e.inputs),tr(e,"ReduceMin",t,(r,i,a)=>{let s=[];for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&s.push(`input_indices[${o}] = 0;`);return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = min(value, ${r.getByIndices("input_indices")});`,""]})},Gm=(e,t)=>{er(e.inputs),tr(e,"ReduceProd",t,(r,i)=>[`var value = ${i.type.storage}(1);`,"",`value *= ${r.getByIndices("input_indices")};`,""])},Fm=(e,t)=>{er(e.inputs),tr(e,"ReduceSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,""])},Hm=(e,t)=>{er(e.inputs),tr(e,"ReduceSumSquare",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += t * t;`,""])},rr=(e,t,r)=>{if(t.length===0)return r;let i=1,a=1;for(let s=0;s<t.length;s++)t.indexOf(s)===-1?i*=e[s]:a*=e[s];return a<32&&i>1024},S0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?jm(e,t):m0(e,t)},T0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Um(e,t):g0(e,t)},C0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Wm(e,t):y0(e,t)},I0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Vm(e,t):_0(e,t)},E0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?qm(e,t):v0(e,t)},z0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Lm(e,t):w0(e,t)},A0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Gm(e,t):b0(e,t)},O0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Fm(e,t):$0(e,t)},R0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Hm(e,t):x0(e,t)},B0=(e,t)=>{rr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Pm(e,t):k0(e,t)}}),GT=ee(()=>{"use strict";be(),et(),zc(),$p=e=>{if(!e||e.length===0||e.length>2)throw new Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(e[0].dataType!==1)throw new Error("Invalid input type.")},N0=(e,t)=>{$p(e.inputs);let r=(i,a,s)=>{let o=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&o.push(`input_indices[${u}] = 0;`);return[`${o.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Jo("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},M0=(e,t)=>{$p(e.inputs);let r=(i,a,s)=>{let o=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&o.push(`input_indices[${u}] = 0;`);return[`${o.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(Jo("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},nc=e=>je(e)}),Ac=ee(()=>{"use strict";be(),Te(),Ic(),Ee(),Km=(e,t)=>{let r=e[0],i=e[1],a=e[2],s=e[3],o=e[4],u=e[5];if(o&&u)throw new Error("Attention cannot have both past and attention_bias");if(r.dims.length!==3)throw new Error('Input "input" must have 3 dimensions');let d=r.dims[0],p=r.dims[1],m=r.dims[2];if(a.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimensions');if(i.dims.length!==2)throw new Error('Input "weights" is expected to have 2 dimensions');if(i.dims[0]!==m)throw new Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(a.dims[0]!==i.dims[1])throw new Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let f=a.dims[0]/3,g=f,v=g;if(t.qkvHiddenSizes.length>0){if(t.qkvHiddenSizes.length!==3)throw new Error("qkv_hidden_sizes attribute should have 3 elements");for(let S of t.qkvHiddenSizes)if(S%t.numHeads!==0)throw new Error("qkv_hidden_sizes should be divisible by num_heads");f=t.qkvHiddenSizes[0],g=t.qkvHiddenSizes[1],v=t.qkvHiddenSizes[2]}let _=p;if(f!==g)throw new Error("qkv_hidden_sizes first element should be same as the second");if(a.dims[0]!==f+g+v)throw new Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let b=0;if(o){if(g!==v)throw new Error('Input "past" expect k_hidden_size == v_hidden_size');if(o.dims.length!==5)throw new Error('Input "past" must have 5 dimensions');if(o.dims[0]!==2)throw new Error('Input "past" first dimension must be 2');if(o.dims[1]!==d)throw new Error('Input "past" second dimension must be batch_size');if(o.dims[2]!==t.numHeads)throw new Error('Input "past" third dimension must be num_heads');if(o.dims[4]!==g/t.numHeads)throw new Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(b=o.dims[3])}let k=_+b,$=-1,w=0;if(s)throw new Error("Mask not supported");if(o)throw new Error("past is not supported");if(u){if(u.dims.length!==4)throw new Error('Input "attention_bias" must have 4 dimensions');if(u.dims[0]!==d||u.dims[1]!==t.numHeads||u.dims[2]!==p||u.dims[3]!==k)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:d,sequenceLength:p,pastSequenceLength:b,kvSequenceLength:_,totalSequenceLength:k,maxSequenceLength:$,inputHiddenSize:m,hiddenSize:f,vHiddenSize:v,headSize:Math.floor(f/t.numHeads),vHeadSize:Math.floor(v/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:w,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}},Po=(e,t,r)=>t&&e?`
      let total_sequence_length_input = u32(${t.getByOffset("0")});
      let present_sequence_length = max(total_sequence_length_input, uniforms.past_sequence_length);
      let is_subsequent_prompt: bool = sequence_length > 1 && sequence_length != total_sequence_length_input;
      let is_first_prompt: bool = is_subsequent_prompt == false && sequence_length == total_sequence_length_input;
      total_sequence_length = u32(${e?.getByOffset("batchIdx")}) + 1;
      var past_sequence_length: u32 = 0;
      if (is_first_prompt == false) {
        past_sequence_length = total_sequence_length - sequence_length;
      }
       `:`
    ${r?"let past_sequence_length = uniforms.past_sequence_length":""};
    let present_sequence_length = total_sequence_length;
    `,Zm=(e,t,r,i,a,s,o,u)=>{let d=Je(o?1:s),p=64,m=s/d;m<p&&(p=32);let f=Math.ceil(s/d/p),g=[{type:12,data:t},{type:12,data:r},{type:12,data:i},{type:12,data:a},{type:12,data:m},{type:12,data:f}],v=dt(e.dataType,d),_=xt(1,d),b=["type"];o&&b.push("type"),u&&b.push("type");let k=$=>{let w=he("x",e.dataType,e.dims,d),S=[w],C=o?K("seq_lens",o.dataType,o.dims):void 0;C&&S.push(C);let I=u?K("total_sequence_length_input",u.dataType,u.dims):void 0;I&&S.push(I);let z=xt(e.dataType),E=[{name:"batch_size",type:"u32"},{name:"num_heads",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"sequence_length",type:"u32"},{name:"total_sequence_length",type:"u32"},{name:"elements_per_thread",type:"u32"}];return`
  var<workgroup> thread_max: array<f32, ${p}>;
  var<workgroup> thread_sum: array<f32, ${p}>;
  ${$.registerUniforms(E).declareVariables(...S)}
  ${$.mainStart([p,1,1])}
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let sequence_length = uniforms.sequence_length;
    var total_sequence_length = uniforms.total_sequence_length;
    ${Po(C,I,!1)}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${p}) * uniforms.total_sequence_length + local_offset;
    let seq_causal_length = ${o?"u32(past_sequence_length + workgroup_id.y + 1)":"total_sequence_length"};
    var thread_max_vector = ${_}(-3.402823e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      thread_max_vector = max(${_}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(d){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.402823e+38f);
    for (var i = 0u; i < ${p}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${_}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      sum_vector += exp(${_}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(d){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${p}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        x[offset + i] = ${w.type.value}(${z}(1.0) / ${z}(seq_causal_length));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        var f32input = ${_}(x[offset + i]);
        x[offset + i] = ${w.type.value}(exp(f32input - max_value) / sum);
      }
    }
      ${o?`
        for (var total_seq_id: u32 = seq_causal_length; total_seq_id + local_offset < uniforms.total_sequence_length; total_seq_id++) {
          x[offset + total_seq_id] = ${w.type.value}(${z}(0));
        }`:""};
  }`};return{name:"AttentionProbsSoftmax",shaderCache:{hint:`${p};${v};${d}`,inputDependencies:b},getShaderSource:k,getRunData:()=>({outputs:[],dispatchGroup:{x:Math.ceil(s/p),y:a,z:t*r},programUniforms:g})}},Qm=(e,t,r,i,a,s,o,u,d)=>{let p=o+s.kvSequenceLength,m=[s.batchSize,s.numHeads,s.sequenceLength,p],f=e>1&&i,g=s.kvNumHeads?s.kvNumHeads:s.numHeads,v=f?[s.batchSize,g,p,s.headSize]:void 0,_=s.nReps?s.nReps:1,b=s.scale===0?1/Math.sqrt(s.headSize):s.scale,k=Je(s.headSize),$=s.headSize/k,w=12,S={x:Math.ceil(p/w),y:Math.ceil(s.sequenceLength/w),z:s.batchSize*s.numHeads},C=[{type:12,data:s.sequenceLength},{type:12,data:$},{type:12,data:p},{type:12,data:s.numHeads},{type:12,data:s.headSize},{type:1,data:b},{type:12,data:o},{type:12,data:s.kvSequenceLength},{type:12,data:_}],I=f&&i&&L.size(i.dims)>0,z=["type","type"];I&&z.push("type"),a&&z.push("type"),u&&z.push("type"),d&&z.push("type");let E=[{dims:m,dataType:t.dataType,gpuDataType:0}];f&&E.push({dims:v,dataType:t.dataType,gpuDataType:0});let B=U=>{let V=K("q",t.dataType,t.dims,k),W=K("key",r.dataType,r.dims,k),J=[V,W];if(I){let H=K("past_key",i.dataType,i.dims,k);J.push(H)}a&&J.push(K("attention_bias",a.dataType,a.dims));let D=u?K("seq_lens",u.dataType,u.dims):void 0;D&&J.push(D);let se=d?K("total_sequence_length_input",d.dataType,d.dims):void 0;se&&J.push(se);let ue=he("output",t.dataType,m),F=[ue];f&&F.push(he("present_key",t.dataType,v,k));let oe=xt(1,k),le=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${w}u;

  var<workgroup> tileQ: array<${V.type.storage}, ${w*w}>;
  var<workgroup> tileK: array<${V.type.storage}, ${w*w}>;
  ${U.registerUniforms(le).declareVariables(...J,...F)}
  ${U.mainStart([w,w,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let kvHeadIdx = ${_===1?"headIdx":"headIdx / uniforms.n_reps"};
    let kv_num_heads = ${_===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let sequence_length = uniforms.M;
    var total_sequence_length = uniforms.N;
    ${Po(D,se,!0)}
    let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx;
    let qOffset = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
    ${I&&f?"let pastKeyOffset = absKvHeadIdx * uniforms.past_sequence_length * uniforms.K;":""};
    let kOffset = absKvHeadIdx * uniforms.kv_sequence_length * uniforms.K;
    ${f?"let presentKeyOffset = absKvHeadIdx * uniforms.N * uniforms.K;":""}
    var value = ${oe}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${I&&f?`
              if (n + local_id.y < past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else if (n + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
                tileK[idx] = key[kOffset + (n + local_id.y - past_sequence_length) * uniforms.K + w + local_id.x];
              }`:`
          if (n + local_id.y < uniforms.kv_sequence_length) {
            tileK[idx] = key[kOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
          }`}
      ${f?`if (n + local_id.y < present_sequence_length) {
        present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];
      }`:""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
          value += ${oe}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    if (global_id.y < uniforms.M && global_id.x < total_sequence_length) {
      let headOffset = workgroup_id.z * uniforms.M * uniforms.N;
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch(k){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw new Error(`Unsupported components: ${k}`)}})()};
        output[outputIdx] = ${ue.type.value} (sum * uniforms.alpha) + ${a?"attention_bias[outputIdx]":"0.0"};
    }
  }`};return{name:"AttentionProbs",shaderCache:{hint:`${k};${a!==void 0};${i!==void 0};${e}`,inputDependencies:z},getRunData:()=>({outputs:E,dispatchGroup:S,programUniforms:C}),getShaderSource:B}},Xm=(e,t,r,i,a,s,o=void 0,u=void 0)=>{let d=s+a.kvSequenceLength,p=a.nReps?a.nReps:1,m=a.vHiddenSize*p,f=e>1&&i,g=a.kvNumHeads?a.kvNumHeads:a.numHeads,v=f?[a.batchSize,g,d,a.headSize]:void 0,_=[a.batchSize,a.sequenceLength,m],b=12,k={x:Math.ceil(a.vHeadSize/b),y:Math.ceil(a.sequenceLength/b),z:a.batchSize*a.numHeads},$=[{type:12,data:a.sequenceLength},{type:12,data:d},{type:12,data:a.vHeadSize},{type:12,data:a.numHeads},{type:12,data:a.headSize},{type:12,data:m},{type:12,data:s},{type:12,data:a.kvSequenceLength},{type:12,data:p}],w=f&&i&&L.size(i.dims)>0,S=["type","type"];w&&S.push("type"),o&&S.push("type"),u&&S.push("type");let C=[{dims:_,dataType:t.dataType,gpuDataType:0}];f&&C.push({dims:v,dataType:t.dataType,gpuDataType:0});let I=z=>{let E=K("probs",t.dataType,t.dims),B=K("v",r.dataType,r.dims),U=[E,B];w&&U.push(K("past_value",i.dataType,i.dims));let V=o?K("seq_lens",o.dataType,o.dims):void 0;o&&U.push(V);let W=u?K("total_sequence_length_input",u.dataType,u.dims):void 0;u&&U.push(W);let J=[he("output",t.dataType,_)];f&&J.push(he("present_value",t.dataType,v));let D=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${b}u;
  var<workgroup> tileQ: array<${E.type.value}, ${b*b}>;
  var<workgroup> tileV: array<${E.type.value}, ${b*b}>;
  ${z.registerUniforms(D).declareVariables(...U,...J)}
  ${z.mainStart([b,b,1])}
   let headIdx = workgroup_id.z % uniforms.num_heads;
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let kvHeadIdx = ${p===1?"headIdx":"headIdx / uniforms.n_reps"};
   let kv_num_heads = ${p===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
   let m = global_id.y;
   let n = global_id.x;
   let sequence_length = uniforms.M;
   var total_sequence_length = uniforms.K;
   ${Po(V,W,!0)}
   let offsetA = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
   let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx; // kvHeadIdx is relative to the batch
   ${w&&f?"let pastValueOffset = absKvHeadIdx * uniforms.N * uniforms.past_sequence_length + n;":""};
   let vOffset = absKvHeadIdx * uniforms.N * uniforms.kv_sequence_length + n;
   ${f?"let presentValueOffset = absKvHeadIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${E.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${w&&f?`
        if (w + local_id.y < past_sequence_length) {
          tileV[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else if (w + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
          tileV[idx] = v[vOffset + (w + local_id.y - past_sequence_length) * uniforms.N];
        }
      `:`
            if (w + local_id.y < uniforms.kv_sequence_length) {
              tileV[idx] = v[vOffset + (w + local_id.y) * uniforms.N];
            }`}
        ${f?`
            if (w + local_id.y < present_sequence_length) {
          present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileV[idx];
        }`:""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < total_sequence_length; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileV[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + headIdx * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`};return{name:"AttentionScore",shaderCache:{hint:`${i!==void 0};${e}`,inputDependencies:S},getRunData:()=>({outputs:C,dispatchGroup:k,programUniforms:$}),getShaderSource:I}},Vs=(e,t,r,i,a,s,o,u,d,p,m=void 0,f=void 0)=>{let g=Math.min(e.outputCount,1+(o?1:0)+(u?1:0)),v=g>1?p.pastSequenceLength:0,_=v+p.kvSequenceLength,b=d&&L.size(d.dims)>0?d:void 0,k=[t,r];g>1&&o&&L.size(o.dims)>0&&k.push(o),b&&k.push(b),m&&k.push(m),f&&k.push(f);let $=e.compute(Qm(g,t,r,o,b,p,v,m,f),{inputs:k,outputs:g>1?[-1,1]:[-1]})[0];e.compute(Zm($,p.batchSize,p.numHeads,v,p.sequenceLength,_,m,f),{inputs:m&&f?[$,m,f]:[$],outputs:[]});let w=[$,i];g>1&&u&&L.size(u.dims)>0&&w.push(u),m&&w.push(m),f&&w.push(f),e.compute(Xm(g,$,i,u,p,v,m,f),{inputs:w,outputs:g>1?[0,2]:[0]})},Jm=(e,t)=>{let r=[t.batchSize,t.numHeads,t.sequenceLength,t.headSize],i=t.sequenceLength,a=t.inputHiddenSize,s=t.headSize,o=12,u={x:Math.ceil(t.headSize/o),y:Math.ceil(t.sequenceLength/o),z:t.batchSize*t.numHeads},d=[e.inputs[0],e.inputs[1],e.inputs[2]],p=[{type:12,data:i},{type:12,data:a},{type:12,data:s},{type:12,data:t.numHeads},{type:12,data:t.headSize},{type:12,data:t.hiddenSize},{type:12,data:t.hiddenSize+t.hiddenSize+t.vHiddenSize}],m=f=>{let g=he("output_q",d[0].dataType,r),v=he("output_k",d[0].dataType,r),_=he("output_v",d[0].dataType,r),b=K("input",d[0].dataType,d[0].dims),k=K("weight",d[1].dataType,d[1].dims),$=K("bias",d[2].dataType,d[2].dims),w=b.type.storage,S=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}];return`
  const TILE_SIZE = ${o}u;
  var<workgroup> tileInput: array<${w}, ${o*o}>;
  var<workgroup> tileWeightQ: array<${w}, ${o*o}>;
  var<workgroup> tileWeightK: array<${w}, ${o*o}>;
  var<workgroup> tileWeightV: array<${w}, ${o*o}>;
  ${f.registerUniforms(S).declareVariables(b,k,$,g,v,_)}
  ${f.mainStart([o,o,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${w}(0);
    var valueK = ${w}(0);
    var valueV = ${w}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`};return e.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0}],dispatchGroup:u,programUniforms:p}),getShaderSource:m},{inputs:d,outputs:[-1,-1,-1]})},D0=(e,t)=>{let r=Km(e.inputs,t),[i,a,s]=Jm(e,r);return Vs(e,i,a,s,e.inputs[4],void 0,void 0,void 0,e.inputs[5],r)}}),FT=ee(()=>{"use strict";sr(),be(),Te(),et(),Ee(),Ym=(e,t)=>{if(!e||e.length!==5)throw new Error("BatchNormalization requires 5 inputs");let r=(i,a,s)=>{let o=a.length;if(o!==i.length)throw new Error(`${s}: num dimensions != ${o}`);a.forEach((u,d)=>{if(u!==i[d])throw new Error(`${s}: dim[${d}] do not match`)})};if(e[0].dims.length>1){let i=t.format==="NHWC"?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,i,"Invalid input scale"),r(e[2].dims,i,"Invalid input B"),r(e[3].dims,i,"Invalid input mean"),r(e[4].dims,i,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")},eg=(e,t)=>{let{epsilon:r,spatial:i,format:a}=t,s=e[0].dims,o=i?Je(s[s.length-1]):1,u=a==="NHWC"&&s.length>1?o:1,d=L.size(s)/o,p=i,m=p?s.length:s,f=K("x",e[0].dataType,e[0].dims,o),g=K("scale",e[1].dataType,e[1].dims,u),v=K("bias",e[2].dataType,e[2].dims,u),_=K("inputMean",e[3].dataType,e[3].dims,u),b=K("inputVar",e[4].dataType,e[4].dims,u),k=he("y",e[0].dataType,m,o),$=()=>{let S="";if(i)S=`let cOffset = ${s.length===1?"0u":a==="NHWC"?`outputIndices[${s.length-1}] / ${o}`:"outputIndices[1]"};`;else if(a==="NCHW")S=`
            ${k.indicesSet("outputIndices","0","0")}
            let cOffset = ${k.indicesToOffset("outputIndices")};`;else{S=`var cIndices = ${g.type.indices}(0);
                       cIndices[0] = outputIndices[${s.length-1}];`;for(let C=1;C<g.rank;C++)S+=`cIndices[${C}] = outputIndices[${C}];`;S+=`let cOffset = ${g.indicesToOffset("cIndices")};`}return S},w=S=>`
  const epsilon = ${r};
  ${S.registerUniform("outputSize","u32").declareVariables(f,g,v,_,b,k)}
  ${S.mainStart()}
  ${S.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${k.offsetToIndices(`global_idx * ${o}`)};
    ${$()}
    let scale = ${g.getByOffset("cOffset")};
    let bias = ${v.getByOffset("cOffset")};
    let inputMean = ${_.getByOffset("cOffset")};
    let inputVar = ${b.getByOffset("cOffset")};
    let x = ${f.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${k.setByOffset("global_idx","value")}
  }`;return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${i}_${o}`,inputDependencies:p?["rank","type","type","type","type"]:void 0},getShaderSource:w,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p?[{type:12,data:d},...ye(s)]:[{type:12,data:d}]})}},tg=e=>je(e),P0=(e,t)=>{let{inputs:r,outputCount:i}=e,a=tg({...t,outputCount:i});if(Ke.webgpu.validateInputContent&&Ym(r,a),t.trainingMode)throw new Error("BatchNormalization trainingMode is not supported yet.");e.compute(eg(r,a))}}),HT=ee(()=>{"use strict";Te(),Ee(),rg=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![320,640,1280].includes(e[0].dims[2]))throw new Error("number of channels should be 320, 640 or 1280");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},ig=e=>{let t=e[0].dims,r=e[0].dims[2],i=L.size(t)/4,a=e[0].dataType,s=K("input",a,t,4),o=K("bias",a,[r],4),u=K("residual",a,t,4),d=he("output",a,t,4);return{name:"BiasAdd",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(i/64)}}),getShaderSource:p=>`
  const channels = ${r}u / 4;
  ${p.declareVariables(s,o,u,d)}

  ${p.mainStart()}
    ${p.guardAgainstOutOfBoundsWorkgroupSizes(i)}
    let value = ${s.getByOffset("global_idx")}
      + ${o.getByOffset("global_idx % channels")} + ${u.getByOffset("global_idx")};
    ${d.setByOffset("global_idx","value")}
  }`}},U0=e=>{rg(e.inputs),e.compute(ig(e.inputs))}}),Oc=ee(()=>{"use strict";be(),Te(),et(),Ee(),ag=(e,t,r,i,a,s,o)=>{let u=Math.ceil(t/4),d="";typeof a=="string"?d=`${a}(a)`:d=a("a");let p=K("inputData",r,[u],4),m=he("outputData",i,[u],4),f=[{name:"vec_size",type:"u32"}];return o&&f.push(...o),`
      ${e.registerUniforms(f).declareVariables(p,m)}

  ${s??""}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${p.getByOffset("global_idx")};
    ${m.setByOffset("global_idx",d)}
  }`},Pe=(e,t,r,i,a,s=e.dataType,o,u)=>{let d=[{type:12,data:Math.ceil(L.size(e.dims)/4)}];return o&&d.push(...o),{name:t,shaderCache:{hint:a,inputDependencies:["type"]},getShaderSource:p=>ag(p,L.size(e.dims),e.dataType,s,r,i,u),getRunData:p=>({outputs:[{dims:e.dims,dataType:s}],dispatchGroup:{x:Math.ceil(L.size(p[0].dims)/64/4)},programUniforms:d})}},W0=e=>{e.compute(Pe(e.inputs[0],"Abs","abs"))},V0=e=>{e.compute(Pe(e.inputs[0],"Acos","acos"))},q0=e=>{e.compute(Pe(e.inputs[0],"Acosh","acosh"))},j0=e=>{e.compute(Pe(e.inputs[0],"Asin","asin"))},L0=e=>{e.compute(Pe(e.inputs[0],"Asinh","asinh"))},G0=e=>{e.compute(Pe(e.inputs[0],"Atan","atan"))},F0=e=>{e.compute(Pe(e.inputs[0],"Atanh","atanh"))},H0=e=>je(e),K0=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw new RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(Pe(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},ng=e=>{let t,r,i=e.length>=2&&e[1].data!==0,a=e.length>=3&&e[2].data!==0;switch(e[0].dataType){case 1:t=i?e[1].getFloat32Array()[0]:-34028234663852886e22,r=a?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=i?e[1].getUint16Array()[0]:64511,r=a?e[2].getUint16Array()[0]:31743;break;default:throw new Error("Unsupport data type")}return je({min:t,max:r})},Z0=(e,t)=>{let r=t||ng(e.inputs),i=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"Clip",a=>`clamp(${a}, vec4<${i}>(uniforms.min), vec4<${i}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:i},{name:"max",type:i}]),{inputs:[0]})},Q0=e=>{e.compute(Pe(e.inputs[0],"Ceil","ceil"))},X0=e=>{e.compute(Pe(e.inputs[0],"Cos","cos"))},J0=e=>{e.compute(Pe(e.inputs[0],"Cosh","cosh"))},Ds=e=>je(e),Y0=(e,t)=>{let r=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"Elu",i=>`elu_vf32(${i})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},Ho=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,ev=e=>{let t=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"Erf",r=>`erf_vf32(${r})`,Ho(t)))},tv=e=>{e.compute(Pe(e.inputs[0],"Exp","exp"))},rv=e=>{e.compute(Pe(e.inputs[0],"Floor","floor"))},iv=e=>{let t=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"Gelu",r=>`0.5 * ${r} * (1.0 + erf_vf32(${r} * 0.7071067811865475))`,Ho(t)))},av=(e,t)=>{let r=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"LeakyRelu",i=>`select(leaky_relu_alpha_ * ${i}, ${i}, ${i} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},nv=e=>{e.compute(Pe(e.inputs[0],"Not",t=>`!${t}`))},sv=e=>{e.compute(Pe(e.inputs[0],"Neg",t=>`-${t}`))},ov=e=>{e.compute(Pe(e.inputs[0],"Reciprocal",t=>`1.0/${t}`))},uv=e=>{let t=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"Relu",r=>`select(vec4<${t}>(0.0), ${r}, ${r} > vec4<${t}>(0.0))`))},lv=e=>{e.compute(Pe(e.inputs[0],"Sigmoid",t=>`(1.0 / (1.0 + exp(-${t})))`))},dv=e=>je(e),pv=(e,t)=>{let r=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"HardSigmoid",i=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${i} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},cv=e=>{e.compute(Pe(e.inputs[0],"Sin","sin"))},hv=e=>{e.compute(Pe(e.inputs[0],"Sinh","sinh"))},fv=e=>{e.compute(Pe(e.inputs[0],"Sqrt","sqrt"))},mv=e=>{e.compute(Pe(e.inputs[0],"Tan","tan"))},xp=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,gv=e=>{e.compute(Pe(e.inputs[0],"Tanh",xp))},sc=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${xp("v")};
}
`,oc=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,yv=e=>{let t=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"FastGelu",oc,sc(t),void 0,e.inputs[0].dataType))},_v=(e,t)=>{let r=xt(e.inputs[0].dataType);return e.compute(Pe(e.inputs[0],"ThresholdedRelu",i=>`select(vec4<${r}>(0.0), ${i}, ${i} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},vv=e=>{e.compute(Pe(e.inputs[0],"Log","log"))},sg=(e,t)=>`
const alpha = vec4<${e}>(${t});
const one = ${e}(1.0);
const zero = ${e}(0.0);

fn quick_gelu_impl(x: vec4<${e}>) -> vec4<${e}> {
  let v = x *alpha;
  var x1 : vec4<${e}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`,og=e=>`quick_gelu_impl(${e})`,wv=(e,t)=>{let r=xt(e.inputs[0].dataType);e.compute(Pe(e.inputs[0],"QuickGelu",og,sg(r,t.alpha),t.cacheKey,e.inputs[0].dataType))}}),KT=ee(()=>{"use strict";Te(),Ee(),Oc(),ug=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![2560,5120,10240].includes(e[0].dims[2]))throw new Error("hidden state should be 2560, 5120 or 10240");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},lg=e=>{let t=e[0].dims.slice();t[2]=t[2]/2;let r=K("input",e[0].dataType,e[0].dims,4),i=K("bias",e[0].dataType,[e[0].dims[2]],4),a=he("output",e[0].dataType,t,4),s=L.size(t)/4,o=dt(e[0].dataType);return{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)}}),getShaderSource:u=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${e[0].dims[2]/4/2}u;

  ${u.declareVariables(r,i,a)}

  ${Ho(o)}

  ${u.mainStart()}
    ${u.guardAgainstOutOfBoundsWorkgroupSizes(s)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${a.setByOffset("global_idx","valueLeft * geluRight")}
  }`}},bv=e=>{ug(e.inputs),e.compute(lg(e.inputs))}}),ZT=ee(()=>{"use strict";be(),Te(),Ee(),dg=(e,t,r,i,a,s,o,u,d,p,m,f)=>{let g,v;typeof u=="string"?g=v=(w,S)=>`${u}((${w}),(${S}))`:typeof u=="function"?g=v=u:(g=u.scalar,v=u.vector);let _=he("outputData",m,i.length,4),b=K("aData",d,t.length,4),k=K("bData",p,r.length,4),$;if(a)if(s){let w=L.size(t)===1,S=L.size(r)===1,C=t.length>0&&t[t.length-1]%4===0,I=r.length>0&&r[r.length-1]%4===0;w||S?$=_.setByOffset("global_idx",v(w?`${b.type.value}(${b.getByOffset("0")}.x)`:b.getByOffset("global_idx"),S?`${k.type.value}(${k.getByOffset("0")}.x)`:k.getByOffset("global_idx"))):$=`
            let outputIndices = ${_.offsetToIndices("global_idx * 4u")};
            let offsetA = ${b.broadcastedIndicesToOffset("outputIndices",_)};
            let offsetB = ${k.broadcastedIndicesToOffset("outputIndices",_)};
            ${_.setByOffset("global_idx",v(o||C?b.getByOffset("offsetA / 4u"):`${b.type.value}(${b.getByOffset("offsetA / 4u")}[offsetA % 4u])`,o||I?k.getByOffset("offsetB / 4u"):`${k.type.value}(${k.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else $=_.setByOffset("global_idx",v(b.getByOffset("global_idx"),k.getByOffset("global_idx")));else{if(!s)throw new Error("no necessary to use scalar implementation for element-wise binary op implementation.");let w=(S,C,I="")=>{let z=`aData[indexA${C}][componentA${C}]`,E=`bData[indexB${C}][componentB${C}]`;return`
            let outputIndices${C} = ${_.offsetToIndices(`global_idx * 4u + ${C}u`)};
            let offsetA${C} = ${b.broadcastedIndicesToOffset(`outputIndices${C}`,_)};
            let offsetB${C} = ${k.broadcastedIndicesToOffset(`outputIndices${C}`,_)};
            let indexA${C} = offsetA${C} / 4u;
            let indexB${C} = offsetB${C} / 4u;
            let componentA${C} = offsetA${C} % 4u;
            let componentB${C} = offsetB${C} % 4u;
            ${S}[${C}] = ${I}(${g(z,E)});
          `};m===9?$=`
            var data = vec4<u32>(0);
            ${w("data",0,"u32")}
            ${w("data",1,"u32")}
            ${w("data",2,"u32")}
            ${w("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:$=`
            ${w("outputData[global_idx]",0)}
            ${w("outputData[global_idx]",1)}
            ${w("outputData[global_idx]",2)}
            ${w("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(b,k,_)}

        ${f??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${$}
      }`},pg=(e,t,r,i,a,s,o=r.dataType)=>{let u=r.dims.map(b=>Number(b)??1),d=i.dims.map(b=>Number(b)??1),p=!L.areEqual(u,d),m=u,f=L.size(u),g=!1,v=!1,_=[p];if(p){let b=ia.calcShape(u,d,!1);if(!b)throw new Error("Can't perform binary op on the given tensors");m=b.slice(),f=L.size(m);let k=L.size(u)===1,$=L.size(d)===1,w=u.length>0&&u[u.length-1]%4===0,S=d.length>0&&d[d.length-1]%4===0;_.push(k),_.push($),_.push(w),_.push(S);let C=1;for(let I=1;I<m.length;I++){let z=u[u.length-I],E=d[d.length-I];if(z===E)C*=z;else break}C%4===0?(v=!0,g=!0):(k||$||w||S)&&(g=!0)}else g=!0;return _.push(g),{name:e,shaderCache:{hint:t+_.map(b=>b.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:b=>dg(b,u,d,m,g,p,v,a,r.dataType,i.dataType,o,s),getRunData:()=>({outputs:[{dims:m,dataType:o}],dispatchGroup:{x:Math.ceil(f/64/4)},programUniforms:[{type:12,data:Math.ceil(L.size(m)/4)},...ye(u,d,m)]})}},ir=(e,t,r,i,a,s)=>{e.compute(pg(t,a??"",e.inputs[0],e.inputs[1],r,i,s))},$v=e=>{ir(e,"Add",(t,r)=>`${t}+${r}`)},xv=e=>{ir(e,"Div",(t,r)=>`${t}/${r}`)},kv=e=>{ir(e,"Equal",{scalar:(t,r)=>`u32(${t}==${r})`,vector:(t,r)=>`vec4<u32>(${t}==${r})`},void 0,void 0,9)},Sv=e=>{ir(e,"Mul",(t,r)=>`${t}*${r}`)},Tv=e=>{let t=K("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;ir(e,"Pow",{scalar:(r,i)=>`pow_custom(${r},${i})`,vector:(r,i)=>`pow_vector_custom(${r},${i})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${t==="i32"?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},Cv=e=>{ir(e,"Sub",(t,r)=>`${t}-${r}`)},Iv=e=>{ir(e,"Greater",{scalar:(t,r)=>`u32(${t}>${r})`,vector:(t,r)=>`vec4<u32>(${t}>${r})`},void 0,void 0,9)},Ev=e=>{ir(e,"Less",{scalar:(t,r)=>`u32(${t}<${r})`,vector:(t,r)=>`vec4<u32>(${t}<${r})`},void 0,void 0,9)},zv=e=>{ir(e,"GreaterOrEqual",{scalar:(t,r)=>`u32(${t}>=${r})`,vector:(t,r)=>`vec4<u32>(${t}>=${r})`},void 0,void 0,9)},Av=e=>{ir(e,"LessOrEqual",{scalar:(t,r)=>`u32(${t}<=${r})`,vector:(t,r)=>`vec4<u32>(${t}<=${r})`},void 0,void 0,9)}}),QT=ee(()=>{"use strict";be(),Te(),et(),Ee(),cg=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");let r=0,i=e[r],a=i.dataType,s=i.dims.length;e.forEach((o,u)=>{if(u!==r){if(o.dataType!==a)throw new Error("input tensors should be one type");if(o.dims.length!==s)throw new Error("input tensors should have the same shape");o.dims.forEach((d,p)=>{if(p!==t&&d!==i.dims[p])throw new Error("non concat dimensions must match")})}})},hg=(e,t)=>`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${e}u>(${t});
    for (var i: u32 = 0u; i < ${e}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${e}u;
  }`,fg=(e,t)=>{let r=e.length,i=[];for(let a=0;a<r;++a){let s=t.setByOffset("global_idx",e[a].getByIndices("indices"));r===1?i.push(s):a===0?i.push(`if (inputIndex == ${a}u) { ${s} }`):a===r-1?i.push(`else { ${s} }`):i.push(`else if (inputIndex == ${a}) { ${s} }`)}return i.join(`
`)},mg=(e,t,r,i)=>{let a=L.size(r),s=new Array(e.length),o=new Array(e.length),u=0,d=[],p=[],m=[{type:12,data:a}];for(let b=0;b<e.length;++b)u+=e[b].dims[t],s[b]=u,p.push(e[b].dims.length),o[b]=K(`input${b}`,i,p[b]),d.push("rank"),m.push({type:12,data:s[b]});for(let b=0;b<e.length;++b)m.push(...ye(e[b].dims));m.push(...ye(r));let f=he("output",i,r.length),g=f.indicesGet("indices",t),v=Array.from(Array(s.length).keys()).map(b=>`uniforms.sizeInConcatAxis${b}`).join(","),_=b=>`

  ${(()=>{b.registerUniform("outputSize","u32");for(let k=0;k<e.length;k++)b.registerUniform(`sizeInConcatAxis${k}`,"u32");return b.declareVariables(...o,f)})()}

  ${hg(s.length,v)}

  ${b.mainStart()}
    ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${f.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${g});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${s.length}u>(${v});
      ${g} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${fg(o,f)}
  }`;return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:d},getRunData:()=>({outputs:[{dims:r,dataType:i}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:m}),getShaderSource:_}},Ov=(e,t)=>{let r=e.inputs,i=r[0].dims,a=L.normalizeAxis(t.axis,i.length);cg(r,a);let s=i.slice();s[a]=r.reduce((u,d)=>u+(d.dims.length>a?d.dims[a]:0),0);let o=r.filter(u=>L.size(u.dims)>0);e.compute(mg(o,a,s,r[0].dataType),{inputs:o})},Rv=e=>je({axis:e.axis})}),Di=ee(()=>{"use strict";be(),Te(),Ri=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw new Error(`Unsupported activation ${e.activation}`)}},Bi=(e,t)=>{e.activation==="Clip"?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):e.activation==="HardSigmoid"?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):e.activation==="LeakyRelu"&&t.push({type:1,data:e.alpha})},Ni=(e,t)=>{e.activation==="Clip"?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):e.activation==="HardSigmoid"?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):e.activation==="LeakyRelu"&&t.push({name:"alpha",type:"f32"})},Rc=e=>{let t=e?.activation||"";if(t==="HardSigmoid"){let[r,i]=e?.activation_params||[.2,.5];return{activation:t,alpha:r,beta:i}}else if(t==="Clip"){let[r,i]=e?.activation_params||[l0,d0];return{activation:t,clipMax:i,clipMin:r}}else if(t==="LeakyRelu"){let[r]=e?.activation_params||[.01];return{activation:t,alpha:r}}return{activation:t}}}),Bc=ee(()=>{"use strict";ht=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw new Error(`${e}-component is not supported.`)}},Bv=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}),XT=ee(()=>{"use strict";Nv=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}),Mc=ee(()=>{"use strict";be(),Te(),Ee(),Di(),Us=(e,t,r,i,a)=>{let s=i-r;return`
      ${Array.from({length:r}).map((o,u)=>`
      if (${me(t.shape,u,t.rank)} != 1) {
        ${t.indicesSet(e,u,me(a,u+s,i))}
      } else {
        ${t.indicesSet(e,u,0)}
      }`).join("")}
`},Nc=(e,t,r,i,a=!1,s)=>{let o=e[0].dims,u=e[1].dims,d=o[o.length-2],p=u[u.length-1],m=o[o.length-1],f=Je(p),g=Je(m),v=Je(d),_=L.size(r)/f/v,b=e.length>2,k=i?i.slice(0,-2):r.slice(0,-2),$=[L.size(k),d,p],w=[{type:12,data:_},{type:12,data:d},{type:12,data:p},{type:12,data:m}];Bi(t,w),w.push(...ye(k,o,u)),b&&w.push(...ye(e[2].dims)),w.push(...ye($));let S=C=>{let I=Ec("batch_dims",e[0].dataType,k.length),z=K("a",e[0].dataType,o.length,g),E=K("b",e[1].dataType,u.length,f),B=he("output",e[0].dataType,$.length,f),U=dt(B.type.tensor),V=Ri(t,B.type.value,U),W=[z,E],J="";if(b){let ue=a?f:1;W.push(K("bias",e[2].dataType,e[2].dims.length,ue)),J=`${a?`value += bias[col / ${ue}];`:`value += ${B.type.value}(bias[row + i]);`}`}let D=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];Ni(t,D);let se=()=>{let ue=`var a_data: ${z.type.value};`;for(let F=0;F<g;F++)ue+=`
              let b_data${F} = b[(b_offset + (k + ${F}) * uniforms.N + col) / ${f}];`;for(let F=0;F<v;F++){ue+=`a_data = a[(a_offset + (row + ${F}) * uniforms.K + k) / ${g}];`;for(let oe=0;oe<g;oe++)ue+=`
            values[${F}] = fma(${E.type.value}(a_data${g===1?"":`[${oe}]`}), b_data${oe}, values[${F}]);
`}return ue};return`
  ${C.registerUniforms(D).registerInternalVariables(I).declareVariables(...W,B)}
  ${C.mainStart()}
    ${C.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${f})) * ${f};
    var index1 = global_idx / (uniforms.N / ${f});
    let stride1 = uniforms.M / ${v};
    let row = (index1 % stride1) * ${v};
    let batch = index1 / stride1;

    ${r.length===2?"":`let batch_indices = ${I.offsetToIndices("batch")};`}

    var a_indices: ${z.type.indices};
    ${Us("a_indices",z,z.rank-2,I.rank,"batch_indices")}
    ${z.indicesSet("a_indices",z.rank-2,0)}
    ${z.indicesSet("a_indices",z.rank-1,0)}
    let a_offset = ${z.indicesToOffset("a_indices")};

    var b_indices: ${E.type.indices};
    ${Us("b_indices",E,E.rank-2,I.rank,"batch_indices")}
    ${E.indicesSet("b_indices",E.rank-2,0)}
    ${E.indicesSet("b_indices",E.rank-1,0)}
    let b_offset = ${E.indicesToOffset("b_indices")};
    var values: array<${B.type.value}, ${v}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${g}) {
      ${se()}
    }
    for (var i = 0u; i < ${v}u; i++) {
      var value = values[i];
      ${J}
      ${V}
      let cur_indices = ${B.type.indices}(batch, row + i, col);
      let offset = ${B.indicesToOffset("cur_indices")};
      ${B.setByOffset(`offset / ${f}`,"value")};
    }
  }
  `};return{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${f};${g};${v};${a}`,inputDependencies:b?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:w}),getShaderSource:S}}}),Dc=ee(()=>{"use strict";be(),Te(),Ee(),Di(),Mc(),Bc(),gg=(e,t)=>e?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${t?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${t?", batchIndices":""});
        `,yg=(e,t)=>e?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${t===3?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`,uc=(e,t,r="f32",i,a=!1,s=32,o=!1,u=32)=>{let d=t[1]*e[1],p=t[0]*e[0],m=a?d:s,f=a?s:d,g=m/t[0],v=s/t[1];if(!((a&&g===4&&e[1]===4||!a&&(g===3||g===4))&&m%t[0]===0&&s%t[1]===0&&e[0]===4))throw new Error(`If transposeA ${a} is true, innerElementSize ${g} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${g} must be 3 or 4.
  tileAWidth ${m} must be divisible by workgroupSize[0]${t[0]}. tileInner ${s} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${g}<${r}>, ${m/g}>, ${f}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${p/e[0]}>, ${s}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${g};
const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${o?"0":"i32(globalId.z)"};
  ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${d};

  let num_tiles = ${o?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${o?`i32(globalId.z) * ${u}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${v};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${gg(a,i)}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${v}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${i?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${g===3?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${yg(a,g)}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},kp=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,_g=e=>e?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];",lc=(e,t,r="f32",i,a=!1,s=32,o=!1,u=32,d=!1)=>{let p=e[1]*t[1],m=e[0]*t[0],f=a?p:s,g=a?s:p;if(!(g%t[1]===0&&f%t[0]===0&&s%t[1]===0))throw new Error(`tileAHight ${g} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${f} must be divisible by workgroupSize[0]${t[0]}, tileInner ${s} must be divisible by workgroupSize[1]${t[1]}`);let v=g/t[1],_=f/t[0],b=s/t[1],k=d?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${p};
    let globalColStart = i32(workgroupId.x) * ${m};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${g}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${f}; inputCol = inputCol + ${t[0]}) {
          ${kp(a,i)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${s}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${m}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${i?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${a?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${p};

let tileRowA = i32(localId.y) * ${v};
let tileColA = i32(localId.x) * ${_};
let tileRowB = i32(localId.y) * ${b};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${v}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${_}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${kp(a,i)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${b}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${i?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${_g(a)}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${f}>, ${g}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${m}>, ${s}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${o?"0":"i32(globalId.z)"};
    ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${o?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${o?`i32(globalId.z) * ${u}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${k}
  }
`},vg=(e,t,r,i,a=!1)=>{let[s,o,u,d]=i,p=dt(i[0].type.tensor);return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${ht(e,p)} {
      var value = ${ht(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        var aIndices: ${o.type.indices};
        ${Us("aIndices",o,o.rank-2,s.rank,"batchIndices")}
        ${o.indicesSet("aIndices",o.rank-2,"u32(row)")}
        ${o.indicesSet("aIndices",o.rank-1,"u32(colIn)")}
        value = ${o.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${ht(e,p)} {
      var value = ${ht(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        var bIndices: ${u.type.indices};
        ${Us("bIndices",u,u.rank-2,s.rank,"batchIndices")}
        ${u.indicesSet("bIndices",u.rank-2,"u32(row)")}
        ${u.indicesSet("bIndices",u.rank-1,"u32(colIn)")}
        value = ${u.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${ht(e,p)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${a?"bias[colIn]":`${ht(e,p)}(bias[row])`};`:""}
        ${r}
        ${d.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `},Yo=(e,t,r,i,a=!1,s)=>{let o=e[0].dims,u=e[1].dims,d=o.slice(0,-2),p=u.slice(0,-2),m=i?i.slice(0,-2):r.slice(0,-2),f=L.size(m),g=o[o.length-2],v=o[o.length-1],_=u[u.length-1],b=v%4===0&&_%4===0,k=g<=8?[4,1,1]:[4,4,1],$=[8,8,1],w=[Math.ceil(_/$[0]/k[0]),Math.ceil(g/$[1]/k[1]),Math.ceil(f/$[2]/k[2])],S=b?4:1,C=[...d,g,v/S],I=C.length,z=[...p,v,_/S],E=z.length,B=[f,g,_/S],U=[{type:6,data:g},{type:6,data:_},{type:6,data:v}];Bi(t,U),U.push(...ye(m,C,z));let V=["rank","rank"],W=e.length>2;W&&(U.push(...ye(e[2].dims)),V.push("rank")),U.push(...ye(B));let J=D=>{let se=m.length,ue=Ec("batchDims",e[0].dataType,se,1),F=dt(e[0].dataType),oe=K("a",e[0].dataType,I,S),le=K("b",e[1].dataType,E,S),H=he("result",e[0].dataType,B.length,S),de=[oe,le];if(W){let Ie=a?S:1;de.push(K("bias",e[2].dataType,e[2].dims.length,Ie))}let M=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];Ni(t,M);let q=dt(H.type.tensor),R=Ri(t,H.type.value,q),X=vg(S,W,R,[ue,oe,le,H],a);return`
  ${D.registerUniforms(M).registerInternalVariables(ue).declareVariables(...de,H)}
  ${X}
  ${b?uc(k,$,F,ue):lc(k,$,F,ue)}
                   `};return{name:"MatMul",shaderCache:{hint:`${k};${t.activation};${b};${a}`,inputDependencies:V},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:w[0],y:w[1],z:w[2]},programUniforms:U}),getShaderSource:J}}}),JT=ee(()=>{"use strict";be(),Dr(),Ee(),Di(),Bc(),XT(),Dc(),wg=(e,t,r,i,a=!1,s,o=4,u=4,d=4,p="f32")=>{let m=U=>{switch(U){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${p}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw new Error(`innerElementSize ${U} is not supported.`)}},f=U=>{switch(U){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw new Error(`innerElementSize ${U} is not supported.`)}},g=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,v=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,_=e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])",b=e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])",k=e?"row":"col",$=e?"col":"row",w=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${k} / outWidth;
    let outCol = ${k} % outWidth;

    let WRow = ${$} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${$} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${$} % inChannels;
    var resData = ${ht(o,p)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${_} && xCol >= 0 && xCol < ${b}) {
      ${g}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${m(o)}
    }
    return resData;`,S=e?t&&i?`
    let col = colIn * ${o};
    ${w}`:`
    let col = colIn * ${o};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${w}
    }
    return ${ht(o,p)}(0.0);`:i&&r?`
    let col = colIn * ${o};
    ${w}`:`
    let col = colIn * ${o};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${w}
    }
    return ${ht(o,p)}(0.0);`,C=e?i&&r?f(u):`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${f(u)}
    }
    return ${ht(u,p)}(0.0);`:`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_a_outer) {
      ${f(u)}
    }
    return ${ht(u,p)}(0.0);`,I=ht(d,p),z=ht(e?o:u,p),E=ht(e?u:o,p),B=Ri(s,I,p);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${z} {
      ${e?S:C}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${E} {
      ${e?C:S}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${I}) {
      let col = colIn * ${d};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${v}
      ${Bv(a)}
      ${B}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`},Mv=(e,t,r,i,a,s,o,u,d)=>{let p=t.format==="NHWC",m=p?e[0].dims[3]:e[0].dims[1],f=r[0],g=p?r[2]:r[3],v=p?r[1]:r[2],_=p?r[3]:r[1],b=p&&(m%4===0||m%3===0)&&_%4===0,k=p?_:g*v,$=p?g*v:_,w=[8,8,1],S=i<=8?[4,1,1]:[4,4,1],C=[Math.ceil(k/w[0]/S[0]),Math.ceil($/w[1]/S[1]),Math.ceil(f/w[2]/S[2])];Ne("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${C}`);let I=b?p&&m%4!==0?3:4:1,z=w[1]*S[1],E=w[0]*S[0],B=Math.max(w[0]*I,w[1]),U=i%z===0,V=a%E===0,W=s%B===0,J=b?[I,4,4]:[1,1,1],D=[{type:6,data:i},{type:6,data:a},{type:6,data:s},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];Bi(t,D),D.push(...ye(e[0].dims,e[1].dims));let se=["rank","rank"];o&&(D.push(...ye(e[2].dims)),se.push("rank")),D.push(...ye(r));let ue=F=>{let oe=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];Ni(t,oe);let le=b?4:1,H=dt(e[0].dataType),de=`
      fn setOutputAtIndex(flatIndex : i32, value : ${b?`vec4<${H}>`:H}) {
        result[flatIndex] = ${b?`vec4<${H}>`:H}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${b?`vec4<${H}>`:H}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${b?"/ 4":""}, value);
      }`,M=K("x",e[0].dataType,e[0].dims.length,I===3?1:I),q=K("w",e[1].dataType,e[1].dims.length,le),R=[M,q],X=he("result",e[0].dataType,r.length,le);if(o){let Ie=K("bias",e[2].dataType,e[2].dims.length,le);R.push(Ie),de+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${b?`vec4<${H}>`:H} {
          return bias[coords.${p?"w":"y"}${b?"/ 4":""}];
        }`}return`
        ${Nv("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${F.registerUniforms(oe).declareVariables(...R,X)}
        ${de}
        ${wg(p,U,V,W,o,t,J[0],J[1],J[2],H)}
        ${b?uc(S,w,H,void 0,!p,B):lc(S,w,H,void 0,!p,B,!1,void 0,u)}`};return{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${I};${b};${U};${V};${W};${z};${E};${B}`,inputDependencies:se},getRunData:()=>({outputs:[{dims:d?d(r):r,dataType:e[0].dataType}],dispatchGroup:{x:C[0],y:C[1],z:C[2]},programUniforms:D}),getShaderSource:ue}}}),YT=ee(()=>{"use strict";be(),Dr(),Te(),Ee(),Di(),Bc(),bg=e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t},Sp=e=>typeof e=="number"?[e,e,e]:e,Es=(e,t)=>t<=1?e:e+(e-1)*(t-1),$g=(e,t,r,i=1)=>{let a=Es(t,i);return Math.floor((e[0]*(r-1)-r+a)/2)},Tp=(e,t,r,i,a)=>{a==null&&(a=$g(e,t[0],i[0]));let s=[0,0,0,r];for(let o=0;o<3;o++)e[o]+2*a>=t[o]&&(s[o]=Math.trunc((e[o]-t[o]+2*a)/i[o]+1));return s},xg=(e,t,r,i,a,s,o,u,d,p)=>{let m,f,g,v;if(e==="VALID"&&(e=0),typeof e=="number"){m={top:e,bottom:e,left:e,right:e,front:e,back:e};let _=Tp([t,r,i,1],[u,d,p],1,[a,s,o],e);f=_[0],g=_[1],v=_[2]}else if(Array.isArray(e)){if(!e.every((b,k,$)=>b===$[0]))throw Error(`Unsupported padding parameter: ${e}`);m={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let _=Tp([t,r,i,1],[u,d,p],1,[a,s,o],e[0]);f=_[0],g=_[1],v=_[2]}else if(e==="SAME_UPPER"){f=Math.ceil(t/a),g=Math.ceil(r/s),v=Math.ceil(i/o);let _=(f-1)*a+u-t,b=(g-1)*s+d-r,k=(v-1)*o+p-i,$=Math.floor(_/2),w=_-$,S=Math.floor(b/2),C=b-S,I=Math.floor(k/2),z=k-I;m={top:S,bottom:C,left:I,right:z,front:$,back:w}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:m,outDepth:f,outHeight:g,outWidth:v}},Dv=(e,t,r,i,a,s=!1,o="channelsLast")=>{let u,d,p,m,f;if(o==="channelsLast")[u,d,p,m,f]=e;else if(o==="channelsFirst")[u,f,d,p,m]=e;else throw new Error(`Unknown dataFormat ${o}`);let[g,,v,_,b]=t,[k,$,w]=Sp(r),[S,C,I]=Sp(i),z=Es(v,S),E=Es(_,C),B=Es(b,I),{padInfo:U,outDepth:V,outHeight:W,outWidth:J}=xg(a,d,p,m,k,$,w,z,E,B),D=s?g*f:g,se=[0,0,0,0,0];return o==="channelsFirst"?se=[u,D,V,W,J]:o==="channelsLast"&&(se=[u,V,W,J,D]),{batchSize:u,dataFormat:o,inDepth:d,inHeight:p,inWidth:m,inChannels:f,outDepth:V,outHeight:W,outWidth:J,outChannels:D,padInfo:U,strideDepth:k,strideHeight:$,strideWidth:w,filterDepth:v,filterHeight:_,filterWidth:b,effectiveFilterDepth:z,effectiveFilterHeight:E,effectiveFilterWidth:B,dilationDepth:S,dilationHeight:C,dilationWidth:I,inShape:e,outShape:se,filterShape:t}},Pv=(e,t,r,i,a,s)=>{let o=s==="channelsLast",u=o?e[0].dims[3]:e[0].dims[1],d=!1,p=[64,1,1],m={x:r.map((w,S)=>S)},f=[Math.ceil(bg(m.x.map(w=>r[w]))/p[0]),1,1];Ne("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${f}`);let g=d?o&&u%4!==0?3:4:1,v=L.size(r),_=[{type:12,data:v},{type:12,data:i},{type:12,data:a},{type:12,data:t.strides},{type:12,data:t.dilations}];Bi(t,_),_.push(...ye(e[0].dims,e[1].dims));let b=["rank","rank"],k=e.length===3;k&&(_.push(...ye(e[2].dims)),b.push("rank")),_.push(...ye(r));let $=w=>{let S=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:i.length},{name:"pads",type:"u32",length:a.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];Ni(t,S);let C=d?4:1,I=dt(e[0].dataType),z=K("x",e[0].dataType,e[0].dims.length,g===3?1:g),E=K("W",e[1].dataType,e[1].dims.length,C),B=[z,E],U=he("result",e[0].dataType,r.length,C),V="";if(k){let D=K("bias",e[2].dataType,e[2].dims.length,C);B.push(D),V+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${d?`vec4<${I}>`:I} {
          return bias[${o?me("coords",4,5):me("coords",1,5)}${d?"/ 4":""}];
        }`}let W=ht(g,I),J=Ri(t,W,I);return`
            ${V}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${z.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${E.getByIndices("aIndices")};
            }
          ${w.registerUniforms(S).declareVariables(...B,U)}
          ${w.mainStart()}
          ${w.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${U.offsetToIndices("global_idx")};
              let batch = ${me("coords",0,z.rank)};
              let d2 = ${o?me("coords",z.rank-1,z.rank):me("coords",1,z.rank)};
              let xFRCCorner = vec3<u32>(${o?me("coords",1,z.rank):me("coords",2,z.rank)},
              ${o?me("coords",2,z.rank):me("coords",3,z.rank)},
              ${o?me("coords",3,z.rank):me("coords",4,z.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${o?me("uniforms.x_shape",1,z.rank):me("uniforms.x_shape",2,z.rank)};
              let xShapeZ = ${o?me("uniforms.x_shape",2,z.rank):me("uniforms.x_shape",3,z.rank)};
              let xShapeW = ${o?me("uniforms.x_shape",3,z.rank):me("uniforms.x_shape",4,z.rank)};
              let xShapeU = ${o?me("uniforms.x_shape",4,z.rank):me("uniforms.x_shape",1,z.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = 0.0;
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${o?`let xValues = vec4<f32>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<f32>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<f32>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${o?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${o?`let xValues = vec2<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${o?`let xValues = vec3<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${k?"value = value + getBiasByOutputCoords(coords)":""};
              ${J}
              result[global_idx] = f32(value);
          }`};return{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${o};${g};${k}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:f[0],y:f[1],z:f[2]},programUniforms:_}),getShaderSource:$}}}),eC=ee(()=>{"use strict";be(),Te(),Ee(),Di(),Uv=(e,t,r,i)=>{let a=e.length>2,s=a?"value += b[output_channel];":"",o=e[0].dims,u=e[1].dims,d=t.format==="NHWC",p=d?r[3]:r[1],m=p/t.group,f=d&&m>=4?Je(p):1,g=L.size(r)/f,v=[{type:12,data:g},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:m}];Bi(t,v),v.push(...ye(o,[u[0],u[1],u[2],u[3]/f]));let _=a?["rank","rank","rank"]:["rank","rank"];v.push(...ye([r[0],r[1],r[2],r[3]/f]));let b=k=>{let $=he("output",e[0].dataType,r.length,f),w=dt($.type.tensor),S=Ri(t,$.type.value,w),C=K("x",e[0].dataType,o.length),I=K("w",e[1].dataType,u.length,f),z=[C,I];a&&z.push(K("b",e[2].dataType,e[2].dims,f));let E=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];Ni(t,E);let B=d?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${C.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${I.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${C.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${I.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${k.registerUniforms(E).declareVariables(...z,$)}

  ${k.mainStart()}
    ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${$.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${d?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${d?1:2}], outputIndices[${d?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${f} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${d?2:1}];

    var value: ${$.type.value} = ${$.type.value}(0);
    ${B}
    ${s}
    ${S}
    ${$.setByOffset("global_idx","value")}
  }`};return{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${f}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:v}),getShaderSource:b}},Wv=(e,t,r,i)=>{let a=e.length>2,s=Je(r[3]),o=Je(r[2]),u=L.size(r)/s/o,d=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/s],p=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/s],m=[r[0],r[1],r[2],r[3]/s],f=[{type:12,data:u},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];Bi(t,f),f.push(...ye(d,p,m));let g=(o-1)*t.strides[1]+p[1],v=_=>{let b=he("output",e[0].dataType,m.length,s),k=dt(b.type.tensor),$=Ri(t,b.type.value,k),w=K("x",e[0].dataType,d.length,s),S=K("w",e[1].dataType,p.length,s),C=[w,S];a&&C.push(K("b",e[2].dataType,e[2].dims,s));let I=a?"value += b[output_channel];":"",z=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return Ni(t,z),`
  ${_.registerUniforms(z).declareVariables(...C,b)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${o}u;
    let col = (index1 % width1) * ${o}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${w.type.value}, ${g}>;
    var values: array<${b.type.value}, ${o}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${p[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${g}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${w.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${w.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${p[1]}; w_width++) {
          let w_val = ${S.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${o}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${o}u; i++) {
      var value = values[i];
      ${I}
      ${$}
      ${b.set("batch","row","col + i","output_channel","value")};
    }
  }`};return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${s};${o};${g};${p[0]};${p[1]}`,inputDependencies:a?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:f}),getShaderSource:v}}}),tC=ee(()=>{"use strict";Te(),JT(),YT(),Dc(),eC(),Di(),Mc(),Hr(),kg=(e,t,r,i,a,s)=>{let o=e[0],u=e.slice(s?1:2,s?3:4),d=u.length,p=t[0],m=t.slice(2).map((g,v)=>g+(g-1)*(r[v]-1)),f=u.map((g,v)=>g+i[v]+i[v+d]).map((g,v)=>Math.floor((g-m[v]+a[v])/a[v]));return f.splice(0,0,o),f.splice(s?3:1,0,p),f},Uo=[2,3,1,0],Sg=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length>5)throw new Error("greater than 5D is not supported");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[1]*t.group;if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(e.length===3&&(e[2].dims.length!==1||e[1].dims[0]!==e[2].dims[0]))throw new Error("invalid bias");let a=e[0].dims.length-2;if(t.dilations.length!==a)throw new Error(`dilations should be ${a}D`);if(t.strides.length!==a)throw new Error(`strides should be ${a}D`);if(t.pads.length!==a*2)throw new Error(`pads should be ${a*2}D`);if(t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape")},Wo=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let s=2;s<t[1].dims.length;++s)r[s-2]===0&&(r[s-2]=t[1].dims[s]);let i=e.pads.slice();Xo.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,i,e.format==="NHWC",e.autoPad);let a=Object.assign({},e);return Object.assign(a,{kernelShape:r,pads:i}),a},dc=e=>{let t=Rc(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],a=e.dilations,s=e.group,o=e.kernel_shape,u=e.pads,d=e.strides,p=e.w_is_const();return{autoPad:i,format:r,dilations:a,group:s,kernelShape:o,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},Cp=(e,t,r,i)=>{let a=r.format==="NHWC",s=kg(t[0].dims,t[1].dims,r.dilations,r.pads,r.strides,a);if(r.group!==1){let z=[t[0]];if(a){let E=e.kernelCustomData.wT??e.compute(Mt(t[1],Uo),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=E),z.push(E)}else z.push(t[1]);t.length===3&&z.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&a&&t[1].dims[0]===r.group&&t[1].dims[1]===1&&r.dilations[0]===1&&r.dilations[1]===1?e.compute(Wv(z,r,s,i),{inputs:z}):e.compute(Uv(z,r,s,i),{inputs:z});return}let o=t.length===3,u=t[0].dims[a?1:2],d=t[0].dims[a?2:3],p=t[0].dims[a?3:1],m=t[1].dims[2],f=t[1].dims[3],g=s[a?1:2],v=s[a?2:3],_=s[a?3:1],b=a&&m===u&&f===d&&r.pads[0]===0&&r.pads[1]===0;if(b||m===1&&f===1&&r.dilations[0]===1&&r.dilations[1]===1&&r.strides[0]===1&&r.strides[1]===1&&r.pads[0]===0&&r.pads[1]===0){let z=s[0],E,B,U,V=[];if(a){let D=e.kernelCustomData.wT??e.compute(Mt(t[1],Uo),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=D),b){let se=u*d*p;E=t[0].reshape([1,z,se]),B=D.reshape([1,se,_]),U=[1,z,_]}else E=t[0].reshape([z,u*d,p]),B=D.reshape([1,p,_]),U=[z,g*v,_];V.push(E),V.push(B)}else E=t[0].reshape([z,p,u*d]),B=t[1].reshape([1,_,p]),U=[z,_,g*v],V.push(B),V.push(E);o&&V.push(t[2]);let W=U[2],J=V[0].dims[V[0].dims.length-1];W<8&&J<8?e.compute(Nc(V,r,s,U,a,i),{inputs:V}):e.compute(Yo(V,r,s,U,a,i),{inputs:V});return}let k=!0,$=e.kernelCustomData.wT??e.compute(Mt(t[1],Uo),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=$);let w=[t[0],$];o&&w.push(t[2]);let S=a?g*v:_,C=a?_:g*v,I=m*f*p;e.compute(Mv(w,r,s,S,C,I,o,k,i),{inputs:w})},Tg=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=[0,t.pads[0],0,t.pads[1]],s=[1].concat(t.strides),o=[1].concat(t.dilations),u=[1].concat(t.kernelShape),d=Wo({...t,pads:a,strides:s,dilations:o,kernelShape:u},i);Cp(e,i,d,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]])},Cg=(e,t,r)=>{let i=r.format==="NHWC"?"channelsLast":"channelsFirst",a=Wo(r,t),s=r.autoPad==="NOTSET"?r.pads:r.autoPad,o=Dv(t[0].dims,t[1].dims,r.strides,r.dilations,s,!1,i);e.compute(Pv(t,a,o.outShape,[o.filterDepth,o.filterHeight,o.filterWidth],[o.padInfo.front,o.padInfo.top,o.padInfo.left],i))},pc=(e,t)=>{if(Sg(e.inputs,t),e.inputs[0].dims.length===3)Tg(e,t);else if(e.inputs[0].dims.length===5)Cg(e,e.inputs,t);else{let r=Wo(t,e.inputs);Cp(e,e.inputs,r)}}}),rC=ee(()=>{"use strict";be(),Dr(),Te(),Ee(),Vv=(e,t,r)=>{let i=e.length>2,a=t.outputShape,s=t.format==="NHWC",o=t.group,u=e[1].dims,d=u[2]/o,p=u[3],m=s?Je(d):1,f=s?Je(p):1,g=s?p===1?m:f:1,v=L.size(a)/f,_=[Math.ceil(v/64),1,1];Ne("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${_}`);let b=["rank","rank"],k=[t.strides[0],t.strides[1]],$=[t.kernelShape[s?1:2],t.kernelShape[s?2:3]],w=[t.dilations[0],t.dilations[1]],S=[$[0]+(t.dilations[0]<=1?0:(t.kernelShape[s?1:2]-1)*(t.dilations[0]-1)),$[1]+(t.dilations[1]<=1?0:(t.kernelShape[s?2:3]-1)*(t.dilations[1]-1))],C=[S[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),S[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],I=[{type:12,data:v},{type:12,data:k},{type:12,data:$},{type:12,data:w},{type:12,data:S},{type:6,data:C},{type:12,data:d},{type:12,data:p},...ye(e[0].dims,e[1].dims)];i&&(I.push(...ye(e[2].dims)),b.push("rank")),I.push(...ye(a));let z=E=>{let B=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:k.length},{name:"filter_dims",type:"u32",length:$.length},{name:"dilations",type:"u32",length:$.length},{name:"effective_filter_dims",type:"u32",length:S.length},{name:"pads",type:"i32",length:C.length},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],U=dt(e[0].dataType),V=s?1:2,W=s?2:3,J=s?3:1,D=K("W",e[1].dataType,e[1].dims.length,g),se=K("Dy",e[0].dataType,e[0].dims.length,m),ue=[se,D];i&&ue.push(K("bias",e[2].dataType,[a[J]].length,f));let F=he("result",e[0].dataType,a.length,f),oe=()=>{let H="";if(m===1)H+=`
        let w_offset = ${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)};
        let wValue = ${D.getByOffset(`w_offset / ${g}`)};
        dotProd = dotProd + xValue * wValue;`;else if(p===1)H+=`
          let wValue = ${D.getByOffset(`${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)} / ${g}`)};
          dotProd = dotProd + dot(xValue, wValue);`;else for(let de=0;de<m;de++)H+=`
            let wValue${de} = ${D.getByOffset(`${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel + ${de}, wOutChannel)`)} / ${g}`)};
            dotProd = dotProd + xValue[${de}] * wValue${de};`;return H},le=`
            let outputIndices = ${F.offsetToIndices(`global_idx * ${f}`)};
            let batch = ${F.indicesGet("outputIndices",0)};
            let d1 = ${F.indicesGet("outputIndices",J)};
            let r = ${F.indicesGet("outputIndices",V)};
            let c = ${F.indicesGet("outputIndices",W)};
            let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
            let dyRCorner = dyCorner.x;
            let dyCCorner = dyCorner.y;
            let groupId = d1 / uniforms.output_channels_per_group;
            let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
            // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
            // ? = to be determined. : = across all values in that axis.
            var dotProd = ${F.type.value}(0.0);
            var wR: u32 = 0;
            if (uniforms.dilations.x == 1) {
              // Minimum wR >= 0 that satisfies (dyRCorner + wR) % (uniforms.strides.x) == 0
              wR = u32(((dyRCorner + i32(uniforms.strides.x) - 1) / i32(uniforms.strides.x)) * i32(uniforms.strides.x) - dyRCorner);
            }
            for (; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
              if (wR % uniforms.dilations.x != 0) {
                continue;
              }
              let dyR = (${U}(dyRCorner) + ${U}(wR)) / ${U}(uniforms.strides[0]);
              let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
              if (dyR < 0.0 || dyR >= ${U}(uniforms.Dy_shape[${V}]) || fract(dyR) > 0.0 ||
                  wRPerm < 0) {
                continue;
              }
              let idyR: u32 = u32(dyR);
              var wC: u32 = 0;
              if (uniforms.dilations.y == 1) {
                // Minimum wC >= 0 that satisfies (dyCCorner + wC) % (uniforms.strides.y) == 0
                wC = u32(((dyCCorner + i32(uniforms.strides.y) - 1) / i32(uniforms.strides.y)) * i32(uniforms.strides.y) - dyCCorner);
              }

              for (; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
                if (wC % uniforms.dilations.y != 0) {
                  continue;
                }
                let dyC = (${U}(dyCCorner) + ${U}(wC)) / ${U}(uniforms.strides.y);
                let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
                if (dyC < 0.0 || dyC >= ${U}(uniforms.Dy_shape[${W}]) ||
                    fract(dyC) > 0.0 || wCPerm < 0) {
                  continue;
                }
                let idyC: u32 = u32(dyC);
                var inputChannel = groupId * uniforms.input_channels_per_group;
                for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group; d2 = d2 + ${m}) {
                  let xValue = ${s?se.getByOffset(`${se.indicesToOffset(`${se.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${m}`):se.get("batch","inputChannel","idyR","idyC")};
                  ${oe()}
                  inputChannel = inputChannel + ${m};
                }
                wC = wC + uniforms.strides.y - 1;
              }
              wR = wR + uniforms.strides[0] - 1;
            }
            let value = dotProd${i?` + bias[d1 / ${f}]`:""};
            ${F.setByOffset("global_idx","value")};
          `;return`
    ${E.registerUniforms(B).declareVariables(...ue,F)}
      ${E.mainStart()}
      ${E.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
    ${le}}`};return{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};${m}${g}${f}${p===1}`,inputDependencies:b},getRunData:()=>({dispatchGroup:{x:_[0],y:_[1],z:_[2]},outputs:[{dims:r?r(a):a,dataType:e[0].dataType}],programUniforms:I}),getShaderSource:z}}}),iC=ee(()=>{"use strict";rC(),Di(),Hr(),Ig=(e,t,r,i,a,s)=>(e-1)*t+r+(i-1)*a+1-s,Eg=(e,t,r,i,a)=>{let s=Math.floor(e/2);t==="SAME_UPPER"?(r[i]=s,r[a]=e-s):t==="SAME_LOWER"&&(r[i]=e-s,r[a]=s)},zg=(e,t,r,i,a,s,o,u,d,p)=>{let m=e.length-2,f=p.length===0;d.length<m&&d.push(...Array(m-d.length).fill(0));let g=e[0],v=t[u?3:1]*a;for(let _=0,b=e.length-m-(u?1:0);_<m;++_,++b){let k=e[b],$=f?k*o[_]:p[_],w=Ig(k,o[_],s[_],t[b],r[_],$);Eg(w,i,s,_,_+m),f&&p.push(o[_]*(k-1)+d[_]+(t[b]-1)*r[_]+1-s[_]-s[_+m])}p.splice(0,0,g),p.splice(u?3:1,0,v)},Ip=(e,t)=>{let r=e.kernelShape.slice();if(e.kernelShape.length===0||e.kernelShape.reduce((f,g)=>f*g,1)===0){r.length=0;for(let f=2;f<t[1].dims.length;++f)r.push(t[1].dims[f])}let i=e.format==="NHWC";r.splice(0,0,t[1].dims[0]),r.splice(i?3:1,0,t[1].dims[1]);let a=e.pads.slice(),s=e.outputShape.slice(),o=e.outputPadding.slice(),u=t[0].dims,d=e.dilations.slice();if(d.reduce((f,g)=>f+g,0)===0){let f=t[0].dims.length-2;d=new Array(f).fill(1)}let p=e.strides.slice();if(p.reduce((f,g)=>f+g,0)===0){let f=t[0].dims.length-2;p=new Array(f).fill(1)}zg(u,r,d,e.autoPad,e.group,a,p,i,o,s);let m=Object.assign({},e);return Object.assign(m,{kernelShape:r,pads:a,outputPadding:o,outputShape:s,dilations:d,strides:p}),m},qv=e=>{let t=Rc(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][typeof e.autoPad>"u"?0:e.autoPad],a=e.dilations,s=e.group,o=e.kernelShape,u=e.pads,d=e.strides,p=e.wIsConst(),m=e.outputPadding,f=e.outputShape;return{autoPad:i,format:r,dilations:a,group:s,kernelShape:o,outputPadding:m,outputShape:f,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},Ag=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length!==4&&e[0].dims.length!==3)throw new Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[0];if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let a=e[1].dims[1]*t.group;if(e.length===3&&(e[2].dims.length!==1||e[2].dims[0]!==a))throw new Error("invalid bias");let s=e[0].dims.length-2;if(t.dilations.reduce((o,u)=>o+u,0)>0&&t.dilations.length!==s)throw new Error(`dilations should be ${s}D`);if(t.strides.reduce((o,u)=>o+u,0)>0&&t.strides.length!==s)throw new Error(`strides should be ${s}D`);if(t.pads.reduce((o,u)=>o+u,0)>0&&t.pads.length!==s*2)throw new Error(`pads should be ${s*2}D`);if(t.outputPadding.length!==s&&t.outputPadding.length!==0)throw new Error(`output_padding should be ${s}D`);if(t.kernelShape.reduce((o,u)=>o+u,0)>0&&t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape");if(t.outputShape.length!==0&&t.outputShape.length!==e[0].dims.length-2)throw new Error("invalid output shape")},Ep=(e,t,r,i)=>{let a=e.kernelCustomData.wT??e.compute(Mt(t[1],[2,3,0,1]),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=a);let s=[t[0],a];t.length===3&&s.push(t[2]),e.compute(Vv(s,r,i),{inputs:s})},Og=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=t.kernelShape;(a.length===0||a[0]===0)&&(a=[e.inputs[1].dims[2]]);let s=t.dilations;(s.length===0||s[0]===0)&&(s=[1]);let o=t.strides;(o.length===0||o[0]===0)&&(o=[1]);let u=t.pads;u.length===0&&(u=[0,0]),u=[0,u[0],0,u[1]],o=[1].concat(o),s=[1].concat(s),a=[1].concat(a);let d=t.outputPadding;d=[0].concat(d);let p=Ip({...t,pads:u,strides:o,dilations:s,kernelShape:a,outputPadding:d},i);Ep(e,i,p,m=>r?[m[0],m[2],m[3]]:[m[0],m[1],m[3]])},jv=(e,t)=>{if(Ag(e.inputs,t),e.inputs[0].dims.length===3)Og(e,t);else{let r=Ip(t,e.inputs);Ep(e,e.inputs,r)}}}),aC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Rg=(e,t,r,i)=>{let a=L.size(t),s=t.length,o=K("input",e,s),u=he("output",e,s),d=r.dataType===6?r.getInt32Array()[0]:Number(r.getBigInt64Array()[0]),p=L.normalizeAxis(d,s),m=f=>{let g=` i32(${o.indicesGet("inputIndices","uniforms.axis")}) `,v=me("uniforms.input_shape","uniforms.axis",s),_=i.reverse?g+(i.exclusive?" + 1":""):"0",b=i.reverse?v:g+(i.exclusive?"":" + 1");return`
                ${f.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(o,u)}
                ${f.mainStart()}
                  ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${u.offsetToIndices("global_idx")};
                  var sum = ${u.type.value}(0);
                  let first : i32 = ${_};
                  let last : i32 = ${b};
                  for (var i : i32 = first; i < last; i++) {
                    ${o.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${o.getByIndices("inputIndices")};
                  }
                  ${u.setByOffset("global_idx","sum")};
                }`};return{name:"CumSum",shaderCache:{hint:i.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:t,dataType:e}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:[{type:12,data:a},{type:12,data:p},...ye(t,t)]}),getShaderSource:m}},Lv=(e,t)=>{let r=e.inputs[0].dims,i=e.inputs[0].dataType,a=e.inputs[1];e.compute(Rg(i,r,a,t),{inputs:[0]})},Gv=e=>{let t=e.exclusive===1,r=e.reverse===1;return je({exclusive:t,reverse:r})}}),nC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Bg=e=>{if(!e||e.length!==1)throw new Error("DepthToSpace requires 1 input.");if(e[0].dims.length!==4)throw new Error("DepthToSpace requires 4D input.")},Ng=(e,t,r,i)=>{let a=[];a.push(`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let s=0;s<t;++s)a.push(r.indicesSet("a",e[s],`i[${s}]`));return a.push("return a;}"),a.join(`
`)},Mg=(e,t)=>{let r,i,a,s,o,u,d=t.format==="NHWC",p=t.blocksize,m=t.mode==="DCR";d?([r,i,a,s]=e.dims,o=m?[r,i,a,p,p,s/p**2]:[r,i,a,s/p**2,p,p],u=m?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([r,i,a,s]=[e.dims[0],e.dims[2],e.dims[3],e.dims[1]],o=m?[r,p,p,s/p**2,i,a]:[r,s/p**2,p,p,i,a],u=m?[0,3,4,1,5,2]:[0,1,4,2,5,3]);let f=e.reshape(o),g=f.dims.length,v=e.dataType,_=K("a",v,g),b=he("output",v,g),k=$=>`
  ${$.registerUniform("output_size","u32").declareVariables(_,b)}

  ${Ng(u,g,_,b)}

  ${$.mainStart()}
    ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${b.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${b.setByOffset("global_idx",_.getByIndices("aIndices"))}
  }`;return{name:"DepthToSpace",shaderCache:{hint:`${e.dims};${t.blocksize};${t.mode}`,inputDependencies:["rank"]},getRunData:$=>{let w=d?[r,i*p,a*p,s/p**2]:[r,s/p**2,i*p,a*p],S=L.size(w),C=f.dims,I=L.sortBasedOnPerm(C,u);return{outputs:[{dims:w,dataType:$[0].dataType}],dispatchGroup:{x:Math.ceil(S/64)},programUniforms:[{type:12,data:S},...ye(C,I)]}},getShaderSource:k}},Fv=(e,t)=>{Bg(e.inputs),e.compute(Mg(e.inputs[0],t))},Hv=e=>je({blocksize:e.blocksize,mode:e.mode,format:e.format})}),sC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Vo="[a-zA-Z]|\\.\\.\\.",zs="("+Vo+")+",zp="^"+zs+"$",Dg="("+zs+",)*"+zs,Pg="^"+Dg+"$",Ug=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);r===void 0?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},Wg=class{constructor(e,t){this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=new Array,this.outputDims=[];let[r,i]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(Pg)))throw new Error("Invalid LHS term");if(r.split(",").forEach((a,s)=>{let o=e[s].dims.slice();if(!a.match(RegExp(zp)))throw new Error("Invalid LHS term");let u=this.processTerm(a,!0,o,s);this.lhs.push(u)}),i==="")i+=[...this.symbolToInfo.entries()].filter(([a,s])=>s.count===1||a==="...").map(([a])=>a).join("");else if(!i.match(RegExp(zs)))throw new Error("Invalid RHS");i.match(RegExp(Vo,"g"))?.forEach(a=>{if(a==="...")this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let s=this.symbolToInfo.get(a);if(s===void 0)throw new Error("Invalid RHS symbol");this.outputDims.push(s.dimValue)}}),this.rhs=this.processTerm(i,!1,this.outputDims)}addSymbol(e,t,r){let i=this.symbolToInfo.get(e);if(i!==void 0){if(i.dimValue!==t&&i.count!==1)throw new Error("Dimension mismatch");i.count++,i.inputIndices.push(r)}else i={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,i)}processTerm(e,t,r,i=-1){let a=r.length,s=!1,o=[],u=0;if(!e.match(RegExp(zp))&&!t&&e!=="")throw new Error("Invalid LHS term");let d=e.match(RegExp(Vo,"g")),p=new Ug(i);return d?.forEach((m,f)=>{if(m==="..."){if(s)throw new Error("Only one ellipsis is allowed per input term");s=!0;let g=a-d.length+1;if(g<0)throw new Error("Ellipsis out of bounds");if(o=r.slice(u,u+g),this.hasEllipsis){if(this.ellipsisDims.length!==o.length||this.ellipsisDims.toString()!==o.toString())throw new Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=o;else throw new Error("Ellipsis must be specified in the LHS");for(let v=0;v<o.length;v++){let _=String.fromCharCode(48+v);p.addSymbol(_,f+v),this.addSymbol(_,r[u++],i)}}else p.addSymbol(m,f+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(m,r[u++],i)}),p}},Ap=e=>e+"_max",Vg=(e,t,r,i)=>{let a=e.map(p=>p.length).map((p,m)=>K(`input${m}`,t,p)),s=L.size(i),o=he("output",t,i.length),u=[...r.symbolToInfo.keys()].filter(p=>!r.rhs.symbolToIndices.has(p)),d=p=>{let m=[],f="var prod = 1.0;",g="var sum = 0.0;",v="sum += prod;",_=[],b=[],k=[],$=[],w=r.symbolToInfo.size===r.rhs.symbolToIndices.size;r.symbolToInfo.forEach((C,I)=>{if(r.rhs.symbolToIndices.has(I)){let z=r.rhs.symbolToIndices.get(I)?.[0];z!==void 0&&r.lhs.forEach((E,B)=>{if(C.inputIndices.includes(B)){let U=E.symbolToIndices.get(I);if(U===void 0)throw new Error("Invalid symbol error");U.forEach(V=>{m.push(`${a[B].indicesSet(`input${B}Indices`,V,o.indicesGet("outputIndices",z))}`)})}})}else r.lhs.forEach((z,E)=>{if(C.inputIndices.includes(E)){let B=z.symbolToIndices.get(I);if(B===void 0)throw new Error("Invalid symbol error");B.forEach(U=>{_.push(`${a[E].indicesSet(`input${E}Indices`,U,`${I}`)}`)}),$.push(`prod *= ${a[E].getByIndices(`input${E}Indices`)};`)}}),b.push(`for(var ${I}: u32 = 0; ${I} < uniforms.${Ap(I)}; ${I}++) {`),k.push("}")});let S=w?[...m,`let sum = ${a.map((C,I)=>C.getByIndices(`input${I}Indices`)).join(" * ")};`]:[...m,g,...b,..._,f,...$,v,...k];return`
            ${p.registerUniforms(u.map(C=>({name:`${Ap(C)}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...a,o)}

            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${o.offsetToIndices("global_idx")};
            ${a.map((C,I)=>`var input${I}Indices: ${a[I].type.indices};`).join(`
`)}
            ${S.join(`
`)};
            ${o.setByOffset("global_idx","sum")};
          }`};return{name:"Einsum",shaderCache:{hint:r.equation,inputDependencies:e.map(()=>"rank")},getRunData:()=>{let p=u.filter(f=>r.symbolToInfo.has(f)).map(f=>({type:12,data:r.symbolToInfo.get(f)?.dimValue||0}));p.push({type:12,data:s});let m=e.map((f,g)=>[...ye(f)]).reduce((f,g)=>f.concat(g),p);return m.push(...ye(i)),{outputs:[{dims:i,dataType:t}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:m}},getShaderSource:d}},Kv=(e,t)=>{let r=new Wg(e.inputs,t.equation),i=r.outputDims,a=e.inputs.map((s,o)=>s.dims);e.compute(Vg(a,e.inputs[0].dataType,r,i))},Zv=e=>{let t=e.equation.replace(/\s+/g,"");return je({equation:t})}}),oC=ee(()=>{"use strict";be(),Te(),Ee(),qg=e=>{if(!e||e.length!==2)throw new Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=r.length<t.length?0:r.length-t.length,a=t.length<r.length?0:t.length-r.length;for(;i<r.length&&a<t.length;++i,++a)if(r[i]!==t[a]&&r[i]!==1&&t[a]!==1)throw new Error("Expand requires shape to be broadcastable to input")},Op=(e,t)=>{let r=e.length-t.length,i=[];for(let a=0;a<r;++a)i.push(e[a]);for(let a=0;a<t.length;++a)i.push(t[a]===1?e[a+r]:t[a]);return i},jg=(e,t)=>e.length>t.length?Op(e,t):Op(t,e),Lg=e=>{let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=jg(t,r),a=e[0].dataType,s=a===9||L.size(t)===1,o=a===9||t.length>0&&t[t.length-1]%4===0?4:1,u=s||i.length>0&&i[i.length-1]%4===0?4:1,d=Math.ceil(L.size(i)/u),p=f=>{let g=K("input",a,t.length,o),v=he("output",a,i.length,u),_;if(a===9){let b=(k,$,w="")=>`
          let outputIndices${$} = ${v.offsetToIndices(`outputOffset + ${$}u`)};
          let offset${$} = ${g.broadcastedIndicesToOffset(`outputIndices${$}`,v)};
          let index${$} = offset${$} / 4u;
          let component${$} = offset${$} % 4u;
          ${k}[${$}] = ${w}(${g.getByOffset(`index${$}`)}[component${$}]);
        `;_=`
        let outputOffset = global_idx * ${u};
        var data = vec4<u32>(0);
        ${b("data",0,"u32")}
        ${b("data",1,"u32")}
        ${b("data",2,"u32")}
        ${b("data",3,"u32")}
        ${v.setByOffset("global_idx","data")}
      }`}else _=`
        let outputIndices = ${v.offsetToIndices(`global_idx * ${u}`)};
        let inputOffset = ${g.broadcastedIndicesToOffset("outputIndices",v)};
        let data = ${v.type.value}(${g.getByOffset(`inputOffset / ${o}`)});
        ${v.setByOffset("global_idx","data")}
      }`;return`
    ${f.registerUniform("vec_size","u32").declareVariables(g,v)}
    ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${_}`},m=[{type:12,data:d},...ye(t,i)];return{name:"Expand",shaderCache:{hint:`${i.length};${o}${u}`,inputDependencies:["rank"]},getShaderSource:p,getRunData:()=>({outputs:[{dims:i,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:m})}},Qv=e=>{qg(e.inputs),e.compute(Lg(e.inputs),{inputs:[0]})}}),uC=ee(()=>{"use strict";be(),Te(),Ee(),Oc(),Gg=e=>{let t=e[0].dataType,r=L.size(e[0].dims),i=L.size(e[1].dims),a=i%4===0,s=o=>{let u=K("x",t,[1],4),d=K("bias",t,[1],4),p=he("y",t,[1],4),m=[{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}],f=v=>`
      let bias${v}_offset: u32 = (global_idx * 4 + ${v}) % uniforms.bias_size;
      let bias${v} = ${d.getByOffset(`bias${v}_offset / 4`)}[bias${v}_offset % 4];`,g=a?`
      let bias = ${d.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${f(0)}${f(1)}${f(2)}${f(3)}
      let bias = ${u.type.value}(bias0, bias1, bias2, bias3);`;return`${o.registerUniforms(m).declareVariables(u,d,p)}

    ${sc(xt(t))}

    ${o.mainStart(aa)}
      ${o.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${u.getByOffset("global_idx")};
      ${g}
      let x_in = x + bias;
      ${p.setByOffset("global_idx",oc("x_in"))}
    }`};return{name:"FastGeluWithBias",shaderCache:{hint:`${a}`,inputDependencies:["type","type"]},getShaderSource:s,getRunData:o=>({outputs:[{dims:o[0].dims,dataType:o[0].dataType}],programUniforms:[{type:12,data:Math.ceil(r/4)},{type:12,data:i}],dispatchGroup:{x:Math.ceil(r/aa/4)}})}},Xv=e=>{e.inputs.length<2||L.size(e.inputs[1].dims)===0?yv(e):e.compute(Gg(e.inputs))}}),lC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Fg=e=>{if(!e||e.length!==2)throw new Error("Gather requires 2 inputs.")},Hg=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=L.normalizeAxis(t.axis,a),o=r.slice(0);o.splice(s,1,...i);let u=r[s],d=e[0].dataType===9?4:1,p=Math.ceil(L.size(o)/d),m=[{type:12,data:p},{type:6,data:u},{type:12,data:s},...ye(e[0].dims,e[1].dims,o)],f=g=>{let v=K("data",e[0].dataType,e[0].dims.length,d),_=K("inputIndices",e[1].dataType,e[1].dims.length),b=he("output",e[0].dataType,o.length,d),k=w=>{let S=i.length,C=`var indicesIndices${w}  = ${_.type.indices}(0);`;for(let I=0;I<S;I++)C+=`${S>1?`indicesIndices${w}[${I}]`:`indicesIndices${w}`} = ${o.length>1?`outputIndices${w}[uniforms.axis + ${I}]`:`outputIndices${w}`};`;C+=`
          var idx${w} = ${_.getByIndices(`indicesIndices${w}`)};
          if (idx${w} < 0) {
            idx${w} = idx${w} + uniforms.axisDimLimit;
          }
          var dataIndices${w} : ${v.type.indices};
        `;for(let I=0,z=0;I<a;I++)I===s?(C+=`${a>1?`dataIndices${w}[${I}]`:`dataIndices${w}`} = u32(idx${w});`,z+=S):(C+=`${a>1?`dataIndices${w}[${I}]`:`dataIndices${w}`} = ${o.length>1?`outputIndices${w}[${z}]`:`outputIndices${w}`};`,z++);return C},$;if(e[0].dataType===9){let w=(S,C,I="")=>`
          let outputIndices${C} = ${b.offsetToIndices(`outputOffset + ${C}u`)};
          ${k(C)};
          let offset${C} = ${v.indicesToOffset(`dataIndices${C}`)};
          let index${C} = offset${C} / 4u;
          let component${C} = offset${C} % 4u;
          ${S}[${C}] = ${I}(${v.getByOffset(`index${C}`)}[component${C}]);
        `;$=`
        let outputOffset = global_idx * ${d};
        var value = vec4<u32>(0);
        ${w("value",0,"u32")}
        ${w("value",1,"u32")}
        ${w("value",2,"u32")}
        ${w("value",3,"u32")}
        ${b.setByOffset("global_idx","value")}
      `}else $=`
      let outputIndices = ${b.offsetToIndices("global_idx")};
      ${k("")};
      let value = ${v.getByIndices("dataIndices")};
      ${b.setByOffset("global_idx","value")};
      `;return`
      ${g.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(v,_,b)}
      ${g.mainStart()}
        ${g.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${$}
      }`};return{name:"Gather",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:o,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:m}),getShaderSource:f}},Jv=e=>je({axis:e.axis}),Yv=(e,t)=>{let r=e.inputs;Fg(r),e.compute(Hg(e.inputs,t))}}),dC=ee(()=>{"use strict";be(),Te(),Ee(),Kg=(e,t,r,i,a,s,o,u,d)=>{let p=[{type:12,data:s},{type:12,data:i},{type:12,data:a},{type:12,data:r},{type:12,data:o},{type:12,data:u},{type:12,data:d}],m=[s];p.push(...ye(t.dims,m));let f=g=>{let v=K("indices_data",t.dataType,t.dims.length),_=he("input_slice_offsets_data",12,1,1),b=[v,_],k=[{name:"output_size",type:"u32"},{name:"batch_dims",type:"u32"},{name:"input_dims",type:"u32",length:a.length},{name:"sizes_from_slice_dims_data",type:"u32",length:r.length},{name:"num_slices_per_batch",type:"u32"},{name:"input_batch_stride",type:"u32"},{name:"num_slice_dims",type:"u32"}];return`
  ${g.registerUniforms(k).declareVariables(...b)}
  ${g.mainStart()}
    ${g.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let batch_idx = global_idx / uniforms.num_slices_per_batch;
    let base_offset = batch_idx * uniforms.input_batch_stride;

    let slice_indices_base_offset = global_idx * uniforms.num_slice_dims;
    var relative_slice_offset = 0;
    for (var dim_idx = 0u; dim_idx < uniforms.num_slice_dims; dim_idx ++) {
      var index = i32(indices_data[dim_idx + slice_indices_base_offset].x);
      let input_dim_idx = uniforms.batch_dims + dim_idx;
      if (index < 0) {
        ${a.length===1?"index += i32(uniforms.input_dims);":"index += i32(uniforms.input_dims[input_dim_idx]);"}
      }
      ${r.length===1?"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data);":"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data[dim_idx]);"}
    }

    input_slice_offsets_data[global_idx] =  base_offset + u32(relative_slice_offset);
  }`};return e.compute({name:"computeSliceOffsets",shaderCache:{hint:`${a.length}_${r.length}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:m,dataType:e.inputs[1].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:p}),getShaderSource:f},{inputs:[t],outputs:[-1]})[0]},ew=(e,t)=>{let r=e.inputs,i=r[0].dims,a=r[0].dataType,s=r[1].dims,o=s[s.length-1],u=L.sizeToDimension(s,s.length-1),d=L.sizeFromDimension(i,t.batchDims+o),p=L.sizeToDimension(i,t.batchDims),m=L.sizeFromDimension(i,t.batchDims),f=u/p,g=new Array(o),v=d;for(let C=0;C<o;++C)g[o-1-C]=v,v*=i[t.batchDims+o-1-C];let _=Kg(e,r[1],g,t.batchDims,i,u,f,m,o),b=t.batchDims+o;if(b>i.length)throw new Error("last dimension of indices must not be larger than rank of input tensor");let k=s.slice(0,-1).concat(i.slice(b)),$=L.size(k),w=[{type:12,data:$},{type:12,data:d},...ye(r[0].dims,_.dims,k)],S=C=>{let I=K("data",r[0].dataType,r[0].dims.length),z=K("slice_offsets",12,_.dims.length),E=he("output",r[0].dataType,k.length);return`
          ${C.registerUniform("output_size","u32").registerUniform("slice_size","u32").declareVariables(I,z,E)}
            ${C.mainStart()}
            ${C.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let slice_offset = slice_offsets[global_idx / uniforms.slice_size];
          output[global_idx] = data[u32(slice_offset) + global_idx % uniforms.slice_size];
        }`};e.compute({name:"GatherND",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:k,dataType:a}],dispatchGroup:{x:Math.ceil($/64)},programUniforms:w}),getShaderSource:S},{inputs:[r[0],_]})},tw=e=>({batchDims:e.batch_dims,cacheKey:""})}),pC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Zg=(e,t)=>{if(e.length<3||e.length>4)throw new Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=L.normalizeAxis(t.quantizeAxis,e[0].dims.length),i=t.blockSize,a=e[0],s=e[2],o=e.length===4?e[3]:void 0;if(s.dims.length!==a.dims.length||!a.dims.map((u,d)=>d===r?Math.ceil(u/i)===s.dims[d]:u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(o){if(o.dataType!==a.dataType)throw new Error("Zero point must have the same data type as the input tensor.");if(o.dims.length!==s.dims.length||!o.dims.map((u,d)=>u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}},Qg=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=L.normalizeAxis(t.gatherAxis,a),o=L.normalizeAxis(t.quantizeAxis,a),u=r.slice(0);u.splice(s,1,...i);let d=L.size(u),p=e[2].dataType,m=e[0].dataType===22,f=[{type:12,data:d},{type:12,data:o},{type:12,data:s},{type:12,data:t.blockSize},...ye(...e.map((v,_)=>v.dims),u)],g=v=>{let _=K("data",e[0].dataType,e[0].dims.length),b=K("inputIndices",e[1].dataType,e[1].dims.length),k=K("scales",e[2].dataType,e[2].dims.length),$=e.length>3?K("zeroPoint",e[3].dataType,e[3].dims.length):void 0,w=he("output",p,u.length),S=[_,b,k];$&&S.push($);let C=[{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}];return`
        ${v.registerUniforms(C).declareVariables(...S,w)}
        ${v.mainStart()}
        let output_indices = ${w.offsetToIndices("global_idx")};
        var indices_indices = ${b.type.indices}(0);
        ${i.length>1?`
          for (var i: u32 = 0; i < ${i.length}; i++) {
            let index = ${w.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${b.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${w.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${_.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${w.indicesGet("output_indices","i")};
          ${_.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${b.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${r[s]};
        }
        ${_.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${u.length}; i++) {
          let index = ${w.indicesGet("output_indices",`i + ${i.length} - 1`)};
          ${_.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${_.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${_.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${m?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${k.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${k.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${k.getByIndices("scale_indices")};
        ${$?`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${$.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${$.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${m?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`:"var zero_point = 0"};
        let dequantized_data = ${xt(p)}(quantized_data - zero_point) * scale;
        ${w.setByOffset("global_idx","dequantized_data")};
    }`};return{name:"GatherBlockQuantized",shaderCache:{hint:`${t.cacheKey};${e.filter((v,_)=>_!==1).map(v=>v.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:e.length},(v,_)=>"rank")},getRunData:()=>({outputs:[{dims:u,dataType:p}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:f}),getShaderSource:g}},rw=(e,t)=>{let r=e.inputs;Zg(r,t),e.compute(Qg(e.inputs,t))},iw=e=>je({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}),cC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Xg=e=>{if(!e||e.length!==2)throw new Error("GatherElements requires 2 inputs.");if(e[0].dims.length<1)throw new Error("GatherElements requires that the data input be rank >= 1.");if(e[0].dims.length!==e[1].dims.length)throw new Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`)},Jg=(e,t)=>{let r=e[0].dims,i=e[0].dataType,a=r.length,s=e[1].dims,o=e[1].dataType,u=L.normalizeAxis(t.axis,a),d=r[u],p=s.slice(0),m=L.size(p),f=K("input",i,a),g=K("indicesInput",o,s.length),v=he("output",i,p.length),_=[{type:12,data:m},{type:6,data:d},{type:12,data:u}];return _.push(...ye(r,s,p)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:p,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:_}),getShaderSource:b=>`
      ${b.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(f,g,v)}
      ${b.mainStart()}
      ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${v.offsetToIndices("global_idx")};

      var idx = ${g.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${f.type.indices}(outputIndices);
      ${f.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${f.getByIndices("inputIndices")};

      ${v.setByOffset("global_idx","value")};
  }`}},aw=e=>je({axis:e.axis}),nw=(e,t)=>{let r=e.inputs;Xg(r),e.compute(Jg(e.inputs,t))}}),hC=ee(()=>{"use strict";be(),Te(),Ee(),Yg=e=>{if(!e)throw new Error("Input is missing");if(e.length<2||e.length>3)throw new Error("Invaid input number.");if(e.length===3&&e[2].dims.length>2)throw new Error("Invalid input shape of C");if(e[0].dataType!==e[1].dataType||e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("Input types are mismatched")},ey=(e,t)=>{let r=e[0].dims.slice(),i=e[1].dims.slice(),[a,s,o]=u0.getShapeOfGemmResult(r,t.transA,i,t.transB,e.length===3?e[2].dims:void 0),u=[a,s];if(!u)throw new Error("Can't use gemm on the given tensors");let d=16,p=Math.ceil(s/d),m=Math.ceil(a/d),f=!0,g=L.size(u),v=[{type:12,data:f?p:g},{type:12,data:a},{type:12,data:s},{type:12,data:o},{type:1,data:t.alpha},{type:1,data:t.beta}],_=["type","type"];e.length===3&&(v.push(...ye(e[2].dims)),_.push("rank")),v.push(...ye(u));let b=$=>{let w="";t.transA&&t.transB?w="value += a[k * uniforms.M + m] * b[n * uniforms.K + k];":t.transA&&!t.transB?w="value += a[k * uniforms.M + m] * b[k * uniforms.N + n];":!t.transA&&t.transB?w="value += a[m * uniforms.K + k] * b[n * uniforms.K + k];":!t.transA&&!t.transB&&(w="value += a[m * uniforms.K + k] * b[k * uniforms.N + n];");let S=t.alpha===1?"":"value *= uniforms.alpha;",C=K("a",e[0].dataType,e[0].dims),I=K("b",e[1].dataType,e[1].dims),z=C.type.value,E=null,B=[C,I];e.length===3&&(E=K("c",e[2].dataType,e[2].dims.length),B.push(E));let U=he("output",e[0].dataType,u.length);B.push(U);let V=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}];return`
  ${$.registerUniforms(V).declareVariables(...B)}

  ${$.mainStart()}
    ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let m = global_idx / uniforms.N;
    let n = global_idx % uniforms.N;

    var value = ${z}(0);
    for (var k: u32 = 0u; k < uniforms.K; k++) {
      ${w}
    }

    ${S}
    ${E!=null?`let cOffset = ${E.broadcastedIndicesToOffset("vec2(m, n)",U)}; value += ${z}(uniforms.beta) * ${E.getByOffset("cOffset")};`:""}
    output[global_idx] = value;
  }`},k=$=>{let w=K("a",e[0].dataType,e[0].dims),S=K("b",e[1].dataType,e[1].dims),C=null,I=[w,S];e.length===3&&(C=K("c",e[2].dataType,e[2].dims.length),I.push(C));let z=he("output",e[0].dataType,u.length);I.push(z);let E=[{name:"num_tile_n",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}],B="",U="";t.transA&&t.transB?(U=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[k][local_id.y] * tile_b[local_id.x][k];"):t.transA&&!t.transB?(U=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[k][local_id.y] * tile_b[k][local_id.x];"):!t.transA&&t.transB?(U=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[local_id.y][k] * tile_b[local_id.x][k];"):!t.transA&&!t.transB&&(U=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[local_id.y][k] * tile_b[k][local_id.x];");let V=t.alpha===1?"":"value *= uniforms.alpha;";return`
  ${$.registerUniforms(E).declareVariables(...I)}
  var<workgroup> tile_a: array<array<${w.type.storage}, ${d}>, ${d}>;
  var<workgroup> tile_b: array<array<${S.type.storage}, ${d}>, ${d}>;
  ${$.mainStart([d,d,1])}
    let tile_col_start = (workgroup_index % uniforms.num_tile_n) * ${d};
    let tile_row_start = (workgroup_index / uniforms.num_tile_n) * ${d};
    let num_tiles = (uniforms.K - 1) / ${d} + 1;
    var k_start = 0u;
    var value = ${z.type.value}(0);
    for (var t: u32 = 0u; t < num_tiles; t++) {
      ${U}
      k_start = k_start + ${d};
      workgroupBarrier();

      for (var k: u32 = 0u; k < ${d}; k++) {
        ${B}
      }
      workgroupBarrier();
    }

    ${V}
    let m = tile_row_start + local_id.y;
    let n = tile_col_start + local_id.x;
    ${C!=null?`let cOffset = ${C.broadcastedIndicesToOffset("vec2(m, n)",z)}; value += ${z.type.value}(uniforms.beta) * ${C.getByOffset("cOffset")};`:""}
    if (m < uniforms.M && n < uniforms.N) {
      output[m * uniforms.N + n] = value;
    }
  }`};return f?{name:"GemmShared",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:p*m},programUniforms:v}),getShaderSource:k}:{name:"Gemm",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:v}),getShaderSource:b}},sw=e=>{let t=e.transA,r=e.transB,i=e.alpha,a=e.beta;return{transA:t,transB:r,alpha:i,beta:a,cacheKey:`${e.transA};${e.transB};${e.alpha===1}`}},ow=(e,t)=>{Yg(e.inputs),e.compute(ey(e.inputs,t))}}),fC=ee(()=>{"use strict";be(),Te(),et(),Ee(),[_r,Mr,Si,Ti]=[0,1,2,3],ty=e=>{if(e[0].dims.length!==4)throw new Error("only 4-D tensor is supported.");if(e[0].dims.length!==e[1].dims.length)throw new Error("input dimensions must be equal to grid dimensions");if(e[0].dims.length-2!==e[1].dims[e[1].dims.length-1])throw new Error(`last dimension of grid must be equal to ${e[0].dims.length-2}`);if(e[0].dims[0]!==e[1].dims[0])throw new Error("grid batch size must match input batch size")},ry=`
  fn gs_get_cubic_coeffs(x: f32) -> vec4<f32> {
    let cubic_alpha = -0.75f;
    let x_abs = abs(x);
    var coeffs: vec4<f32>;
    coeffs[0] = (((cubic_alpha * (x_abs + 1) - 5 * cubic_alpha) * (x_abs + 1) + 8 * cubic_alpha) * (x_abs + 1) - 4 * cubic_alpha);
    coeffs[1] = (((cubic_alpha + 2) * x_abs - (cubic_alpha + 3)) * x_abs * x_abs + 1);
    coeffs[2] = (((cubic_alpha + 2) * (1 - x_abs) - (cubic_alpha + 3)) * (1 - x_abs) * (1 - x_abs) + 1);
    coeffs[3] = (((cubic_alpha * (2 - x_abs) - 5 * cubic_alpha) * (2 - x_abs) + 8 * cubic_alpha) * (2 - x_abs) - 4 * cubic_alpha);
    return coeffs;
  }
`,iy=e=>`
  fn gs_bicubic_interpolate(p: mat4x4<${e}>, x: f32, y: f32) -> ${e} {
    var v: vec4<f32>;
    var coeffs = gs_get_cubic_coeffs(x);
    for (var i = 0; i < 4; i++) {
      v[i] = coeffs[0] * p[i][0] + coeffs[1] * p[i][1] + coeffs[2] * p[i][2] + coeffs[3] * p[i][3];
    }
    coeffs = gs_get_cubic_coeffs(y);
    let pixel = ${e}(coeffs[0] * v[0] + coeffs[1] * v[1] + coeffs[2] * v[2] + coeffs[3] * v[3]);
    return pixel;
  }
`,ay=e=>`
  fn gs_denormalize(n: f32, length: i32) -> f32 {
    ${e.alignCorners===0?`
    // alignCorners: false => [-1, 1] to [-0.5, length - 0.5]
    return ((n + 1.0) * f32(length) - 1.0) / 2.0;
    `:`
    // alignCorners: true => [-1, 1] to [0, length - 1]
    return (n + 1.0) / 2.0 * (f32(length - 1));
    `}
  }
`,ny=e=>`
  ${e.paddingMode==="reflection"?`
      fn gs_reflect(x: i32, x_min: f32, x_max: f32) -> u32 {
        var dx = 0.0;
        var fx = f32(x);
        let range = x_max - x_min;
        if (fx < x_min) {
          dx = x_min - fx;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_min + r;
          } else {
            fx = x_max - r;
          }
        } else if (fx > x_max) {
          dx = fx - x_max;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_max - r;
          } else {
            fx = x_min + r;
          }
        }
        return u32(fx);
      }`:""}
`,sy=(e,t,r)=>`
  fn pixel_at_grid(r: i32, c: i32, H: i32, W: i32, batch: u32, channel: u32, border: vec4<f32>) -> ${t} {
     var pixel = ${t}(0);
     var indices = vec4<u32>(0);
     indices[${_r}] = batch;
     indices[${Mr}] = channel;`+(()=>{switch(r.paddingMode){case"zeros":return`
          if (r >= 0 && r < H && c >=0 && c < W) {
            indices[${Si}] = u32(r);
            indices[${Ti}] = u32(c);
          }
        `;case"border":return`
          indices[${Si}] = u32(clamp(r, 0, H - 1));
          indices[${Ti}] = u32(clamp(c, 0, W - 1));
        `;case"reflection":return`
          indices[${Si}] = gs_reflect(r, border[1], border[3]);
          indices[${Ti}] = gs_reflect(c, border[0], border[2]);
        `;default:throw new Error(`padding mode ${r.paddingMode} is not supported`)}})()+`
    return ${e.getByIndices("indices")};
  }
`,oy=(e,t,r)=>(()=>{switch(r.mode){case"nearest":return`
          let result = pixel_at_grid(i32(round(y)), i32(round(x)), H_in, W_in, indices[${_r}], indices[${Mr}], border);
        `;case"bilinear":return`
          let x1 = i32(floor(x));
          let y1 = i32(floor(y));
          let x2 = x1 + 1;
          let y2 = y1 + 1;

          let p11 = pixel_at_grid(y1, x1, H_in, W_in, indices[${_r}], indices[${Mr}], border);
          let p12 = pixel_at_grid(y1, x2, H_in, W_in, indices[${_r}], indices[${Mr}], border);
          let p21 = pixel_at_grid(y2, x1, H_in, W_in, indices[${_r}], indices[${Mr}], border);
          let p22 = pixel_at_grid(y2, x2, H_in, W_in, indices[${_r}], indices[${Mr}], border);

          let dx2 = ${t}(f32(x2) - x);
          let dx1 = ${t}(x - f32(x1));
          let dy2 = ${t}(f32(y2) - y);
          let dy1 = ${t}(y - f32(y1));
          let result = dy2 * (dx2 * p11 + dx1 * p12) + dy1 * (dx2 * p21 + dx1 * p22);
        `;case"bicubic":return`
          let x0 = i32(floor(x)) - 1;
          let y0 = i32(floor(y)) - 1;
          var p: mat4x4<${t}>;
          for (var h = 0; h < 4; h++) {
            for (var w = 0; w < 4; w++) {
              p[h][w] = pixel_at_grid(h + y0, w + x0, H_in, W_in, indices[${_r}], indices[${Mr}], border);
            }
          }

          let dx = x - f32(x0 + 1);
          let dy = y - f32(y0 + 1);
          let result = gs_bicubic_interpolate(p, dx, dy);
        `;default:throw new Error(`mode ${r.mode} is not supported`)}})()+`${e.setByOffset("global_idx","result")}`,uy=(e,t)=>{let r=K("x",e[0].dataType,e[0].dims.length),i=[e[1].dims[0],e[1].dims[1],e[1].dims[2]],a=K("grid",e[1].dataType,i.length,2),s=[e[0].dims[0],e[0].dims[1],e[1].dims[1],e[1].dims[2]];t.format==="NHWC"&&(s=[e[0].dims[0],e[1].dims[1],e[1].dims[2],e[0].dims[3]],[_r,Mr,Si,Ti]=[0,3,1,2]);let o=he("output",e[0].dataType,s.length),u=r.type.value,d=L.size(s),p=[{type:12,data:d},...ye(e[0].dims,i,s)],m=f=>`
  ${f.registerUniform("output_size","u32").declareVariables(r,a,o)}
  ${ry}
  ${iy(u)}
  ${ay(t)}
  ${ny(t)}
  ${sy(r,u,t)}

  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let H_in = i32(uniforms.x_shape[${Si}]);
      let W_in = i32(uniforms.x_shape[${Ti}]);

      ${t.alignCorners===0?`
      let x_min = -0.5;
      let x_max = f32(W_in) - 0.5;
      let y_min = -0.5;
      let y_max = f32(H_in) - 0.5;
      `:`
      let x_min = 0.0;
      let x_max = f32(W_in) - 1.0;
      let y_min = 0.0;
      let y_max = f32(H_in) - 1.0;
      `};
      let border = vec4<f32>(x_min, y_min, x_max, y_max);

      let indices = ${o.offsetToIndices("global_idx")};
      var grid_indices = vec3<u32>(indices[${_r}], indices[${Si}], indices[${Ti}]);
      let nxy = ${a.getByIndices("grid_indices")};
      var x = gs_denormalize(f32(nxy[0]), W_in);
      var y = gs_denormalize(f32(nxy[1]), H_in);

      ${oy(o,u,t)}
  }`;return{name:"GridSample",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:["type","type"]},getRunData:f=>{let g=L.size(s);return{outputs:[{dims:s,dataType:f[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:p}},getShaderSource:m}},uw=(e,t)=>{ty(e.inputs),e.compute(uy(e.inputs,t))},lw=e=>je({alignCorners:e.align_corners,mode:e.mode,paddingMode:e.padding_mode,format:e.format})}),cw=ee(()=>{"use strict";be(),Te(),et(),Ic(),Ac(),Ee(),Hr(),Tt=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,ly=(e,t)=>{let r=e[0],i=Tt(e,1),a=Tt(e,2),s=Tt(e,3),o=Tt(e,4),u=Tt(e,5),d=Tt(e,6),p=Tt(e,7);if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let m=r.dims[0],f=r.dims[1],g=r.dims.length===3?r.dims[2]:t.numHeads*r.dims[4],v=f,_=0,b=0,k=Math.floor(g/t.numHeads);if(d&&p&&L.size(d.dims)&&L.size(p.dims)){if(d.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(d.dims[0]!==m||d.dims[1]!==t.numHeads||d.dims[3]!==k)throw new Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(p.dims[0]!==m||p.dims[1]!==t.numHeads||p.dims[3]!==k)throw new Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(d.dims[2]!==p.dims[2])throw new Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(p.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');_=d.dims[2],b=d.dims[2]}else if(d&&L.size(d.dims)||p&&L.size(p.dims))throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let $;if(i&&L.size(i.dims)>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(i.dims[2]!==r.dims[2])throw new Error('Input "query" and "key" shall have same dim 2 (hidden_size)');$=2,v=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==k)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');$=5,v=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==k)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');$=0,v=i.dims[2]}}else{if(r.dims.length!==5)throw new Error('Input "query" is expected to have 5 dimensions when key is empty');if(r.dims[2]!==t.numHeads||r.dims[3]!==3)throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');$=3}if(s&&L.size(s.dims)>0){if(s.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimension');if(i&&i.dims.length===5&&i.dims[3]===2)throw new Error("bias is not allowed for packed kv.")}let w=_+v,S=0;if(o&&L.size(o.dims)>0){S=8;let E=o.dims;throw E.length===1?E[0]===m?S=1:E[0]===3*m+2&&(S=3):E.length===2&&E[0]===m&&E[1]===w&&(S=5),S===8?new Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)'):new Error("Mask not supported")}let C=!1,I=g;if(a&&L.size(a.dims)>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(v!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');I=a.dims[2]}else{if(v!==a.dims[2])throw new Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');I=a.dims[1]*a.dims[3],C=!0}}let z=!1;if(o&&L.size(o.dims)>0)throw new Error("Key padding mask is not supported");if(u&&L.size(u.dims)>0){if(u.dims.length!==4)throw new Error('Input "attention_bias" is expected to have 4 dimensions');if(u.dims[0]!==m||u.dims[1]!==t.numHeads||u.dims[2]!==f||u.dims[3]!==w)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:m,sequenceLength:f,pastSequenceLength:_,kvSequenceLength:v,totalSequenceLength:w,maxSequenceLength:b,inputHiddenSize:0,hiddenSize:g,vHiddenSize:I,headSize:k,vHeadSize:Math.floor(I/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:S,scale:t.scale,broadcastResPosBias:z,passPastInKv:C,qkvFormat:$}},dw=e=>je({...e}),Rp=je({perm:[0,2,1,3]}),dy=(e,t,r,i,a,s,o)=>{let u=[i,a,s],d=L.size(u),p=[{type:12,data:d},{type:12,data:o},{type:12,data:s}],m=f=>{let g=he("qkv_with_bias",t.dataType,u),v=K("qkv",t.dataType,u),_=K("bias",r.dataType,u),b=[{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}];return`
  ${f.registerUniforms(b).declareVariables(v,_,g)}
  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`};return e.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:u,dataType:t.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p}),getShaderSource:m},{inputs:[t,r],outputs:[-1]})[0]},Ps=(e,t,r,i,a,s,o,u)=>{let d=s;if(o&&L.size(o.dims)>0){if(i===1)throw new Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");return d=dy(e,s,o,t,i,r*a,u),d=d.reshape([t,i,r,a]),r===1||i===1?d:e.compute(Mt(d,Rp.perm),{inputs:[d],outputs:[-1]})[0]}else return s.dims.length===3&&(d=s.reshape([t,i,r,a])),r===1||i===1?d:e.compute(Mt(d,Rp.perm),{inputs:[d],outputs:[-1]})[0]},pw=(e,t)=>{let r=ly(e.inputs,t),i=e.inputs[0],a=Tt(e.inputs,1),s=Tt(e.inputs,2),o=Tt(e.inputs,3),u=Tt(e.inputs,4),d=Tt(e.inputs,5),p=Tt(e.inputs,6),m=Tt(e.inputs,7);if(i.dims.length===5)throw new Error("Packed QKV is not implemented");if(a?.dims.length===5)throw new Error("Packed KV is not implemented");let f=a&&s&&a.dims.length===4&&s.dims.length===4,g=Ps(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,i,o,0);if(f)return Vs(e,g,a,s,u,void 0,p,m,d,r);if(!a||!s)throw new Error("key and value must be provided");let v=Ps(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,a,o,r.hiddenSize),_=Ps(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,s,o,2*r.hiddenSize);Vs(e,g,v,_,u,void 0,p,m,d,r)}}),mw=ee(()=>{"use strict";be(),Te(),et(),Ee(),py=e=>{if(!e||e.length<1)throw new Error("too few inputs")},cy=(e,t)=>{let r=[],i=t.numOutputs;return e[1].dims[0]>0&&(e[1].getBigInt64Array().forEach(a=>r.push(Number(a))),i=r.length),je({numOutputs:i,axis:t.axis,splitSizes:r})},hy=e=>`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${e}u; i += 1u ) {
    if (index < ${me("uniforms.size_in_split_axis","i",e)}) {
        return i;
    }
    }
    return ${e}u;
}`,fy=e=>{let t=e.length,r=[];for(let i=0;i<t;++i){let a=e[i].setByIndices("indices","input[global_idx]");t===1?r.push(a):i===0?r.push(`if (output_number == ${i}u) { ${a} }`):i===t-1?r.push(`else { ${a} }`):r.push(`else if (output_number == ${i}) { ${a} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join(`
`)}
      }`},cc=(e,t)=>{let r=e[0].dims,i=L.size(r),a=e[0].dataType,s=L.normalizeAxis(t.axis,r.length),o=new Array(t.numOutputs),u=K("input",a,r.length),d=new Array(t.numOutputs),p=[],m=[],f=0,g=[{type:12,data:i}];for(let _=0;_<t.numOutputs;_++){f+=t.splitSizes[_],d[_]=f;let b=r.slice();b[s]=t.splitSizes[_],m.push(b),o[_]=he(`output${_}`,a,b.length),p.push({dims:m[_],dataType:e[0].dataType})}g.push({type:12,data:d},...ye(r,...m));let v=_=>`
  ${_.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",d.length).declareVariables(u,...o)}
  ${hy(d.length)}
  ${fy(o)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${u.offsetToIndices("global_idx")};
    var index = ${u.indicesGet("indices",s)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${me("uniforms.size_in_split_axis","output_number - 1u",d.length)};
      ${u.indicesSet("indices",s,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`;return{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:v,getRunData:()=>({outputs:p,dispatchGroup:{x:Math.ceil(i/64)},programUniforms:g})}},hw=(e,t)=>{py(e.inputs);let r=e.inputs.length===1?t:cy(e.inputs,t);e.compute(cc(e.inputs,r),{inputs:[0]})},fw=e=>{let t=e.axis,r=e.splitSizes,i=e.numOutputs<0?r.length:e.numOutputs;if(i!==r.length)throw new Error("numOutputs and splitSizes lengh must be equal");return je({axis:t,numOutputs:i,splitSizes:r})}}),mC=ee(()=>{"use strict";et(),Ac(),cw(),mw(),Hr(),my=(e,t)=>{if(t.doRotary)throw new Error("GroupQuerryAttention do_rotary attribute is not supported");if(t.doRotary&&e.length<=7)throw new Error("cos_cache and sin_cache inputs are required if do_rotary is specified");let r=e[0],i=e[1],a=e[2],s=e[3],o=e[4];if(t.localWindowSize!==-1)throw new Error("Local attention is not supported");if(t.softcap!==0)throw new Error("Softcap is not supported");if(t.rotaryInterleaved!==0)throw new Error("Rotary interleaved is not supported");if(t.smoothSoftmax)throw new Error("Smooth softmax is not supported");if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let u=!1,d=r.dims[0],p=r.dims[1],m=r.dims.length===3?u?r.dims[2]/3:r.dims[2]:t.numHeads*r.dims[4],f=p,g=0,v=!i||i.dims.length===0,_=Math.floor(v?m/(t.numHeads+2*t.kvNumHeads):m/t.numHeads);v&&(m=_*t.numHeads);let b=s&&s.dims.length!==0,k=o&&o.dims.length!==0;if(b&&s.dims.length===4&&s.dims[0]===d&&s.dims[1]!==t.kvNumHeads&&s.dims[2]===t.kvNumHeads&&s.dims[3]===_)throw new Error("BSNH pastKey/pastValue is not supported");if(b&&k){if(s.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(o.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');g=s.dims[2]}else if(b||k)throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let $=1;if(i&&i.dims.length>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(r.dims[2]%i.dims[2]!==0)throw new Error('Dimension 2 of "query" should be a multiple of "key"');f=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==_)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');f=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==_)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');f=i.dims[2]}}else{if(r.dims.length!==3&&r.dims.length!==5)throw new Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(r.dims.length===5&&(r.dims[2]!==t.numHeads||r.dims[3]!==3))throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');$=3}let w=0,S=!1,C=t.kvNumHeads?_*t.kvNumHeads:m;if(a&&a.dims.length>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(f!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');C=a.dims[2]}else{if(f!==a.dims[2])throw new Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');C=a.dims[1]*a.dims[3],S=!0}}let I=e.length>4?e[5]:void 0;if(I&&I.dims.length!==1&&I.dims[0]!==d)throw new Error('Input "seqlens" is expected to have 1 dimension and the same dim 0 as batch_size');return{batchSize:d,sequenceLength:p,pastSequenceLength:g,kvSequenceLength:f,totalSequenceLength:-1,maxSequenceLength:-1,inputHiddenSize:0,hiddenSize:m,vHiddenSize:C,headSize:_,vHeadSize:Math.floor(C/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:w,scale:t.scale,broadcastResPosBias:!1,passPastInKv:S,qkvFormat:$}},gy=je({perm:[0,2,1,3]}),Bp=(e,t,r)=>{let i=t,a=r.kvNumHeads;return t.dims.length===3&&r.kvSequenceLength!==0&&(i=t.reshape([r.batchSize,r.kvSequenceLength,a,r.headSize]),i=e.compute(Mt(i,gy.perm),{inputs:[i],outputs:[-1]})[0]),i},gw=(e,t)=>{let r=my(e.inputs,t);if(e.inputs[0].dims.length===5)throw new Error("Packed QKV is not implemented");if(e.inputs[1]?.dims.length===5)throw new Error("Packed KV is not implemented");let i=e.inputs[0],a=e.inputs[1]&&e.inputs[1].dims.length>0?e.inputs[1]:void 0,s=e.inputs[2]&&e.inputs[2].dims.length>0?e.inputs[2]:void 0,o=e.inputs[3]&&e.inputs[3].dims.length!==0?e.inputs[3]:void 0,u=e.inputs[4]&&e.inputs[4].dims.length!==0?e.inputs[4]:void 0,d=e.inputs.length>4?e.inputs[5]:void 0,p=e.inputs.length>5?e.inputs[6]:void 0,m=r.kvNumHeads?r.kvNumHeads:r.numHeads,f=je({axis:2,numOutputs:3,splitSizes:[r.numHeads*r.headSize,m*r.headSize,m*r.headSize]}),[g,v,_]=!a&&!s?e.compute(cc([i],f),{inputs:[i],outputs:[-1,-1,-1]}):[i,a,s],b=Ps(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,g,void 0,0);Vs(e,b,Bp(e,v,r),Bp(e,_,r),void 0,void 0,o,u,void 0,r,d,p)}}),gC=ee(()=>{"use strict";be(),Te(),Hr(),Ee(),Np=(e,t,r,i,a,s,o,u)=>{let d=Je(s),p=d===1?"f32":`vec${d}f`,m=d===1?"vec2f":`mat2x${d}f`,f=a*o,g=64;f===1&&(g=256);let v=[a,o,s/d],_=[a,o,2],b=["rank","type","type"],k=[];k.push(...ye(v,_));let $=w=>{let S=K("x",t.dataType,3,d),C=K("scale",r.dataType,r.dims),I=K("bias",i.dataType,i.dims),z=he("output",1,3,2),E=[S,C,I,z];return`
  var<workgroup> workgroup_shared : array<${m}, ${g}>;
  const workgroup_size = ${g}u;
  ${w.declareVariables(...E)}
  ${w.mainStart(g)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${p}(0);
    var squared_sum = ${p}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${p}(${S.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${m}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${Fr("workgroup_shared[0][0]",d)} / f32(hight * ${d});
      let squared_sum_final = ${Fr("workgroup_shared[0][1]",d)} / f32(hight * ${d});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${u}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`};return e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${d};${u};${g}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:_,dataType:1}],dispatchGroup:{x:f},programUniforms:k}),getShaderSource:$},{inputs:[t,r,i],outputs:[-1]})[0]},yy=(e,t,r)=>{let i=t[0].dims,a=i,s=2,o=i[0],u=i[1],d=L.sizeFromDimension(i,s),p=Je(d),m=L.size(a)/p,f=Np(e,t[0],t[1],t[2],o,d,u,r.epsilon),g=[o,u,d/p],v=[o,u],_=["type","none"],b=k=>{let $=K("x",t[0].dataType,g.length,p),w=K("scale_shift",1,v.length,2),S=he("output",t[0].dataType,g.length,p),C=[$,w,S];return`
  ${k.registerUniform("output_size","u32").declareVariables(...C)}
  ${k.mainStart()}
  ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${S.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${w.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${$.getByOffset("global_idx")} * ${S.type.value}(scale_shift.x) + ${S.type.value}(scale_shift.y);
      ${S.setByOffset("global_idx","value")};
  }`};e.compute({name:"InstanceNormalization",shaderCache:{hint:`${p}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:[{type:12,data:m},...ye(g,v,g)]}),getShaderSource:b},{inputs:[t[0],f]})},_y=(e,t,r)=>{let i=t[0].dims,a=i,s=i[0],o=i[i.length-1],u=L.sizeFromDimension(i,1)/o,d=Je(o),p=L.size(a)/d,m=[{type:12,data:u},{type:12,data:Math.floor(o/d)}],f=["type","type"],g=!1,v=[0,i.length-1];for(let $=0;$<i.length-2;$++)g=g||i[$+1]!==1,v.push($+1);g=g&&i[i.length-1]!==1;let _=g?e.compute(Mt(e.inputs[0],v),{inputs:[e.inputs[0]],outputs:[-1]})[0]:e.inputs[0].reshape(Array.from({length:i.length},($,w)=>i[v[w]])),b=Np(e,_,t[1],t[2],s,u,o,r.epsilon),k=$=>{let w=dt(t[0].dataType),S=d===1?"vec2f":`mat${d}x2f`,C=E=>{let B=E===0?"x":"y",U=d===1?"f32":`vec${d}f`;switch(d){case 1:return`${w}(${U}(scale.${B}))`;case 2:return`vec2<${w}>(${U}(scale[0].${B}, scale[1].${B}))`;case 4:return`vec4<${w}>(${U}(scale[0].${B}, scale[1].${B}, scale[2].${B}, scale[3].${B}))`;default:throw new Error(`Not supported compoents ${d}`)}},I=K("input",t[0].dataType,t[0].dims,d),z=he("output",t[0].dataType,a,d);return`
  @group(0) @binding(0) var<storage, read> input : array<${I.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${S}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${z.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${$.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${C(0)}, ${C(1)});
  }`};e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${d}`,inputDependencies:f},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:m}),getShaderSource:k},{inputs:[t[0],b]})},yw=(e,t)=>{t.format==="NHWC"?_y(e,e.inputs,t):yy(e,e.inputs,t)}}),yC=ee(()=>{"use strict";be(),Te(),Ee(),vy=e=>{if(!e||e.length<2)throw new Error("layerNorm requires at least 2 inputs.")},wy=(e,t,r)=>{let i=t.simplified,a=e[0].dims,s=e[1],o=!i&&e[2],u=a,d=L.normalizeAxis(t.axis,a.length),p=L.sizeToDimension(a,d),m=L.sizeFromDimension(a,d),f=L.size(s.dims),g=o?L.size(o.dims):0;if(f!==m||o&&g!==m)throw new Error(`Size of X.shape()[axis:] == ${m}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${f} and bias size of ${g}`);let v=[];for(let I=0;I<a.length;++I)I<d?v.push(a[I]):v.push(1);let _=Je(m),b=["type","type"],k=[{type:12,data:p},{type:1,data:m},{type:12,data:Math.floor(m/_)},{type:1,data:t.epsilon}];o&&b.push("type");let $=r>1,w=r>2,S=I=>{let z=dt(e[0].dataType),E=[K("x",e[0].dataType,e[0].dims,_),K("scale",s.dataType,s.dims,_)];o&&E.push(K("bias",o.dataType,o.dims,_)),E.push(he("output",e[0].dataType,u,_)),$&&E.push(he("mean_data_output",1,v)),w&&E.push(he("inv_std_output",1,v));let B=[{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}];return`
  ${I.registerUniforms(B).declareVariables(...E)}
  ${I.mainStart()}
    ${I.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${ic("f32",_)};
    var mean_square_vector = ${ic("f32",_)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${ra(z,_,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${Fr("mean_vector",_)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${Fr("mean_square_vector",_)} / uniforms.norm_size ${i?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${ra(z,_,"x[j + offset]")};
      let f32scale = ${ra(z,_,"scale[j]")};
      output[j + offset] = ${E[0].type.value}((f32input ${i?"":"- mean"}) * inv_std_dev * f32scale
        ${o?`+ ${ra(z,_,"bias[j]")}`:""}
      );
    }

    ${$?"mean_data_output[global_idx] = mean":""};
    ${w?"inv_std_output[global_idx] = inv_std_dev":""};
  }`},C=[{dims:u,dataType:e[0].dataType}];return $&&C.push({dims:v,dataType:1}),w&&C.push({dims:v,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${_};${r};${i}`,inputDependencies:b},getRunData:()=>({outputs:C,dispatchGroup:{x:Math.ceil(p/64)},programUniforms:k}),getShaderSource:S}},_w=(e,t)=>{vy(e.inputs),e.compute(wy(e.inputs,t,e.outputCount))}}),_C=ee(()=>{"use strict";Te(),Mc(),Dc(),by=e=>{if(!e||e.length!==2)throw new Error("MatMul requires 2 inputs.");if(e[0].dims[e[0].dims.length-1]!==e[1].dims[e[1].dims.length-2])throw new Error("shared dimension does not match.")},vw=e=>{by(e.inputs);let t=ia.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!t)throw new Error("Can't use matmul on the given tensors");let r=t[t.length-1],i=e.inputs[0].dims[e.inputs[0].dims.length-1];if(r<8&&i<8)e.compute(Nc(e.inputs,{activation:""},t));else{let a=t[t.length-2],s=L.size(e.inputs[0].dims.slice(0,-2)),o=L.size(e.inputs[1].dims.slice(0,-2));if(s!==1&&a===1&&o===1){let u=e.inputs[0].reshape([1,s,i]),d=e.inputs[1].reshape([1,i,r]),p=[1,s,r],m=[u,d];e.compute(Yo(m,{activation:""},t,p),{inputs:m})}else e.compute(Yo(e.inputs,{activation:""},t))}}}),vC=ee(()=>{"use strict";be(),Te(),et(),Ee(),$y=(e,t)=>{if(e.length<3||e.length>4)throw new Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],i=r.dims.length;if(r.dims[i-1]!==t.k)throw new Error("The last dim of input shape does not match the k value");let a=Math.floor((t.k+t.blockSize-1)/t.blockSize),s=t.blockSize/8*t.bits,o=e[1];if(!L.areEqual(o.dims,[t.n,a,s]))throw new Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let u=e[2].dims;if(L.size(u)!==t.n*a)throw new Error("scales input size error.");if(e.length===4){let d=e[3].dims,p=t.bits>4?t.n*a:t.n*Math.floor((a+1)/2);if(L.size(d)!==p)throw new Error("zeroPoints input size error.")}},xy=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,o=t.n,u=r.slice(0,i-2),d=L.size(u),p=e[1].dims[2]/4,m=e[0].dataType,f=Je(t.k),g=Je(p),v=Je(o),_=u.concat([a,o]),b=a>1&&o/v%2===0?2:1,k=L.size(_)/v/b,$=64,w=[],S=[d,a,s/f],C=L.convertShape(e[1].dims).slice();C.splice(-1,1,p/g),w.push(...ye(S)),w.push(...ye(C)),w.push(...ye(e[2].dims)),e.length===4&&w.push(...ye(L.convertShape(e[3].dims)));let I=[d,a,o/v];w.push(...ye(I));let z=E=>{let B=S.length,U=K("a",e[0].dataType,B,f),V=K("b",12,C.length,g),W=K("scales",e[2].dataType,e[2].dims.length),J=[U,V,W],D=e.length===4?K("zero_points",12,e[3].dims.length):void 0;D&&J.push(D);let se=I.length,ue=he("output",e[0].dataType,se,v),F=dt(e[0].dataType),oe=(()=>{switch(f){case 1:return`array<${F}, 8>`;case 2:return`mat4x2<${F}>`;case 4:return`mat2x4<${F}>`;default:throw new Error(`${f}-component is not supported.`)}})(),le=()=>{let M=`
          // reuse a data
            var input_offset = ${U.indicesToOffset(`${U.type.indices}(batch, row, word_offset)`)};
            var a_data: ${oe};
            for (var j: u32 = 0; j < ${8/f}; j++) {
              a_data[j] = ${U.getByOffset("input_offset")};
              input_offset++;
            }
          `;for(let q=0;q<v*b;q++)M+=`
            b_value = ${g===1?`b${q}_data`:`b${q}_data[i]`};
            b_value_lower = unpack4xU8(b_value & b_mask);
            b_value_upper = unpack4xU8((b_value >> 4) & b_mask);
            b_quantized_values = ${oe}(${Array.from({length:4},(R,X)=>`${F}(b_value_lower[${X}]), ${F}(b_value_upper[${X}])`).join(", ")});
            b_dequantized_values = ${f===1?`${oe}(${Array.from({length:8},(R,X)=>`(b_quantized_values[${X}] - ${D?`zero_point${q}`:"zero_point"}) * scale${q}`).join(", ")});`:`(b_quantized_values - ${oe}(${Array(8).fill(`${D?`zero_point${q}`:"zero_point"}`).join(",")})) * scale${q};`};
            workgroup_shared[local_id.x * ${b} + ${Math.floor(q/v)}]${v>1?`[${q%v}]`:""} += ${Array.from({length:8/f},(R,X)=>`${f===1?`a_data[${X}] * b_dequantized_values[${X}]`:`dot(a_data[${X}], b_dequantized_values[${X}])`}`).join(" + ")};
          `;return M},H=()=>{let M=`
            var col_index = col * ${v};
            ${D?`
            let zero_point_bytes_per_col = (nBlocksPerCol + 1) / 2;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${F}(8);`}
            `;for(let q=0;q<v*b;q++)M+=`
            let scale${q} = ${W.getByOffset("col_index * nBlocksPerCol + block")};
            ${D?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block >> 0x1u);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            zero_point_word = ${D.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${q} = ${F}((zero_point_word) & 0xFu);`:""}
            col_index += 1;`;return M},de=()=>{let M=`col_index = col * ${v};`;for(let q=0;q<v*b;q++)M+=`
            let b${q}_data = ${V.getByIndices(`${V.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return M+=`
            var b_value: u32;
            let b_mask: u32 = 0x0F0F0F0Fu;
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${oe};
            var b_dequantized_values: ${oe};`,M};return`
        var<workgroup> workgroup_shared: array<${ue.type.value}, ${b*$}>;
        ${E.declareVariables(...J,ue)}
        ${E.mainStart([$,1,1])}
          let output_indices = ${ue.offsetToIndices(`(global_idx / ${$}) * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += ${$}) {
            //process one block
            var word_offset: u32 = block * ${t.blockSize/f};
            ${H()}
            for (var word: u32 = 0; word < ${p}; word += ${g}) {
              ${de()}
              for (var i: u32 = 0; i < ${g}; i++) {
                ${le()}
                word_offset += ${8/f};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${b}) {
            var output_value: ${ue.type.value} = ${ue.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < ${$}u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${b};
            }
            ${ue.setByIndices(`${ue.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`};return{name:"MatMulNBits",shaderCache:{hint:`${t.blockSize};${t.bits};${f};${g};${v};${b};${$}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:_,dataType:m}],dispatchGroup:{x:k},programUniforms:w}),getShaderSource:z}},ky=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,o=t.n,u=r.slice(0,i-2),d=L.size(u),p=e[1].dims[2]/4,m=e[0].dataType,f=Je(t.k),g=Je(p),v=u.concat([a,o]),_=128,b=o%8===0?8:o%4===0?4:1,k=_/b,$=k*g*8,w=$/f,S=$/t.blockSize,C=L.size(v)/b,I=[],z=[d,a,s/f],E=L.convertShape(e[1].dims).slice();E.splice(-1,1,p/g),I.push(...ye(z)),I.push(...ye(E)),I.push(...ye(e[2].dims)),e.length===4&&I.push(...ye(L.convertShape(e[3].dims)));let B=[d,a,o];I.push(...ye(B));let U=V=>{let W=z.length,J=K("a",e[0].dataType,W,f),D=K("b",12,E.length,g),se=K("scales",e[2].dataType,e[2].dims.length),ue=[J,D,se],F=e.length===4?K("zero_points",12,e[3].dims.length):void 0;F&&ue.push(F);let oe=B.length,le=he("output",e[0].dataType,oe),H=dt(e[0].dataType),de=()=>{switch(f){case 1:return`
          let a_data0 = vec4<${H}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${H}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${H}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${H}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw new Error(`${f}-component is not supported.`)}};return`
        var<workgroup> sub_a: array<${J.type.value}, ${w}>;
        var<workgroup> inter_results: array<array<${le.type.value}, ${k}>, ${b}>;
        ${V.declareVariables(...ue,le)}
        ${V.mainStart([k,b,1])}
          let output_indices = ${le.offsetToIndices(`workgroup_index * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${S} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${w};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${w}; a_offset += ${_})
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${J.getByIndices(`${J.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${J.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${S} + local_id.x;
            ${F?`
            let zero_point_bytes_per_col = (n_blocks_per_col + 1) / 2;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block >> 0x1u);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            let zero_point_word = ${F.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${H}((zero_point_word) & 0xFu);`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${H}(8);`}
            let scale = ${se.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${D.getByIndices(`${D.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${t.blockSize/f};
            for (var i: u32 = 0; i < ${g}; i++) {
              ${de()}
              let b_value = ${g===1?"b_data":"b_data[i]"};
              let b_value_lower = unpack4xU8(b_value & 0x0F0F0F0Fu);
              let b_value_upper = unpack4xU8((b_value >> 4) & 0x0F0F0F0Fu);
              let b_quantized_values = mat2x4<${H}>(${Array.from({length:4},(M,q)=>`${H}(b_value_lower[${q}]), ${H}(b_value_upper[${q}])`).join(", ")});
              let b_dequantized_values = (b_quantized_values - mat2x4<${H}>(${Array(8).fill("zero_point").join(",")})) * scale;
              inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(M,q)=>`${`dot(a_data${q}, b_dequantized_values[${q}])`}`).join(" + ")};
              word_offset += ${8/f};
            }
            workgroupBarrier();
          }

          if (local_idx < ${b}) {
            var output_value: ${le.type.value} = ${le.type.value}(0);
            for (var b = 0u; b < ${k}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${le.setByIndices(`${le.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`};return{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${t.blockSize};${f};${g};${k};${b}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:v,dataType:m}],dispatchGroup:{x:C},programUniforms:I}),getShaderSource:U}},ww=(e,t)=>{$y(e.inputs,t),t.blockSize===32&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")?e.compute(ky(e.inputs,t)):e.compute(xy(e.inputs,t))},bw=e=>je(e)}),wC=ee(()=>{"use strict";be(),Te(),Ee(),Sy=e=>{if(!e||e.length<1)throw new Error("Too few inputs");if(e[0].dataType!==1&&e[0].dataType!==10)throw new Error("Input type must be float or float16.");if(e.length>=2){let t=e[0].dims.length*2===e[1].dims[0];if(e.length===4&&(t=e[3].dims[0]*2===e[1].dims[0]),!t)throw new Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}},Ty=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
            k = i32(${e.indicesGet("indices",a)}) - ${me("uniforms.pads",a,r)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${me("uniforms.x_shape",a,t)})) {
              break;
            }
            offset += k * i32(${me("uniforms.x_strides",a,t)});
        `;return`
          value = ${e.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${i}
            value = x[offset];
          }
      `},Cy=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${me("uniforms.pads",a,r)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${me("uniforms.x_shape",a,t)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${me("uniforms.x_shape",a,t)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${me("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},Iy=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${me("uniforms.pads",a,r)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${me("uniforms.x_shape",a,t)})) {
                  k = i32(${me("uniforms.x_shape",a,t)}) - 1;
                }
                offset += k * i32(${me("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},Ey=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${me("uniforms.pads",a,r)};
                if (k < 0)  {
                  k += i32(${me("uniforms.x_shape",a,t)}]);
                }
                if (k >= i32(${me("uniforms.x_shape",a,t)})) {
                  k -= i32(${me("uniforms.x_shape",a,t)});
                }
                offset += k * i32(${me("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},zy=(e,t,r)=>{switch(r.mode){case 0:return Ty(e,t,r.pads.length);case 1:return Cy(e,t,r.pads.length);case 2:return Iy(e,t,r.pads.length);case 3:return Ey(e,t,r.pads.length);default:throw new Error("Invalid mode")}},Ay=(e,t)=>{let r=L.padShape(e[0].dims.slice(),t.pads),i=e[0].dims,a=L.size(r),s=[{type:12,data:a},{type:6,data:t.pads}],o=e.length>=3&&e[2].data;t.mode===0&&s.push({type:o?e[2].dataType:1,data:t.value}),s.push(...ye(e[0].dims,r));let u=["rank"],d=p=>{let m=he("output",e[0].dataType,r.length),f=K("x",e[0].dataType,i.length),g=f.type.value,v=zy(m,i.length,t),_=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:t.pads.length}];return t.mode===0&&_.push({name:"constant_value",type:o?g:"f32"}),`
            ${p.registerUniforms(_).declareVariables(f,m)}
            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${m.offsetToIndices("global_idx")};

            var value = ${g}(0);
            ${v}
            output[global_idx] = value;
        }`};return{name:"Pad",shaderCache:{hint:`${t.mode}${o}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(L.size(r)/64)},programUniforms:s}),getShaderSource:d}},Oy=(e,t)=>{if(e.length>1){let r=e[1].getBigInt64Array(),i=e.length>=3&&e[2].data?e[2].dataType===10?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,a=e[0].dims.length,s=new Int32Array(2*a).fill(0);if(e.length>=4){let u=e[3].getBigInt64Array();for(let d=0;d<u.length;d++)s[Number(u[d])]=Number(r[d]),s[Number(u[d])+a]=Number(r[d+u.length])}else r.forEach((u,d)=>s[Number(d)]=Number(u));let o=[];return s.forEach(u=>o.push(u)),{mode:t.mode,value:i,pads:o}}else return t},$w=(e,t)=>{Sy(e.inputs);let r=Oy(e.inputs,t);e.compute(Ay(e.inputs,r),{inputs:[0]})}}),bC=ee(()=>{"use strict";sr(),be(),Te(),Ee(),As=e=>{if(Ke.webgpu.validateInputContent&&(!e||e.length!==1))throw new Error("Pool ops requires 1 input.")},Mp=(e,t,r)=>{let i=t.format==="NHWC",a=e.dims.slice();i&&a.splice(1,0,a.pop());let s=Object.hasOwnProperty.call(t,"dilations"),o=t.kernelShape.slice(),u=t.strides.slice(),d=s?t.dilations.slice():[],p=t.pads.slice();Xo.adjustPoolAttributes(r,a,o,u,d,p);let m=Xo.computePoolOutputShape(r,a,u,d,o,p,t.autoPad),f=Object.assign({},t);s?Object.assign(f,{kernelShape:o,strides:u,pads:p,dilations:d,cacheKey:t.cacheKey}):Object.assign(f,{kernelShape:o,strides:u,pads:p,cacheKey:t.cacheKey});let g=m.slice();return g.push(g.splice(1,1)[0]),[f,i?g:m]},Dp=(e,t)=>{let r=t.format==="NHWC",i=L.size(e),a=L.size(t.kernelShape),s=[{type:12,data:i},{type:12,data:a}],o=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let u=t.kernelShape[t.kernelShape.length-1],d=t.strides[t.strides.length-1],p=t.pads[t.pads.length/2-1],m=t.pads[t.pads.length-1],f=!!(p+m);s.push({type:12,data:u},{type:12,data:d},{type:12,data:p},{type:12,data:m}),o.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let g=!1;if(t.kernelShape.length===2){let v=t.kernelShape[t.kernelShape.length-2],_=t.strides[t.strides.length-2],b=t.pads[t.pads.length/2-2],k=t.pads[t.pads.length-2];g=!!(b+k),s.push({type:12,data:v},{type:12,data:_},{type:12,data:b},{type:12,data:k}),o.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[s,o,!0,f,g]}else{if(r)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let u=L.computeStrides(t.kernelShape);s.push({type:12,data:u},{type:12,data:t.pads},{type:12,data:t.strides}),o.push({name:"kernelStrides",type:"u32",length:u.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length});let d=t.pads.reduce((p,m)=>p+m);return[s,o,!!d,!1,!1]}},Pp=(e,t,r,i,a,s,o,u,d,p,m,f)=>{let g=a.format==="NHWC",v=t.type.value,_=he("output",t.type.tensor,i);if(a.kernelShape.length<=2){let b="",k="",$="",w=r-(g?2:1);if(m?b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${w}] = indices[${w}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${w}] < 0 || xIndices[${w}]
                      >= uniforms.x_shape[${w}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`:b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${w}] = indices[${w}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`,a.kernelShape.length===2){let S=r-(g?3:2);f?k=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${S}] < 0 || xIndices[${S}] >= uniforms.x_shape[${S}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:k=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                `,$=`
              }
            `}return`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var value = ${v}(${u});
              var pad = 0;
              ${k}
              ${b}
              ${$}
              ${o}

              output[global_idx] = value;
            }`}else{if(g)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let b=a.kernelShape.length,k=a.pads.length,$="";return p?$=`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${s}
              }`:$=`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${s}
            `,`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var offsets: array<u32, ${b}>;

              var value = ${v}(${u});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${b-1}u; j++) {
                  offsets[j] = offset / ${me("uniforms.kernelStrides","j",b)};
                  offset -= offsets[j] * ${me("uniforms.kernelStrides","j",b)};
                }
                offsets[${b-1}] = offset;

                isPad = false;
                for (var j = ${r-b}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${me("uniforms.strides",`j - ${r-b}u`,b)}
                    + offsets[j - ${r-b}u] - ${me("uniforms.pads","j - 2u",k)};
                  ${$}
              }
              ${o}

              output[global_idx] = value;
            }`}},Up=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,Ry=e=>`${Up(e)};${e.countIncludePad}`,By=e=>`${Up(e)};${e.storageOrder};${e.dilations}`,Wp=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),Vp=(e,t,r,i)=>{let[a,s]=Mp(t,i,r),o=K("x",t.dataType,t.dims.length),u=o.type.value,d="value += x_val;",p="";a.countIncludePad?p+=`value /= ${u}(uniforms.kernelSize);`:p+=`value /= ${u}(i32(uniforms.kernelSize) - pad);`;let[m,f,g,v,_]=Dp(s,a);m.push(...ye(t.dims,s));let b=["rank"];return{name:e,shaderCache:{hint:`${i.cacheKey};${g};${v};${_}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(L.size(s)/64)},programUniforms:m}),getShaderSource:k=>Pp(k,o,t.dims.length,s.length,a,d,p,0,f,g,v,_)}},xw=e=>{let t=e.count_include_pad!==0,r=Wp(e);if(r.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for AveragePool");let i={countIncludePad:t,...r,cacheKey:""};return{...i,cacheKey:Ry(i)}},kw=(e,t)=>{As(e.inputs),e.compute(Vp("AveragePool",e.inputs[0],!1,t))},qp={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},Sw=e=>{let t=e.format;return{format:t,...qp,cacheKey:t}},Tw=(e,t)=>{As(e.inputs),e.compute(Vp("GlobalAveragePool",e.inputs[0],!0,t))},jp=(e,t,r,i)=>{let[a,s]=Mp(t,i,r),o=`
      value = max(x_val, value);
    `,u="",d=K("x",t.dataType,t.dims.length),p=["rank"],[m,f,g,v,_]=Dp(s,a);return m.push(...ye(t.dims,s)),{name:e,shaderCache:{hint:`${i.cacheKey};${g};${v};${_}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(L.size(s)/64)},programUniforms:m}),getShaderSource:b=>Pp(b,d,t.dims.length,s.length,a,o,u,t.dataType===10?-65504:-1e5,f,g,v,_)}},Cw=(e,t)=>{As(e.inputs),e.compute(jp("MaxPool",e.inputs[0],!1,t))},Iw=e=>{let t=e.storage_order,r=e.dilations,i=Wp(e);if(t!==0)throw new Error("column major storage order is not yet supported for MaxPool");if(i.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for MaxPool");let a={storageOrder:t,dilations:r,...i,cacheKey:""};return{...a,cacheKey:By(a)}},Ew=e=>{let t=e.format;return{format:t,...qp,cacheKey:t}},zw=(e,t)=>{As(e.inputs),e.compute(jp("GlobalMaxPool",e.inputs[0],!0,t))}}),$C=ee(()=>{"use strict";be(),Te(),et(),Ee(),Ny=(e,t)=>{if(e.length<2||e.length>3)throw new Error("DequantizeLinear requires 2 or 3 inputs.");if(e.length===3&&e[1].dims===e[2].dims)throw new Error("x-scale and x-zero-point must have the same shape.");if(e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[0].dataType===6&&e.length>2)throw new Error("In the case of dequantizing int32 there is no zero point.");if(e[1].dims.length!==0&&e[1].dims.length!==1&&e[1].dims.length!==e[0].dims.length)throw new Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(e.length>2){if(e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[1].dims.length!==e[2].dims.length)throw new Error("scale and zero-point inputs must have the same rank.");if(!e[1].dims.map((r,i)=>r===e[2].dims[i]).reduce((r,i)=>r&&i,!0))throw new Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(e[1].dims.length===0||e[1].dims.length===1&&e[1].dims[0]===1)throw new Error("blockSize must be set only for block quantization.");if(!e[1].dims.map((a,s)=>s===t.axis||a===e[0].dims[s]).reduce((a,s)=>a&&s,!0))throw new Error("For block qunatization, scale input shape to match the input shape except for the axis");if(e[1].dims.length!==e[0].dims.length)throw new Error("For block qunatization the scale input rank must be the same as the x rank.");let r=e[0].dims[t.axis],i=e[1].dims[t.axis];if(t.blockSize<Math.ceil(r/i)||t.blockSize>Math.ceil(r/(i-1)-1))throw new Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}},My=(e,t)=>{let r=L.normalizeAxis(t.axis,e[0].dims.length),i=e[0].dataType,a=i===3,s=e[0].dims,o=e[1].dataType,u=L.size(s),d=i===3||i===2,p=d?[Math.ceil(L.size(e[0].dims)/4)]:e[0].dims,m=e[1].dims,f=e.length>2?e[2]:void 0,g=f?d?[Math.ceil(L.size(f.dims)/4)]:f.dims:void 0,v=m.length===0||m.length===1&&m[0]===1,_=v===!1&&m.length===1,b=Je(u),k=v&&(!d||b===4),$=k?b:1,w=k&&!d?b:1,S=K("input",d?12:i,p.length,w),C=K("scale",o,m.length),I=f?K("zero_point",d?12:i,g.length):void 0,z=he("output",o,s.length,$),E=[S,C];I&&E.push(I);let B=[p,m];f&&B.push(g);let U=[{type:12,data:u/$},{type:12,data:r},{type:12,data:t.blockSize},...ye(...B,s)],V=W=>{let J=[{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}];return`
      ${W.registerUniforms(J).declareVariables(...E,z)}
      ${W.mainStart()}
          ${W.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${z.offsetToIndices("global_idx")};

          // Set input x
          ${d?`
            let input = ${S.getByOffset("global_idx / 4")};
            let x_vec = ${a?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${$===1?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${S.getByOffset("global_idx")};`};

          // Set scale input
          ${v?`let scale_value= ${C.getByOffset("0")}`:_?`
            let scale_index = ${z.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${C.getByOffset("scale_index")};`:`
            var scale_indices: ${C.type.indices} = output_indices;
            let index = ${C.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${C.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${C.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${I?v?d?`
                let zero_point_input = ${I.getByOffset("0")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`:`let zero_point_value = ${I.getByOffset("0")}`:_?d?`
                let zero_point_index = ${z.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${I.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`:`
                let zero_point_index = ${z.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${I.getByOffset("zero_point_index")};`:d?`
                let zero_point_offset = ${C.indicesToOffset("scale_indices")};
                let zero_point_input = ${I.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`:`let zero_point_value = ${I.getByIndices("scale_indices")};`:`let zero_point_value = ${d?a?"i32":"u32":S.type.value}(0);`};
      // Compute and write output
      ${z.setByOffset("global_idx",`${z.type.value}(x_value - zero_point_value) * scale_value`)};
      }`};return{name:"DequantizeLinear",shaderCache:{hint:t.cacheKey,inputDependencies:I?["rank","rank","rank"]:["rank","rank"]},getShaderSource:V,getRunData:()=>({outputs:[{dims:s,dataType:o}],dispatchGroup:{x:Math.ceil(u/$/64),y:1,z:1},programUniforms:U})}},Aw=(e,t)=>{Ny(e.inputs,t),e.compute(My(e.inputs,t))},Ow=e=>je({axis:e.axis,blockSize:e.blockSize})}),xC=ee(()=>{"use strict";sr(),be(),Ee(),Dy=(e,t,r)=>{let i=e===t,a=e<t&&r<0,s=e>t&&r>0;if(i||a||s)throw new Error("Range these inputs' contents are invalid.")},Py=(e,t,r,i)=>{let a=Math.abs(Math.ceil((t-e)/r)),s=[a],o=a,u=[{type:12,data:o},{type:i,data:e},{type:i,data:r},...ye(s)],d=p=>{let m=he("output",i,s.length),f=m.type.value,g=[{name:"outputSize",type:"u32"},{name:"start",type:f},{name:"delta",type:f}];return`
        ${p.registerUniforms(g).declareVariables(m)}
        ${p.mainStart()}
        ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${f}(global_idx) * uniforms.delta;
      }`};return{name:"Range",shaderCache:{hint:`${i}`},getShaderSource:d,getRunData:()=>({outputs:[{dims:s,dataType:i}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:u})}},Rw=e=>{let t=0,r=0,i=0;e.inputs[0].dataType===6?(t=e.inputs[0].getInt32Array()[0],r=e.inputs[1].getInt32Array()[0],i=e.inputs[2].getInt32Array()[0]):e.inputs[0].dataType===1&&(t=e.inputs[0].getFloat32Array()[0],r=e.inputs[1].getFloat32Array()[0],i=e.inputs[2].getFloat32Array()[0]),Ke.webgpu.validateInputContent&&Dy(t,r,i),e.compute(Py(t,r,i,e.inputs[0].dataType),{inputs:[]})}}),kC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Uy=(e,t,r,i)=>{if(e!=="none"&&i!=="i32"&&i!=="u32"&&i!=="f32")throw new Error(`Input ${i} is not supported with reduction ${e}.`);let a=`{
                var oldValue = 0;
                loop {
                  let newValueF32 =`,s=`;
                  let newValue = bitcast<i32>(newValueF32);
                  let res = atomicCompareExchangeWeak(&${t}, oldValue, newValue);
                  if res.exchanged {
                    break;
                  }
                  oldValue = res.old_value;
                }
              }`;switch(e){case"none":return`${t}=${r};`;case"add":return i==="i32"||i==="u32"?`atomicAdd(&${t}, bitcast<${i}>(${r}));`:`
              ${a}bitcast<${i}>(oldValue) + (${r})${s}`;case"max":return i==="i32"||i==="u32"?`atomicMax(&${t}, bitcast<${i}>(${r}));`:`
                ${a}max(bitcast<f32>(oldValue), (${r}))${s}`;case"min":return i==="i32"||i==="u32"?`atomicMin(&${t}, bitcast<${i}>(${r}));`:`${a}min(bitcast<${i}>(oldValue), (${r}))${s}`;case"mul":return`${a}(bitcast<${i}>(oldValue) * (${r}))${s}`;default:throw new Error(`Reduction ${e} is not supported.`)}},Wy=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r,s=1,o=Math.ceil(L.size(i)/s),u=i[i.length-1],d=L.sizeFromDimension(r,u),p=[{type:12,data:o},{type:12,data:u},{type:12,data:d},...ye(e[1].dims,e[2].dims,a)],m=f=>{let g=K("indices",e[1].dataType,e[1].dims.length),v=K("updates",e[2].dataType,e[2].dims.length,s),_=t.reduction!=="none"&&t.reduction!==""?p0("output",e[0].dataType,a.length):he("output",e[0].dataType,a.length,s);return`
      ${f.registerUniform("output_size","u32").registerUniform("last_index_dimension","u32").registerUniform("num_updates_elements","u32").declareVariables(g,v,_)}
      ${f.mainStart()}
        ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
  var hasDuplicates = false;
  if (${t.reduction==="none"}) {
    let n = ${L.size(i)};
    for (var i = 0; i < n; i = i + 1) {
      for (var j = i + 1; j < n; j = j + 1) {
        var index_i = i32(indices[i].x);
        var index_j = i32(indices[j].x);
        if (index_i == index_j) {
          hasDuplicates = true;
          break;
        }
      }
      if (hasDuplicates) {
        break;
      }
    }
  }

  var data_offset = 0u;
  var indices_start = uniforms.last_index_dimension * global_idx;
  if (${t.reduction==="none"} && hasDuplicates) {
    if (global_idx != 0u) {
      return;
    }
    indices_start = 0u;
  }
  let indices_end = indices_start + uniforms.last_index_dimension;
  for (var i = indices_start; i < indices_end; i++) {
    var index = i32(indices[i].x);
    ${e[0].dims.length===1?`
    let element_count_dim = uniforms.output_strides;
    let dim_value = uniforms.output_shape;`:`
    let element_count_dim = uniforms.output_strides[i - indices_start];
    let dim_value = uniforms.output_shape[i - indices_start + uniforms.last_index_dimension];`}
    if (index >= 0) {
      if (index >= i32(dim_value)) {
        index = i32(dim_value - 1);
      }
    } else {
      if (index < -i32(dim_value)) {
        index = 0;
      } else {
        index += i32(dim_value);
      }
    }
    data_offset += u32((u32(index) * element_count_dim));
  }

  for (var i = 0u; i < uniforms.num_updates_elements; i++) {
    let value = updates[uniforms.num_updates_elements * global_idx + i];
    ${Uy(t.reduction,"output[data_offset + i]","value",_.type.value)}
  }

      }`};return{name:"ScatterND",shaderCache:{hint:`${t.cacheKey}_${t.reduction}`,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:p}),getShaderSource:m}},Bw=e=>je({reduction:e.reduction}),Nw=(e,t)=>{e.compute(Wy(e.inputs,t),{inputs:[e.inputs[1],e.inputs[2]],outputs:[]})}}),SC=ee(()=>{"use strict";be(),Te(),et(),Ee(),Vy=(e,t)=>{if(e.every(r=>r>0||(()=>{throw new Error("Resize requires scales input values to be positive")})),e.length>0){if(t.mode==="linear"){if(!(e.length===2||e.length===3||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1||e.length===5&&e[0]===1&&e[1]===1))throw new Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if(t.mode==="cubic"&&!(e.length===2||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1))throw new Error("Resize requires scales input size to be 2 or 4 for cubic mode")}},qy=(e,t,r)=>{t.every(a=>a>=0&&a<r||(()=>{throw new Error("Resize requires axes input values to be positive and less than rank")}));let i=new Array(r).fill(1);return t.forEach((a,s)=>i[a]=e[s]),i},jy=(e,t,r,i,a,s)=>{let[o,u,d]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],p=e[0].dims.length;if(o>0&&e.length>o&&e[o].dims.length>0)e[o].getFloat32Array().forEach(m=>s.push(m));else if(t.coordinateTransformMode==="tf_crop_and_resize")throw new Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(u>0&&e.length>u&&e[u].dims.length===1&&e[u].dims[0]>0){if(e[u].getFloat32Array().forEach(m=>i.push(m)),i.length!==0&&i.length!==p&&r>=18&&i.length!==t.axes.length)throw new Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");Vy(i,t),t.axes.length>0&&qy(i,t.axes,p).forEach((m,f)=>i[f]=m)}if(d>0&&e.length>d&&e[d].dims.length===1&&e[d].dims[0]>0&&(e[d].getBigInt64Array().forEach(m=>a.push(Number(m))),a.length!==0&&a.length!==p&&r>=18&&a.length!==t.axes.length))throw new Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(i.length!==0&&i.length!==t.axes.length)throw new Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(a.length!==0&&a.length!==t.axes.length)throw new Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if(typeof i<"u"&&typeof a<"u"&&i.length>0&&a.length>p)throw new Error("Resize requires only of scales or sizes to be specified")},Lp=(e,t,r,i)=>`
  // The whole part and the fractional part are calculated separately due to inaccuracy of floating
  // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
  // offset-by-one error later in floor().
  let big = (${e}) * (${t});
  let whole = ${i}(big / (${r}));
  let fract = ${i}(big % (${r})) / ${i}(${r});
  return whole + fract;
`,Ly=(e,t)=>`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${t} { `+(()=>{switch(e){case"asymmetric":return`
          if (xScale < 1.0 || floor(xScale) != xScale) {
            return ${t}(xResized) / ${t}(xScale);
          } else {
            ${Lp("xResized","lengthOriginal","lengthResized",t)}
          }
        `;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${t}(xResized) + 0.5) / ${t}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${t}(xResized) + 0.5) / ${t}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    ${Lp("xResized","lengthOriginal - 1","lengthResized - 1",t)}
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${t}(roiStart) * ${t}(lengthOriginal - 1) +
                        (${t}(xResized) * ${t}(roiEnd - roiStart) * ${t}(lengthOriginal - 1)) /
                        ${t}(lengthResized - 1);
                  } else {
                    return 0.5 * ${t}(roiStart + roiEnd) * ${t}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${t}xScale * ${t}(lengthResized);
                  const adjustment = ${t}(lengthResized) / outputWidth;
                  const center = ${t}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;case"half_pixel":return`return ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;default:throw new Error(`Coordinate transform mode ${e} is not supported`)}})()+"}",Gy=(e,t,r)=>`fn getNearestPixelFromOriginal(xOriginal: ${r}, isDownSample: bool) -> ${r} {`+(()=>{switch(e){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";case"simple":default:if(t<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw new Error(`Nearest mode ${e} is not supported`)}})()+"}",Fy=(e,t,r)=>{let i=new Array(r).fill(0).concat(new Array(r).fill(1)),a=e.length===0?i:e.slice();return t.length>0?(t.forEach((s,o)=>{i[s]=a[o],i[o+r]=a[t.length+o]}),i):a},Hy=(e,t,r,i)=>{let a=[];if(r.length>0)if(i.length>0){if(e.forEach(s=>a.push(s)),Math.max(...i)>e.length)throw new Error("axes is out of bound");i.forEach((s,o)=>a[s]=r[o])}else r.forEach(s=>a.push(s));else{if(t.length===0)throw new Error("Resize requires either scales or sizes.");a=e.map((s,o)=>Math.round(s*t[o]))}return a},Ky=(e,t,r)=>{let i=(()=>{switch(r.keepAspectRatioPolicy){case"not_larger":return r.axes.length>0?Math.min(...r.axes.map(s=>t[s]),Number.MAX_VALUE):Math.min(...t,Number.MAX_VALUE);case"not_smaller":return r.axes.length>0?Math.max(...r.axes.map(s=>t[s]),Number.MIN_VALUE):Math.max(...t,Number.MIN_VALUE);default:throw new Error(`Keep aspect ratio policy ${r.keepAspectRatioPolicy} is not supported`)}})();t.fill(1,0,t.length);let a=e.slice();return r.axes.length>0?(r.axes.forEach(s=>t[s]=i),r.axes.forEach(s=>a[s]=Math.round(e[s]*t[s]))):(t.fill(i,0,t.length),a.forEach((s,o)=>a[o]=Math.round(s*t[o]))),a},Zy=(e,t,r,i,a)=>`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${e.type.indices}) -> array<${e.type.value}, ${r.length}> {
      var original_indices: array<${e.type.value}, ${r.length}>;
      for (var i:u32 = 0; i < ${r.length}; i++) {
        var output_index = ${e.indicesGet("output_indices","i")};
        var scale = ${me("uniforms.scales","i",i)};
        var roi_low = ${me("uniforms.roi","i",a)};
        var roi_hi = ${me("uniforms.roi",`i + ${t.length}`,a)};
        if (scale == 1.0) {
          original_indices[i] = ${e.type.value}(output_index);
        } else {
          var input_shape_i = ${me("uniforms.input_shape","i",t.length)};
          var output_shape_i = ${me("uniforms.output_shape","i",r.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`,Qy=(e,t,r,i,a,s,o)=>`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
      var input_indices: ${e.type.indices};
      for (var i:u32 = 0; i < ${i.length}; i++) {
        var output_index = ${t.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${me("uniforms.scales","i",a)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${me("uniforms.roi","i",s)};
          var roi_hi = ${me("uniforms.roi",`i + ${r.length}`,s)};
          var input_shape_i = ${me("uniforms.input_shape","i",r.length)};
          var output_shape_i = ${me("uniforms.output_shape","i",i.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${o} || (original_idx >= 0 && original_idx < ${t.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${t.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${e.indicesSet("input_indices","i","input_index")}
      }
      return input_indices;
    }`,Xy=(e,t)=>`
    fn checkInputIndices(input_indices: ${e.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${t.length}; i++) {
        var input_index = ${e.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${me("uniforms.input_shape","i",t.length)}) {
          return false;
        }
      }
      return true;
    }`,Gp=(e,t,r,i)=>e.rank>i?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",Jy=(e,t,r,i,a)=>{let[s,o,u,d]=r.length===2?[-1,0,1,-1]:[0,2,3,1],p=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${p} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",o,`max(0, min(row, ${r[o]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(col, ${r[u]} - 1))`)};
      ${Gp(e,d,s,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${p} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${p} = originalIndices[${o}];
      var col:${p} = originalIndices[${u}];
      ${i?`if (row < 0 || row > (${r[o]} - 1) || col < 0 || col > (${r[u]} - 1)) {
        return ${a};
      }`:""};
      row = max(0, min(row, ${r[o]} - 1));
      col = max(0, min(col, ${r[u]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${d}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${s}])`:"0"};
      var x11: ${p} = getInputValue(batch, channel, row1, col1);
      var x12: ${p} = getInputValue(batch, channel, row1, col2);
      var x21: ${p} = getInputValue(batch, channel, row2, col1);
      var x22: ${p} = getInputValue(batch, channel, row2, col2);
      var dx1: ${p} = abs(row - ${p}(row1));
      var dx2: ${p} = abs(${p}(row2) - row);
      var dy1: ${p} = abs(col - ${p}(col1));
      var dy2: ${p} = abs(${p}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`},Yy=(e,t,r,i,a,s,o,u,d,p)=>{let m=r.length===2,f=!0,[g,v]=m?[0,1]:f?[2,3]:[1,2],_=e.type.value,b=k=>{let $=k===g?"row":"col";return`
      fn ${$}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${_} {
        var output_index = ${t.indicesGet("output_indices",k)};
        var originalIdx: ${_} = getOriginalCoordinateFromResizedCoordinate(output_index, ${a[k]},
        ${i[k]}, ${r[k]}, ${s[k]}, ${s[k]} + ${r.length});
        var fractOriginalIdx: ${_} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${u} && (originalIdx < 0 || originalIdx > (${r[k]} - 1))) {
          return ${d};
        }
        var data: array<${_}, 4> = array<${_}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${$}: ${_} = originalIdx + ${_}(i);
          if (${$} < 0 || ${$} >= ${r[k]}) {
            ${p?`coefs[i + 1] = 0.0;
                        continue;`:u?`return ${d};`:`${$} = max(0, min(${$}, ${r[k]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",k,`u32(${$})`)};
          data[i + 1] = ${k===g?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${b(g)};
    ${b(v)};
  fn getCubicInterpolationCoefs(s: ${_}) -> array<${_}, 4> {
    var absS = abs(s);
    var coeffs: array<${_}, 4> = array<${_}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${_} = 1.0 - absS;
    var twoMinusAbsS: ${_} = 2.0 - absS;
    var onePlusAbsS: ${_} = 1.0 + absS;
    coeffs[0] = ((${o} * onePlusAbsS - 5 * ${o}) * onePlusAbsS + 8 * ${o}) * onePlusAbsS - 4 * ${o};
    coeffs[1] = ((${o} + 2) * absS - (${o} + 3)) * absS * absS + 1;
    coeffs[2] = ((${o} + 2) * oneMinusAbsS - (${o} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${o} * twoMinusAbsS - 5 * ${o}) * twoMinusAbsS + 8 * ${o}) * twoMinusAbsS - 4 * ${o};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${_}, 4>, coefs: array<${_}, 4>) -> ${_} {
    var coefsSum: ${_} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${_} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `},e_=(e,t,r,i,a)=>{let[s,o,u,d,p]=r.length===3?[-1,0,1,2,-1]:[0,2,3,4,1],m=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${m} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",o,`max(0, min(depth, ${r[o]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(height, ${r[u]} - 1))`)};
      ${e.indicesSet("input_indices",d,`max(0, min(width, ${r[d]} - 1))`)};
      ${Gp(e,p,s,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${m} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${m} = originalIndices[${o}];
      var height:${m} = originalIndices[${u}];
      var width:${m} = originalIndices[${d}];
      ${i?`if (depth < 0 || depth > (${r[o]} - 1) || height < 0 || height > (${r[u]} - 1) || width < 0 || (width > ${r[d]} - 1)) {
      return ${a};
        }`:""};

    depth = max(0, min(depth, ${r[o]} - 1));
      height = max(0, min(height, ${r[u]} - 1));
      width = max(0, min(width, ${r[d]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${p}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${s}])`:"0"};

      var x111: ${m} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${m} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${m} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${m} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${m} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${m} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${m} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${m} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${m} = abs(depth - ${m}(depth1));
      var dx2: ${m} = abs(${m}(depth2) - depth);
      var dy1: ${m} = abs(height - ${m}(height1));
      var dy2: ${m} = abs(${m}(height2) - height);
      var dz1: ${m} = abs(width - ${m}(width1));
      var dz2: ${m} = abs(${m}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`},t_=(e,t,r,i,a,s)=>{let o=e.dims,u=Fy(s,t.axes,o.length),d=Hy(o,i,a,t.axes),p=i.slice();i.length===0&&(p=o.map((w,S)=>w===0?1:d[S]/w),t.keepAspectRatioPolicy!=="stretch"&&(d=Ky(o,p,t)));let m=he("output",e.dataType,d.length),f=K("input",e.dataType,o.length),g=L.size(d),v=o.length===d.length&&o.every((w,S)=>w===d[S]),_=t.coordinateTransformMode==="tf_crop_and_resize",b=t.extrapolationValue,k=f.type.value,$=w=>`
      ${v?"":`
      ${Ly(t.coordinateTransformMode,k)};
      ${(()=>{switch(t.mode){case"nearest":return`
              ${Xy(f,o)};
              ${Gy(t.nearestMode,r,k)};
              ${Qy(f,m,o,d,p.length,u.length,_)};
              `;case"linear":return`
              ${Zy(m,o,d,p.length,u.length)};
              ${(()=>{if(o.length===2||o.length===4)return`${Jy(f,m,o,_,b)}`;if(o.length===3||o.length===5)return`${e_(f,m,o,_,b)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(o.length===2||o.length===4)return`${Yy(f,m,o,d,p,u,t.cubicCoeffA,_,t.extrapolationValue,t.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${w.registerUniform("output_size","u32").registerUniform("scales","f32",p.length).registerUniform("roi","f32",u.length).declareVariables(f,m)}
      ${w.mainStart()}
        ${w.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${v?"output[global_idx] = input[global_idx];":`
        let output_indices = ${m.offsetToIndices("global_idx")};
        var input_indices: ${f.type.indices};
        ${(()=>{switch(t.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${f.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${t.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${o.length===2||o.length===4?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${t.mode}`)}})()};
`}
      }`;return{name:"Resize",shaderCache:{hint:`${t.cacheKey}|${r}|${p.length>0?t.mode==="cubic"?p:p.length:""}|${a.length>0?a:""}|${u.length>0?u:""}|${v}|${t.mode==="nearest"?o.length:o}`,inputDependencies:["rank"]},getShaderSource:$,getRunData:()=>({outputs:[{dims:d,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:[{type:12,data:g},{type:1,data:p},{type:1,data:u},...ye(o,d)]})}},r_=e=>{let t=e.customDataBuffer;return new Uint32Array(t,t.byteOffset,1)[0]},Mw=(e,t)=>{let r=[],i=[],a=[],s=r_(e);if(t.antialias!==0)throw Error("Only default value (0) for Antialias attribute is supported");jy(e.inputs,t,s,r,i,a),e.compute(t_(e.inputs[0],t,s,r,i,a),{inputs:[0]})},Dw=e=>{let t=e.antialias,r=e.axes,i=e.coordinateTransformMode,a=e.cubicCoeffA,s=e.excludeOutside!==0,o=e.extrapolationValue,u=e.keepAspectRatioPolicy,d=e.mode,p=e.nearestMode===""?"simple":e.nearestMode;return je({antialias:t,axes:r,coordinateTransformMode:i,cubicCoeffA:a,excludeOutside:s,extrapolationValue:o,keepAspectRatioPolicy:u,mode:d,nearestMode:p})}}),TC=ee(()=>{"use strict";be(),Te(),et(),Ee(),i_=(e,t)=>{let[r,i,a,s]=e,{numHeads:o,rotaryEmbeddingDim:u}=t;if(r.dims.length!==3&&r.dims.length!==4)throw new Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!L.areEqual(i.dims,[])&&!L.areEqual(i.dims,[1])&&i.dims.length!==2)throw new Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${i.dims.length}`);if(a.dims.length!==2)throw new Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${a.dims.length}`);if(s.dims.length!==2)throw new Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${s.dims.length}`);if(!L.areEqual(a.dims,s.dims))throw new Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(u>0&&o===0)throw new Error("num_heads must be provided if rotary_embedding_dim is specified");let d=r.dims[0],p=r.dims[r.dims.length-2],m=a.dims[0],f=L.sizeFromDimension(r.dims,1)/p,g=u===0?a.dims[1]*2:f/o;if(u>g)throw new Error("rotary_embedding_dim must be less than or equal to head_size");if(i.dims.length===2){if(d!==i.dims[0])throw new Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${i.dims[0]}`);if(p!==i.dims[1])throw new Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${i.dims[1]}`)}if(g/2!==a.dims[1]&&u/2!==a.dims[1])throw new Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${a.dims[1]}`);if(p>m)throw new Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported")},a_=(e,t)=>{let{interleaved:r,numHeads:i,rotaryEmbeddingDim:a,scale:s}=t,o=e[0].dims[0],u=L.sizeFromDimension(e[0].dims,1),d=e[0].dims[e[0].dims.length-2],p=u/d,m=e[2].dims[1],f=a===0?m*2:p/i,g=new Array(o,d,p/f,f-m),v=L.computeStrides(g),_=[{type:1,data:s},{type:12,data:g},{type:12,data:v},...e[0].dims.length===3?new Array({type:12,data:[u,p,f,1]}):[],...e[0].dims.length===4?new Array({type:12,data:[u,f,d*f,1]}):[],...ye(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)],b=k=>{let $=K("input",e[0].dataType,e[0].dims.length),w=K("position_ids",e[1].dataType,e[1].dims.length),S=K("cos_cache",e[2].dataType,e[2].dims.length),C=K("sin_cache",e[3].dataType,e[3].dims.length),I=he("output",e[0].dataType,e[0].dims.length);return k.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:g.length},{name:"global_strides",type:"u32",length:v.length},{name:"input_output_strides",type:"u32",length:v.length}]),`
        ${k.declareVariables($,w,S,C,I)}

        ${k.mainStart(aa)}
          let half_rotary_emb_dim = uniforms.${S.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${k.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${w.broadcastedIndicesToOffset("bsnh.xy",he("",w.type.tensor,2))};
            let position_id =
                u32(${w.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${$.getByOffset("i")} * ${S.get("position_id","bsnh[3]")} -
                ${$.getByOffset("j")} * ${C.get("position_id","bsnh[3]")};
            ${I.setByOffset("i","re")}
            let im = ${$.getByOffset("i")} * ${C.get("position_id","bsnh[3]")} +
                ${$.getByOffset("j")} * ${S.get("position_id","bsnh[3]")};
            ${I.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${I.setByOffset("k",$.getByOffset("k"))}
          }
        }`};return{name:"RotaryEmbedding",shaderCache:{hint:je({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:b,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(L.size(g)/aa)},programUniforms:_})}},Pw=(e,t)=>{i_(e.inputs,t),e.compute(a_(e.inputs,t))}}),CC=ee(()=>{"use strict";be(),Te(),Ee(),n_=e=>{if(!e||e.length<3)throw new Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],i=e[2];if(t.dataType!==r.dataType||t.dataType!==i.dataType)throw new Error("All inputs must have the same data type");if(t.dims.length!==3&&t.dims.length!==2)throw new Error("Input must be 2D or 3D");if(r.dims.length!==3&&r.dims.length!==2)throw new Error("Skip must be 2D or 3D");let a=t.dims[t.dims.length-1],s=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==a)throw new Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==s)throw new Error("Skip must have the same sequence length as input");if(i.dims.length!==1)throw new Error("Gamma must be 1D");if(i.dims[i.dims.length-1]!==a)throw new Error("Gamma must have the same hidden size as input");if(e.length>3){let o=e[3];if(o.dims.length!==1)throw new Error("Beta must be 1D");if(o.dims[o.dims.length-1]!==a)throw new Error("Beta must have the same hidden size as input")}if(e.length>4){let o=e[4];if(o.dims.length!==1)throw new Error("Bias must be 1D");if(o.dims[o.dims.length-1]!==a)throw new Error("Bias must have the same hidden size as input")}},s_=(e,t,r,i)=>{let a=t.simplified,s=e[0].dims,o=L.size(s),u=s,d=o,p=s.slice(-1)[0],m=i?s.slice(0,-1).concat(1):[],f=!a&&e.length>3,g=e.length>4,v=i&&r>1,_=i&&r>2,b=r>3,k=64,$=Je(p),w=[{type:12,data:d},{type:12,data:$},{type:12,data:p},{type:1,data:t.epsilon}],S=I=>{let z=[{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}],E=[K("x",e[0].dataType,e[0].dims,$),K("skip",e[1].dataType,e[1].dims,$),K("gamma",e[2].dataType,e[2].dims,$)];f&&E.push(K("beta",e[3].dataType,e[3].dims,$)),g&&E.push(K("bias",e[4].dataType,e[4].dims,$)),E.push(he("output",e[0].dataType,u,$)),v&&E.push(he("mean_output",1,m)),_&&E.push(he("inv_std_output",1,m)),b&&E.push(he("input_skip_bias_sum",e[0].dataType,u,$));let B=dt(e[0].dataType),U=dt(1,$);return`

      ${I.registerUniforms(z).declareVariables(...E)}
      var<workgroup> sum_shared : array<${U}, ${k}>;
      var<workgroup> sum_squared_shared : array<${U}, ${k}>;

      ${I.mainStart([k,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / ${k};

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / ${k};
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == ${k-1}) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${g?"bias[offset1d + i]":B+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${b?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${ra(B,$,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = ${k};
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${Fr("sum",$)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${Fr("square_sum",$)} / f32(uniforms.hidden_size) ${a?"":"- mean * mean"} + uniforms.epsilon);
        ${v?"mean_output[global_idx] = mean;":""}
        ${_?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${a?"":`- ${B}(mean)`}) *
            ${B}(inv_std_dev) * gamma[offset1d + i]
            ${f?"+ beta[offset1d + i]":""};
        }
      }`},C=[{dims:u,dataType:e[0].dataType}];return r>1&&C.push({dims:m,dataType:1}),r>2&&C.push({dims:m,dataType:1}),r>3&&C.push({dims:s,dataType:e[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${$};${v};${_};${b}`,inputDependencies:e.map((I,z)=>"type")},getShaderSource:S,getRunData:()=>({outputs:C,dispatchGroup:{x:Math.ceil(d/p)},programUniforms:w})}},Uw=(e,t)=>{n_(e.inputs);let r=[0];e.outputCount>1&&r.push(-3),e.outputCount>2&&r.push(-3),e.outputCount>3&&r.push(3),e.compute(s_(e.inputs,t,e.outputCount,!1),{outputs:r})}}),IC=ee(()=>{"use strict";be(),Te(),et(),Ee(),o_=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");if(t.axes.length!==0){if(t.axes.length!==t.starts.length||t.axes.length!==t.ends.length)throw new Error("axes, starts and ends must have the same length")}else if(t.starts.length!==t.ends.length)throw new Error("starts and ends must have the same length");e.slice(1).forEach((r,i)=>{if(e[i+1].dataType!==6&&e[i+1].dataType!==7)throw new Error(`Input ${i} must be an array of int32 or int64`)})},Os=(e,t)=>{let r=[];if(e.length>t)if(e[t].dataType===7)e[t].getBigInt64Array().forEach(i=>r.push(Number(i)));else if(e[t].dataType===6)e[t].getInt32Array().forEach(i=>r.push(Number(i)));else throw new Error(`Input ${t} must be an array of int32 or int64`);return r},u_=(e,t)=>{if(e.length>1){let r=Os(e,1),i=Os(e,2),a=Os(e,3);return a.length===0&&(a=[...Array(e[0].dims.length).keys()]),je({starts:r,ends:i,axes:a})}else return t},Fp=(e,t,r,i,a)=>{let s=e;return e<0&&(s+=r[i[t]]),a[t]<0?Math.max(0,Math.min(s,r[i[t]]-1)):Math.max(0,Math.min(s,r[i[t]]))},l_=(e,t,r)=>`fn calculateInputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
          var input_indices: ${e.type.indices};
          var carry = 0u;
          for (var i = ${r.length}; i >= 0; i--) {
            let input_shape_i = ${me("uniforms.input_shape","i",r.length)};
            let steps_i = ${me("uniforms.steps","i",r.length)};
            let signs_i = ${me("uniforms.signs","i",r.length)};
            let starts_i = ${me("uniforms.starts","i",r.length)};
            var output_index = ${t.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${e.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }`,d_=(e,t)=>{let r=e[0].dims,i=L.size(r),a=t.axes.length>0?L.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],s=Os(e,4);s.forEach($=>$!==0||(()=>{throw new Error("step cannot be 0")})),s.length===0&&(s=Array(a.length).fill(1));let o=t.starts.map(($,w)=>Fp($,w,r,a,s)),u=t.ends.map(($,w)=>Fp($,w,r,a,s));if(a.length!==o.length||a.length!==u.length)throw new Error("start, ends and axes should have the same number of elements");if(a.length!==r.length)for(let $=0;$<r.length;++$)a.includes($)||(o.splice($,0,0),u.splice($,0,r[$]),s.splice($,0,1));let d=s.map($=>Math.sign($));s.forEach(($,w,S)=>{if($<0){let C=(u[w]-o[w])/$,I=o[w],z=I+C*s[w];o[w]=z,u[w]=I,S[w]=-$}});let p=r.slice(0);a.forEach(($,w)=>{p[$]=Math.ceil((u[$]-o[$])/s[$])});let m={dims:p,dataType:e[0].dataType},f=he("output",e[0].dataType,p.length),g=K("input",e[0].dataType,e[0].dims.length),v=L.size(p),_=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:o.length},{name:"signs",type:"i32",length:d.length},{name:"steps",type:"u32",length:s.length}],b=[{type:12,data:v},{type:12,data:o},{type:6,data:d},{type:12,data:s},...ye(e[0].dims,p)],k=$=>`
      ${$.registerUniforms(_).declareVariables(g,f)}
        ${l_(g,f,r)}
        ${$.mainStart()}
          ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${f.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${f.setByOffset("global_idx",g.getByIndices("input_indices"))}
      }`;return{name:"Slice",shaderCache:{hint:`${d.length}_${o.length}_${s.length}`,inputDependencies:["rank"]},getShaderSource:k,getRunData:()=>({outputs:[m],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:b})}},Ww=(e,t)=>{o_(e.inputs,t);let r=u_(e.inputs,t);e.compute(d_(e.inputs,r),{inputs:[0]})},Vw=e=>{let t=e.starts,r=e.ends,i=e.axes;return je({starts:t,ends:r,axes:i})}}),EC=ee(()=>{"use strict";be(),Te(),et(),Hr(),Ee(),p_=e=>{if(!e||e.length!==1)throw new Error("Softmax op requires 1 input.")},c_=(e,t)=>{let r=e.inputs[0],i=r.dims,a=L.size(i),s=i.length,o=L.normalizeAxis(t.axis,s),u=o<i.length-1,d,p=[];u?(p=Array.from({length:s},(E,B)=>B),p[o]=s-1,p[s-1]=o,d=e.compute(Mt(r,p),{inputs:[r],outputs:[-1]})[0]):d=r;let m=d.dims,f=m[s-1],g=a/f,v=Je(f),_=f/v,b=64;g===1&&(b=256);let k=(E,B)=>B===4?`max(max(${E}.x, ${E}.y), max(${E}.z, ${E}.w))`:B===2?`max(${E}.x, ${E}.y)`:B===3?`max(max(${E}.x, ${E}.y), ${E}.z)`:E,$=K("x",d.dataType,d.dims,v),w=he("result",d.dataType,d.dims,v),S=$.type.value,C=dt(d.dataType)==="f32"?`var threadMax = ${S}(-3.402823e+38f);`:`var threadMax = ${S}(-65504.0h);`,I=E=>`
      var<workgroup> rowMaxShared : ${S};
      var<workgroup> rowSumShared : ${S};
      var<workgroup> threadShared : array<${S}, ${b}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${S} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${S}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${E.registerUniform("packedCols","i32").declareVariables($,w)}
      ${E.mainStart(b)}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${b};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${C}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${S}(${k("threadShared[0]",v)});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${S}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${S}(${Fr("threadShared[0]",v)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          let value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          setValue(row, col, row_stride, value);
        }
      }`,z=e.compute({name:"Softmax",shaderCache:{hint:`${v};${b}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:m,dataType:d.dataType}],dispatchGroup:{x:g},programUniforms:[{type:6,data:_}]}),getShaderSource:I},{inputs:[d],outputs:[u?-1:0]})[0];u&&e.compute(Mt(z,p),{inputs:[z]})},qw=(e,t)=>{p_(e.inputs),c_(e,t)},jw=e=>je({axis:e.axis})}),zC=ee(()=>{"use strict";be(),Te(),Ee(),Hp=e=>Array.from(e.getBigInt64Array(),Number),h_=e=>{if(!e||e.length!==2)throw new Error("Tile requires 2 inputs.");if(e[0].dataType!==1&&e[0].dataType!==10&&e[0].dataType!==6&&e[0].dataType!==12)throw new Error("Tile only support float, float16, int32, and uint32 data types");if(e[1].dataType!==7)throw new Error("Tile `repeats` input should be of int64 data type");if(e[1].dims.length!==1)throw new Error("Tile `repeats` input should be 1-D");if(Hp(e[1]).length!==e[0].dims.length)throw new Error("Tile `repeats` input should have same number of elements as rank of input data tensor")},f_=(e,t)=>{let r=[];for(let i=0;i<e.length;++i)r.push(e[i]*t[i]);return r},m_=(e,t)=>{let r=e[0].dims,i=t??Hp(e[1]),a=f_(r,i),s=L.size(a),o=e[0].dataType,u=K("input",o,r.length),d=he("output",o,a.length),p=m=>`
      const inputShape = ${u.indices(...r)};
      ${m.registerUniform("output_size","u32").declareVariables(u,d)}
      ${m.mainStart()}
      ${m.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${d.offsetToIndices("global_idx")};
      var input_indices: ${u.type.indices};
      for (var i = 0; i < ${r.length}; i++) {
        let input_dim_i = ${u.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${d.indicesGet("output_indices","i")}  % input_dim_i;

        ${u.indicesSet("input_indices","i","input_dim_value")}
      }
      ${d.setByOffset("global_idx",u.getByIndices("input_indices"))}
    }`;return{name:"Tile",shaderCache:{hint:`${i}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:[{type:12,data:s},...ye(e[0].dims,a)]}),getShaderSource:p}},Lw=e=>{h_(e.inputs),e.compute(m_(e.inputs),{inputs:[0]})}}),AC=ee(()=>{"use strict";be(),Te(),Ee(),g_=(e,t,r,i,a)=>{let s=he("output_data",a,r.length,4),o=K("a_data",t[1].dataType,t[1].dims.length,4),u=K("b_data",t[2].dataType,t[2].dims.length,4),d=K("c_data",t[0].dataType,t[0].dims.length,4),p,m=(f,g,v)=>`select(${g}, ${f}, ${v})`;if(!i)p=s.setByOffset("global_idx",m(o.getByOffset("global_idx"),u.getByOffset("global_idx"),d.getByOffset("global_idx")));else{let f=(g,v,_="")=>{let b=`a_data[index_a${v}][component_a${v}]`,k=`b_data[index_b${v}][component_b${v}]`,$=`bool(c_data[index_c${v}] & (0xffu << (component_c${v} * 8)))`;return`
            let output_indices${v} = ${s.offsetToIndices(`global_idx * 4u + ${v}u`)};
            let offset_a${v} = ${o.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let offset_b${v} = ${u.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let offset_c${v} = ${d.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let index_a${v} = offset_a${v} / 4u;
            let index_b${v} = offset_b${v} / 4u;
            let index_c${v} = offset_c${v} / 4u;
            let component_a${v} = offset_a${v} % 4u;
            let component_b${v} = offset_b${v} % 4u;
            let component_c${v} = offset_c${v} % 4u;
            ${g}[${v}] = ${_}(${m(b,k,$)});
          `};a===9?p=`
            var data = vec4<u32>(0);
            ${f("data",0,"u32")}
            ${f("data",1,"u32")}
            ${f("data",2,"u32")}
            ${f("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:p=`
            ${f("output_data[global_idx]",0)}
            ${f("output_data[global_idx]",1)}
            ${f("output_data[global_idx]",2)}
            ${f("output_data[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(d,o,u,s)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${p}
      }`},y_=e=>{let t=e[1].dims,r=e[2].dims,i=e[0].dims,a=e[1].dataType,s=!(L.areEqual(t,r)&&L.areEqual(r,i)),o=t,u=L.size(t);if(s){let p=ia.calcShape(ia.calcShape(t,r,!1),i,!1);if(!p)throw new Error("Can't perform where op on the given tensors");o=p,u=L.size(o)}let d=Math.ceil(u/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:p=>g_(p,e,o,s,a),getRunData:()=>({outputs:[{dims:o,dataType:a}],dispatchGroup:{x:Math.ceil(u/64/4)},programUniforms:[{type:12,data:d},...ye(i,t,r,o)]})}},Gw=e=>{e.compute(y_(e.inputs))}}),OC=ee(()=>{"use strict";GT(),Ac(),FT(),HT(),KT(),ZT(),QT(),tC(),iC(),aC(),nC(),sC(),oC(),uC(),lC(),dC(),pC(),cC(),hC(),fC(),mC(),gC(),yC(),_C(),vC(),cw(),wC(),bC(),$C(),xC(),kC(),zc(),SC(),TC(),CC(),IC(),EC(),mw(),zC(),Hr(),Oc(),AC(),Fw=new Map([["Abs",[W0]],["Acos",[V0]],["Acosh",[q0]],["Add",[$v]],["ArgMax",[M0,nc]],["ArgMin",[N0,nc]],["Asin",[j0]],["Asinh",[L0]],["Atan",[G0]],["Atanh",[F0]],["Attention",[D0]],["AveragePool",[kw,xw]],["BatchNormalization",[P0]],["BiasAdd",[U0]],["BiasSplitGelu",[bv]],["Cast",[K0,H0]],["Ceil",[Q0]],["Clip",[Z0]],["Concat",[Ov,Rv]],["Conv",[pc,dc]],["ConvTranspose",[jv,qv]],["Cos",[X0]],["Cosh",[J0]],["CumSum",[Lv,Gv]],["DepthToSpace",[Fv,Hv]],["DequantizeLinear",[Aw,Ow]],["Div",[xv]],["Einsum",[Kv,Zv]],["Elu",[Y0,Ds]],["Equal",[kv]],["Erf",[ev]],["Exp",[tv]],["Expand",[Qv]],["FastGelu",[Xv]],["Floor",[rv]],["FusedConv",[pc,dc]],["Gather",[Yv,Jv]],["GatherElements",[nw,aw]],["GatherBlockQuantized",[rw,iw]],["GatherND",[ew,tw]],["Gelu",[iv]],["Gemm",[ow,sw]],["GlobalAveragePool",[Tw,Sw]],["GlobalMaxPool",[zw,Ew]],["Greater",[Iv]],["GreaterOrEqual",[zv]],["GridSample",[uw,lw]],["GroupQueryAttention",[gw]],["HardSigmoid",[pv,dv]],["InstanceNormalization",[yw]],["LayerNormalization",[_w]],["LeakyRelu",[av,Ds]],["Less",[Ev]],["LessOrEqual",[Av]],["Log",[vv]],["MatMul",[vw]],["MatMulNBits",[ww,bw]],["MaxPool",[Cw,Iw]],["Mul",[Sv]],["MultiHeadAttention",[pw,dw]],["Neg",[sv]],["Not",[nv]],["Pad",[$w]],["Pow",[Tv]],["QuickGelu",[wv,Ds]],["Range",[Rw]],["Reciprocal",[ov]],["ReduceMin",[z0]],["ReduceMean",[S0]],["ReduceMax",[E0]],["ReduceSum",[O0]],["ReduceProd",[A0]],["ReduceL1",[T0]],["ReduceL2",[C0]],["ReduceLogSum",[B0]],["ReduceLogSumExp",[I0]],["ReduceSumSquare",[R0]],["Relu",[uv]],["Resize",[Mw,Dw]],["RotaryEmbedding",[Pw]],["ScatterND",[Nw,Bw]],["Sigmoid",[lv]],["Sin",[cv]],["Sinh",[hv]],["Slice",[Ww,Vw]],["SkipLayerNormalization",[Uw]],["Split",[hw,fw]],["Sqrt",[fv]],["Softmax",[qw,jw]],["Sub",[Cv]],["Tan",[mv]],["Tanh",[gv]],["ThresholdedRelu",[_v,Ds]],["Tile",[Lw]],["Transpose",[h0,f0]],["Where",[Gw]]])}),RC=ee(()=>{"use strict";sr(),Dr(),Ee(),Hw=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,i,a){nr(e.programInfo.name);let s=this.backend.device,o=this.backend.getComputePassEncoder();this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2);let u=[];for(let p of t)u.push({binding:u.length,resource:{buffer:p.buffer}});for(let p of r)u.push({binding:u.length,resource:{buffer:p.buffer}});a&&u.push({binding:u.length,resource:a});let d=s.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:u,label:e.programInfo.name});if(this.backend.sessionStatus==="capturing"){let p={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:d,dispatchGroup:i};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(p)}o.setPipeline(e.computePipeline),o.setBindGroup(0,d),o.dispatchWorkgroups(...i),this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||this.backend.queryType==="at-passes")&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),qt(e.programInfo.name)}dispose(){}build(e,t){nr(e.name);let r=this.backend.device,i=[];[{feature:"shader-f16",extension:"f16"},{feature:"subgroups",extension:"subgroups"},{feature:"subgroups-f16",extension:"subgroups_f16"}].forEach(p=>{r.features.has(p.feature)&&i.push(`enable ${p.extension};`)});let a=c0(t,this.backend.device.limits),s=e.getShaderSource(a),o=`${i.join(`
`)}
${a.additionalImplementations}
${s}`,u=r.createShaderModule({code:o,label:e.name});Ne("verbose",()=>`[WebGPU] ${e.name} shader code: ${o}`);let d=r.createComputePipeline({compute:{module:u,entryPoint:"main"},layout:"auto",label:e.name});return qt(e.name),{programInfo:e,computePipeline:d,uniformVariablesInfo:a.variablesInfo}}normalizeDispatchGroupSize(e){let t=typeof e=="number"?e:e.x,r=typeof e=="number"?1:e.y||1,i=typeof e=="number"?1:e.z||1,a=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=a&&r<=a&&i<=a)return[t,r,i];let s=t*r*i,o=Math.ceil(Math.sqrt(s));if(o>a){if(o=Math.ceil(Math.cbrt(s)),o>a)throw new Error("Total dispatch size exceeds WebGPU maximum.");return[o,o,o]}else return[o,o,1]}}}),BC=ee(()=>{"use strict";sr(),be(),Dr(),s0(),jT(),OC(),RC(),__=(e,t)=>{if(t.length!==e.length)throw new Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let i=0;i<e.length;++i){let a=e[i].dataType;switch(t[i]){case"none":{r.push("");break}case"type":{r.push(`${a}`);break}case"rank":{let s=e[i].dims.length;r.push(`${a};${s}`);break}case"dims":{let s=e[i].dims.join(",");r.push(`${a};${s}`);break}default:throw new Error(`unsupported input dependency: ${t[i]}`)}}return r.join("|")},v_=(e,t,r)=>{let i=e.name;return e.shaderCache?.hint&&(i+="["+e.shaderCache.hint+"]"),i+=":"+r+`:${__(t,e.shaderCache?.inputDependencies??new Array(t.length).fill("dims"))}`,i},w_=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},b_=class{constructor(e){this.subgroupsSupported=e.features.has("subgroups"),this.subgroupsF16Supported=e.features.has("subgroups");let t=e.limits;!this.subgroupsSupported||!t.minSubgroupSize||!t.maxSubgroupSize?this.subgroupSizeRange=void 0:this.subgroupSizeRange=[t.minSubgroupSize,t.maxSubgroupSize]}},Kw=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(this.currentKernelId===null)throw new Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],i={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r},a=s=>t.features.has(s)&&r.push(s)&&!0;a("chromium-experimental-timestamp-query-inside-passes")||a("timestamp-query"),a("shader-f16"),a("subgroups")&&a("subgroups-f16"),this.device=await t.requestDevice(i),this.deviceInfo=new b_(this.device),this.adapterInfo=new w_(t.info||await t.requestAdapterInfo()),this.gpuDataManager=o0(this),this.programManager=new Hw(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,Tc(e.logLevel,!!e.debug),this.device.onuncapturederror=s=>{s.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${s.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!1}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){typeof this.querySet<"u"&&this.querySet.destroy(),this.gpuDataManager.dispose()}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};this.queryType==="at-passes"&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:this.pendingDispatchNumber*2,endOfPassWriteIndex:this.pendingDispatchNumber*2+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){if(!this.commandEncoder)return;nr(),this.endComputePass();let e;this.queryType!=="none"&&(this.commandEncoder.resolveQuerySet(this.querySet,0,this.pendingDispatchNumber*2,this.queryResolveBuffer,0),e=this.device.createBuffer({size:this.pendingDispatchNumber*2*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,this.pendingDispatchNumber*2*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,this.queryType!=="none"&&e.mapAsync(GPUMapMode.READ).then(()=>{let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let i=0;i<t.length/2;i++){let a=r[i],s=a.kernelId,o=this.kernels.get(s),u=o.kernelType,d=o.kernelName,p=a.programName,m=a.inputTensorViews,f=a.outputTensorViews,g=t[i*2],v=t[i*2+1];typeof this.queryTimeBase>"u"&&(this.queryTimeBase=g);let _=Number(g-this.queryTimeBase),b=Number(v-this.queryTimeBase);if(!Number.isSafeInteger(_)||!Number.isSafeInteger(b))throw new RangeError("incorrect timestamp range");if(this.env.webgpu.profiling?.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:m.map(k=>({dims:k.dims,dataType:zi(k.dataType)})),outputsMetadata:f.map(k=>({dims:k.dims,dataType:zi(k.dataType)})),kernelId:s,kernelType:u,kernelName:d,programName:p,startTime:_,endTime:b});else{let k="";m.forEach((w,S)=>{k+=`input[${S}]: [${w.dims}] | ${zi(w.dataType)}, `});let $="";f.forEach((w,S)=>{$+=`output[${S}]: [${w.dims}] | ${zi(w.dataType)}, `}),console.log(`[profiling] kernel "${s}|${u}|${d}|${p}" ${k}${$}execution time: ${b-_} ns`)}Ws("GPU",`${p}::${g}::${v}`)}e.unmap(),this.pendingQueries.delete(e)}),qt()}run(e,t,r,i,a,s){nr(e.name);let o=[];for(let w=0;w<t.length;++w){let S=t[w].data;if(S===0)continue;let C=this.gpuDataManager.get(S);if(!C)throw new Error(`no GPU data for input: ${S}`);o.push(C)}let{outputs:u,dispatchGroup:d,programUniforms:p}=e.getRunData(t),m=r.length===0?u.map((w,S)=>S):r;if(m.length!==u.length)throw new Error(`Output size ${m.length} must be equal to ${u.length}.`);let f=[],g=[];for(let w=0;w<u.length;++w){if(!Number.isInteger(m[w])||m[w]<-3||m[w]>=s)throw new Error(`Invalid output index: ${m[w]}`);if(m[w]===-3)continue;let S=m[w]===-1,C=m[w]===-2,I=S||C?a(u[w].dataType,u[w].dims):i(m[w],u[w].dataType,u[w].dims);if(f.push(I),I.data===0)continue;let z=this.gpuDataManager.get(I.data);if(!z)throw new Error(`no GPU data for output: ${I.data}`);if(S&&this.temporaryData.push(z),C){let E=this.kernelPersistentData.get(this.currentKernelId);E||(E=[],this.kernelPersistentData.set(this.currentKernelId,E)),E.push(z)}g.push(z)}if(o.length!==t.length||g.length!==f.length){if(g.length===0)return qt(e.name),f;throw new Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}let v;if(p){let w=0,S=[];p.forEach(E=>{let B=typeof E.data=="number"?[E.data]:E.data;if(B.length===0)return;let U=E.type===10?2:4,V,W;E.type===10?(W=B.length>4?16:B.length>2?8:B.length*U,V=B.length>4?16:U*B.length):(W=B.length<=2?B.length*U:16,V=16),w=Math.ceil(w/W)*W,S.push(w);let J=E.type===10?8:4;w+=B.length>4?Math.ceil(B.length/J)*V:B.length*U});let C=16;w=Math.ceil(w/C)*C;let I=new ArrayBuffer(w);p.forEach((E,B)=>{let U=S[B],V=typeof E.data=="number"?[E.data]:E.data;if(E.type===6)new Int32Array(I,U,V.length).set(V);else if(E.type===12)new Uint32Array(I,U,V.length).set(V);else if(E.type===10)new Uint16Array(I,U,V.length).set(V);else if(E.type===1)new Float32Array(I,U,V.length).set(V);else throw new Error(`Unsupported uniform type: ${zi(E.type)}`)});let z=this.gpuDataManager.create(w,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(z.buffer,0,I,0,w),this.gpuDataManager.release(z.id),v={offset:0,size:w,buffer:z.buffer}}let _=this.programManager.normalizeDispatchGroupSize(d),b=_[1]===1&&_[2]===1,k=v_(e,t,b),$=this.programManager.getArtifact(k);if($||($=this.programManager.build(e,_),this.programManager.setArtifact(k,$),Ne("info",()=>`[artifact] key: ${k}, programName: ${e.name}`)),p&&$.uniformVariablesInfo){if(p.length!==$.uniformVariablesInfo.length)throw new Error(`Uniform variables count mismatch: expect ${$.uniformVariablesInfo.length}, got ${p.length} in program "${$.programInfo.name}".`);for(let w=0;w<p.length;w++){let S=p[w],C=S.type,I=typeof S.data=="number"?1:S.data.length,[z,E]=$.uniformVariablesInfo[w];if(C!==z||I!==E)throw new Error(`Uniform variable ${w} mismatch: expect type ${z} with size ${E}, got type ${C} with size ${I} in program "${$.programInfo.name}".`)}}if(Ne("info",()=>`[ProgramManager] run "${e.name}" (key=${k}) with ${_[0]}x${_[1]}x${_[2]}`),this.queryType!=="none"||this.sessionStatus==="capturing"){let w={kernelId:this.currentKernelId,programName:$.programInfo.name,inputTensorViews:t,outputTensorViews:f};this.pendingKernels.push(w),this.sessionStatus==="capturing"&&this.capturedPendingKernels.get(this.currentSessionId).push(w)}return this.programManager.run($,o,g,_,v),qt(e.name),f}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,i){let a=Fw.get(e);if(!a)throw new Error(`kernel not implemented: ${e}`);let s={kernelType:e,kernelName:i,kernelEntry:a[0],attributes:[a[1],r]};this.kernels.set(t,s)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let r of t)this.gpuDataManager.release(r.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let i=this.kernels.get(e);if(!i)throw new Error(`kernel not created: ${e}`);let a=i.kernelType,s=i.kernelName,o=i.kernelEntry,u=i.attributes;if(this.currentKernelId!==null)throw new Error(`kernel "[${a}] ${s}" is not allowed to be called recursively`);this.currentKernelId=e,u[0]&&(u[1]=u[0](u[1]),u[0]=void 0),Ne("info",()=>`[WebGPU] Start to run kernel "[${a}] ${s}"...`);let d=this.env.debug;this.temporaryData=[];try{return d&&this.device.pushErrorScope("validation"),o(t,u[1]),0}catch(p){return r.push(Promise.resolve(`[WebGPU] Kernel "[${a}] ${s}" failed. ${p}`)),1}finally{d&&r.push(this.device.popErrorScope().then(p=>p?`GPU validation error for kernel "[${a}] ${s}": ${p.message}`:null));for(let p of this.temporaryData)this.gpuDataManager.release(p.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,i){let a=this.sessionExternalDataMapping.get(e);a||(a=new Map,this.sessionExternalDataMapping.set(e,a));let s=a.get(t),o=this.gpuDataManager.registerExternalBuffer(r,i,s);return a.set(t,[o,r]),o}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(r=>this.gpuDataManager.unregisterExternalBuffer(r[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw new Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let i=await rc(this,e,t);return Cc(i.buffer,r)}}writeTimestamp(e){this.queryType==="inside-passes"&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){this.queryType="none",(this.env.webgpu.profiling?.mode==="default"||(typeof this.env.trace>"u"?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),this.queryType!=="none"&&typeof this.querySet>"u"&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:this.maxDispatchNumber*2}),this.queryResolveBuffer=this.device.createBuffer({size:this.maxDispatchNumber*2*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){Ne("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){Ne("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){Ne("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let i=0;i<r;i++){let a=this.getComputePassEncoder(),s=e[i];this.writeTimestamp(this.pendingDispatchNumber*2),a.setPipeline(s.computePipeline),a.setBindGroup(0,s.bindGroup),a.dispatchWorkgroups(...s.dispatchGroup),this.writeTimestamp(this.pendingDispatchNumber*2+1),this.pendingDispatchNumber++,this.queryType!=="none"&&this.pendingKernels.push(t[i]),(this.pendingDispatchNumber>=this.maxDispatchNumber||this.queryType==="at-passes")&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onCreateSession(){this.gpuDataManager.onCreateSession()}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}),NC=ee(()=>{"use strict";Dr(),$_=1,Kp=()=>$_++,x_=new Map([["float32",32],["float16",16],["int32",32],["uint32",32],["int64",64],["uint64",64],["int8",8],["uint8",8],["int4",4],["uint4",4]]),Zp=(e,t)=>{let r=x_.get(e);if(!r)throw new Error("Unsupported data type.");return t.length>0?Math.ceil(t.reduce((i,a)=>i*a)*r/8):0},Qp=class{constructor(e){this.sessionId=e.sessionId,this.mlContext=e.context,this.mlTensor=e.tensor,this.dataType=e.dataType,this.tensorShape=e.shape}get tensor(){return this.mlTensor}get type(){return this.dataType}get shape(){return this.tensorShape}get byteLength(){return Zp(this.dataType,this.tensorShape)}destroy(){Ne("verbose",()=>"[WebNN] TensorWrapper.destroy"),this.mlTensor.destroy()}write(e){this.mlContext.writeTensor(this.mlTensor,e)}async read(e){return e?this.mlContext.readTensor(this.mlTensor,e):this.mlContext.readTensor(this.mlTensor)}canReuseTensor(e,t,r){return this.mlContext===e&&this.dataType===t&&this.tensorShape.length===r.length&&this.tensorShape.every((i,a)=>i===r[a])}},Xp=class{constructor(e,t){this.tensorManager=e,this.wrapper=t}get tensorWrapper(){return this.wrapper}releaseTensor(){this.tensorWrapper&&(this.tensorManager.releaseTensor(this.tensorWrapper),this.wrapper=void 0)}async ensureTensor(e,t,r,i){let a=this.tensorManager.getMLContext(e);if(this.wrapper){if(this.wrapper.canReuseTensor(a,t,r))return this.wrapper.tensor;if(i){if(this.wrapper.byteLength!==Zp(t,r))throw new Error("Unable to copy data to tensor with different size.");this.activeUpload=new Uint8Array(await this.wrapper.read())}this.tensorManager.releaseTensor(this.wrapper)}let s=typeof MLTensorUsage>"u"?void 0:MLTensorUsage.READ|MLTensorUsage.WRITE;return this.wrapper=await this.tensorManager.getCachedTensor(e,t,r,s,!0,!0),i&&this.activeUpload&&(this.wrapper.write(this.activeUpload),this.activeUpload=void 0),this.wrapper.tensor}upload(e){if(this.wrapper)if(e.byteLength===this.wrapper.byteLength){this.wrapper.write(e);return}else Ne("verbose",()=>"Data size does not match tensor size. Releasing tensor."),this.releaseTensor();this.activeUpload?this.activeUpload.set(e):this.activeUpload=new Uint8Array(e)}async download(e){if(this.activeUpload)if(e){e instanceof ArrayBuffer?new Uint8Array(e).set(this.activeUpload):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(this.activeUpload);return}else return this.activeUpload.buffer;if(!this.wrapper)throw new Error("Tensor has not been created.");return e?this.wrapper.read(e):this.wrapper.read()}},k_=class{constructor(e){this.backend=e,this.tensorTrackersById=new Map,this.freeTensors=[],this.externalTensors=new Set}getMLContext(e){let t=this.backend.getMLContext(e);if(!t)throw new Error("MLContext not found for session.");return t}reserveTensorId(){let e=Kp();return this.tensorTrackersById.set(e,new Xp(this)),e}releaseTensorId(e){let t=this.tensorTrackersById.get(e);t&&(this.tensorTrackersById.delete(e),t.tensorWrapper&&this.releaseTensor(t.tensorWrapper))}async ensureTensor(e,t,r,i,a){Ne("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${t}, dataType: ${r}, shape: ${i}, copyOld: ${a}}`);let s=this.tensorTrackersById.get(t);if(!s)throw new Error("Tensor not found.");return s.ensureTensor(e,r,i,a)}upload(e,t){let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");r.upload(t)}async download(e,t){Ne("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t?.byteLength}}`);let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");return r.download(t)}releaseTensorsForSession(e){for(let t of this.freeTensors)t.sessionId===e&&t.destroy();this.freeTensors=this.freeTensors.filter(t=>t.sessionId!==e)}registerTensor(e,t,r,i){let a=this.getMLContext(e),s=Kp(),o=new Qp({sessionId:e,context:a,tensor:t,dataType:r,shape:i});return this.tensorTrackersById.set(s,new Xp(this,o)),this.externalTensors.add(o),s}async getCachedTensor(e,t,r,i,a,s){let o=this.getMLContext(e);for(let[d,p]of this.freeTensors.entries())if(p.canReuseTensor(o,t,r)){Ne("verbose",()=>`[WebNN] Reusing tensor {dataType: ${t}, shape: ${r}}`);let m=this.freeTensors.splice(d,1)[0];return m.sessionId=e,m}Ne("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${t}, shape: ${r}}`);let u=await o.createTensor({dataType:t,shape:r,dimensions:r,usage:i,writable:a,readable:s});return new Qp({sessionId:e,context:o,tensor:u,dataType:t,shape:r})}releaseTensor(e){this.externalTensors.has(e)&&this.externalTensors.delete(e),this.freeTensors.push(e)}},Zw=(...e)=>new k_(...e)}),MC=ee(()=>{"use strict";be(),Mi(),s0(),NC(),Dr(),qo=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[22,"int4"],[21,"uint4"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),S_=(e,t)=>{if(e===t)return!0;if(e===void 0||t===void 0)return!1;let r=Object.keys(e).sort(),i=Object.keys(t).sort();return r.length===i.length&&r.every((a,s)=>a===i[s]&&e[a]===t[a])},Qw=class{constructor(e){this.tensorManager=Zw(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,this.mlContextCache=[],this.sessionGraphInputs=new Map,this.temporaryGraphInputs=[],this.temporarySessionTensorIds=new Map,Tc(e.logLevel,!!e.debug)}get currentSessionId(){if(this.activeSessionId===void 0)throw new Error("No active session");return this.activeSessionId}onRunStart(e){Ne("verbose",()=>`[WebNN] onRunStart {sessionId: ${e}}`),this.activeSessionId=e}onRunEnd(e){Ne("verbose",()=>`[WebNN] onRunEnd {sessionId: ${e}}`);let t=this.temporarySessionTensorIds.get(e);if(t){for(let r of t)Ne("verbose",()=>`[WebNN] releasing temporary tensor {tensorId: ${r}}`),this.tensorManager.releaseTensorId(r);this.temporarySessionTensorIds.delete(e),this.activeSessionId=void 0}}async createMLContext(e){if(e instanceof GPUDevice){let r=this.mlContextCache.findIndex(i=>i.gpuDevice===e);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext(e);return this.mlContextCache.push({gpuDevice:e,mlContext:i}),i}}else if(e===void 0){let r=this.mlContextCache.findIndex(i=>i.options===void 0&&i.gpuDevice===void 0);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext();return this.mlContextCache.push({mlContext:i}),i}}let t=this.mlContextCache.findIndex(r=>S_(r.options,e));if(t!==-1)return this.mlContextCache[t].mlContext;{let r=await navigator.ml.createContext(e);return this.mlContextCache.push({options:e,mlContext:r}),r}}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e),this.temporaryGraphInputs.length>0&&(this.sessionGraphInputs.set(e,this.temporaryGraphInputs),this.temporaryGraphInputs=[])}onReleaseSession(e){this.sessionGraphInputs.delete(e);let t=this.mlContextBySessionId.get(e);if(!t)return;this.tensorManager.releaseTensorsForSession(e),this.mlContextBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);if(r.delete(e),r.size===0){this.sessionIdsByMLContext.delete(t);let i=this.mlContextCache.findIndex(a=>a.mlContext===t);i!==-1&&this.mlContextCache.splice(i,1)}}getMLContext(e){return this.mlContextBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){Ne("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,i,a){let s=qo.get(r);if(!s)throw new Error(`Unsupported ONNX data type: ${r}`);return this.tensorManager.ensureTensor(e??this.currentSessionId,t,s,i,a)}async createTemporaryTensor(e,t,r){Ne("verbose",()=>`[WebNN] createTemporaryTensor {onnxDataType: ${t}, shape: ${r}}`);let i=qo.get(t);if(!i)throw new Error(`Unsupported ONNX data type: ${t}`);let a=this.tensorManager.reserveTensorId();await this.tensorManager.ensureTensor(e,a,i,r,!1);let s=this.temporarySessionTensorIds.get(e);return s?s.push(a):this.temporarySessionTensorIds.set(e,[a]),a}uploadTensor(e,t){if(!lt().shouldTransferToMLTensor)throw new Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");Ne("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return Cc(r,t)}}registerMLTensor(e,t,r,i){let a=qo.get(r);if(!a)throw new Error(`Unsupported ONNX data type: ${r}`);let s=this.tensorManager.registerTensor(e,t,a,i);return Ne("verbose",()=>`[WebNN] registerMLTensor {tensor: ${t}, dataType: ${a}, dimensions: ${i}} -> {tensorId: ${s}}`),s}registerMLConstant(e,t,r,i,a,s){if(!s)throw new Error("External mounted files are not available.");let o=e;e.startsWith("./")&&(o=e.substring(2));let u=s.get(o);if(!u)throw new Error(`File with name ${o} not found in preloaded files.`);if(t+r>u.byteLength)throw new Error("Out of bounds: data offset and length exceed the external file data size.");let d=u.slice(t,t+r).buffer,p;switch(a.dataType){case"float32":p=new Float32Array(d);break;case"float16":p=new Uint16Array(d);break;case"int32":p=new Int32Array(d);break;case"uint32":p=new Uint32Array(d);break;case"int64":p=new BigInt64Array(d);break;case"uint64":p=new BigUint64Array(d);break;case"int8":p=new Int8Array(d);break;case"int4":case"uint4":case"uint8":p=new Uint8Array(d);break;default:throw new Error(`Unsupported data type: ${a.dataType} in creating WebNN Constant from external data.`)}return Ne("verbose",()=>`[WebNN] registerMLConstant {dataType: ${a.dataType}, shape: ${a.shape}}}`),i.constant(a,p)}registerGraphInput(e){this.temporaryGraphInputs.push(e)}isGraphInput(e,t){let r=this.sessionGraphInputs.get(e);return r?r.includes(t):!1}flush(){}}}),Xw={};qs(Xw,{init:()=>Jw});DC=ee(()=>{"use strict";be(),BC(),Dr(),Te(),MC(),jo=class Yw{constructor(t,r,i,a){this.module=t,this.dataType=r,this.data=i,this.dims=a}getFloat32Array(){if(this.dataType!==1)throw new Error("Invalid data type");let t=L.size(this.dims);return t===0?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,t)}getBigInt64Array(){if(this.dataType!==7)throw new Error("Invalid data type");let t=L.size(this.dims);return t===0?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,t)}getInt32Array(){if(this.dataType!==6)throw new Error("Invalid data type");let t=L.size(this.dims);return t===0?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,t)}getUint16Array(){if(this.dataType!==10&&this.dataType!==4)throw new Error("Invalid data type");let t=L.size(this.dims);return t===0?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,t)}reshape(t){if(L.size(t)!==L.size(this.dims))throw new Error("Invalid new shape");return new Yw(this.module,this.dataType,this.data,t)}},T_=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo,this.deviceInfo=t.deviceInfo;let i=e.PTR_SIZE,a=r/e.PTR_SIZE,s=i===4?"i32":"i64";this.opKernelContext=Number(e.getValue(i*a++,s));let o=Number(e.getValue(i*a++,s));this.outputCount=Number(e.getValue(i*a++,s)),this.customDataOffset=Number(e.getValue(i*a++,"*")),this.customDataSize=Number(e.getValue(i*a++,s));let u=[];for(let d=0;d<o;d++){let p=Number(e.getValue(i*a++,s)),m=Number(e.getValue(i*a++,"*")),f=Number(e.getValue(i*a++,s)),g=[];for(let v=0;v<f;v++)g.push(Number(e.getValue(i*a++,s)));u.push(new jo(e,p,m,g))}this.inputs=u}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}compute(e,t){let r=t?.inputs?.map(o=>typeof o=="number"?this.inputs[o]:o)??this.inputs,i=t?.outputs??[],a=(o,u,d)=>new jo(this.module,u,this.output(o,d),d),s=(o,u)=>{let d=Ai(o,u);if(!d)throw new Error(`Unsupported data type: ${o}`);let p=d>0?this.backend.gpuDataManager.create(d).id:0;return new jo(this.module,o,p,u)};return this.backend.run(e,r,i,a,s,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let i=this.module.PTR_SIZE,a=i===4?"i32":"i64",s=this.module.stackAlloc((1+t.length)*i);this.module.setValue(s,t.length,a);for(let o=0;o<t.length;o++)this.module.setValue(s+i*(o+1),t[o],a);return this.module._JsepOutput(this.opKernelContext,e,s)}catch(i){throw new Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${i}`)}finally{this.module.stackRestore(r)}}},Jw=async(e,t,r,i)=>{let a=t.jsepInit;if(!a)throw new Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if(e==="webgpu"){let s=new Kw;await s.initialize(r,i),a("webgpu",[s,o=>s.alloc(Number(o)),o=>s.free(o),(o,u,d,p=!1)=>{if(p)Ne("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${Number(o)}, dst=${Number(u)}, size=${Number(d)}`),s.memcpy(Number(o),Number(u));else{Ne("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${Number(o)}, gpuDataId=${Number(u)}, size=${Number(d)}`);let m=t.HEAPU8.subarray(Number(o>>>0),Number(o>>>0)+Number(d));s.upload(Number(u),m)}},async(o,u,d)=>{Ne("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${o}, dataOffset=${u}, size=${d}`),await s.download(Number(o),()=>t.HEAPU8.subarray(Number(u)>>>0,Number(u+d)>>>0))},(o,u,d)=>s.createKernel(o,Number(u),d,t.UTF8ToString(t._JsepGetNodeName(Number(u)))),o=>s.releaseKernel(o),(o,u,d,p)=>{Ne("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${d}, kernel=${o}, contextDataOffset=${u}`);let m=new T_(t,s,Number(u));return s.computeKernel(Number(o),m,p)},()=>s.captureBegin(),()=>s.captureEnd(),()=>s.replay()])}else{let s=new Qw(r);a("webnn",[s,()=>s.reserveTensorId(),o=>s.releaseTensorId(o),async(o,u,d,p,m)=>s.ensureTensor(o,u,d,p,m),(o,u)=>{s.uploadTensor(o,u)},async(o,u)=>s.downloadTensor(o,u)])}}}),eb=ee(()=>{"use strict";VT(),qT(),be(),Mi(),bc(),n0(),C_=(e,t)=>{lt()._OrtInit(e,t)!==0&&Ve("Can't initialize onnxruntime.")},Pc=async e=>{C_(e.wasm.numThreads,Qo(e.logLevel))},Uc=async(e,t)=>{{let r=(DC(),Ko(Xw)).init;if(t==="webgpu"){if(typeof navigator>"u"||!navigator.gpu)throw new Error("WebGPU is not supported in current environment");let i=e.webgpu.adapter;if(i){if(typeof i.limits!="object"||typeof i.features!="object"||typeof i.requestDevice!="function")throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let a=e.webgpu.powerPreference;if(a!==void 0&&a!=="low-power"&&a!=="high-performance")throw new Error(`Invalid powerPreference setting: "${a}"`);let s=e.webgpu.forceFallbackAdapter;if(s!==void 0&&typeof s!="boolean")throw new Error(`Invalid forceFallbackAdapter setting: "${s}"`);if(i=await navigator.gpu.requestAdapter({powerPreference:a,forceFallbackAdapter:s}),!i)throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}await r("webgpu",lt(),e,i)}if(t==="webnn"){if(typeof navigator>"u"||!navigator.ml)throw new Error("WebNN is not supported in current environment");await r("webnn",lt(),e)}}},Lr=new Map,I_=e=>{let t=lt(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetInputOutputCount(e,a,a+i)!==0&&Ve("Can't get session input/output count.");let s=i===4?"i32":"i64";return[Number(t.getValue(a,s)),Number(t.getValue(a+i,s))]}finally{t.stackRestore(r)}},eu=e=>{let t=lt(),r=t._malloc(e.byteLength);if(r===0)throw new Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},Wc=async(e,t)=>{let r,i,a=lt();Array.isArray(e)?[r,i]=e:e.buffer===a.HEAPU8.buffer?[r,i]=[e.byteOffset,e.byteLength]:[r,i]=eu(e);let s=0,o=0,u=0,d=[],p=[],m=[];try{if([o,d]=a0(t),t?.externalData&&a.mountExternalData){let w=[];for(let S of t.externalData){let C=typeof S=="string"?S:S.path;w.push(Sc(typeof S=="string"?S:S.data).then(I=>{a.mountExternalData(C,I)}))}await Promise.all(w)}for(let w of t?.executionProviders??[])if((typeof w=="string"?w:w.name)==="webnn"){if(a.shouldTransferToMLTensor=!1,typeof w!="string"){let S=w,C=S?.context,I=S?.gpuDevice,z=S?.deviceType,E=S?.powerPreference;C?a.currentContext=C:I?a.currentContext=await a.jsepCreateMLContext(I):a.currentContext=await a.jsepCreateMLContext({deviceType:z,powerPreference:E})}else a.currentContext=await a.jsepCreateMLContext();break}s=await a._OrtCreateSession(r,i,o),s===0&&Ve("Can't create a session."),a.jsepOnCreateSession?.(),a.currentContext&&(a.jsepRegisterMLContext(s,a.currentContext),a.currentContext=void 0,a.shouldTransferToMLTensor=!0);let[f,g]=I_(s),v=!!t?.enableGraphCapture,_=[],b=[],k=[];for(let w=0;w<f;w++){let S=a._OrtGetInputName(s,w);S===0&&Ve("Can't get an input name."),p.push(S),_.push(a.UTF8ToString(S))}for(let w=0;w<g;w++){let S=a._OrtGetOutputName(s,w);S===0&&Ve("Can't get an output name."),m.push(S);let C=a.UTF8ToString(S);b.push(C);{if(v&&t?.preferredOutputLocation===void 0){k.push("gpu-buffer");continue}let I=typeof t?.preferredOutputLocation=="string"?t.preferredOutputLocation:t?.preferredOutputLocation?.[C]??"cpu";if(I!=="cpu"&&I!=="cpu-pinned"&&I!=="gpu-buffer"&&I!=="ml-tensor")throw new Error(`Not supported preferred output location: ${I}.`);if(v&&I!=="gpu-buffer")throw new Error(`Not supported preferred output location: ${I}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);k.push(I)}}let $=null;return k.some(w=>w==="gpu-buffer"||w==="ml-tensor")&&(u=a._OrtCreateBinding(s),u===0&&Ve("Can't create IO binding."),$={handle:u,outputPreferredLocations:k,outputPreferredLocationsEncoded:k.map(w=>tc(w))}),Lr.set(s,[s,p,m,$,v,!1]),[s,_,b]}catch(f){throw p.forEach(g=>a._OrtFree(g)),m.forEach(g=>a._OrtFree(g)),u!==0&&a._OrtReleaseBinding(u)!==0&&Ve("Can't release IO binding."),s!==0&&a._OrtReleaseSession(s)!==0&&Ve("Can't release session."),f}finally{a._free(r),o!==0&&a._OrtReleaseSessionOptions(o)!==0&&Ve("Can't release session options."),d.forEach(f=>a._free(f)),a.unmountExternalData?.()}},Vc=e=>{let t=lt(),r=Lr.get(e);if(!r)throw new Error(`cannot release session. invalid session id: ${e}`);let[i,a,s,o,u]=r;o&&(u&&t._OrtClearBoundOutputs(o.handle)!==0&&Ve("Can't clear bound outputs."),t._OrtReleaseBinding(o.handle)!==0&&Ve("Can't release IO binding.")),t.jsepOnReleaseSession?.(e),a.forEach(d=>t._OrtFree(d)),s.forEach(d=>t._OrtFree(d)),t._OrtReleaseSession(i)!==0&&Ve("Can't release session."),Lr.delete(e)},Jp=async(e,t,r,i,a,s=!1)=>{if(!e){t.push(0);return}let o=lt(),u=o.PTR_SIZE,d=e[0],p=e[1],m=e[3],f=m,g,v;if(d==="string"&&(m==="gpu-buffer"||m==="ml-tensor"))throw new Error("String tensor is not supported on GPU.");if(s&&m!=="gpu-buffer")throw new Error(`External buffer must be provided for input/output index ${a} when enableGraphCapture is true.`);if(m==="gpu-buffer"){let k=e[2].gpuBuffer;v=Ai(ta(d),p);let $=o.jsepRegisterBuffer;if(!$)throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');g=$(i,a,k,v)}else if(m==="ml-tensor"){let k=e[2].mlTensor;v=Ai(ta(d),p);let $=o.jsepRegisterMLTensor;if(!$)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');g=$(i,k,ta(d),p)}else{let k=e[2];if(Array.isArray(k)){v=u*k.length,g=o._malloc(v),r.push(g);for(let $=0;$<k.length;$++){if(typeof k[$]!="string")throw new TypeError(`tensor data at index ${$} is not a string`);o.setValue(g+$*u,wt(k[$],r),"*")}}else{let $=o.jsepIsGraphInput;if(d!=="string"&&$){let w=o._OrtGetInputName(i,a),S=o.UTF8ToString(w);if($(i,S)){let C=ta(d);v=Ai(C,p),f="ml-tensor";let I=o.jsepCreateTemporaryTensor,z=o.jsepUploadTensor;if(!I||!z)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');let E=await I(i,C,p);z(E,new Uint8Array(k.buffer,k.byteOffset,k.byteLength)),g=E}else v=k.byteLength,g=o._malloc(v),r.push(g),o.HEAPU8.set(new Uint8Array(k.buffer,k.byteOffset,v),g)}else v=k.byteLength,g=o._malloc(v),r.push(g),o.HEAPU8.set(new Uint8Array(k.buffer,k.byteOffset,v),g)}}let _=o.stackSave(),b=o.stackAlloc(4*p.length);try{p.forEach(($,w)=>o.setValue(b+w*u,$,u===4?"i32":"i64"));let k=o._OrtCreateTensor(ta(d),g,v,b,p.length,tc(f));k===0&&Ve(`Can't create tensor for input/output. session=${i}, index=${a}.`),t.push(k)}finally{o.stackRestore(_)}},qc=async(e,t,r,i,a,s)=>{let o=lt(),u=o.PTR_SIZE,d=Lr.get(e);if(!d)throw new Error(`cannot run inference. invalid session id: ${e}`);let p=d[0],m=d[1],f=d[2],g=d[3],v=d[4],_=d[5],b=t.length,k=i.length,$=0,w=[],S=[],C=[],I=[],z=o.stackSave(),E=o.stackAlloc(b*u),B=o.stackAlloc(b*u),U=o.stackAlloc(k*u),V=o.stackAlloc(k*u);try{[$,w]=i0(s);for(let D=0;D<b;D++)await Jp(r[D],S,I,e,t[D],v);for(let D=0;D<k;D++)await Jp(a[D],C,I,e,b+i[D],v);for(let D=0;D<b;D++)o.setValue(E+D*u,S[D],"*"),o.setValue(B+D*u,m[t[D]],"*");for(let D=0;D<k;D++)o.setValue(U+D*u,C[D],"*"),o.setValue(V+D*u,f[i[D]],"*");if(g&&!_){let{handle:D,outputPreferredLocations:se,outputPreferredLocationsEncoded:ue}=g;if(m.length!==b)throw new Error(`input count from feeds (${b}) is expected to be always equal to model's input count (${m.length}).`);for(let F=0;F<b;F++){let oe=t[F];await o._OrtBindInput(D,m[oe],S[F])!==0&&Ve(`Can't bind input[${F}] for session=${e}.`)}for(let F=0;F<k;F++){let oe=i[F];a[F]?.[3]?o._OrtBindOutput(D,f[oe],C[F],0)!==0&&Ve(`Can't bind pre-allocated output[${F}] for session=${e}.`):o._OrtBindOutput(D,f[oe],0,ue[oe])!==0&&Ve(`Can't bind output[${F}] to ${se[F]} for session=${e}.`)}Lr.set(e,[p,m,f,g,v,!0])}o.jsepOnRunStart?.(p);let W;g?W=await o._OrtRunWithBinding(p,g.handle,k,U,$):W=await o._OrtRun(p,B,E,b,V,k,U,$),W!==0&&Ve("failed to call OrtRun().");let J=[];for(let D=0;D<k;D++){let se=Number(o.getValue(U+D*u,"*"));if(se===C[D]){J.push(a[D]);continue}let ue=o.stackSave(),F=o.stackAlloc(4*u),oe=!1,le,H=0;try{o._OrtGetTensorData(se,F,F+u,F+2*u,F+3*u)!==0&&Ve(`Can't access output tensor data on index ${D}.`);let de=u===4?"i32":"i64",M=Number(o.getValue(F,de));H=o.getValue(F+u,"*");let q=o.getValue(F+u*2,"*"),R=Number(o.getValue(F+u*3,de)),X=[];for(let De=0;De<R;De++)X.push(Number(o.getValue(q+De*u,de)));o._OrtFree(q)!==0&&Ve("Can't free memory for tensor dims.");let Ie=X.reduce((De,Ae)=>De*Ae,1);le=zi(M);let Fe=g?.outputPreferredLocations[i[D]];if(le==="string"){if(Fe==="gpu-buffer"||Fe==="ml-tensor")throw new Error("String tensor is not supported on GPU.");let De=[];for(let Ae=0;Ae<Ie;Ae++){let nt=o.getValue(H+Ae*u,"*"),Ge=o.getValue(H+(Ae+1)*u,"*"),kr=Ae===Ie-1?void 0:Ge-nt;De.push(o.UTF8ToString(nt,kr))}J.push([le,X,De,"cpu"])}else if(Fe==="gpu-buffer"&&Ie>0){let De=o.jsepGetBuffer;if(!De)throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let Ae=De(H),nt=Ai(M,Ie);if(nt===void 0||!xc(le))throw new Error(`Unsupported data type: ${le}`);oe=!0,J.push([le,X,{gpuBuffer:Ae,download:o.jsepCreateDownloader(Ae,nt,le),dispose:()=>{o._OrtReleaseTensor(se)!==0&&Ve("Can't release tensor.")}},"gpu-buffer"])}else if(Fe==="ml-tensor"&&Ie>0){let De=o.jsepEnsureTensor;if(!De)throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');if(Ai(M,Ie)===void 0||!kc(le))throw new Error(`Unsupported data type: ${le}`);let Ae=await De(e,H,M,X,!1);oe=!0,J.push([le,X,{mlTensor:Ae,download:o.jsepCreateMLTensorDownloader(H,le),dispose:()=>{o.jsepReleaseTensorId(H),o._OrtReleaseTensor(se)}},"ml-tensor"])}else{let De=$c(le),Ae=new De(Ie);new Uint8Array(Ae.buffer,Ae.byteOffset,Ae.byteLength).set(o.HEAPU8.subarray(H,H+Ae.byteLength)),J.push([le,X,Ae,"cpu"])}}finally{o.stackRestore(ue),le==="string"&&H&&o._free(H),oe||o._OrtReleaseTensor(se),o.jsepOnRunEnd?.(p)}}return g&&!v&&(o._OrtClearBoundOutputs(g.handle)!==0&&Ve("Can't clear bound outputs."),Lr.set(e,[p,m,f,g,v,!1])),J}finally{o.stackRestore(z),S.forEach(W=>o._OrtReleaseTensor(W)),C.forEach(W=>o._OrtReleaseTensor(W)),I.forEach(W=>o._free(W)),$!==0&&o._OrtReleaseRunOptions($),w.forEach(W=>o._free(W))}},jc=e=>{let t=lt(),r=Lr.get(e);if(!r)throw new Error("invalid session id");let i=r[0],a=t._OrtEndProfiling(i);a===0&&Ve("Can't get an profile file name."),t._OrtFree(a)},Lc=e=>{let t=[];for(let r of e){let i=r[2];!Array.isArray(i)&&"buffer"in i&&t.push(i.buffer)}return t}}),ub=ee(()=>{"use strict";sr(),eb(),Mi(),vc(),Gr=()=>!!Ke.wasm.proxy&&typeof document<"u",ea=!1,Rs=!1,Bs=!1,Go=new Map,Ci=(e,t)=>{let r=Go.get(e);r?r.push(t):Go.set(e,[t])},Ii=()=>{if(ea||!Rs||Bs||!Wt)throw new Error("worker not ready")},E_=e=>{switch(e.data.type){case"init-wasm":ea=!1,e.data.err?(Bs=!0,Yp[1](e.data.err)):(Rs=!0,Yp[0]()),Lo&&(URL.revokeObjectURL(Lo),Lo=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=Go.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out);break}default:}},tb=async()=>{if(!Rs){if(ea)throw new Error("multiple calls to 'initWasm()' detected.");if(Bs)throw new Error("previous call to 'initWasm()' failed.");if(ea=!0,Gr())return new Promise((e,t)=>{Wt?.terminate(),t0().then(([r,i])=>{try{Wt=i,Wt.onerror=s=>t(s),Wt.onmessage=E_,Yp=[e,t];let a={type:"init-wasm",in:Ke};!a.in.wasm.wasmPaths&&(r||vr.url?.startsWith("file:"))&&(a.in.wasm.wasmPaths={wasm:new URL("ort-wasm-simd-threaded.jsep.wasm",vr.url).href}),Wt.postMessage(a),Lo=r}catch(a){t(a)}},t)});try{await wc(Ke.wasm),await Pc(Ke),Rs=!0}catch(e){throw Bs=!0,e}finally{ea=!1}}},rb=async e=>{if(Gr())return Ii(),new Promise((t,r)=>{Ci("init-ep",[t,r]);let i={type:"init-ep",in:{epName:e,env:Ke}};Wt.postMessage(i)});await Uc(Ke,e)},ib=async e=>Gr()?(Ii(),new Promise((t,r)=>{Ci("copy-from",[t,r]);let i={type:"copy-from",in:{buffer:e}};Wt.postMessage(i,[e.buffer])})):eu(e),ab=async(e,t)=>{if(Gr()){if(t?.preferredOutputLocation)throw new Error('session option "preferredOutputLocation" is not supported for proxy.');return Ii(),new Promise((r,i)=>{Ci("create",[r,i]);let a={type:"create",in:{model:e,options:{...t}}},s=[];e instanceof Uint8Array&&s.push(e.buffer),Wt.postMessage(a,s)})}else return Wc(e,t)},nb=async e=>{if(Gr())return Ii(),new Promise((t,r)=>{Ci("release",[t,r]);let i={type:"release",in:e};Wt.postMessage(i)});Vc(e)},sb=async(e,t,r,i,a,s)=>{if(Gr()){if(r.some(o=>o[3]!=="cpu"))throw new Error("input tensor on GPU is not supported for proxy.");if(a.some(o=>o))throw new Error("pre-allocated output tensor is not supported for proxy.");return Ii(),new Promise((o,u)=>{Ci("run",[o,u]);let d=r,p={type:"run",in:{sessionId:e,inputIndices:t,inputs:d,outputIndices:i,options:s}};Wt.postMessage(p,Lc(d))})}else return qc(e,t,r,i,a,s)},ob=async e=>{if(Gr())return Ii(),new Promise((t,r)=>{Ci("end-profiling",[t,r]);let i={type:"end-profiling",in:e};Wt.postMessage(i)});jc(e)}}),PC=ee(()=>{"use strict";sr(),ub(),be(),_c(),n0(),ec=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw new Error(`invalid data location: ${e.location} for ${t()}`)}},z_=e=>{switch(e[3]){case"cpu":return new ar(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!xc(t))throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:i,dispose:a}=e[2];return ar.fromGpuBuffer(r,{dataType:t,dims:e[1],download:i,dispose:a})}case"ml-tensor":{let t=e[0];if(!kc(t))throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:i,dispose:a}=e[2];return ar.fromMLTensor(r,{dataType:t,dims:e[1],download:i,dispose:a})}default:throw new Error(`invalid data location: ${e[3]}`)}},lb=class{async fetchModelAndCopyToWasmMemory(e){return ib(await Sc(e))}async loadModel(e,t){nr();let r;typeof e=="string"?r=await this.fetchModelAndCopyToWasmMemory(e):r=e,[this.sessionId,this.inputNames,this.outputNames]=await ab(r,t),qt()}async dispose(){return nb(this.sessionId)}async run(e,t,r){nr();let i=[],a=[];Object.entries(e).forEach(f=>{let g=f[0],v=f[1],_=this.inputNames.indexOf(g);if(_===-1)throw new Error(`invalid input '${g}'`);i.push(v),a.push(_)});let s=[],o=[];Object.entries(t).forEach(f=>{let g=f[0],v=f[1],_=this.outputNames.indexOf(g);if(_===-1)throw new Error(`invalid output '${g}'`);s.push(v),o.push(_)});let u=i.map((f,g)=>ec(f,()=>`input "${this.inputNames[a[g]]}"`)),d=s.map((f,g)=>f?ec(f,()=>`output "${this.outputNames[o[g]]}"`):null),p=await sb(this.sessionId,a,u,o,d,r),m={};for(let f=0;f<p.length;f++)m[this.outputNames[o[f]]]=s[f]??z_(p[f]);return qt(),m}startProfiling(){}endProfiling(){ob(this.sessionId)}}}),db={};qs(db,{OnnxruntimeWebAssemblyBackend:()=>fc,initializeFlags:()=>hc,wasmBackend:()=>pb});UC=ee(()=>{"use strict";sr(),ub(),PC(),hc=()=>{if((typeof Ke.wasm.initTimeout!="number"||Ke.wasm.initTimeout<0)&&(Ke.wasm.initTimeout=0),Ke.wasm.simd===!1&&console.warn('Deprecated property "env.wasm.simd" is set to false. non-SIMD build is no longer provided, and this setting will be ignored.'),typeof Ke.wasm.proxy!="boolean"&&(Ke.wasm.proxy=!1),typeof Ke.wasm.trace!="boolean"&&(Ke.wasm.trace=!1),typeof Ke.wasm.numThreads!="number"||!Number.isInteger(Ke.wasm.numThreads)||Ke.wasm.numThreads<=0)if(typeof self<"u"&&!self.crossOriginIsolated)Ke.wasm.numThreads=1;else{let e=typeof navigator>"u"?kT("node:os").cpus().length:navigator.hardwareConcurrency;Ke.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},fc=class{async init(e){hc(),await tb(),await rb(e)}async createInferenceSessionHandler(e,t){let r=new lb;return await r.loadModel(e,t),Promise.resolve(r)}},pb=new fc});sr();sr();sr();WC="1.21.0",VC=Z_;{let e=(UC(),Ko(db)).wasmBackend;Oi("webgpu",e,5),Oi("webnn",e,5),Oi("cpu",e,10),Oi("wasm",e,10)}Object.defineProperty(Ke.versions,"web",{value:WC,enumerable:!0});});var CS={};np(CS,{InferenceSession:()=>rf,TRACE:()=>io,TRACE_FUNC_BEGIN:()=>hr,TRACE_FUNC_END:()=>Gt,Tensor:()=>cr,default:()=>uE,env:()=>Ze,registerBackend:()=>Gi});var br,ef,qC,jC,LC,GC,te,no,FC,yu,js,Kr,Gi,fb,F2,H2,HC,K2,KC,Gc,Lt,Z2,Ze,ZC,Q2,X2,QC,tu,J2,Y2,ex,tx,rx,XC,qi,Js,Fc,ix,JC,ax,nx,YC,Pt,tf,cr,sx,io,Hc,hr,Gt,ox,ux,eI,rf,tI,rI,iI,aI,nI,dx,fr,af,px,Kc,Zc,cx,sI,hx,Qc,Xc,fx,mb,oI,Jc,gb,Dt,mx,ru,yb,_b,Yc,vb,eh,gx,th,yx,nf,rh,iu,Ls,ih,wb,bb,sf,pt,Zi,bt,_u,qe,of,_x,uI,$b,xb,kb,Sb,vx,lI,sa,ji,Li,uf,vu,lf,df,Wh,$e,pf,wx,Tb,Cb,Ib,Eb,cf,zb,Me,Ur,hf,bx,ff,ah,au,nu,Ab,Ob,nh,Vh,Rb,$x,dI,Bb,Le,tt,Nb,ua,G,wu,xx,kx,Sx,Ce,la,su,ct,kt,_e,Ye,qh,oa,Xr,ge,Gs,Z,fe,Tx,mf,Mb,Cx,ze,Db,sh,Pb,Ub,Wb,Vb,Ut,Ix,Ex,Jr,qb,jb,Lb,Gb,Fb,Hb,Kb,Zb,Qb,Xb,or,zx,Ax,Ox,Rx,Bx,Nx,Mx,Dx,Px,Ux,pI,ur,Jb,bu,jh,lr,Yb,e$,t$,r$,i$,a$,n$,s$,o$,u$,dr,Wx,Vx,qx,jx,Lx,Gx,Fx,Hx,Kx,Zx,gf,oh,Qx,Xx,Lh,cI,l$,ou,d$,p$,c$,ao,h$,Jx,yf,f$,m$,g$,Yx,hI,y$,_$,e3,fI,v$,Ue,t3,r3,i3,a3,n3,s3,o3,u3,l3,w$,d3,p3,c3,h3,eo,f3,gu,m3,g3,y3,_3,v3,w3,b3,$3,x3,k3,S3,T3,C3,I3,E3,z3,uh,A3,Gh,Fh,O3,R3,B3,b$,$$,N3,_f,x$,k$,M3,mI,S$,T$,pr,D3,P3,U3,W3,V3,q3,j3,L3,G3,F3,gI,C$,I$,E$,z$,H3,K3,yI,Fi,Hi,Ki,vf,Qi,ft,Z3,wf,Q3,_I,ro,bf,$f,A$,O$,Hh,lh,R$,Kh,B$,$u,xf,N$,X3,vI,M$,dh,Fs,D$,ph,P$,J3,Y3,wI,ek,tk,bI,U$,uu,W$,lu,Zh,ch,V$,q$,Qh,$I,rk,xI,j$,L$,G$,hh,ik,F$,fh,H$,ak,kI,K$,nk,sk,SI,Z$,Q$,X$,ok,uk,TI,du,Hs,mh,J$,Y$,e1,t1,gh,r1,lk,dk,CI,i1,yh,a1,n1,pk,II,s1,ck,EI,o1,u1,hk,fk,zI,l1,mk,gk,AI,d1,p1,yk,_k,OI,c1,h1,vk,wk,RI,f1,m1,bk,$k,BI,wr,Pr,Pi,Ui,g1,y1,_1,v1,w1,b1,$1,x1,xk,kk,NI,Ct,k1,Sk,_h,S1,to,Tk,Ck,T1,C1,I1,E1,Xh,Ik,Ek,zk,z1,A1,vh,Ak,MI,wh,O1,R1,Ok,DI,B1,N1,Rk,PI,M1,Bk,UI,D1,P1,U1,Nk,Mk,WI,W1,V1,q1,j1,L1,G1,F1,H1,Dk,VI,Ks,bh,$h,xh,kh,K1,Z1,Sh,Th,Pk,Uk,Ch,Wk,Vk,Ih,qk,jk,Lk,Gk,qI,Q1,X1,Fk,Hk,jI,J1,Y1,Kk,LI,e2,t2,Zk,Qk,GI,r2,i2,a2,Eh,n2,s2,o2,u2,l2,d2,p2,c2,zh,h2,f2,m2,g2,y2,Xk,Jk,FI,_2,v2,Yk,HI,w2,b2,eS,KI,$2,Zs,x2,Ah,k2,S2,tS,rS,ZI,T2,C2,iS,aS,QI,Oh,I2,E2,z2,nS,XI,A2,O2,sS,JI,oS,YI,uS,eE,R2,B2,N2,M2,lS,tE,D2,Rh,P2,Bh,Nh,Mh,U2,dS,rE,pu,W2,pS,iE,cS,cu,V2,hS,aE,q2,kf,Sf,Zr,j2,xu,Tf,Cf,Dh,If,Ef,zf,mS,Qr,jt,na,Qs,Xs,hu,Ph,fu,Wi,Vi,L2,gS,yS,_S,vS,wS,bS,$S,xS,Uh,G2,kS,nE,SS,Jh,Yh,TS,sE,oE,uE,IS=Jf(()=>{br={};ef=Object.defineProperty,qC=Object.getOwnPropertyDescriptor,jC=Object.getOwnPropertyNames,LC=Object.prototype.hasOwnProperty,GC=(e=>typeof Et<"u"?Et:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof Et<"u"?Et:t)[r]}):e)(function(e){if(typeof Et<"u")return Et.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),te=(e,t)=>()=>(e&&(t=e(e=0)),t),no=(e,t)=>{for(var r in t)ef(e,r,{get:t[r],enumerable:!0})},FC=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of jC(t))!LC.call(e,a)&&a!==r&&ef(e,a,{get:()=>t[a],enumerable:!(i=qC(t,a))||i.enumerable});return e},yu=e=>FC(ef({},"__esModule",{value:!0}),e),H2=te(()=>{"use strict";js=new Map,Kr=[],Gi=(e,t,r)=>{if(t&&typeof t.init=="function"&&typeof t.createInferenceSessionHandler=="function"){let i=js.get(e);if(i===void 0)js.set(e,{backend:t,priority:r});else{if(i.priority>r)return;if(i.priority===r&&i.backend!==t)throw new Error(`cannot register backend "${e}" using priority ${r}`)}if(r>=0){let a=Kr.indexOf(e);a!==-1&&Kr.splice(a,1);for(let s=0;s<Kr.length;s++)if(js.get(Kr[s]).priority<=r){Kr.splice(s,0,e);return}Kr.push(e)}return}throw new TypeError("not a valid backend")},fb=async e=>{let t=js.get(e);if(!t)return"backend not found.";if(t.initialized)return t.backend;if(t.aborted)return t.error;{let r=!!t.initPromise;try{return r||(t.initPromise=t.backend.init(e)),await t.initPromise,t.initialized=!0,t.backend}catch(i){return r||(t.error=`${i}`,t.aborted=!0),t.error}finally{delete t.initPromise}}},F2=async e=>{let t=e.executionProviders||[],r=t.map(d=>typeof d=="string"?d:d.name),i=r.length===0?Kr:r,a,s=[],o=new Set;for(let d of i){let p=await fb(d);typeof p=="string"?s.push({name:d,err:p}):(a||(a=p),a===p&&o.add(d))}if(!a)throw new Error(`no available backend found. ERR: ${s.map(d=>`[${d.name}] ${d.err}`).join(", ")}`);for(let{name:d,err:p}of s)r.includes(d)&&console.warn(`removing requested execution provider "${d}" from session options because it is not available: ${p}`);let u=t.filter(d=>o.has(typeof d=="string"?d:d.name));return[a,new Proxy(e,{get:(d,p)=>p==="executionProviders"?u:Reflect.get(d,p)})]}}),HC=te(()=>{"use strict";H2()}),KC=te(()=>{"use strict";K2="1.21.0"}),Z2=te(()=>{"use strict";KC(),Gc="warning",Lt={wasm:{},webgl:{},webgpu:{},versions:{common:K2},set logLevel(e){if(e!==void 0){if(typeof e!="string"||["verbose","info","warning","error","fatal"].indexOf(e)===-1)throw new Error(`Unsupported logging level: ${e}`);Gc=e}},get logLevel(){return Gc}},Object.defineProperty(Lt,"logLevel",{enumerable:!0})}),ZC=te(()=>{"use strict";Z2(),Ze=Lt}),QC=te(()=>{"use strict";Q2=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let i=r.getContext("2d");if(i!=null){let a,s;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[3]):(a=e.dims[3],s=e.dims[2]);let o=t?.format!==void 0?t.format:"RGB",u=t?.norm,d,p;u===void 0||u.mean===void 0?d=[255,255,255,255]:typeof u.mean=="number"?d=[u.mean,u.mean,u.mean,u.mean]:(d=[u.mean[0],u.mean[1],u.mean[2],0],u.mean[3]!==void 0&&(d[3]=u.mean[3])),u===void 0||u.bias===void 0?p=[0,0,0,0]:typeof u.bias=="number"?p=[u.bias,u.bias,u.bias,u.bias]:(p=[u.bias[0],u.bias[1],u.bias[2],0],u.bias[3]!==void 0&&(p[3]=u.bias[3]));let m=s*a,f=0,g=m,v=m*2,_=-1;o==="RGBA"?(f=0,g=m,v=m*2,_=m*3):o==="RGB"?(f=0,g=m,v=m*2):o==="RBG"&&(f=0,v=m,g=m*2);for(let b=0;b<s;b++)for(let k=0;k<a;k++){let $=(e.data[f++]-p[0])*d[0],w=(e.data[g++]-p[1])*d[1],S=(e.data[v++]-p[2])*d[2],C=_===-1?255:(e.data[_++]-p[3])*d[3];i.fillStyle="rgba("+$+","+w+","+S+","+C+")",i.fillRect(k,b,1,1)}if("toDataURL"in r)return r.toDataURL();throw new Error("toDataURL is not supported")}else throw new Error("Can not access image data")},X2=(e,t)=>{let r=typeof document<"u"?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d"),i;if(r!=null){let a,s,o;t?.tensorLayout!==void 0&&t.tensorLayout==="NHWC"?(a=e.dims[2],s=e.dims[1],o=e.dims[3]):(a=e.dims[3],s=e.dims[2],o=e.dims[1]);let u=t!==void 0&&t.format!==void 0?t.format:"RGB",d=t?.norm,p,m;d===void 0||d.mean===void 0?p=[255,255,255,255]:typeof d.mean=="number"?p=[d.mean,d.mean,d.mean,d.mean]:(p=[d.mean[0],d.mean[1],d.mean[2],255],d.mean[3]!==void 0&&(p[3]=d.mean[3])),d===void 0||d.bias===void 0?m=[0,0,0,0]:typeof d.bias=="number"?m=[d.bias,d.bias,d.bias,d.bias]:(m=[d.bias[0],d.bias[1],d.bias[2],0],d.bias[3]!==void 0&&(m[3]=d.bias[3]));let f=s*a;if(t!==void 0&&(t.format!==void 0&&o===4&&t.format!=="RGBA"||o===3&&t.format!=="RGB"&&t.format!=="BGR"))throw new Error("Tensor format doesn't match input tensor dims");let g=4,v=0,_=1,b=2,k=3,$=0,w=f,S=f*2,C=-1;u==="RGBA"?($=0,w=f,S=f*2,C=f*3):u==="RGB"?($=0,w=f,S=f*2):u==="RBG"&&($=0,S=f,w=f*2),i=r.createImageData(a,s);for(let I=0;I<s*a;v+=g,_+=g,b+=g,k+=g,I++)i.data[v]=(e.data[$++]-m[0])*p[0],i.data[_]=(e.data[w++]-m[1])*p[1],i.data[b]=(e.data[S++]-m[2])*p[2],i.data[k]=C===-1?255:(e.data[C++]-m[3])*p[3]}else throw new Error("Can not access image data");return i}}),XC=te(()=>{"use strict";tf(),tu=(e,t)=>{if(e===void 0)throw new Error("Image buffer must be defined");if(t.height===void 0||t.width===void 0)throw new Error("Image height and width must be defined");if(t.tensorLayout==="NHWC")throw new Error("NHWC Tensor layout is not supported yet");let{height:r,width:i}=t,a=t.norm??{mean:255,bias:0},s,o;typeof a.mean=="number"?s=[a.mean,a.mean,a.mean,a.mean]:s=[a.mean[0],a.mean[1],a.mean[2],a.mean[3]??255],typeof a.bias=="number"?o=[a.bias,a.bias,a.bias,a.bias]:o=[a.bias[0],a.bias[1],a.bias[2],a.bias[3]??0];let u=t.format!==void 0?t.format:"RGBA",d=t.tensorFormat!==void 0&&t.tensorFormat!==void 0?t.tensorFormat:"RGB",p=r*i,m=d==="RGBA"?new Float32Array(p*4):new Float32Array(p*3),f=4,g=0,v=1,_=2,b=3,k=0,$=p,w=p*2,S=-1;u==="RGB"&&(f=3,g=0,v=1,_=2,b=-1),d==="RGBA"?S=p*3:d==="RBG"?(k=0,w=p,$=p*2):d==="BGR"&&(w=0,$=p,k=p*2);for(let C=0;C<p;C++,g+=f,_+=f,v+=f,b+=f)m[k++]=(e[g]+o[0])/s[0],m[$++]=(e[v]+o[1])/s[1],m[w++]=(e[_]+o[2])/s[2],S!==-1&&b!==-1&&(m[S++]=(e[b]+o[3])/s[3]);return d==="RGBA"?new Pt("float32",m,[1,4,r,i]):new Pt("float32",m,[1,3,r,i])},J2=async(e,t)=>{let r=typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement,i=typeof ImageData<"u"&&e instanceof ImageData,a=typeof ImageBitmap<"u"&&e instanceof ImageBitmap,s=typeof e=="string",o,u=t??{},d=()=>{if(typeof document<"u")return document.createElement("canvas");if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(1,1);throw new Error("Canvas is not supported")},p=m=>typeof HTMLCanvasElement<"u"&&m instanceof HTMLCanvasElement||m instanceof OffscreenCanvas?m.getContext("2d"):null;if(r){let m=d();m.width=e.width,m.height=e.height;let f=p(m);if(f!=null){let g=e.height,v=e.width;if(t!==void 0&&t.resizedHeight!==void 0&&t.resizedWidth!==void 0&&(g=t.resizedHeight,v=t.resizedWidth),t!==void 0){if(u=t,t.tensorFormat!==void 0)throw new Error("Image input config format must be RGBA for HTMLImageElement");u.tensorFormat="RGBA",u.height=g,u.width=v}else u.tensorFormat="RGBA",u.height=g,u.width=v;f.drawImage(e,0,0),o=f.getImageData(0,0,v,g).data}else throw new Error("Can not access image data")}else if(i){let m,f;if(t!==void 0&&t.resizedWidth!==void 0&&t.resizedHeight!==void 0?(m=t.resizedHeight,f=t.resizedWidth):(m=e.height,f=e.width),t!==void 0&&(u=t),u.format="RGBA",u.height=m,u.width=f,t!==void 0){let g=d();g.width=f,g.height=m;let v=p(g);if(v!=null)v.putImageData(e,0,0),o=v.getImageData(0,0,f,m).data;else throw new Error("Can not access image data")}else o=e.data}else if(a){if(t===void 0)throw new Error("Please provide image config with format for Imagebitmap");let m=d();m.width=e.width,m.height=e.height;let f=p(m);if(f!=null){let g=e.height,v=e.width;return f.drawImage(e,0,0,v,g),o=f.getImageData(0,0,v,g).data,u.height=g,u.width=v,tu(o,u)}else throw new Error("Can not access image data")}else{if(s)return new Promise((m,f)=>{let g=d(),v=p(g);if(!e||!v)return f();let _=new Image;_.crossOrigin="Anonymous",_.src=e,_.onload=()=>{g.width=_.width,g.height=_.height,v.drawImage(_,0,0,g.width,g.height);let b=v.getImageData(0,0,g.width,g.height);u.height=g.height,u.width=g.width,m(tu(b.data,u))}});throw new Error("Input data provided is not supported - aborted tensor creation")}if(o!==void 0)return tu(o,u);throw new Error("Input data provided is not supported - aborted tensor creation")},Y2=(e,t)=>{let{width:r,height:i,download:a,dispose:s}=t,o=[1,i,r,4];return new Pt({location:"texture",type:"float32",texture:e,dims:o,download:a,dispose:s})},ex=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Pt({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:i,download:a,dispose:s})},tx=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:s}=t;return new Pt({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:i,download:a,dispose:s})},rx=(e,t,r)=>new Pt({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}),JC=te(()=>{"use strict";qi=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),Js=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),Fc=!1,ix=()=>{if(!Fc){Fc=!0;let e=typeof BigInt64Array<"u"&&BigInt64Array.from,t=typeof BigUint64Array<"u"&&BigUint64Array.from,r=globalThis.Float16Array,i=typeof r<"u"&&r.from;e&&(qi.set("int64",BigInt64Array),Js.set(BigInt64Array,"int64")),t&&(qi.set("uint64",BigUint64Array),Js.set(BigUint64Array,"uint64")),i?(qi.set("float16",r),Js.set(r,"float16")):qi.set("float16",Uint16Array)}}}),YC=te(()=>{"use strict";tf(),ax=e=>{let t=1;for(let r=0;r<e.length;r++){let i=e[r];if(typeof i!="number"||!Number.isSafeInteger(i))throw new TypeError(`dims[${r}] must be an integer, got: ${i}`);if(i<0)throw new RangeError(`dims[${r}] must be a non-negative integer, got: ${i}`);t*=i}return t},nx=(e,t)=>{switch(e.location){case"cpu":return new Pt(e.type,e.data,t);case"cpu-pinned":return new Pt({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new Pt({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new Pt({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new Pt({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw new Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}),tf=te(()=>{"use strict";QC(),XC(),JC(),YC(),Pt=class{constructor(e,t,r){ix();let i,a;if(typeof e=="object"&&"location"in e)switch(this.dataLocation=e.location,i=e.type,a=e.dims,e.location){case"cpu-pinned":{let o=qi.get(i);if(!o)throw new TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);if(!(e.data instanceof o))throw new TypeError(`buffer should be of type ${o.name}`);this.cpuData=e.data;break}case"texture":{if(i!=="float32")throw new TypeError(`unsupported type "${i}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break}case"gpu-buffer":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break}case"ml-tensor":{if(i!=="float32"&&i!=="float16"&&i!=="int32"&&i!=="int64"&&i!=="uint32"&&i!=="uint64"&&i!=="int8"&&i!=="uint8"&&i!=="bool"&&i!=="uint4"&&i!=="int4")throw new TypeError(`unsupported type "${i}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break}default:throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let o,u;if(typeof e=="string")if(i=e,u=r,e==="string"){if(!Array.isArray(t))throw new TypeError("A string tensor's data must be a string array.");o=t}else{let d=qi.get(e);if(d===void 0)throw new TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t)){if(e==="float16"&&d===Uint16Array||e==="uint4"||e==="int4")throw new TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${d.name} as data.`);e==="uint64"||e==="int64"?o=d.from(t,BigInt):o=d.from(t)}else if(t instanceof d)o=t;else if(t instanceof Uint8ClampedArray)if(e==="uint8")o=Uint8Array.from(t);else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else if(e==="float16"&&t instanceof Uint16Array&&d!==Uint16Array)o=new globalThis.Float16Array(t.buffer,t.byteOffset,t.length);else throw new TypeError(`A ${i} tensor's data must be type of ${d}`)}else if(u=t,Array.isArray(e)){if(e.length===0)throw new TypeError("Tensor type cannot be inferred from an empty array.");let d=typeof e[0];if(d==="string")i="string",o=e;else if(d==="boolean")i="bool",o=Uint8Array.from(e);else throw new TypeError(`Invalid element type of data array: ${d}.`)}else if(e instanceof Uint8ClampedArray)i="uint8",o=Uint8Array.from(e);else{let d=Js.get(e.constructor);if(d===void 0)throw new TypeError(`Unsupported type for tensor data: ${e.constructor}.`);i=d,o=e}if(u===void 0)u=[o.length];else if(!Array.isArray(u))throw new TypeError("A tensor's dims must be a number array");a=u,this.cpuData=o,this.dataLocation="cpu"}let s=ax(a);if(this.cpuData&&s!==this.cpuData.length&&!((i==="uint4"||i==="int4")&&Math.ceil(s/2)===this.cpuData.length))throw new Error(`Tensor's size(${s}) does not match data length(${this.cpuData.length}).`);this.type=i,this.dims=a,this.size=s}static async fromImage(e,t){return J2(e,t)}static fromTexture(e,t){return Y2(e,t)}static fromGpuBuffer(e,t){return ex(e,t)}static fromMLTensor(e,t){return tx(e,t)}static fromPinnedBuffer(e,t,r){return rx(e,t,r)}toDataURL(e){return Q2(this,e)}toImageData(e){return X2(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw new Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw new Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw new Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":{if(!this.downloader)throw new Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw new Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}}default:throw new Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw new Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if(this.dataLocation==="none")throw new Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw new Error("Cannot reshape a tensor that owns GPU resource.");return nx(this,e)}}}),sx=te(()=>{"use strict";tf(),cr=Pt}),ox=te(()=>{"use strict";Z2(),io=(e,t)=>{(typeof Lt.trace>"u"?!Lt.wasm.trace:!Lt.trace)||console.timeStamp(`${e}::ORT::${t}`)},Hc=(e,t)=>{let r=new Error().stack?.split(/\r\n|\r|\n/g)||[],i=!1;for(let a=0;a<r.length;a++){if(i&&!r[a].includes("TRACE_FUNC")){let s=`FUNC_${e}::${r[a].trim().split(" ")[1]}`;t&&(s+=`::${t}`),io("CPU",s);return}r[a].includes("TRACE_FUNC")&&(i=!0)}},hr=e=>{(typeof Lt.trace>"u"?!Lt.wasm.trace:!Lt.trace)||Hc("BEGIN",e)},Gt=e=>{(typeof Lt.trace>"u"?!Lt.wasm.trace:!Lt.trace)||Hc("END",e)}}),eI=te(()=>{"use strict";H2(),sx(),ox(),ux=class lx{constructor(t){this.handler=t}async run(t,r,i){hr();let a={},s={};if(typeof t!="object"||t===null||t instanceof cr||Array.isArray(t))throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let o=!0;if(typeof r=="object"){if(r===null)throw new TypeError("Unexpected argument[1]: cannot be null.");if(r instanceof cr)throw new TypeError("'fetches' cannot be a Tensor");if(Array.isArray(r)){if(r.length===0)throw new TypeError("'fetches' cannot be an empty array.");o=!1;for(let p of r){if(typeof p!="string")throw new TypeError("'fetches' must be a string array or an object.");if(this.outputNames.indexOf(p)===-1)throw new RangeError(`'fetches' contains invalid output name: ${p}.`);a[p]=null}if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else{let p=!1,m=Object.getOwnPropertyNames(r);for(let f of this.outputNames)if(m.indexOf(f)!==-1){let g=r[f];(g===null||g instanceof cr)&&(p=!0,o=!1,a[f]=g)}if(p){if(typeof i=="object"&&i!==null)s=i;else if(typeof i<"u")throw new TypeError("'options' must be an object.")}else s=r}}else if(typeof r<"u")throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let p of this.inputNames)if(typeof t[p]>"u")throw new Error(`input '${p}' is missing in 'feeds'.`);if(o)for(let p of this.outputNames)a[p]=null;let u=await this.handler.run(t,a,s),d={};for(let p in u)if(Object.hasOwnProperty.call(u,p)){let m=u[p];m instanceof cr?d[p]=m:d[p]=new cr(m.type,m.data,m.dims)}return Gt(),d}async release(){return this.handler.dispose()}static async create(t,r,i,a){hr();let s,o={};if(typeof t=="string"){if(s=t,typeof r=="object"&&r!==null)o=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(s=t,typeof r=="object"&&r!==null)o=r;else if(typeof r<"u")throw new TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||typeof SharedArrayBuffer<"u"&&t instanceof SharedArrayBuffer){let m=t,f=0,g=t.byteLength;if(typeof r=="object"&&r!==null)o=r;else if(typeof r=="number"){if(f=r,!Number.isSafeInteger(f))throw new RangeError("'byteOffset' must be an integer.");if(f<0||f>=m.byteLength)throw new RangeError(`'byteOffset' is out of range [0, ${m.byteLength}).`);if(g=t.byteLength-f,typeof i=="number"){if(g=i,!Number.isSafeInteger(g))throw new RangeError("'byteLength' must be an integer.");if(g<=0||f+g>m.byteLength)throw new RangeError(`'byteLength' is out of range (0, ${m.byteLength-f}].`);if(typeof a=="object"&&a!==null)o=a;else if(typeof a<"u")throw new TypeError("'options' must be an object.")}else if(typeof i<"u")throw new TypeError("'byteLength' must be a number.")}else if(typeof r<"u")throw new TypeError("'options' must be an object.");s=new Uint8Array(m,f,g)}else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[u,d]=await F2(o),p=await u.createInferenceSessionHandler(s,d);return Gt(),new lx(p)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}}}),tI=te(()=>{"use strict";eI(),rf=ux}),rI=te(()=>{"use strict"}),iI=te(()=>{"use strict"}),aI=te(()=>{"use strict"}),nI=te(()=>{"use strict"}),dx={};no(dx,{InferenceSession:()=>rf,TRACE:()=>io,TRACE_FUNC_BEGIN:()=>hr,TRACE_FUNC_END:()=>Gt,Tensor:()=>cr,env:()=>Ze,registerBackend:()=>Gi});fr=te(()=>{"use strict";HC(),ZC(),tI(),sx(),rI(),iI(),ox(),aI(),nI()}),af=te(()=>{"use strict"}),px={};no(px,{default:()=>cx});sI=te(()=>{"use strict";mS(),Zi(),nf(),Kc="ort-wasm-proxy-worker",Zc=globalThis.self?.name===Kc,Zc&&(self.onmessage=e=>{let{type:t,in:r}=e.data;try{switch(t){case"init-wasm":sf(r.wasm).then(()=>{kf(r).then(()=>{postMessage({type:t})},i=>{postMessage({type:t,err:i})})},i=>{postMessage({type:t,err:i})});break;case"init-ep":{let{epName:i,env:a}=r;Sf(a,i).then(()=>{postMessage({type:t})},s=>{postMessage({type:t,err:s})});break}case"copy-from":{let{buffer:i}=r,a=xu(i);postMessage({type:t,out:a});break}case"create":{let{model:i,options:a}=r;Tf(i,a).then(s=>{postMessage({type:t,out:s})},s=>{postMessage({type:t,err:s})});break}case"release":Cf(r),postMessage({type:t});break;case"run":{let{sessionId:i,inputIndices:a,inputs:s,outputIndices:o,options:u}=r;If(i,a,s,o,new Array(o.length).fill(null),u).then(d=>{d.some(p=>p[3]!=="cpu")?postMessage({type:t,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:t,out:d},zf([...s,...d]))},d=>{postMessage({type:t,err:d})});break}case"end-profiling":Ef(r),postMessage({type:t});break;default:}}catch(i){postMessage({type:t,err:i})}}),cx=Zc?null:e=>new Worker(e??Dt,{type:"module",name:Kc})}),hx={};no(hx,{default:()=>fx});oI=te(()=>{"use strict";Xc=(Qc=br.url,async function(e={}){var t,r,i=e,a=new Promise((n,l)=>{t=n,r=l}),s=typeof window=="object",o=typeof WorkerGlobalScope<"u",u=o&&self.name?.startsWith("em-pthread");i.mountExternalData=(n,l)=>{n.startsWith("./")&&(n=n.substring(2)),(i.Bd||(i.Bd=new Map)).set(n,l)},i.unmountExternalData=()=>{delete i.Bd};var d=globalThis.SharedArrayBuffer??new WebAssembly.Memory({initial:0,maximum:0,shared:!0}).buffer.constructor;let p=()=>{let n=(c,h,y)=>(...x)=>{let T=it,A=h?.();x=c(...x);let O=h?.();return A!==O&&(c=O,y(A),h=y=null),it!=T?new Promise((P,j)=>{yi={resolve:P,reject:j}}):x},l=c=>async(...h)=>{try{if(i.Cd)throw Error("Session already started");let y=i.Cd={be:h[0],errors:[]},x=await c(...h);if(i.Cd!==y)throw Error("Session mismatch");i.Dd?.flush();let T=y.errors;if(0<T.length){let A=await Promise.all(T);if(A=A.filter(O=>O),0<A.length)throw Error(A.join(`
`))}return x}finally{i.Cd=null}};i._OrtCreateSession=n(i._OrtCreateSession,()=>i._OrtCreateSession,c=>i._OrtCreateSession=c),i._OrtRun=l(n(i._OrtRun,()=>i._OrtRun,c=>i._OrtRun=c)),i._OrtRunWithBinding=l(n(i._OrtRunWithBinding,()=>i._OrtRunWithBinding,c=>i._OrtRunWithBinding=c)),i._OrtBindInput=n(i._OrtBindInput,()=>i._OrtBindInput,c=>i._OrtBindInput=c),p=void 0};i.jsepInit=(n,l)=>{if(p?.(),n==="webgpu"){[i.Dd,i.Rd,i.Vd,i.Hd,i.Ud,i.hc,i.Wd,i.Zd,i.Sd,i.Td,i.Xd]=l;let c=i.Dd;i.jsepRegisterBuffer=(h,y,x,T)=>c.registerBuffer(h,y,x,T),i.jsepGetBuffer=h=>c.getBuffer(h),i.jsepCreateDownloader=(h,y,x)=>c.createDownloader(h,y,x),i.jsepOnCreateSession=h=>{c.onCreateSession(h)},i.jsepOnReleaseSession=h=>{c.onReleaseSession(h)},i.jsepOnRunStart=h=>c.onRunStart(h),i.$d=(h,y)=>{c.upload(h,y)}}else if(n==="webnn"){[i.Dd,i.Yd,i.Id,i.jsepEnsureTensor,i.Jd,i.jsepDownloadTensor]=l,i.jsepReleaseTensorId=i.Id,i.jsepUploadTensor=i.Jd;let c=i.Dd;i.jsepOnRunStart=h=>c.onRunStart(h),i.jsepOnRunEnd=c.onRunEnd.bind(c),i.jsepRegisterMLContext=(h,y)=>{c.registerMLContext(h,y)},i.jsepOnReleaseSession=h=>{c.onReleaseSession(h)},i.jsepCreateMLTensorDownloader=(h,y)=>c.createMLTensorDownloader(h,y),i.jsepRegisterMLTensor=(h,y,x,T)=>c.registerMLTensor(h,y,x,T),i.jsepCreateMLContext=h=>c.createMLContext(h),i.jsepRegisterMLConstant=(h,y,x,T,A)=>c.registerMLConstant(h,y,x,T,A,i.Bd),i.jsepRegisterGraphInput=c.registerGraphInput.bind(c),i.jsepIsGraphInput=c.isGraphInput.bind(c),i.jsepCreateTemporaryTensor=c.createTemporaryTensor.bind(c)}};var m,f,g=Object.assign({},i),v=(n,l)=>{throw l},_="";(s||o)&&(o?_=self.location.href:typeof document<"u"&&document.currentScript&&(_=document.currentScript.src),Qc&&(_=Qc),_=_.startsWith("blob:")?"":_.slice(0,_.replace(/[?#].*/,"").lastIndexOf("/")+1),o&&(f=n=>{var l=new XMLHttpRequest;return l.open("GET",n,!1),l.responseType="arraybuffer",l.send(null),new Uint8Array(l.response)}),m=async n=>{if(le(n))return new Promise((c,h)=>{var y=new XMLHttpRequest;y.open("GET",n,!0),y.responseType="arraybuffer",y.onload=()=>{y.status==200||y.status==0&&y.response?c(y.response):h(y.status)},y.onerror=h,y.send(null)});var l=await fetch(n,{credentials:"same-origin"});if(l.ok)return l.arrayBuffer();throw Error(l.status+" : "+l.url)});var b=console.log.bind(console),k=console.error.bind(console),$=b,w=k;Object.assign(i,g),g=null;var S,C,I,z,E,B,U,V,W,J,D,se,ue,F=i.wasmBinary,oe=!1,le=n=>n.startsWith("file://");function H(){return S.buffer!=z.buffer&&Ge(),z}function de(){return S.buffer!=z.buffer&&Ge(),E}function M(){return S.buffer!=z.buffer&&Ge(),B}function q(){return S.buffer!=z.buffer&&Ge(),U}function R(){return S.buffer!=z.buffer&&Ge(),V}function X(){return S.buffer!=z.buffer&&Ge(),W}function Ie(){return S.buffer!=z.buffer&&Ge(),J}function Fe(){return S.buffer!=z.buffer&&Ge(),ue}if(u){let n=function(l){try{var c=l.data,h=c.yd;if(h==="load"){let y=[];self.onmessage=x=>y.push(x),self.startWorker=()=>{postMessage({yd:"loaded"});for(let x of y)n(x);self.onmessage=n};for(let x of c.Od)i[x]&&!i[x].proxy||(i[x]=(...T)=>{postMessage({yd:"callHandler",Nd:x,args:T})},x=="print"&&($=i[x]),x=="printErr"&&(w=i[x]));S=c.he,Ge(),Ae(c.ie)}else if(h==="run"){ju(c.xd),bi(c.xd,0,0,1,0,0),Ta(),mi(c.xd),nt||(bn(),nt=!0);try{Lu(c.de,c.Fd)}catch(y){if(y!="unwind")throw y}}else c.target!=="setimmediate"&&(h==="checkMailbox"?nt&&Tr():h&&(w(`worker: received unknown command ${h}`),w(c)))}catch(y){throw $n(),y}};var De=n,Ae,nt=!1;w=function(...l){l=l.join(" "),console.error(l)},self.alert=function(...l){postMessage({yd:"alert",text:l.join(" "),fe:Br()})},self.onunhandledrejection=l=>{throw l.reason||l},self.onmessage=n}function Ge(){var n=S.buffer;i.HEAP8=z=new Int8Array(n),i.HEAP16=B=new Int16Array(n),i.HEAPU8=E=new Uint8Array(n),i.HEAPU16=U=new Uint16Array(n),i.HEAP32=V=new Int32Array(n),i.HEAPU32=W=new Uint32Array(n),i.HEAPF32=J=new Float32Array(n),i.HEAPF64=ue=new Float64Array(n),i.HEAP64=D=new BigInt64Array(n),i.HEAPU64=se=new BigUint64Array(n)}function kr(){u?startWorker(i):N.Bb()}u||(S=new WebAssembly.Memory({initial:256,maximum:65536,shared:!0}),Ge());var ti,Ht=0,Kt=null;function va(){if(--Ht==0&&Kt){var n=Kt;Kt=null,n()}}function st(n){throw w(n="Aborted("+n+")"),oe=!0,n=new WebAssembly.RuntimeError(n+". Build with -sASSERTIONS for more info."),r(n),n}function wa(){return{a:{Ta:qu,Va:Vu,W:Gu,la:Fu,b:Ku,u:Zu,R:Qu,Za:Xu,d:Ju,pb:za,g:Hu,T:Ra,Ga:Ba,lb:Ma,nb:Da,Ha:Pa,Ea:Ua,wb:Wa,Da:Va,pa:qa,mb:ja,jb:La,Fa:Ga,kb:Fa,Ma:Yu,za:tl,eb:rl,cb:al,ya:sl,V:ol,N:ul,db:ll,ma:gl,fb:yl,zb:_l,hb:vl,qb:wl,ab:bl,Aa:$l,yb:mi,Ja:xl,S:kl,Wa:Sl,$:Il,G:El,E:Al,m:ci,H:Ol,B:Nl,X:Ml,J:Dl,v:Pl,O:Ul,D:Wl,t:Vl,A:ql,z:jl,w:Ll,r:Gl,tb:Fl,ub:Hl,vb:Kl,rb:on,sb:un,bb:ln,Oa:Ql,La:Yl,y:ed,ja:td,Ba:rd,Ka:Xl,qa:id,Ia:ad,ib:nd,U:Zl,fa:sd,Sa:od,gb:ud,Qa:ld,Pa:dd,Ab:hn,Ca:fn,ob:si,aa:mn,oa:gn,xb:yn,na:_n,$a:Dd,ia:Qd,sa:tp,ga:Nd,da:jd,ua:Yd,p:Rd,e:yd,c:md,ea:Vd,f:_d,n:wd,k:Ed,Y:$d,ka:zd,j:Bd,wa:Wd,Ra:ap,ca:Kd,Ua:ip,P:qd,K:kd,_:Hd,Q:Md,Z:Xd,x:xd,l:gd,va:Fd,i:fd,h:bd,ra:rp,ta:ep,o:vd,q:Sd,s:Cd,I:Id,C:Od,L:Ad,xa:Ud,_a:Pd,F:Zd,Ya:Ld,ba:Jd,M:Td,Xa:Gd,ha:cd,a:S,Na:ni}}}var ri={1319426:()=>typeof wasmOffsetConverter<"u",1319483:(n,l,c,h,y)=>{if(i===void 0||!i.Bd)return 1;if((n=Oe(Number(n>>>0))).startsWith("./")&&(n=n.substring(2)),!(n=i.Bd.get(n)))return 2;if(l=Number(l>>>0),c=Number(c>>>0),h=Number(h>>>0),l+c>n.byteLength)return 3;try{let x=n.subarray(l,l+c);switch(y){case 0:de().set(x,h>>>0);break;case 1:i.$d(h,x);break;default:return 4}return 0}catch{return 4}},1320198:(n,l,c)=>{i.Jd(n,de().subarray(l>>>0,l+c>>>0))},1320261:()=>i.Yd(),1320302:n=>{i.Id(n)},1320338:()=>{i.Sd()},1320369:()=>{i.Td()},1320398:()=>{i.Xd()},1320423:n=>i.Rd(n),1320456:n=>i.Vd(n),1320488:(n,l,c)=>{i.Hd(Number(n),Number(l),Number(c),!0)},1320551:(n,l,c)=>{i.Hd(Number(n),Number(l),Number(c))},1320608:n=>{i.hc("Abs",n,void 0)},1320659:n=>{i.hc("Neg",n,void 0)},1320710:n=>{i.hc("Floor",n,void 0)},1320763:n=>{i.hc("Ceil",n,void 0)},1320815:n=>{i.hc("Reciprocal",n,void 0)},1320873:n=>{i.hc("Sqrt",n,void 0)},1320925:n=>{i.hc("Exp",n,void 0)},1320976:n=>{i.hc("Erf",n,void 0)},1321027:n=>{i.hc("Sigmoid",n,void 0)},1321082:(n,l,c)=>{i.hc("HardSigmoid",n,{alpha:l,beta:c})},1321161:n=>{i.hc("Log",n,void 0)},1321212:n=>{i.hc("Sin",n,void 0)},1321263:n=>{i.hc("Cos",n,void 0)},1321314:n=>{i.hc("Tan",n,void 0)},1321365:n=>{i.hc("Asin",n,void 0)},1321417:n=>{i.hc("Acos",n,void 0)},1321469:n=>{i.hc("Atan",n,void 0)},1321521:n=>{i.hc("Sinh",n,void 0)},1321573:n=>{i.hc("Cosh",n,void 0)},1321625:n=>{i.hc("Asinh",n,void 0)},1321678:n=>{i.hc("Acosh",n,void 0)},1321731:n=>{i.hc("Atanh",n,void 0)},1321784:n=>{i.hc("Tanh",n,void 0)},1321836:n=>{i.hc("Not",n,void 0)},1321887:(n,l,c)=>{i.hc("Clip",n,{min:l,max:c})},1321956:n=>{i.hc("Clip",n,void 0)},1322008:(n,l)=>{i.hc("Elu",n,{alpha:l})},1322066:n=>{i.hc("Gelu",n,void 0)},1322118:n=>{i.hc("Relu",n,void 0)},1322170:(n,l)=>{i.hc("LeakyRelu",n,{alpha:l})},1322234:(n,l)=>{i.hc("ThresholdedRelu",n,{alpha:l})},1322304:(n,l)=>{i.hc("Cast",n,{to:l})},1322362:n=>{i.hc("Add",n,void 0)},1322413:n=>{i.hc("Sub",n,void 0)},1322464:n=>{i.hc("Mul",n,void 0)},1322515:n=>{i.hc("Div",n,void 0)},1322566:n=>{i.hc("Pow",n,void 0)},1322617:n=>{i.hc("Equal",n,void 0)},1322670:n=>{i.hc("Greater",n,void 0)},1322725:n=>{i.hc("GreaterOrEqual",n,void 0)},1322787:n=>{i.hc("Less",n,void 0)},1322839:n=>{i.hc("LessOrEqual",n,void 0)},1322898:(n,l,c,h,y)=>{i.hc("ReduceMean",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323073:(n,l,c,h,y)=>{i.hc("ReduceMax",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323247:(n,l,c,h,y)=>{i.hc("ReduceMin",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323421:(n,l,c,h,y)=>{i.hc("ReduceProd",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323596:(n,l,c,h,y)=>{i.hc("ReduceSum",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323770:(n,l,c,h,y)=>{i.hc("ReduceL1",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1323943:(n,l,c,h,y)=>{i.hc("ReduceL2",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324116:(n,l,c,h,y)=>{i.hc("ReduceLogSum",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324293:(n,l,c,h,y)=>{i.hc("ReduceSumSquare",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324473:(n,l,c,h,y)=>{i.hc("ReduceLogSumExp",n,{keepDims:!!l,noopWithEmptyAxes:!!c,axes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1324653:n=>{i.hc("Where",n,void 0)},1324706:(n,l,c)=>{i.hc("Transpose",n,{perm:l?Array.from(R().subarray(Number(l)>>>0,Number(c)>>>0)):[]})},1324830:(n,l,c,h)=>{i.hc("DepthToSpace",n,{blocksize:l,mode:Oe(c),format:h?"NHWC":"NCHW"})},1324963:(n,l,c,h)=>{i.hc("DepthToSpace",n,{blocksize:l,mode:Oe(c),format:h?"NHWC":"NCHW"})},1325096:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe)=>{i.hc("ConvTranspose",n,{format:O?"NHWC":"NCHW",autoPad:l,dilations:[c],group:h,kernelShape:[y],pads:[x,T],strides:[A],wIsConst:()=>!!H()[P>>>0],outputPadding:j?Array.from(R().subarray(Number(j)>>>0,Number(Q)>>>0)):[],outputShape:ae?Array.from(R().subarray(Number(ae)>>>0,Number(we)>>>0)):[],activation:Oe(Xe)})},1325529:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("ConvTranspose",n,{format:A?"NHWC":"NCHW",autoPad:l,dilations:Array.from(R().subarray(Number(c)>>>0,2+(Number(c)>>>0)>>>0)),group:h,kernelShape:Array.from(R().subarray(Number(y)>>>0,2+(Number(y)>>>0)>>>0)),pads:Array.from(R().subarray(Number(x)>>>0,4+(Number(x)>>>0)>>>0)),strides:Array.from(R().subarray(Number(T)>>>0,2+(Number(T)>>>0)>>>0)),wIsConst:()=>!!H()[O>>>0],outputPadding:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],outputShape:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[],activation:Oe(we)})},1326190:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe)=>{i.hc("ConvTranspose",n,{format:O?"NHWC":"NCHW",autoPad:l,dilations:[c],group:h,kernelShape:[y],pads:[x,T],strides:[A],wIsConst:()=>!!H()[P>>>0],outputPadding:j?Array.from(R().subarray(Number(j)>>>0,Number(Q)>>>0)):[],outputShape:ae?Array.from(R().subarray(Number(ae)>>>0,Number(we)>>>0)):[],activation:Oe(Xe)})},1326623:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("ConvTranspose",n,{format:A?"NHWC":"NCHW",autoPad:l,dilations:Array.from(R().subarray(Number(c)>>>0,2+(Number(c)>>>0)>>>0)),group:h,kernelShape:Array.from(R().subarray(Number(y)>>>0,2+(Number(y)>>>0)>>>0)),pads:Array.from(R().subarray(Number(x)>>>0,4+(Number(x)>>>0)>>>0)),strides:Array.from(R().subarray(Number(T)>>>0,2+(Number(T)>>>0)>>>0)),wIsConst:()=>!!H()[O>>>0],outputPadding:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],outputShape:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[],activation:Oe(we)})},1327284:(n,l)=>{i.hc("GlobalAveragePool",n,{format:l?"NHWC":"NCHW"})},1327375:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("AveragePool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1327854:(n,l)=>{i.hc("GlobalAveragePool",n,{format:l?"NHWC":"NCHW"})},1327945:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("AveragePool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1328424:(n,l)=>{i.hc("GlobalMaxPool",n,{format:l?"NHWC":"NCHW"})},1328511:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("MaxPool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1328986:(n,l)=>{i.hc("GlobalMaxPool",n,{format:l?"NHWC":"NCHW"})},1329073:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>{i.hc("MaxPool",n,{format:we?"NHWC":"NCHW",auto_pad:l,ceil_mode:c,count_include_pad:h,storage_order:y,dilations:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],kernel_shape:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],pads:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],strides:Q?Array.from(R().subarray(Number(Q)>>>0,Number(ae)>>>0)):[]})},1329548:(n,l,c,h,y)=>{i.hc("Gemm",n,{alpha:l,beta:c,transA:h,transB:y})},1329652:n=>{i.hc("MatMul",n,void 0)},1329706:(n,l,c,h)=>{i.hc("ArgMax",n,{keepDims:!!l,selectLastIndex:!!c,axis:h})},1329814:(n,l,c,h)=>{i.hc("ArgMin",n,{keepDims:!!l,selectLastIndex:!!c,axis:h})},1329922:(n,l)=>{i.hc("Softmax",n,{axis:l})},1329985:(n,l)=>{i.hc("Concat",n,{axis:l})},1330045:(n,l,c,h,y)=>{i.hc("Split",n,{axis:l,numOutputs:c,splitSizes:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1330201:n=>{i.hc("Expand",n,void 0)},1330255:(n,l)=>{i.hc("Gather",n,{axis:Number(l)})},1330326:(n,l)=>{i.hc("GatherElements",n,{axis:Number(l)})},1330405:(n,l)=>{i.hc("GatherND",n,{batch_dims:Number(l)})},1330484:(n,l,c,h,y,x,T,A,O,P,j)=>{i.hc("Resize",n,{antialias:l,axes:c?Array.from(R().subarray(Number(c)>>>0,Number(h)>>>0)):[],coordinateTransformMode:Oe(y),cubicCoeffA:x,excludeOutside:T,extrapolationValue:A,keepAspectRatioPolicy:Oe(O),mode:Oe(P),nearestMode:Oe(j)})},1330846:(n,l,c,h,y,x,T)=>{i.hc("Slice",n,{starts:l?Array.from(R().subarray(Number(l)>>>0,Number(c)>>>0)):[],ends:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[],axes:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[]})},1331110:n=>{i.hc("Tile",n,void 0)},1331162:(n,l,c)=>{i.hc("InstanceNormalization",n,{epsilon:l,format:c?"NHWC":"NCHW"})},1331276:(n,l,c)=>{i.hc("InstanceNormalization",n,{epsilon:l,format:c?"NHWC":"NCHW"})},1331390:n=>{i.hc("Range",n,void 0)},1331443:(n,l)=>{i.hc("Einsum",n,{equation:Oe(l)})},1331524:(n,l,c,h,y)=>{i.hc("Pad",n,{mode:l,value:c,pads:h?Array.from(R().subarray(Number(h)>>>0,Number(y)>>>0)):[]})},1331667:(n,l,c,h,y,x)=>{i.hc("BatchNormalization",n,{epsilon:l,momentum:c,spatial:!!y,trainingMode:!!h,format:x?"NHWC":"NCHW"})},1331836:(n,l,c,h,y,x)=>{i.hc("BatchNormalization",n,{epsilon:l,momentum:c,spatial:!!y,trainingMode:!!h,format:x?"NHWC":"NCHW"})},1332005:(n,l,c)=>{i.hc("CumSum",n,{exclusive:Number(l),reverse:Number(c)})},1332102:(n,l,c)=>{i.hc("DequantizeLinear",n,{axis:l,blockSize:c})},1332192:(n,l,c,h,y)=>{i.hc("GridSample",n,{align_corners:l,mode:Oe(c),padding_mode:Oe(h),format:y?"NHWC":"NCHW"})},1332362:(n,l,c,h,y)=>{i.hc("GridSample",n,{align_corners:l,mode:Oe(c),padding_mode:Oe(h),format:y?"NHWC":"NCHW"})},1332532:(n,l)=>{i.hc("ScatterND",n,{reduction:Oe(l)})},1332617:(n,l,c,h,y,x,T,A,O)=>{i.hc("Attention",n,{numHeads:l,isUnidirectional:c,maskFilterValue:h,scale:y,doRotary:x,qkvHiddenSizes:T?Array.from(R().subarray(Number(A)>>>0,Number(A)+T>>>0)):[],pastPresentShareBuffer:!!O})},1332889:n=>{i.hc("BiasAdd",n,void 0)},1332944:n=>{i.hc("BiasSplitGelu",n,void 0)},1333005:n=>{i.hc("FastGelu",n,void 0)},1333061:(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we,Xe,Jt)=>{i.hc("Conv",n,{format:Q?"NHWC":"NCHW",auto_pad:l,dilations:c?Array.from(R().subarray(Number(c)>>>0,Number(h)>>>0)):[],group:y,kernel_shape:x?Array.from(R().subarray(Number(x)>>>0,Number(T)>>>0)):[],pads:A?Array.from(R().subarray(Number(A)>>>0,Number(O)>>>0)):[],strides:P?Array.from(R().subarray(Number(P)>>>0,Number(j)>>>0)):[],w_is_const:()=>!!H()[Number(ae)>>>0],activation:Oe(we),activation_params:Xe?Array.from(Ie().subarray(Number(Xe)>>>0,Number(Jt)>>>0)):[]})},1333645:n=>{i.hc("Gelu",n,void 0)},1333697:(n,l,c,h,y,x,T,A,O)=>{i.hc("GroupQueryAttention",n,{numHeads:l,kvNumHeads:c,scale:h,softcap:y,doRotary:x,rotaryInterleaved:T,smoothSoftmax:A,localWindowSize:O})},1333914:(n,l,c,h)=>{i.hc("LayerNormalization",n,{axis:l,epsilon:c,simplified:!!h})},1334025:(n,l,c,h)=>{i.hc("LayerNormalization",n,{axis:l,epsilon:c,simplified:!!h})},1334136:(n,l,c,h,y,x)=>{i.hc("MatMulNBits",n,{k:l,n:c,accuracyLevel:h,bits:y,blockSize:x})},1334263:(n,l,c,h,y,x)=>{i.hc("MultiHeadAttention",n,{numHeads:l,isUnidirectional:c,maskFilterValue:h,scale:y,doRotary:x})},1334422:(n,l)=>{i.hc("QuickGelu",n,{alpha:l})},1334486:(n,l,c,h,y)=>{i.hc("RotaryEmbedding",n,{interleaved:!!l,numHeads:c,rotaryEmbeddingDim:h,scale:y})},1334625:(n,l,c)=>{i.hc("SkipLayerNormalization",n,{epsilon:l,simplified:!!c})},1334727:(n,l,c)=>{i.hc("SkipLayerNormalization",n,{epsilon:l,simplified:!!c})},1334829:(n,l,c,h)=>{i.hc("GatherBlockQuantized",n,{gatherAxis:l,quantizeAxis:c,blockSize:h})},1334950:n=>{i.Wd(n)},1334984:(n,l)=>i.Zd(Number(n),Number(l),i.Cd.be,i.Cd.errors)};function Vu(n,l,c){return en(async()=>{await i.Ud(Number(n),Number(l),Number(c))})}function qu(){return typeof wasmOffsetConverter<"u"}class ii{constructor(l){Ao(this,"name","ExitStatus");this.message=`Program terminated with exit(${l})`,this.status=l}}var ba=n=>{n.terminate(),n.onmessage=()=>{}},ai=[],$a=n=>{gt.length==0&&(Ia(),Ca(gt[0]));var l=gt.pop();if(!l)return 6;Zt.push(l),St[n.xd]=l,l.xd=n.xd;var c={yd:"run",de:n.ce,Fd:n.Fd,xd:n.xd};return l.postMessage(c,n.Ld),0},mt=0,xe=(n,l,...c)=>{for(var h=2*c.length,y=re(),x=xi(8*h),T=x>>>3,A=0;A<c.length;A++){var O=c[A];typeof O=="bigint"?(D[T+2*A]=1n,D[T+2*A+1]=O):(D[T+2*A]=0n,Fe()[T+2*A+1>>>0]=O)}return n=xn(n,0,h,x,l),Y(y),n};function ni(n){if(u)return xe(0,1,n);if(I=n,!(0<mt)){for(var l of Zt)ba(l);for(l of gt)ba(l);gt=[],Zt=[],St={},oe=!0}v(0,new ii(n))}function xa(n){if(u)return xe(1,0,n);si(n)}var si=n=>{if(I=n,u)throw xa(n),"unwind";ni(n)},gt=[],Zt=[],ka=[],St={},Sa=n=>{var l=n.xd;delete St[l],gt.push(n),Zt.splice(Zt.indexOf(n),1),n.xd=0,kn(l)};function Ta(){ka.forEach(n=>n())}var Ca=n=>new Promise(l=>{n.onmessage=y=>{var x=(y=y.data).yd;if(y.Ed&&y.Ed!=Br()){var T=St[y.Ed];T?T.postMessage(y,y.Ld):w(`Internal error! Worker sent a message "${x}" to target pthread ${y.Ed}, but that thread no longer exists!`)}else x==="checkMailbox"?Tr():x==="spawnThread"?$a(y):x==="cleanupThread"?Sa(St[y.ee]):x==="loaded"?(n.loaded=!0,l(n)):x==="alert"?alert(`Thread ${y.fe}: ${y.text}`):y.target==="setimmediate"?n.postMessage(y):x==="callHandler"?i[y.Nd](...y.args):x&&w(`worker sent an unknown command ${x}`)},n.onerror=y=>{throw w(`worker sent an error! ${y.filename}:${y.lineno}: ${y.message}`),y};var c,h=[];for(c of[])i.propertyIsEnumerable(c)&&h.push(c);n.postMessage({yd:"load",Od:h,he:S,ie:C})});function Ia(){var n=new Worker(br.url.startsWith("file:")?new URL("ort.bundle.min.mjs",br.url):new URL(br.url),{type:"module",workerData:"em-pthread",name:"em-pthread"});gt.push(n)}var ju=n=>{Ge();var l=X()[n+52>>>2>>>0];n=X()[n+56>>>2>>>0],Cn(l,l-n),Y(l)},Lu=(n,l)=>{mt=0,n=ki(n,l),0<mt?I=n:$i(n)},Sr=[];function Gu(n){var l=new oi(n>>>=0);if(H()[l.wd+12>>>0]==0){var c=1;H()[l.wd+12>>>0]=c}return c=0,H()[l.wd+13>>>0]=c,Sr.push(l),En(n),An(n)}var At=0,Fu=()=>{ie(0,0);var n=Sr.pop();In(n.Gd),At=0};class oi{constructor(l){this.Gd=l,this.wd=l-24}}function Hu(n){throw At||(At=n>>>0),At}var ui=n=>{var l=At;if(!l)return Xt(0),0;var c=new oi(l);X()[c.wd+16>>>2>>>0]=l;var h=X()[c.wd+4>>>2>>>0];if(!h)return Xt(0),l;for(var y of n){if(y===0||y===h)break;if(zn(y,h,c.wd+16))return Xt(y),l}return Xt(h),l};function Ku(){return ui([])}function Zu(n){return ui([n>>>0])}function Qu(n,l){return ui([n>>>0,l>>>0])}var Xu=()=>{var n=Sr.pop();n||st("no exception to throw");var l=n.Gd;if(H()[n.wd+13>>>0]==0){Sr.push(n);var c=1;H()[n.wd+13>>>0]=c,c=0,H()[n.wd+12>>>0]=c}throw At=l};function Ju(n,l,c){var h=new oi(n>>>=0);throw l>>>=0,c>>>=0,X()[h.wd+16>>>2>>>0]=0,X()[h.wd+4>>>2>>>0]=l,X()[h.wd+8>>>2>>>0]=c,At=n}function Ea(n,l,c,h){return u?xe(2,1,n,l,c,h):za(n,l,c,h)}function za(n,l,c,h){if(n>>>=0,c>>>=0,h>>>=0,d===void 0)return 6;var y=[];return u&&y.length===0?Ea(n,l>>>=0,c,h):(n={ce:c,xd:n,Fd:h,Ld:y},u?(n.yd="spawnThread",postMessage(n,y),0):$a(n))}var Aa=typeof TextDecoder<"u"?new TextDecoder:void 0,Oa=(n,l=0,c=NaN)=>{var h=(l>>>=0)+c;for(c=l;n[c]&&!(c>=h);)++c;if(16<c-l&&n.buffer&&Aa)return Aa.decode(n.buffer instanceof ArrayBuffer?n.subarray(l,c):n.slice(l,c));for(h="";l<c;){var y=n[l++];if(128&y){var x=63&n[l++];if((224&y)==192)h+=String.fromCharCode((31&y)<<6|x);else{var T=63&n[l++];65536>(y=(240&y)==224?(15&y)<<12|x<<6|T:(7&y)<<18|x<<12|T<<6|63&n[l++])?h+=String.fromCharCode(y):(y-=65536,h+=String.fromCharCode(55296|y>>10,56320|1023&y))}}else h+=String.fromCharCode(y)}return h},Oe=(n,l)=>(n>>>=0)?Oa(de(),n,l):"";function Ra(n,l,c){return u?xe(3,1,n,l,c):0}function Ba(n,l){if(u)return xe(4,1,n,l)}var Na=n=>{for(var l=0,c=0;c<n.length;++c){var h=n.charCodeAt(c);127>=h?l++:2047>=h?l+=2:55296<=h&&57343>=h?(l+=4,++c):l+=3}return l},Ot=(n,l,c)=>{var h=de();if(l>>>=0,0<c){var y=l;c=l+c-1;for(var x=0;x<n.length;++x){var T=n.charCodeAt(x);if(55296<=T&&57343>=T&&(T=65536+((1023&T)<<10)|1023&n.charCodeAt(++x)),127>=T){if(l>=c)break;h[l++>>>0]=T}else{if(2047>=T){if(l+1>=c)break;h[l++>>>0]=192|T>>6}else{if(65535>=T){if(l+2>=c)break;h[l++>>>0]=224|T>>12}else{if(l+3>=c)break;h[l++>>>0]=240|T>>18,h[l++>>>0]=128|T>>12&63}h[l++>>>0]=128|T>>6&63}h[l++>>>0]=128|63&T}}h[l>>>0]=0,n=l-y}else n=0;return n};function Ma(n,l){if(u)return xe(5,1,n,l)}function Da(n,l,c){if(u)return xe(6,1,n,l,c)}function Pa(n,l,c){return u?xe(7,1,n,l,c):0}function Ua(n,l){if(u)return xe(8,1,n,l)}function Wa(n,l,c){if(u)return xe(9,1,n,l,c)}function Va(n,l,c,h){if(u)return xe(10,1,n,l,c,h)}function qa(n,l,c,h){if(u)return xe(11,1,n,l,c,h)}function ja(n,l,c,h){if(u)return xe(12,1,n,l,c,h)}function La(n){if(u)return xe(13,1,n)}function Ga(n,l){if(u)return xe(14,1,n,l)}function Fa(n,l,c){if(u)return xe(15,1,n,l,c)}var Ha,yt,Yu=()=>st(""),rt=n=>{for(var l="";de()[n>>>0];)l+=Ha[de()[n++>>>0]];return l},li={},di={},el={};function ot(n,l,c={}){return function(h,y,x={}){var T=y.name;if(!h)throw new yt(`type "${T}" must have a positive integer typeid pointer`);if(di.hasOwnProperty(h)){if(x.Pd)return;throw new yt(`Cannot register type '${T}' twice`)}di[h]=y,delete el[h],li.hasOwnProperty(h)&&(y=li[h],delete li[h],y.forEach(A=>A()))}(n,l,c)}var Ka=(n,l,c)=>{switch(l){case 1:return c?h=>H()[h>>>0]:h=>de()[h>>>0];case 2:return c?h=>M()[h>>>1>>>0]:h=>q()[h>>>1>>>0];case 4:return c?h=>R()[h>>>2>>>0]:h=>X()[h>>>2>>>0];case 8:return c?h=>D[h>>>3]:h=>se[h>>>3];default:throw new TypeError(`invalid integer width (${l}): ${n}`)}};function tl(n,l,c){c>>>=0,ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:h=>h,toWireType:function(h,y){if(typeof y!="bigint"&&typeof y!="number")throw y=y===null?"null":(h=typeof y)=="object"||h==="array"||h==="function"?y.toString():""+y,new TypeError(`Cannot convert "${y}" to ${this.name}`);return typeof y=="number"&&(y=BigInt(y)),y},zd:_t,readValueFromPointer:Ka(l,c,l.indexOf("u")==-1),Ad:null})}var _t=8;function rl(n,l,c,h){ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:function(y){return!!y},toWireType:function(y,x){return x?c:h},zd:_t,readValueFromPointer:function(y){return this.fromWireType(de()[y>>>0])},Ad:null})}var pi=[],ut=[];function ci(n){9<(n>>>=0)&&--ut[n+1]==0&&(ut[n]=void 0,pi.push(n))}var He=n=>{if(!n)throw new yt("Cannot use deleted val. handle = "+n);return ut[n]},Qe=n=>{switch(n){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:let l=pi.pop()||ut.length;return ut[l]=n,ut[l+1]=1,l}};function hi(n){return this.fromWireType(X()[n>>>2>>>0])}var il={name:"emscripten::val",fromWireType:n=>{var l=He(n);return ci(n),l},toWireType:(n,l)=>Qe(l),zd:_t,readValueFromPointer:hi,Ad:null};function al(n){return ot(n>>>0,il)}var nl=(n,l)=>{switch(l){case 4:return function(c){return this.fromWireType(Ie()[c>>>2>>>0])};case 8:return function(c){return this.fromWireType(Fe()[c>>>3>>>0])};default:throw new TypeError(`invalid float width (${l}): ${n}`)}};function sl(n,l,c){c>>>=0,ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:h=>h,toWireType:(h,y)=>y,zd:_t,readValueFromPointer:nl(l,c),Ad:null})}function ol(n,l,c,h,y){if(n>>>=0,c>>>=0,l=rt(l>>>0),y===-1&&(y=4294967295),y=A=>A,h===0){var x=32-8*c;y=A=>A<<x>>>x}var T=l.includes("unsigned")?function(A,O){return O>>>0}:function(A,O){return O};ot(n,{name:l,fromWireType:y,toWireType:T,zd:_t,readValueFromPointer:Ka(l,c,h!==0),Ad:null})}function ul(n,l,c){function h(x){var T=X()[x>>>2>>>0];return x=X()[x+4>>>2>>>0],new y(H().buffer,x,T)}var y=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array][l];ot(n>>>=0,{name:c=rt(c>>>0),fromWireType:h,zd:_t,readValueFromPointer:h},{Pd:!0})}function ll(n,l){ot(n>>>=0,{name:l=rt(l>>>0),fromWireType:function(c){for(var h,y=X()[c>>>2>>>0],x=c+4,T=x,A=0;A<=y;++A){var O=x+A;A!=y&&de()[O>>>0]!=0||(T=Oe(T,O-T),h===void 0?h=T:(h+="\0",h+=T),T=O+1)}return at(c),h},toWireType:function(c,h){h instanceof ArrayBuffer&&(h=new Uint8Array(h));var y=typeof h=="string";if(!(y||h instanceof Uint8Array||h instanceof Uint8ClampedArray||h instanceof Int8Array))throw new yt("Cannot pass non-string to std::string");var x=y?Na(h):h.length,T=Nr(4+x+1),A=T+4;if(X()[T>>>2>>>0]=x,y)Ot(h,A,x+1);else if(y)for(y=0;y<x;++y){var O=h.charCodeAt(y);if(255<O)throw at(T),new yt("String has UTF-16 code units that do not fit in 8 bits");de()[A+y>>>0]=O}else for(y=0;y<x;++y)de()[A+y>>>0]=h[y];return c!==null&&c.push(at,T),T},zd:_t,readValueFromPointer:hi,Ad(c){at(c)}})}var Za=typeof TextDecoder<"u"?new TextDecoder("utf-16le"):void 0,dl=(n,l)=>{for(var c=n>>1,h=c+l/2;!(c>=h)&&q()[c>>>0];)++c;if(32<(c<<=1)-n&&Za)return Za.decode(de().slice(n,c));for(c="",h=0;!(h>=l/2);++h){var y=M()[n+2*h>>>1>>>0];if(y==0)break;c+=String.fromCharCode(y)}return c},pl=(n,l,c)=>{if(c??(c=2147483647),2>c)return 0;var h=l;c=(c-=2)<2*n.length?c/2:n.length;for(var y=0;y<c;++y){var x=n.charCodeAt(y);M()[l>>>1>>>0]=x,l+=2}return M()[l>>>1>>>0]=0,l-h},cl=n=>2*n.length,hl=(n,l)=>{for(var c=0,h="";!(c>=l/4);){var y=R()[n+4*c>>>2>>>0];if(y==0)break;++c,65536<=y?(y-=65536,h+=String.fromCharCode(55296|y>>10,56320|1023&y)):h+=String.fromCharCode(y)}return h},fl=(n,l,c)=>{if(l>>>=0,c??(c=2147483647),4>c)return 0;var h=l;c=h+c-4;for(var y=0;y<n.length;++y){var x=n.charCodeAt(y);if(55296<=x&&57343>=x&&(x=65536+((1023&x)<<10)|1023&n.charCodeAt(++y)),R()[l>>>2>>>0]=x,(l+=4)+4>c)break}return R()[l>>>2>>>0]=0,l-h},ml=n=>{for(var l=0,c=0;c<n.length;++c){var h=n.charCodeAt(c);55296<=h&&57343>=h&&++c,l+=4}return l};function gl(n,l,c){if(n>>>=0,l>>>=0,c=rt(c>>>=0),l===2)var h=dl,y=pl,x=cl,T=A=>q()[A>>>1>>>0];else l===4&&(h=hl,y=fl,x=ml,T=A=>X()[A>>>2>>>0]);ot(n,{name:c,fromWireType:A=>{for(var O,P=X()[A>>>2>>>0],j=A+4,Q=0;Q<=P;++Q){var ae=A+4+Q*l;Q!=P&&T(ae)!=0||(j=h(j,ae-j),O===void 0?O=j:(O+="\0",O+=j),j=ae+l)}return at(A),O},toWireType:(A,O)=>{if(typeof O!="string")throw new yt(`Cannot pass non-string to C++ string type ${c}`);var P=x(O),j=Nr(4+P+l);return X()[j>>>2>>>0]=P/l,y(O,j+4,P+l),A!==null&&A.push(at,j),j},zd:_t,readValueFromPointer:hi,Ad(A){at(A)}})}function yl(n,l){ot(n>>>=0,{Qd:!0,name:l=rt(l>>>0),zd:0,fromWireType:()=>{},toWireType:()=>{}})}function _l(n){bi(n>>>0,!o,1,!s,131072,!1),Ta()}var fi=n=>{if(!oe)try{if(n(),!(0<mt))try{u?$i(I):si(I)}catch(l){l instanceof ii||l=="unwind"||v(0,l)}}catch(l){l instanceof ii||l=="unwind"||v(0,l)}};function mi(n){n>>>=0,typeof Atomics.ge=="function"&&(Atomics.ge(R(),n>>>2,n).value.then(Tr),n+=128,Atomics.store(R(),n>>>2,1))}var Tr=()=>{var n=Br();n&&(mi(n),fi(Tn))};function vl(n,l){(n>>>=0)==l>>>0?setTimeout(Tr):u?postMessage({Ed:n,yd:"checkMailbox"}):(n=St[n])&&n.postMessage({yd:"checkMailbox"})}var gi=[];function wl(n,l,c,h,y){for(l>>>=0,h/=2,gi.length=h,c=y>>>0>>>3,y=0;y<h;y++)gi[y]=D[c+2*y]?D[c+2*y+1]:Fe()[c+2*y+1>>>0];return(l?ri[l]:hd[n])(...gi)}var bl=()=>{mt=0};function $l(n){n>>>=0,u?postMessage({yd:"cleanupThread",ee:n}):Sa(St[n])}function xl(n){}var Cr=(n,l)=>{var c=di[n];if(c===void 0)throw n=wn(n),c=rt(n),at(n),new yt(`${l} has unknown type ${c}`);return c},Qa=(n,l,c)=>{var h=[];return n=n.toWireType(h,c),h.length&&(X()[l>>>2>>>0]=Qe(h)),n};function kl(n,l,c){return l>>>=0,c>>>=0,n=He(n>>>0),l=Cr(l,"emval::as"),Qa(l,c,n)}function Sl(n,l){return l>>>=0,n=He(n>>>0),(l=Cr(l,"emval::as")).toWireType(null,n)}var Ir=n=>{try{n()}catch(l){st(l)}},vt=0,it=null,Xa=0,Er=[],Ja={},Ya={},Tl=0,yi=null,Cl=[];function en(n){return function(l){if(!oe){if(vt===0){var c=!1,h=!1;l((y=0)=>{if(!oe&&(Xa=y,c=!0,h)){vt=2,Ir(()=>ks(it)),typeof MainLoop<"u"&&MainLoop.Md&&MainLoop.resume(),y=!1;try{var x=function(){var O=R()[it+8>>>2>>>0];return O=N[Ya[O]],--mt,O()}()}catch(O){x=O,y=!0}var T=!1;if(!it){var A=yi;A&&(yi=null,(y?A.reject:A.resolve)(x),T=!0)}if(y&&!T)throw x}}),h=!0,c||(vt=1,it=function(){var y=Nr(65548),x=y+12;X()[y>>>2>>>0]=x,X()[y+4>>>2>>>0]=x+65536,x=Er[0];var T=Ja[x];return T===void 0&&(T=Tl++,Ja[x]=T,Ya[T]=x),x=T,R()[y+8>>>2>>>0]=x,y}(),typeof MainLoop<"u"&&MainLoop.Md&&MainLoop.pause(),Ir(()=>$s(it)))}else vt===2?(vt=0,Ir(Ss),at(it),it=null,Cl.forEach(fi)):st(`invalid state: ${vt}`);return Xa}}(l=>{n().then(l)})}function Il(n){return n>>>=0,en(async()=>{var l=await He(n);return Qe(l)})}var zr=[];function El(n,l,c,h){return c>>>=0,h>>>=0,(n=zr[n>>>0])(null,l=He(l>>>0),c,h)}var zl={},Ar=n=>{var l=zl[n];return l===void 0?rt(n):l};function Al(n,l,c,h,y){return c>>>=0,h>>>=0,y>>>=0,(n=zr[n>>>0])(l=He(l>>>0),l[c=Ar(c)],h,y)}var tn=()=>typeof globalThis=="object"?globalThis:Function("return this")();function Ol(n){return(n>>>=0)==0?Qe(tn()):(n=Ar(n),Qe(tn()[n]))}var Rl=n=>{var l=zr.length;return zr.push(n),l},Bl=(n,l)=>{for(var c=Array(n),h=0;h<n;++h)c[h]=Cr(X()[l+4*h>>>2>>>0],"parameter "+h);return c},rn=(n,l)=>Object.defineProperty(l,"name",{value:n});function Nl(n,l,c){var h=(l=Bl(n,l>>>0)).shift();n--;var y=`return function (obj, func, destructorsRef, args) {
`,x=0,T=[];c===0&&T.push("obj");for(var A=["retType"],O=[h],P=0;P<n;++P)T.push("arg"+P),A.push("argType"+P),O.push(l[P]),y+=`  var arg${P} = argType${P}.readValueFromPointer(args${x?"+"+x:""});
`,x+=l[P].zd;return y+=`  var rv = ${c===1?"new func":"func.call"}(${T.join(", ")});
`,h.Qd||(A.push("emval_returnValue"),O.push(Qa),y+=`  return emval_returnValue(retType, destructorsRef, rv);
`),A.push(y+`};
`),n=function(j){var Q=Function;if(!(Q instanceof Function))throw new TypeError(`new_ called with constructor type ${typeof Q} which is not a function`);var ae=rn(Q.name||"unknownFunctionName",function(){});return ae.prototype=Q.prototype,ae=new ae,(j=Q.apply(ae,j))instanceof Object?j:ae}(A)(...O),c=`methodCaller<(${l.map(j=>j.name).join(", ")}) => ${h.name}>`,Rl(rn(c,n))}function Ml(n){return n=Ar(n>>>0),Qe(i[n])}function Dl(n,l){return l>>>=0,n=He(n>>>0),l=He(l),Qe(n[l])}function Pl(n){9<(n>>>=0)&&(ut[n+1]+=1)}function Ul(){return Qe([])}function Wl(n){n=He(n>>>0);for(var l=Array(n.length),c=0;c<n.length;c++)l[c]=n[c];return Qe(l)}function Vl(n){return Qe(Ar(n>>>0))}function ql(){return Qe({})}function jl(n){for(var l=He(n>>>=0);l.length;){var c=l.pop();l.pop()(c)}ci(n)}function Ll(n,l,c){l>>>=0,c>>>=0,n=He(n>>>0),l=He(l),c=He(c),n[l]=c}function Gl(n,l){return l>>>=0,n=(n=Cr(n>>>0,"_emval_take_value")).readValueFromPointer(l),Qe(n)}function Fl(n,l){n=-9007199254740992>n||9007199254740992<n?NaN:Number(n),l>>>=0,n=new Date(1e3*n),R()[l>>>2>>>0]=n.getUTCSeconds(),R()[l+4>>>2>>>0]=n.getUTCMinutes(),R()[l+8>>>2>>>0]=n.getUTCHours(),R()[l+12>>>2>>>0]=n.getUTCDate(),R()[l+16>>>2>>>0]=n.getUTCMonth(),R()[l+20>>>2>>>0]=n.getUTCFullYear()-1900,R()[l+24>>>2>>>0]=n.getUTCDay(),n=(n.getTime()-Date.UTC(n.getUTCFullYear(),0,1,0,0,0,0))/864e5|0,R()[l+28>>>2>>>0]=n}var an=n=>n%4==0&&(n%100!=0||n%400==0),nn=[0,31,60,91,121,152,182,213,244,274,305,335],sn=[0,31,59,90,120,151,181,212,243,273,304,334];function Hl(n,l){n=-9007199254740992>n||9007199254740992<n?NaN:Number(n),l>>>=0,n=new Date(1e3*n),R()[l>>>2>>>0]=n.getSeconds(),R()[l+4>>>2>>>0]=n.getMinutes(),R()[l+8>>>2>>>0]=n.getHours(),R()[l+12>>>2>>>0]=n.getDate(),R()[l+16>>>2>>>0]=n.getMonth(),R()[l+20>>>2>>>0]=n.getFullYear()-1900,R()[l+24>>>2>>>0]=n.getDay();var c=(an(n.getFullYear())?nn:sn)[n.getMonth()]+n.getDate()-1|0;R()[l+28>>>2>>>0]=c,R()[l+36>>>2>>>0]=-60*n.getTimezoneOffset(),c=new Date(n.getFullYear(),6,1).getTimezoneOffset();var h=new Date(n.getFullYear(),0,1).getTimezoneOffset();n=0|(c!=h&&n.getTimezoneOffset()==Math.min(h,c)),R()[l+32>>>2>>>0]=n}function Kl(n){n>>>=0;var l=new Date(R()[n+20>>>2>>>0]+1900,R()[n+16>>>2>>>0],R()[n+12>>>2>>>0],R()[n+8>>>2>>>0],R()[n+4>>>2>>>0],R()[n>>>2>>>0],0),c=R()[n+32>>>2>>>0],h=l.getTimezoneOffset(),y=new Date(l.getFullYear(),6,1).getTimezoneOffset(),x=new Date(l.getFullYear(),0,1).getTimezoneOffset(),T=Math.min(x,y);return 0>c?R()[n+32>>>2>>>0]=+(y!=x&&T==h):0<c!=(T==h)&&(y=Math.max(x,y),l.setTime(l.getTime()+6e4*((0<c?T:y)-h))),R()[n+24>>>2>>>0]=l.getDay(),c=(an(l.getFullYear())?nn:sn)[l.getMonth()]+l.getDate()-1|0,R()[n+28>>>2>>>0]=c,R()[n>>>2>>>0]=l.getSeconds(),R()[n+4>>>2>>>0]=l.getMinutes(),R()[n+8>>>2>>>0]=l.getHours(),R()[n+12>>>2>>>0]=l.getDate(),R()[n+16>>>2>>>0]=l.getMonth(),R()[n+20>>>2>>>0]=l.getYear(),n=l.getTime(),BigInt(isNaN(n)?-1:n/1e3)}function on(n,l,c,h,y,x,T){return u?xe(16,1,n,l,c,h,y,x,T):-52}function un(n,l,c,h,y,x){if(u)return xe(17,1,n,l,c,h,y,x)}var Qt={},Zl=()=>performance.timeOrigin+performance.now();function ln(n,l){if(u)return xe(18,1,n,l);if(Qt[n]&&(clearTimeout(Qt[n].id),delete Qt[n]),!l)return 0;var c=setTimeout(()=>{delete Qt[n],fi(()=>Sn(n,performance.timeOrigin+performance.now()))},l);return Qt[n]={id:c,ke:l},0}function Ql(n,l,c,h){n>>>=0,l>>>=0,c>>>=0,h>>>=0;var y=new Date().getFullYear(),x=new Date(y,0,1).getTimezoneOffset();y=new Date(y,6,1).getTimezoneOffset();var T=Math.max(x,y);X()[n>>>2>>>0]=60*T,R()[l>>>2>>>0]=+(x!=y),n=(l=A=>{var O=Math.abs(A);return`UTC${0<=A?"-":"+"}${String(Math.floor(O/60)).padStart(2,"0")}${String(O%60).padStart(2,"0")}`})(x),l=l(y),y<x?(Ot(n,c,17),Ot(l,h,17)):(Ot(n,h,17),Ot(l,c,17))}var Xl=()=>Date.now(),Jl=1;function Yl(n,l,c){if(!(0<=n&&3>=n))return 28;if(n===0)n=Date.now();else{if(!Jl)return 52;n=performance.timeOrigin+performance.now()}return D[c>>>0>>>3]=BigInt(Math.round(1e6*n)),0}var _i=[],dn=(n,l)=>{_i.length=0;for(var c;c=de()[n++>>>0];){var h=c!=105;l+=(h&=c!=112)&&l%8?4:0,_i.push(c==112?X()[l>>>2>>>0]:c==106?D[l>>>3]:c==105?R()[l>>>2>>>0]:Fe()[l>>>3>>>0]),l+=h?8:4}return _i};function ed(n,l,c){return n>>>=0,l=dn(l>>>0,c>>>0),ri[n](...l)}function td(n,l,c){return n>>>=0,l=dn(l>>>0,c>>>0),ri[n](...l)}var rd=()=>{};function id(n,l){return w(Oe(n>>>0,l>>>0))}var ad=()=>{throw mt+=1,"unwind"};function nd(){return 4294901760}var sd=()=>navigator.hardwareConcurrency;function od(){return st("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"),0}function ud(n){n>>>=0;var l=de().length;if(n<=l||4294901760<n)return!1;for(var c=1;4>=c;c*=2){var h=l*(1+.2/c);h=Math.min(h,n+100663296);e:{h=(Math.min(4294901760,65536*Math.ceil(Math.max(n,h)/65536))-S.buffer.byteLength+65535)/65536|0;try{S.grow(h),Ge();var y=1;break e}catch{}y=void 0}if(y)return!0}return!1}var Or=()=>(st("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"),0),Rt={},pn=n=>{n.forEach(l=>{var c=Or();c&&(Rt[c]=l)})};function ld(){var n=Error().stack.toString().split(`
`);return n[0]=="Error"&&n.shift(),pn(n),Rt.Kd=Or(),Rt.ae=n,Rt.Kd}function dd(n,l,c){if(n>>>=0,l>>>=0,Rt.Kd==n)var h=Rt.ae;else(h=Error().stack.toString().split(`
`))[0]=="Error"&&h.shift(),pn(h);for(var y=3;h[y]&&Or()!=n;)++y;for(n=0;n<c&&h[n+y];++n)R()[l+4*n>>>2>>>0]=Or();return n}var vi,wi={},cn=()=>{if(!vi){var n,l={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",_:"./this.program"};for(n in wi)wi[n]===void 0?delete l[n]:l[n]=wi[n];var c=[];for(n in l)c.push(`${n}=${l[n]}`);vi=c}return vi};function hn(n,l){if(u)return xe(19,1,n,l);n>>>=0,l>>>=0;var c=0;return cn().forEach((h,y)=>{var x=l+c;for(y=X()[n+4*y>>>2>>>0]=x,x=0;x<h.length;++x)H()[y++>>>0]=h.charCodeAt(x);H()[y>>>0]=0,c+=h.length+1}),0}function fn(n,l){if(u)return xe(20,1,n,l);n>>>=0,l>>>=0;var c=cn();X()[n>>>2>>>0]=c.length;var h=0;return c.forEach(y=>h+=y.length+1),X()[l>>>2>>>0]=h,0}function mn(n){return u?xe(21,1,n):52}function gn(n,l,c,h){return u?xe(22,1,n,l,c,h):52}function yn(n,l,c,h){return u?xe(23,1,n,l,c,h):70}var pd=[null,[],[]];function _n(n,l,c,h){if(u)return xe(24,1,n,l,c,h);l>>>=0,c>>>=0,h>>>=0;for(var y=0,x=0;x<c;x++){var T=X()[l>>>2>>>0],A=X()[l+4>>>2>>>0];l+=8;for(var O=0;O<A;O++){var P=de()[T+O>>>0],j=pd[n];P===0||P===10?((n===1?$:w)(Oa(j)),j.length=0):j.push(P)}y+=A}return X()[h>>>2>>>0]=y,0}function cd(n){return n>>>0}u||function(){for(var n=i.numThreads-1;n--;)Ia();ai.unshift(()=>{Ht++,function(l){u?l():Promise.all(gt.map(Ca)).then(l)}(()=>va())})}();for(var vn=Array(256),Rr=0;256>Rr;++Rr)vn[Rr]=String.fromCharCode(Rr);Ha=vn,yt=i.BindingError=class extends Error{constructor(n){super(n),this.name="BindingError"}},i.InternalError=class extends Error{constructor(n){super(n),this.name="InternalError"}},ut.push(0,1,void 0,1,null,1,!0,1,!1,1),i.count_emval_handles=()=>ut.length/2-5-pi.length;var N,hd=[ni,xa,Ea,Ra,Ba,Ma,Da,Pa,Ua,Wa,Va,qa,ja,La,Ga,Fa,on,un,ln,hn,fn,mn,gn,yn,_n];(async function(){function n(h,y){return N=h.exports,N=function(){var x=N,T={};for(let[A,O]of Object.entries(x))T[A]=typeof O=="function"?(...P)=>{Er.push(A);try{return O(...P)}finally{oe||(Er.pop(),it&&vt===1&&Er.length===0&&(vt=0,mt+=1,Ir(xs),typeof Fibers<"u"&&Fibers.le()))}}:O;return T}(),N=function(){var x=N,T=O=>P=>O(P)>>>0,A=O=>()=>O()>>>0;return(x=Object.assign({},x)).Cb=T(x.Cb),x.fc=A(x.fc),x.ic=T(x.ic),x.vc=T(x.vc),x.wc=A(x.wc),x.Ac=T(x.Ac),x}(),ka.push(N.jc),C=y,va(),N}Ht++;var l=wa();if(i.instantiateWasm)return new Promise(h=>{i.instantiateWasm(l,(y,x)=>{n(y,x),h(y.exports)})});if(u)return new Promise(h=>{Ae=y=>{var x=new WebAssembly.Instance(y,wa());h(n(x,y))}});ti??(ti=i.locateFile?i.locateFile?i.locateFile("ort-wasm-simd-threaded.jsep.wasm",_):_+"ort-wasm-simd-threaded.jsep.wasm":new URL("ort-wasm-simd-threaded.jsep.wasm",br.url).href);try{var c=await async function(h){var y=ti;if(!F&&typeof WebAssembly.instantiateStreaming=="function"&&!le(y))try{var x=fetch(y,{credentials:"same-origin"});return await WebAssembly.instantiateStreaming(x,h)}catch(T){w(`wasm streaming compile failed: ${T}`),w("falling back to ArrayBuffer instantiation")}return async function(T,A){try{var O=await async function(P){if(!F)try{var j=await m(P);return new Uint8Array(j)}catch{}if(P==ti&&F)P=new Uint8Array(F);else{if(!f)throw"both async and sync fetching of the wasm failed";P=f(P)}return P}(T);return await WebAssembly.instantiate(O,A)}catch(P){w(`failed to asynchronously prepare wasm: ${P}`),st(P)}}(y,h)}(l);return n(c.instance,c.module)}catch(h){return r(h),Promise.reject(h)}})();var wn=n=>(wn=N.Cb)(n),bn=()=>(bn=N.Db)();i._OrtInit=(n,l)=>(i._OrtInit=N.Eb)(n,l),i._OrtGetLastError=(n,l)=>(i._OrtGetLastError=N.Fb)(n,l),i._OrtCreateSessionOptions=(n,l,c,h,y,x,T,A,O,P)=>(i._OrtCreateSessionOptions=N.Gb)(n,l,c,h,y,x,T,A,O,P),i._OrtAppendExecutionProvider=(n,l)=>(i._OrtAppendExecutionProvider=N.Hb)(n,l),i._OrtAddFreeDimensionOverride=(n,l,c)=>(i._OrtAddFreeDimensionOverride=N.Ib)(n,l,c),i._OrtAddSessionConfigEntry=(n,l,c)=>(i._OrtAddSessionConfigEntry=N.Jb)(n,l,c),i._OrtReleaseSessionOptions=n=>(i._OrtReleaseSessionOptions=N.Kb)(n),i._OrtCreateSession=(n,l,c)=>(i._OrtCreateSession=N.Lb)(n,l,c),i._OrtReleaseSession=n=>(i._OrtReleaseSession=N.Mb)(n),i._OrtGetInputOutputCount=(n,l,c)=>(i._OrtGetInputOutputCount=N.Nb)(n,l,c),i._OrtGetInputName=(n,l)=>(i._OrtGetInputName=N.Ob)(n,l),i._OrtGetOutputName=(n,l)=>(i._OrtGetOutputName=N.Pb)(n,l),i._OrtFree=n=>(i._OrtFree=N.Qb)(n),i._OrtCreateTensor=(n,l,c,h,y,x)=>(i._OrtCreateTensor=N.Rb)(n,l,c,h,y,x),i._OrtGetTensorData=(n,l,c,h,y)=>(i._OrtGetTensorData=N.Sb)(n,l,c,h,y),i._OrtReleaseTensor=n=>(i._OrtReleaseTensor=N.Tb)(n),i._OrtCreateRunOptions=(n,l,c,h)=>(i._OrtCreateRunOptions=N.Ub)(n,l,c,h),i._OrtAddRunConfigEntry=(n,l,c)=>(i._OrtAddRunConfigEntry=N.Vb)(n,l,c),i._OrtReleaseRunOptions=n=>(i._OrtReleaseRunOptions=N.Wb)(n),i._OrtCreateBinding=n=>(i._OrtCreateBinding=N.Xb)(n),i._OrtBindInput=(n,l,c)=>(i._OrtBindInput=N.Yb)(n,l,c),i._OrtBindOutput=(n,l,c,h)=>(i._OrtBindOutput=N.Zb)(n,l,c,h),i._OrtClearBoundOutputs=n=>(i._OrtClearBoundOutputs=N._b)(n),i._OrtReleaseBinding=n=>(i._OrtReleaseBinding=N.$b)(n),i._OrtRunWithBinding=(n,l,c,h,y)=>(i._OrtRunWithBinding=N.ac)(n,l,c,h,y),i._OrtRun=(n,l,c,h,y,x,T,A)=>(i._OrtRun=N.bc)(n,l,c,h,y,x,T,A),i._OrtEndProfiling=n=>(i._OrtEndProfiling=N.cc)(n),i._JsepOutput=(n,l,c)=>(i._JsepOutput=N.dc)(n,l,c),i._JsepGetNodeName=n=>(i._JsepGetNodeName=N.ec)(n);var Br=()=>(Br=N.fc)(),at=i._free=n=>(at=i._free=N.gc)(n),Nr=i._malloc=n=>(Nr=i._malloc=N.ic)(n),bi=(n,l,c,h,y,x)=>(bi=N.kc)(n,l,c,h,y,x),$n=()=>($n=N.lc)(),xn=(n,l,c,h,y)=>(xn=N.mc)(n,l,c,h,y),kn=n=>(kn=N.nc)(n),$i=n=>($i=N.oc)(n),Sn=(n,l)=>(Sn=N.pc)(n,l),Tn=()=>(Tn=N.qc)(),ie=(n,l)=>(ie=N.rc)(n,l),Xt=n=>(Xt=N.sc)(n),Cn=(n,l)=>(Cn=N.tc)(n,l),Y=n=>(Y=N.uc)(n),xi=n=>(xi=N.vc)(n),re=()=>(re=N.wc)(),In=n=>(In=N.xc)(n),En=n=>(En=N.yc)(n),zn=(n,l,c)=>(zn=N.zc)(n,l,c),An=n=>(An=N.Ac)(n),On=i.dynCall_iii=(n,l,c)=>(On=i.dynCall_iii=N.Bc)(n,l,c),Rn=i.dynCall_vi=(n,l)=>(Rn=i.dynCall_vi=N.Cc)(n,l),ki=i.dynCall_ii=(n,l)=>(ki=i.dynCall_ii=N.Dc)(n,l),Bn=i.dynCall_vii=(n,l,c)=>(Bn=i.dynCall_vii=N.Ec)(n,l,c),Nn=i.dynCall_iiii=(n,l,c,h)=>(Nn=i.dynCall_iiii=N.Fc)(n,l,c,h),Mn=i.dynCall_viii=(n,l,c,h)=>(Mn=i.dynCall_viii=N.Gc)(n,l,c,h),Dn=i.dynCall_iiiii=(n,l,c,h,y)=>(Dn=i.dynCall_iiiii=N.Hc)(n,l,c,h,y),Pn=i.dynCall_viiii=(n,l,c,h,y)=>(Pn=i.dynCall_viiii=N.Ic)(n,l,c,h,y),Un=i.dynCall_viiiiii=(n,l,c,h,y,x,T)=>(Un=i.dynCall_viiiiii=N.Jc)(n,l,c,h,y,x,T),Wn=i.dynCall_viiiiiii=(n,l,c,h,y,x,T,A)=>(Wn=i.dynCall_viiiiiii=N.Kc)(n,l,c,h,y,x,T,A),Vn=i.dynCall_ji=(n,l)=>(Vn=i.dynCall_ji=N.Lc)(n,l),qn=i.dynCall_v=n=>(qn=i.dynCall_v=N.Mc)(n),jn=i.dynCall_viiiii=(n,l,c,h,y,x)=>(jn=i.dynCall_viiiii=N.Nc)(n,l,c,h,y,x),Ln=i.dynCall_i=n=>(Ln=i.dynCall_i=N.Oc)(n),Gn=i.dynCall_fii=(n,l,c)=>(Gn=i.dynCall_fii=N.Pc)(n,l,c),Fn=i.dynCall_viiiiiiii=(n,l,c,h,y,x,T,A,O)=>(Fn=i.dynCall_viiiiiiii=N.Qc)(n,l,c,h,y,x,T,A,O),Hn=i.dynCall_viiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j)=>(Hn=i.dynCall_viiiiiiiiii=N.Rc)(n,l,c,h,y,x,T,A,O,P,j),Kn=i.dynCall_jiii=(n,l,c,h)=>(Kn=i.dynCall_jiii=N.Sc)(n,l,c,h),Zn=i.dynCall_dii=(n,l,c)=>(Zn=i.dynCall_dii=N.Tc)(n,l,c),Qn=i.dynCall_viiiiiiiii=(n,l,c,h,y,x,T,A,O,P)=>(Qn=i.dynCall_viiiiiiiii=N.Uc)(n,l,c,h,y,x,T,A,O,P),Xn=i.dynCall_viiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q)=>(Xn=i.dynCall_viiiiiiiiiii=N.Vc)(n,l,c,h,y,x,T,A,O,P,j,Q),Jn=i.dynCall_iiiiii=(n,l,c,h,y,x)=>(Jn=i.dynCall_iiiiii=N.Wc)(n,l,c,h,y,x),Yn=i.dynCall_iij=(n,l,c)=>(Yn=i.dynCall_iij=N.Xc)(n,l,c),es=i.dynCall_iiiiiiiiii=(n,l,c,h,y,x,T,A,O,P)=>(es=i.dynCall_iiiiiiiiii=N.Yc)(n,l,c,h,y,x,T,A,O,P),ts=i.dynCall_iiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j)=>(ts=i.dynCall_iiiiiiiiiii=N.Zc)(n,l,c,h,y,x,T,A,O,P,j),rs=i.dynCall_vij=(n,l,c)=>(rs=i.dynCall_vij=N._c)(n,l,c),is=i.dynCall_iiif=(n,l,c,h)=>(is=i.dynCall_iiif=N.$c)(n,l,c,h),as=i.dynCall_iiij=(n,l,c,h)=>(as=i.dynCall_iiij=N.ad)(n,l,c,h),ns=i.dynCall_fiii=(n,l,c,h)=>(ns=i.dynCall_fiii=N.bd)(n,l,c,h),ss=i.dynCall_viiiiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)=>(ss=i.dynCall_viiiiiiiiiiiii=N.cd)(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we),os=i.dynCall_vjiii=(n,l,c,h,y)=>(os=i.dynCall_vjiii=N.dd)(n,l,c,h,y),us=i.dynCall_vif=(n,l,c)=>(us=i.dynCall_vif=N.ed)(n,l,c),ls=i.dynCall_iiiiiii=(n,l,c,h,y,x,T)=>(ls=i.dynCall_iiiiiii=N.fd)(n,l,c,h,y,x,T),ds=i.dynCall_iiiij=(n,l,c,h,y)=>(ds=i.dynCall_iiiij=N.gd)(n,l,c,h,y),ps=i.dynCall_iiiiiiii=(n,l,c,h,y,x,T,A)=>(ps=i.dynCall_iiiiiiii=N.hd)(n,l,c,h,y,x,T,A),cs=i.dynCall_viiiiiiiiiiii=(n,l,c,h,y,x,T,A,O,P,j,Q,ae)=>(cs=i.dynCall_viiiiiiiiiiii=N.id)(n,l,c,h,y,x,T,A,O,P,j,Q,ae),hs=i.dynCall_diii=(n,l,c,h)=>(hs=i.dynCall_diii=N.jd)(n,l,c,h),fs=i.dynCall_jiiii=(n,l,c,h,y)=>(fs=i.dynCall_jiiii=N.kd)(n,l,c,h,y),ms=i.dynCall_viiij=(n,l,c,h,y)=>(ms=i.dynCall_viiij=N.ld)(n,l,c,h,y),gs=i.dynCall_fiiii=(n,l,c,h,y)=>(gs=i.dynCall_fiiii=N.md)(n,l,c,h,y),ys=i.dynCall_viiif=(n,l,c,h,y)=>(ys=i.dynCall_viiif=N.nd)(n,l,c,h,y),_s=i.dynCall_diiii=(n,l,c,h,y)=>(_s=i.dynCall_diiii=N.od)(n,l,c,h,y),vs=i.dynCall_viiid=(n,l,c,h,y)=>(vs=i.dynCall_viiid=N.pd)(n,l,c,h,y),ws=i.dynCall_iiiijii=(n,l,c,h,y,x,T)=>(ws=i.dynCall_iiiijii=N.qd)(n,l,c,h,y,x,T),bs=i.dynCall_iiiiiij=(n,l,c,h,y,x,T)=>(bs=i.dynCall_iiiiiij=N.rd)(n,l,c,h,y,x,T),$s=n=>($s=N.sd)(n),xs=()=>(xs=N.td)(),ks=n=>(ks=N.ud)(n),Ss=()=>(Ss=N.vd)();function fd(n,l,c){var h=re();try{Bn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function md(n,l,c){var h=re();try{return On(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function gd(n,l){var c=re();try{Rn(n,l)}catch(h){if(Y(c),h!==h+0)throw h;ie(1,0)}}function yd(n,l){var c=re();try{return ki(n,l)}catch(h){if(Y(c),h!==h+0)throw h;ie(1,0)}}function _d(n,l,c,h){var y=re();try{return Nn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function vd(n,l,c,h,y){var x=re();try{Pn(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function wd(n,l,c,h,y){var x=re();try{return Dn(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function bd(n,l,c,h){var y=re();try{Mn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function $d(n,l,c,h,y,x,T){var A=re();try{return ls(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function xd(n){var l=re();try{qn(n)}catch(c){if(Y(l),c!==c+0)throw c;ie(1,0)}}function kd(n,l,c){var h=re();try{return Yn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Sd(n,l,c,h,y,x){var T=re();try{jn(n,l,c,h,y,x)}catch(A){if(Y(T),A!==A+0)throw A;ie(1,0)}}function Td(n,l,c){var h=re();try{rs(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Cd(n,l,c,h,y,x,T){var A=re();try{Un(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function Id(n,l,c,h,y,x,T,A){var O=re();try{Wn(n,l,c,h,y,x,T,A)}catch(P){if(Y(O),P!==P+0)throw P;ie(1,0)}}function Ed(n,l,c,h,y,x){var T=re();try{return Jn(n,l,c,h,y,x)}catch(A){if(Y(T),A!==A+0)throw A;ie(1,0)}}function zd(n,l,c,h,y,x,T,A){var O=re();try{return ps(n,l,c,h,y,x,T,A)}catch(P){if(Y(O),P!==P+0)throw P;ie(1,0)}}function Ad(n,l,c,h,y,x,T,A,O,P){var j=re();try{Qn(n,l,c,h,y,x,T,A,O,P)}catch(Q){if(Y(j),Q!==Q+0)throw Q;ie(1,0)}}function Od(n,l,c,h,y,x,T,A,O){var P=re();try{Fn(n,l,c,h,y,x,T,A,O)}catch(j){if(Y(P),j!==j+0)throw j;ie(1,0)}}function Rd(n){var l=re();try{return Ln(n)}catch(c){if(Y(l),c!==c+0)throw c;ie(1,0)}}function Bd(n,l,c,h,y,x,T,A,O,P){var j=re();try{return es(n,l,c,h,y,x,T,A,O,P)}catch(Q){if(Y(j),Q!==Q+0)throw Q;ie(1,0)}}function Nd(n,l,c){var h=re();try{return Gn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Md(n,l,c,h){var y=re();try{return Kn(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;return ie(1,0),0n}}function Dd(n,l,c){var h=re();try{return Zn(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Pd(n,l,c,h,y,x,T,A,O,P,j,Q){var ae=re();try{Xn(n,l,c,h,y,x,T,A,O,P,j,Q)}catch(we){if(Y(ae),we!==we+0)throw we;ie(1,0)}}function Ud(n,l,c,h,y,x,T,A,O,P,j){var Q=re();try{Hn(n,l,c,h,y,x,T,A,O,P,j)}catch(ae){if(Y(Q),ae!==ae+0)throw ae;ie(1,0)}}function Wd(n,l,c,h,y,x,T,A,O,P,j){var Q=re();try{return ts(n,l,c,h,y,x,T,A,O,P,j)}catch(ae){if(Y(Q),ae!==ae+0)throw ae;ie(1,0)}}function Vd(n,l,c,h){var y=re();try{return is(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function qd(n,l,c,h){var y=re();try{return as(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function jd(n,l,c,h){var y=re();try{return ns(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function Ld(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we){var Xe=re();try{ss(n,l,c,h,y,x,T,A,O,P,j,Q,ae,we)}catch(Jt){if(Y(Xe),Jt!==Jt+0)throw Jt;ie(1,0)}}function Gd(n,l,c,h,y){var x=re();try{os(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Fd(n,l,c){var h=re();try{us(n,l,c)}catch(y){if(Y(h),y!==y+0)throw y;ie(1,0)}}function Hd(n,l){var c=re();try{return Vn(n,l)}catch(h){if(Y(c),h!==h+0)throw h;return ie(1,0),0n}}function Kd(n,l,c,h,y){var x=re();try{return ds(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Zd(n,l,c,h,y,x,T,A,O,P,j,Q,ae){var we=re();try{cs(n,l,c,h,y,x,T,A,O,P,j,Q,ae)}catch(Xe){if(Y(we),Xe!==Xe+0)throw Xe;ie(1,0)}}function Qd(n,l,c,h){var y=re();try{return hs(n,l,c,h)}catch(x){if(Y(y),x!==x+0)throw x;ie(1,0)}}function Xd(n,l,c,h,y){var x=re();try{return fs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;return ie(1,0),0n}}function Jd(n,l,c,h,y){var x=re();try{ms(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function Yd(n,l,c,h,y){var x=re();try{return gs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function ep(n,l,c,h,y){var x=re();try{ys(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function tp(n,l,c,h,y){var x=re();try{return _s(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function rp(n,l,c,h,y){var x=re();try{vs(n,l,c,h,y)}catch(T){if(Y(x),T!==T+0)throw T;ie(1,0)}}function ip(n,l,c,h,y,x,T){var A=re();try{return ws(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}function ap(n,l,c,h,y,x,T){var A=re();try{return bs(n,l,c,h,y,x,T)}catch(O){if(Y(A),O!==O+0)throw O;ie(1,0)}}return i.stackSave=()=>re(),i.stackRestore=n=>Y(n),i.stackAlloc=n=>xi(n),i.setValue=function(n,l,c="i8"){switch(c.endsWith("*")&&(c="*"),c){case"i1":case"i8":H()[n>>>0]=l;break;case"i16":M()[n>>>1>>>0]=l;break;case"i32":R()[n>>>2>>>0]=l;break;case"i64":D[n>>>3]=BigInt(l);break;case"float":Ie()[n>>>2>>>0]=l;break;case"double":Fe()[n>>>3>>>0]=l;break;case"*":X()[n>>>2>>>0]=l;break;default:st(`invalid type for setValue: ${c}`)}},i.getValue=function(n,l="i8"){switch(l.endsWith("*")&&(l="*"),l){case"i1":case"i8":return H()[n>>>0];case"i16":return M()[n>>>1>>>0];case"i32":return R()[n>>>2>>>0];case"i64":return D[n>>>3];case"float":return Ie()[n>>>2>>>0];case"double":return Fe()[n>>>3>>>0];case"*":return X()[n>>>2>>>0];default:st(`invalid type for getValue: ${l}`)}},i.UTF8ToString=Oe,i.stringToUTF8=Ot,i.lengthBytesUTF8=Na,function n(){if(0<Ht)Kt=n;else if(u)t(i),kr();else{for(;0<ai.length;)ai.shift()(i);0<Ht?Kt=n:(i.calledRun=!0,oe||(kr(),t(i)))}}(),i.PTR_SIZE=4,a}),fx=Xc,mb=globalThis.self?.name?.startsWith("em-pthread"),mb&&Xc()}),nf=te(()=>{"use strict";af(),Jc=typeof location>"u"?void 0:location.origin,gb=()=>br.url?.startsWith("file:")?new URL(new URL("ort.bundle.min.mjs",br.url).href,Jc).href:br.url,Dt=gb(),mx=()=>{if(Dt&&!Dt.startsWith("blob:"))return Dt.substring(0,Dt.lastIndexOf("/")+1)},ru=(e,t)=>{try{let r=t??Dt;return(r?new URL(e,r):new URL(e)).origin===Jc}catch{return!1}},yb=(e,t)=>{let r=t??Dt;try{return(r?new URL(e,r):new URL(e)).href}catch{return}},_b=(e,t)=>`${t??"./"}${e}`,Yc=async e=>{let t=await(await fetch(e,{credentials:"same-origin"})).blob();return URL.createObjectURL(t)},vb=async e=>(await import(e)).default,eh=(sI(),yu(px)).default,gx=async()=>{if(!Dt)throw new Error("Failed to load proxy worker: cannot determine the script source URL.");if(ru(Dt))return[void 0,eh()];let e=await Yc(Dt);return[e,eh(e)]},th=(oI(),yu(hx)).default,yx=async(e,t,r)=>{if(!e&&!t&&th&&Dt&&ru(Dt))return[void 0,th];{let i="ort-wasm-simd-threaded.jsep.mjs",a=e??yb(i,t),s=r&&a&&!ru(a,t),o=s?await Yc(a):a??_b(i,t);return[s?o:void 0,await vb(o)]}}}),Zi=te(()=>{"use strict";nf(),iu=!1,Ls=!1,ih=!1,wb=()=>{if(typeof SharedArrayBuffer>"u")return!1;try{return typeof MessageChannel<"u"&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}},bb=()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}},sf=async e=>{if(iu)return Promise.resolve();if(Ls)throw new Error("multiple calls to 'initializeWebAssembly()' detected.");if(ih)throw new Error("previous call to 'initializeWebAssembly()' failed.");Ls=!0;let t=e.initTimeout,r=e.numThreads;if(!bb())throw new Error("WebAssembly SIMD is not supported in the current environment.");let i=wb();r>1&&!i&&(typeof self<"u"&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let a=e.wasmPaths,s=typeof a=="string"?a:void 0,o=a?.mjs,u=o?.href??o,d=a?.wasm,p=d?.href??d,m=e.wasmBinary,[f,g]=await yx(u,s,r>1),v=!1,_=[];if(t>0&&_.push(new Promise(b=>{setTimeout(()=>{v=!0,b()},t)})),_.push(new Promise((b,k)=>{let $={numThreads:r};if(m)$.wasmBinary=m;else if(p||s)$.locateFile=w=>p??s+w;else if(u&&u.indexOf("blob:")!==0)$.locateFile=w=>new URL(w,u).href;else if(f){let w=mx();w&&($.locateFile=S=>w+S)}g($).then(w=>{Ls=!1,iu=!0,rh=w,b(),f&&URL.revokeObjectURL(f)},w=>{Ls=!1,ih=!0,k(w)})})),await Promise.race(_),v)throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},pt=()=>{if(iu&&rh)return rh;throw new Error("WebAssembly is not initialized yet.")}}),of=te(()=>{"use strict";Zi(),bt=(e,t)=>{let r=pt(),i=r.lengthBytesUTF8(e)+1,a=r._malloc(i);return r.stringToUTF8(e,a,i),t.push(a),a},_u=(e,t,r,i)=>{if(typeof e=="object"&&e!==null){if(r.has(e))throw new Error("Circular reference in options");r.add(e)}Object.entries(e).forEach(([a,s])=>{let o=t?t+a:a;if(typeof s=="object")_u(s,o+".",r,i);else if(typeof s=="string"||typeof s=="number")i(o,s.toString());else if(typeof s=="boolean")i(o,s?"1":"0");else throw new Error(`Can't handle extra config type: ${typeof s}`)})},qe=e=>{let t=pt(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetLastError(a,a+i);let s=Number(t.getValue(a,i===4?"i32":"i64")),o=t.getValue(a+i,"*"),u=o?t.UTF8ToString(o):"";throw new Error(`${e} ERROR_CODE: ${s}, ERROR_MESSAGE: ${u}`)}finally{t.stackRestore(r)}}}),uI=te(()=>{"use strict";Zi(),of(),_x=e=>{let t=pt(),r=0,i=[],a=e||{};try{if(e?.logSeverityLevel===void 0)a.logSeverityLevel=2;else if(typeof e.logSeverityLevel!="number"||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw new Error(`log serverity level is not valid: ${e.logSeverityLevel}`);if(e?.logVerbosityLevel===void 0)a.logVerbosityLevel=0;else if(typeof e.logVerbosityLevel!="number"||!Number.isInteger(e.logVerbosityLevel))throw new Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);e?.terminate===void 0&&(a.terminate=!1);let s=0;return e?.tag!==void 0&&(s=bt(e.tag,i)),r=t._OrtCreateRunOptions(a.logSeverityLevel,a.logVerbosityLevel,!!a.terminate,s),r===0&&qe("Can't create run options."),e?.extra!==void 0&&_u(e.extra,"",new WeakSet,(o,u)=>{let d=bt(o,i),p=bt(u,i);t._OrtAddRunConfigEntry(r,d,p)!==0&&qe(`Can't set a run config entry: ${o} - ${u}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseRunOptions(r),i.forEach(o=>t._free(o)),s}}}),lI=te(()=>{"use strict";Zi(),of(),$b=e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"all":return 99;default:throw new Error(`unsupported graph optimization level: ${e}`)}},xb=e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw new Error(`unsupported execution mode: ${e}`)}},kb=e=>{e.extra||(e.extra={}),e.extra.session||(e.extra.session={});let t=e.extra.session;t.use_ort_model_bytes_directly||(t.use_ort_model_bytes_directly="1"),e.executionProviders&&e.executionProviders.some(r=>(typeof r=="string"?r:r.name)==="webgpu")&&(e.enableMemPattern=!1)},Sb=(e,t,r)=>{for(let i of t){let a=typeof i=="string"?i:i.name;switch(a){case"webnn":if(a="WEBNN",typeof i!="string"){let o=i?.deviceType;if(o){let u=bt("deviceType",r),d=bt(o,r);pt()._OrtAddSessionConfigEntry(e,u,d)!==0&&qe(`Can't set a session config entry: 'deviceType' - ${o}.`)}}break;case"webgpu":if(a="JS",typeof i!="string"){let o=i;if(o?.preferredLayout){if(o.preferredLayout!=="NCHW"&&o.preferredLayout!=="NHWC")throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${o.preferredLayout}`);let u=bt("preferredLayout",r),d=bt(o.preferredLayout,r);pt()._OrtAddSessionConfigEntry(e,u,d)!==0&&qe(`Can't set a session config entry: 'preferredLayout' - ${o.preferredLayout}.`)}}break;case"wasm":case"cpu":continue;default:throw new Error(`not supported execution provider: ${a}`)}let s=bt(a,r);pt()._OrtAppendExecutionProvider(e,s)!==0&&qe(`Can't append execution provider: ${a}.`)}},vx=e=>{let t=pt(),r=0,i=[],a=e||{};kb(a);try{let s=$b(a.graphOptimizationLevel??"all"),o=xb(a.executionMode??"sequential"),u=typeof a.logId=="string"?bt(a.logId,i):0,d=a.logSeverityLevel??2;if(!Number.isInteger(d)||d<0||d>4)throw new Error(`log serverity level is not valid: ${d}`);let p=a.logVerbosityLevel??0;if(!Number.isInteger(p)||p<0||p>4)throw new Error(`log verbosity level is not valid: ${p}`);let m=typeof a.optimizedModelFilePath=="string"?bt(a.optimizedModelFilePath,i):0;if(r=t._OrtCreateSessionOptions(s,!!a.enableCpuMemArena,!!a.enableMemPattern,o,!!a.enableProfiling,0,u,d,p,m),r===0&&qe("Can't create session options."),a.executionProviders&&Sb(r,a.executionProviders,i),a.enableGraphCapture!==void 0){if(typeof a.enableGraphCapture!="boolean")throw new Error(`enableGraphCapture must be a boolean value: ${a.enableGraphCapture}`);let f=bt("enableGraphCapture",i),g=bt(a.enableGraphCapture.toString(),i);t._OrtAddSessionConfigEntry(r,f,g)!==0&&qe(`Can't set a session config entry: 'enableGraphCapture' - ${a.enableGraphCapture}.`)}if(a.freeDimensionOverrides)for(let[f,g]of Object.entries(a.freeDimensionOverrides)){if(typeof f!="string")throw new Error(`free dimension override name must be a string: ${f}`);if(typeof g!="number"||!Number.isInteger(g)||g<0)throw new Error(`free dimension override value must be a non-negative integer: ${g}`);let v=bt(f,i);t._OrtAddFreeDimensionOverride(r,v,g)!==0&&qe(`Can't set a free dimension override: ${f} - ${g}.`)}return a.extra!==void 0&&_u(a.extra,"",new WeakSet,(f,g)=>{let v=bt(f,i),_=bt(g,i);t._OrtAddSessionConfigEntry(r,v,_)!==0&&qe(`Can't set a session config entry: ${f} - ${g}.`)}),[r,i]}catch(s){throw r!==0&&t._OrtReleaseSessionOptions(r)!==0&&qe("Can't release session options."),i.forEach(o=>t._free(o)),s}}}),$e=te(()=>{"use strict";sa=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw new Error(`unsupported data type: ${e}`)}},ji=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw new Error(`unsupported data type: ${e}`)}},Li=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],i=typeof t=="number"?t:t.reduce((a,s)=>a*s,1);return r>0?Math.ceil(i*r):void 0},uf=e=>{switch(e){case"float16":return typeof Float16Array<"u"&&Float16Array.from?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"bool":return Uint8Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw new Error(`unsupported type: ${e}`)}},vu=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw new Error(`unsupported logging level: ${e}`)}},lf=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",df=e=>e==="float32"||e==="float16"||e==="int32"||e==="int64"||e==="uint32"||e==="uint64"||e==="int8"||e==="uint8"||e==="bool"||e==="uint4"||e==="int4",Wh=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw new Error(`unsupported data location: ${e}`)}}}),wx=te(()=>{"use strict";af(),pf=async e=>{if(typeof e=="string")if(0)try{}catch(t){}else{let t=await fetch(e);if(!t.ok)throw new Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),i=r?parseInt(r,10):0;if(i<1073741824)return new Uint8Array(await t.arrayBuffer());{if(!t.body)throw new Error(`failed to load external data file: ${e}, no response body.`);let a=t.body.getReader(),s;try{s=new ArrayBuffer(i)}catch(u){if(u instanceof RangeError){let d=Math.ceil(i/65536);s=new WebAssembly.Memory({initial:d,maximum:d}).buffer}else throw u}let o=0;for(;;){let{done:u,value:d}=await a.read();if(u)break;let p=d.byteLength;new Uint8Array(s,o,p).set(d),o+=p}return new Uint8Array(s,0,i)}}else return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e)}}),Ur=te(()=>{"use strict";$e(),Tb=["V","I","W","E","F"],Cb=(e,t)=>{console.log(`[${Tb[e]},${new Date().toISOString()}]${t}`)},cf=(e,t)=>{Ib=e,Eb=t},zb=(e,t)=>{let r=vu(e),i=vu(Ib);r>=i&&Cb(r,typeof t=="function"?t():t)},Me=(...e)=>{Eb&&zb(...e)}}),bx=te(()=>{"use strict";$e(),hf=(e,t)=>new(uf(t))(e)}),ff=te(()=>{"use strict"}),dI=te(()=>{"use strict";Ur(),ff(),ah=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[12582912,10],[16777216,10],[26214400,15],[33554432,22],[44236800,2],[58982400,6],[67108864,6],[134217728,6],[167772160,6]]),au=[],nu=e=>Math.ceil(Number(e)/16)*16,Ab=e=>{for(let t=0;t<au.length;t++){let r=au[t];if(e<=r)return r}return Math.ceil(e/16)*16},Ob=1,nh=()=>Ob++,Vh=async(e,t,r,i)=>{let a=nu(r),s=e.device.createBuffer({size:a,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let o=e.getCommandEncoder();e.endComputePass(),o.copyBufferToBuffer(t,0,s,0,a),e.flush(),await s.mapAsync(GPUMapMode.READ);let u=s.getMappedRange();if(i){let d=i();return d.set(new Uint8Array(u,0,r)),d}else return new Uint8Array(u.slice(0,r))}finally{s.destroy()}},Rb=class{constructor(e){this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersPending=[],this.capturedPendingBuffers=new Map;for(let[t]of ah)au.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[]);this.sessionCount=0}upload(e,t){let r=t.buffer,i=t.byteOffset,a=t.byteLength,s=nu(a),o=this.storageCache.get(e);if(!o)throw new Error("gpu data for uploading does not exist");if(Number(o.originalSize)!==a)throw new Error(`inconsistent data size. gpu data size=${o.originalSize}, data size=${a}`);let u=this.backend.device.createBuffer({mappedAtCreation:!0,size:s,usage:GPUBufferUsage.MAP_WRITE|GPUBufferUsage.COPY_SRC}),d=u.getMappedRange();new Uint8Array(d).set(new Uint8Array(r,i,a)),u.unmap();let p=this.backend.device.createCommandEncoder();p.copyBufferToBuffer(u,0,o.gpuData.buffer,0,s),this.backend.device.queue.submit([p.finish()]),u.destroy(),Me("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw new Error("source gpu data for memcpy does not exist");let i=this.storageCache.get(t);if(!i)throw new Error("destination gpu data for memcpy does not exist");if(r.originalSize!==i.originalSize)throw new Error("inconsistent source and destination gpu data size");let a=nu(r.originalSize),s=this.backend.getCommandEncoder();this.backend.endComputePass(),s.copyBufferToBuffer(r.gpuData.buffer,0,i.gpuData.buffer,0,a)}registerExternalBuffer(e,t,r){let i;if(r){if(i=r[0],e===r[1])return Me("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, buffer is the same, skip.`),i;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw new Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else i=nh();return this.storageCache.set(i,{gpuData:{id:i,type:0,buffer:e},originalSize:t}),Me("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, registered.`),i}unregisterExternalBuffer(e){e!==void 0&&(this.storageCache.delete(e),Me("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r=Ab(e),i,a=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,s=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(a||s){let u=(a?this.freeBuffers:this.freeUniformBuffers).get(r);u?u.length>0?i=u.pop():i=this.backend.device.createBuffer({size:r,usage:t}):i=this.backend.device.createBuffer({size:r,usage:t})}else i=this.backend.device.createBuffer({size:r,usage:t});let o={id:nh(),type:0,buffer:i};return this.storageCache.set(o.id,{gpuData:o,originalSize:Number(e)}),Me("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${o.id}`),o}get(e){return this.storageCache.get(e)?.gpuData}release(e){let t=typeof e=="bigint"?Number(e):e,r=this.storageCache.get(t);if(!r){if(this.storageCache.size===0)return 0;throw new Error("releasing data does not exist")}return Me("verbose",()=>`[WebGPU] GpuDataManager.release(id=${t}), gpuDataId=${r.gpuData.id}`),this.storageCache.delete(t),this.buffersPending.push(r.gpuData.buffer),r.originalSize}async download(e,t){let r=this.storageCache.get(Number(e));if(!r)throw new Error("data does not exist");await Vh(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){if(this.buffersPending.length!==0)if(this.backend.sessionStatus==="default"){for(let e of this.buffersPending){let t=ah.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];t===void 0||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e));for(let t of this.buffersPending)e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(t=>{t.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onCreateSession(){this.sessionCount+=1}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(r=>{r.destroy()}),this.capturedPendingBuffers.delete(e)),this.sessionCount-=1,this.sessionCount===0&&(Me("warning",()=>"[WebGPU] Clearing webgpu buffer cache"),this.storageCache.forEach(r=>{r.gpuData.buffer.destroy()}),this.storageCache=new Map)}},$x=(...e)=>new Rb(...e)}),tt=te(()=>{"use strict";Bb=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},Le=e=>new Bb(e)}),Ce=te(()=>{"use strict";Nb=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},ua=class{static calcShape(e,t,r=!1){let i=e.length,a=t.length;if(i===0)return t;if(a===0)return e;let s=Math.max(e.length,t.length),o=new Array(s);if(r){if(i<2||a<2)return;let u=Nb.calcMatMulShape([e[i-2],e[i-1]],[t[a-2],t[a-1]]);if(u===void 0)return;[o[s-2],o[s-1]]=u}for(let u=r?3:1;u<=s;u++){let d=i-u<0?1:e[i-u],p=a-u<0?1:t[a-u];if(d!==p&&d>1&&p>1)return;let m=Math.max(d,p);if(d&&p)o[s-u]=Math.max(d,p);else{if(m>1)return;o[s-u]=0}}return o}static isValidBroadcast(e,t){let r=e.length,i=t.length;if(r>i)return!1;for(let a=1;a<=r;a++)if(e[r-a]!==1&&e[r-a]!==t[i-a])return!1;return!0}},G=class mu{static size(t){return mu.getSizeFromDimensionRange(t,0,t.length)}static convertShape(t,r=4){let i=t.length;if(i===0)return[];let a=new Array(i),s=i-1;for(;s>=0;){if(t[s]%r===0){a[s]=t[s]/r;break}if(r%t[s]!==0)throw new Error("cannot convert shape");a[s]=1,r/=t[s],s--}for(s--;s>=0;s--)a[s]=t[s];return a}static sizeFromDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return mu.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw new Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return mu.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(t,r,i){let a=1;for(let s=r;s<i;s++){if(t[s]<0)throw new Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");a*=Number(t[s])}return a}static computeStrides(t){let r=t.length;if(r===0)return[];if(r===1)return[1];let i=new Array(r);i[r-1]=1,i[r-2]=t[r-1];for(let a=r-3;a>=0;--a)i[a]=i[a+1]*t[a+1];return i}static normalizeAxis(t,r){if(t<-r&&t>=r)throw new Error("unsupported axis for this operation.");return t<0?t+r:t}static normalizeAxes(t,r){return t.map(i=>this.normalizeAxis(i,r??t.length))}static sortBasedOnPerm(t,r){return r?r.map(i=>t[i]):t.slice().reverse()}static padShape(t,r){let i=t.length;return t.map((a,s)=>a+r[s]+r[s+i])}static areEqual(t,r){return t.length!==r.length?!1:t.every((i,a)=>i===r[a])}},wu=class Ys{static adjustPoolAttributes(t,r,i,a,s,o){if(!t&&i.length!==r.length-2)throw new Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(t)for(let u=0;u<r.length-2;u++)u>=i.length?i.push(r[u+2]):i[u]=r[u+2];for(let u=0;u<i.length;u++)if(u<a.length){if(a[u]<0)throw new Error("strides should be greater than or equal to 1")}else a.push(1);for(let u=0;u<i.length;u++)if(u<s.length){if(s[u]<0)throw new Error("dilations should be greater than or equal to 1")}else s.push(1);for(let u=0;u<i.length*2;u++)if(u<o.length){if(o[u]<0)throw new Error("pad should be greater than or equal to 1")}else o.push(0);for(let u=0;u<i.length;u++){if(i[u]<=0)throw new Error("kernel shapes need to be greater than 0");if(o[u]>=i[u]||o[u+i.length]>=i[u])throw new Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,i,a,s,o,u){if(u){if(s.length!==2*(t.length-2))throw new Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw new Error("length of strides should be the length of data dimensions");if(a.length!==t.length-2)throw new Error("length of kernel shapes should be the length of data dimensions");for(let d=0;d<t.length-2;d++)Ys.adjustPadAndReturnShape(t[d+(o?1:2)],r[d],i[d],a[d],s,d,d+t.length-2,u)}}static computePoolOutputShape(t,r,i,a,s,o,u){if(r.length<=0)throw new Error("input shape must be of size greater than 0");let d=[r[0],r[1]];return Ys.computeShapeHelper(t,r,d,i,a,s,o,u),d}static computeConvOutputShape(t,r,i,a,s,o,u){if(t.length<=0||r.length<=0)throw new Error("invalid input tensor dims or invalid filter tensor dims");let d=[t[0],r[0]];return Ys.computeShapeHelper(!1,t,d,i,a,s,o,u),d}static computeShapeHelper(t,r,i,a,s,o,u,d){if(t)for(let p=0;p<r.length-2;p++)i.push(1);else for(let p=0;p<r.length-2;p++)i.push(Ys.adjustPadAndReturnShape(r[p+2],a[p],s[p],o[p],u,p,p+r.length-2,d))}static adjustPadAndReturnShape(t,r,i,a,s,o,u,d){let p=i*(a-1)+1;if(d&&d!=="NOTSET")switch(d){case"VALID":return s[o]=0,s[u]=0,Math.floor((t-p)/r+1);case"SAME_LOWER":case"SAME_UPPER":if(i!==1)throw new Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let m=((t+r-1)/r-1)*r+a-t;return s[o]=Math.floor(d==="SAME_LOWER"?(m+1)/2:m/2),s[u]=m-s[o],Math.floor((t+m-a)/r+1)}default:throw new Error("Unsupported AutoPad type")}else return Math.floor((t+s[o]+s[u]-p)/r+1)}},xx=class{static getShapeOfGemmResult(e,t,r,i,a){if(e.length!==2||r.length!==2)throw new Error("shape need to be of size 2");let s,o,u;t?(s=e[1],o=e[0]):(s=e[0],o=e[1]);let d=-1;if(i?(u=r[0],d=1):(u=r[1],d=0),r[d]!==o)throw new Error("dimension mismatch");if(s<=0||u<=0||o<=0)throw new Error("invalid shape specified");if(a&&!ua.isValidBroadcast(a,[s,u]))throw new Error("gemm: invalid bias shape for broadcast");return[s,u,o]}},kx=-34028234663852886e22,Sx=34028234663852886e22}),ze=te(()=>{"use strict";$e(),Ce(),la=64,su=(e,t)=>{if(t===3)throw new Error("vec3 has same alignment as vec4, use vec4 instead");switch(Number(e)){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw new Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(t!==4)throw new Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw new Error(`Unknown data type: ${e}`)}},ct=(e,t=1)=>{let r=su(e,t);return typeof r=="string"?r:r[0]},kt=(e,t=1)=>{let r=su(e,t);return typeof r=="string"?r:r[1]},_e=(...e)=>{let t=[];return e.forEach(r=>{r.length!==0&&t.push({type:12,data:r},{type:12,data:G.computeStrides(r)})}),t},Ye=e=>e%4===0?4:e%2===0?2:1,qh=(e="f32",t,r="0")=>!t||t===1?`${e}(${r})`:`vec${t}<${e}>(${r})`,oa=(e,t,r)=>e==="f32"?r:t===1?`f32(${r})`:`vec${t}<f32>(${r})`,Xr=(e,t)=>t===4?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:t===2?`(${e}.x + ${e}.y)`:t===3?`(${e}.x + ${e}.y + ${e}.z)`:e,ge=(e,t,r,i)=>e.startsWith("uniforms.")&&r>4?typeof t=="string"?i==="f16"?`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`:`${e}[(${t}) / 4][(${t}) % 4]`:i==="f16"?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`:r>1?`${e}[${t}]`:e,Gs=(e,t,r,i,a)=>{let s=typeof r=="number",o=s?r:r.length,u=[...new Array(o).keys()],d=o<2?"u32":o<=4?`vec${o}<u32>`:`array<u32, ${o}>`,p=su(t,a),m=typeof p=="string"?p:p[1],f=typeof p=="string"?p:p[0],g={indices:d,value:m,storage:f,tensor:t},v=M=>typeof M=="string"?M:`${M}u`,_={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},b=s?"uniforms.":"",k=`${b}${e}_shape`,$=`${b}${e}_strides`,w="";for(let M=0;M<o-1;M++)w+=`
    let dim${M} = current / ${ge($,M,o)};
    let rest${M} = current % ${ge($,M,o)};
    indices[${M}] = dim${M};
    current = rest${M};
    `;w+=`indices[${o-1}] = current;`;let S=o<2?"":`
  fn o2i_${e}(offset: u32) -> ${g.indices} {
    var indices: ${g.indices};
    var current = offset;
    ${w}
    return indices;
  }`,C=M=>(_.offsetToIndices=!0,o<2?M:`o2i_${e}(${M})`),I=[];if(o>=2)for(let M=o-1;M>=0;M--)I.push(`${ge($,M,o)} * (indices[${M}])`);let z=o<2?"":`
  fn i2o_${e}(indices: ${g.indices}) -> u32 {
    return ${I.join("+")};
  }`,E=M=>(_.indicesToOffset=!0,o<2?M:`i2o_${e}(${M})`),B=(...M)=>o===0?"0u":`${g.indices}(${M.map(v).join(",")})`,U=(M,q)=>o<2?`${M}`:`${ge(M,q,o)}`,V=(M,q,R)=>o<2?`${M}=${R};`:`${ge(M,q,o)}=${R};`,W={},J=(M,q)=>{_.broadcastedIndicesToOffset=!0;let R=`${q.name}broadcastedIndicesTo${e}Offset`;if(R in W)return`${R}(${M})`;let X=[];for(let Ie=o-1;Ie>=0;Ie--){let Fe=q.indicesGet("outputIndices",Ie+q.rank-o);X.push(`${U($,Ie)} * (${Fe} % ${U(k,Ie)})`)}return W[R]=`fn ${R}(outputIndices: ${q.type.indices}) -> u32 {
             return ${X.length>0?X.join("+"):"0u"};
           }`,`${R}(${M})`},D=(M,q)=>(()=>{if(g.storage===g.value)return`${e}[${M}]=${q};`;if(g.storage==="vec2<u32>"&&g.value==="i32")return`${e}[${M}]=vec2<u32>(u32(${q}), select(0u, 0xFFFFFFFFu, ${q} < 0));`;if(g.storage==="vec2<u32>"&&g.value==="u32")return`${e}[${M}]=vec2<u32>(u32(${q}), 0u);`;if(g.storage==="u32"&&g.value==="vec4<bool>")return`${e}[${M}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${q}));`;throw new Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),se=M=>(()=>{if(g.storage===g.value)return`${e}[${M}]`;if(g.storage==="vec2<u32>"&&g.value==="i32")return`i32(${e}[${M}].x)`;if(g.storage==="vec2<u32>"&&g.value==="u32")return`u32(${e}[${M}].x)`;if(g.storage==="u32"&&g.value==="vec4<bool>")return`vec4<bool>(bool(${e}[${M}] & 0xFFu), bool(${e}[${M}] & 0xFF00u), bool(${e}[${M}] & 0xFF0000u), bool(${e}[${M}] & 0xFF000000u))`;throw new Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),ue=o<2?"":`
  fn get_${e}ByIndices(indices: ${g.indices}) -> ${m} {
    return ${se(`i2o_${e}(indices)`)};
  }`,F=o<2?"":(()=>{let M=u.map(R=>`d${R}: u32`).join(", "),q=u.map(R=>`d${R}`).join(", ");return`
  fn get_${e}(${M}) -> ${m} {
    return get_${e}ByIndices(${B(q)});
  }`})(),oe=(...M)=>{if(M.length!==o)throw new Error(`indices length must be ${o}`);let q=M.map(v).join(",");return o===0?se("0u"):o===1?se(q[0]):(_.get=!0,_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}(${q})`)},le=M=>o<2?se(M):(_.getByIndices=!0,_.indicesToOffset=!0,`get_${e}ByIndices(${M})`),H=o<2?"":`
  fn set_${e}ByIndices(indices: ${g.indices}, value: ${m}) {
    ${D(`i2o_${e}(indices)`,"value")}
  }`,de=o<2?"":(()=>{let M=u.map(R=>`d${R}: u32`).join(", "),q=u.map(R=>`d${R}`).join(", ");return`
  fn set_${e}(${M}, value: ${m}) {
    set_${e}ByIndices(${B(q)}, value);
  }`})();return{impl:()=>{let M=[],q=!1;return _.offsetToIndices&&(M.push(S),q=!0),_.indicesToOffset&&(M.push(z),q=!0),_.broadcastedIndicesToOffset&&(Object.values(W).forEach(R=>M.push(R)),q=!0),_.set&&(M.push(de),q=!0),_.setByIndices&&(M.push(H),q=!0),_.get&&(M.push(F),q=!0),_.getByIndices&&(M.push(ue),q=!0),!s&&q&&M.unshift(`const ${k} = ${g.indices}(${r.join(",")});`,`const ${$} = ${g.indices}(${G.computeStrides(r).join(",")});`),M.join(`
`)},type:g,offsetToIndices:C,indicesToOffset:E,broadcastedIndicesToOffset:J,indices:B,indicesGet:U,indicesSet:V,set:(...M)=>{if(M.length!==o+1)throw new Error(`indices length must be ${o}`);let q=M[o];if(typeof q!="string")throw new Error("value must be string");let R=M.slice(0,o).map(v).join(",");return o===0?D("0u",q):o===1?D(R[0],q):(_.set=!0,_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}(${R}, ${q})`)},setByOffset:D,setByIndices:(M,q)=>o<2?D(M,q):(_.setByIndices=!0,_.indicesToOffset=!0,`set_${e}ByIndices(${M}, ${q});`),get:oe,getByOffset:se,getByIndices:le,usage:i,name:e,strides:$,shape:k,rank:o}},Z=(e,t,r,i=1)=>Gs(e,t,r,"input",i),fe=(e,t,r,i=1)=>Gs(e,t,r,"output",i),Tx=(e,t,r)=>Gs(e,t,r,"atomicOutput",1),mf=(e,t,r,i=1)=>Gs(e,t,r,"internal",i),Mb=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){return`if (global_idx >= ${typeof e=="number"?`${e}u`:e}) { return; }`}mainStart(e=la){let t=typeof e=="number"?e:e[0],r=typeof e=="number"?1:e[1],i=typeof e=="number"?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||i>this.limits.maxComputeWorkgroupSizeZ)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*i>this.limits.maxComputeInvocationsPerWorkgroup)throw new Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let a=this.normalizedDispatchGroup[1]===1&&this.normalizedDispatchGroup[2]===1,s=a?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,o=a?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*i}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${i})
  fn main(${s}) {
    ${o}
  `}appendVariableUniforms(e){e.rank!==0&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if(e.usage==="internal")throw new Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r=e.usage==="input"?"read":"read_write",i=e.usage==="atomicOutput"?"atomic<i32>":e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${i}>;`}declareVariables(...e){return e.map(t=>this.declareVariable(t,this.variableIndex++)).join(`
`)}registerInternalVariable(e){if(e.usage!=="internal")throw new Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(t=>this.registerInternalVariable(t)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(this.uniforms.length===0)return"";let e=[];for(let{name:t,type:r,length:i}of this.uniforms)if(i&&i>4)r==="f16"?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(i/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(i/4)}>`);else{let a=i==null||i===1?r:`vec${i}<${r}>`;e.push(`${t}:${a}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join(`
`)+this.internalVariables.map(e=>e.impl()).join(`
`)}get variablesInfo(){if(this.uniforms.length===0)return;let e=t=>[12,10,1,6][["u32","f16","f32","i32"].indexOf(t)];return this.uniforms.map(t=>[e(t.type),t.length??1])}},Cx=(e,t)=>new Mb(e,t)}),Jr=te(()=>{"use strict";$e(),Ce(),tt(),ze(),Db=(e,t)=>{if(!e||e.length!==1)throw new Error("Transpose requires 1 input.");if(t.length!==0&&t.length!==e[0].dims.length)throw new Error(`perm size ${t.length} does not match input rank ${e[0].dims.length}`)},sh=(e,t)=>t.length!==0?t:[...new Array(e).keys()].reverse(),Pb=(e,t)=>G.sortBasedOnPerm(e,sh(e.length,t)),Ub=(e,t,r,i)=>{let a=`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let s=0;s<t;++s)a+=`a[${e[s]}]=i[${s}];`;return a+="return a;}"},Wb=(e,t)=>{let r=[],i=[];for(let a=0;a<e.length;++a)e[a]!==1&&r.push(e[a]),e[t[a]]!==1&&i.push(t[a]);return{newShape:r,newPerm:i}},Vb=(e,t)=>{let r=0;for(let i=0;i<e.length;++i)if(t[e[i]]!==1){if(e[i]<r)return!1;r=e[i]}return!0},Ut=(e,t)=>{let r=e.dataType,i=e.dims.length,a=sh(i,t),s=Pb(e.dims,a),o=e.dims,u=s,d=i<2||Vb(a,e.dims),p;if(d)return p=_=>{let b=Z("input",r,o,4),k=fe("output",r,u,4);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,k)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    output[global_idx] = input[global_idx];
  }`},{name:"TransposeCopy",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let _=G.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64/4)},programUniforms:[{type:12,data:Math.ceil(_/4)}]}},getShaderSource:p};let{newShape:m,newPerm:f}=Wb(e.dims,a),g=G.areEqual(f,[2,3,1]),v=G.areEqual(f,[3,1,2]);if(m.length===2||g||v){o=g?[m[0],m[1]*m[2]]:v?[m[0]*m[1],m[2]]:m,u=[o[1],o[0]];let _=16;return p=b=>{let k=Z("a",r,o.length),$=fe("output",r,u.length);return`
  ${b.registerUniform("output_size","u32").declareVariables(k,$)}
  var<workgroup> tile : array<array<${$.type.value}, ${_+1}>, ${_}>;
  ${b.mainStart([_,_,1])}
    let stride = (uniforms.output_shape[1] - 1) / ${_} + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * ${_}u + local_id.x;
    let input_row = workgroup_id_x * ${_}u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${k.getByIndices(`${k.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * ${_}u + local_id.x;
    let output_row = workgroup_id_y * ${_}u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${$.setByIndices(`${$.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`},{name:"TransposeShared",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let b=G.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(u[1]/_),y:Math.ceil(u[0]/_)},programUniforms:[{type:12,data:b},..._e(o,u)]}},getShaderSource:p}}return p=_=>{let b=Z("a",r,o.length),k=fe("output",r,u.length);return`
  ${_.registerUniform("output_size","u32").declareVariables(b,k)}

  ${Ub(a,i,b,k)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${k.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${k.setByOffset("global_idx",b.getByIndices("aIndices"))}
  }`},{name:"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let _=G.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},..._e(o,u)]}},getShaderSource:p}},Ix=(e,t)=>{Db(e.inputs,t.perm),e.compute(Ut(e.inputs[0],t.perm))},Ex=e=>Le({perm:e.perm})}),pI=te(()=>{"use strict";$e(),Ce(),ze(),gf(),Jr(),qb={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},jb={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},Lb={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},Gb={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},Fb=(e,t)=>{let r=[];for(let i=t-e;i<t;++i)r.push(i);return r},Hb=(e,t)=>{let r=[],i=e.length;for(let s=0;s<i;s++)t.indexOf(s)===-1&&r.push(e[s]);let a=t.map(s=>e[s]);return[r,a]},Kb=(e,t)=>{let r=e.length+t.length,i=[],a=0;for(let s=0;s<r;s++)t.indexOf(s)===-1?i.push(e[a++]):i.push(1);return i},Zb=(e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0},Qb=(e,t)=>{let r=[];if(!Zb(e,t)){for(let i=0;i<t;++i)e.indexOf(i)===-1&&r.push(i);e.forEach(i=>r.push(i))}return r},Xb=(e,t,r,i,a,s,o)=>{let u=r[0].dims,d=G.size(s),p=G.size(o),m=Z("_A",r[0].dataType,u),f=fe("output",a,s),g=64;d===1&&(g=256);let v=`
          var<workgroup> aBestValues : array<f32, ${g}>;
       `,_=b=>`
        ${b.registerUniform("reduceSize","u32").declareVariables(m,f)}
        ${v}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${b.mainStart(g)}

          let outputIndex = global_idx / ${g};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${Lb[i]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${g}) {
           let candidate = f32(${m.getByOffset("offset + k")});
           bestValue = ${qb[i]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${g}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${jb[i]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${f.setByOffset("outputIndex",`${i==="mean"?`${f.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${f.type.storage}(${Gb[i]})`}`)};
         }
        }`;return{name:e,shaderCache:{hint:`${t};${g}`,inputDependencies:["type"]},getShaderSource:_,getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:d},programUniforms:[{type:12,data:p}]})}},or=(e,t,r,i)=>{let a=e.inputs.length===1?r:jh(e.inputs,r),s=a.axes;s.length===0&&!a.noopWithEmptyAxes&&(s=e.inputs[0].dims.map((v,_)=>_));let o=G.normalizeAxes(s,e.inputs[0].dims.length),u=o,d=e.inputs[0],p=Qb(u,e.inputs[0].dims.length);p.length>0&&(d=e.compute(Ut(e.inputs[0],p),{inputs:[0],outputs:[-1]})[0],u=Fb(u.length,d.dims.length));let[m,f]=Hb(d.dims,u),g=m;a.keepDims&&(g=Kb(m,o)),e.compute(Xb(t,a.cacheKey,[d],i,e.inputs[0].dataType,g,f),{inputs:[d]})},zx=(e,t)=>{or(e,"ReduceMeanShared",t,"mean")},Ax=(e,t)=>{or(e,"ReduceL1Shared",t,"l1")},Ox=(e,t)=>{or(e,"ReduceL2Shared",t,"l2")},Rx=(e,t)=>{or(e,"ReduceLogSumExpShared",t,"logSumExp")},Bx=(e,t)=>{or(e,"ReduceMaxShared",t,"max")},Nx=(e,t)=>{or(e,"ReduceMinShared",t,"min")},Mx=(e,t)=>{or(e,"ReduceProdShared",t,"prod")},Dx=(e,t)=>{or(e,"ReduceSumShared",t,"sum")},Px=(e,t)=>{or(e,"ReduceSumSquareShared",t,"sumSquare")},Ux=(e,t)=>{or(e,"ReduceLogSumShared",t,"logSum")}}),gf=te(()=>{"use strict";$e(),Ce(),tt(),ze(),pI(),ur=e=>{if(!e||e.length===0||e.length>2)throw new Error("Reduce op requires 1 or 2 inputs.");if(e.length===2&&e[1].dims.length!==1)throw new Error("Invalid axes input dims.")},Jb=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],bu=(e,t,r,i,a,s,o=!1,u=!1)=>{let d=[],p=r[0].dims,m=p.length,f=G.normalizeAxes(a,m),g=!u&&f.length===0;p.forEach((b,k)=>{g||f.indexOf(k)>=0?o&&d.push(1):d.push(b)});let v=d.length,_=G.size(d);return{name:e,shaderCache:t,getShaderSource:b=>{let k=[],$=Z("_A",r[0].dataType,m),w=fe("output",s,v),S=i($,w,f),C=S[2];for(let I=0,z=0;I<m;I++)g||f.indexOf(I)>=0?(o&&z++,C=`for(var j${I}: u32 = 0; j${I} < ${p[I]}; j${I}++) {
                  ${S[2].includes("last_index")?`let last_index = j${I};`:""}
                  ${$.indicesSet("input_indices",I,`j${I}`)}
                  ${C}
                }`):(k.push(`${$.indicesSet("input_indices",I,w.indicesGet("output_indices",z))};`),z++);return`

        ${b.registerUniform("output_size","u32").declareVariables($,w)}

        ${b.mainStart()}
          ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${$.type.indices};
          let output_indices = ${w.offsetToIndices("global_idx")};

          ${k.join(`
`)}
          ${S[0]}       // init ops for reduce max/min
          ${S[1]}
          ${C}
          ${S[3]}
          ${S.length===4?w.setByOffset("global_idx","value"):S.slice(4).join(`
`)}
        }`},getRunData:()=>({outputs:[{dims:d,dataType:s}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:[{type:12,data:_},..._e(p,d)]})}},jh=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(i=>r.push(Number(i))),Le({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},lr=(e,t,r,i)=>{let a=e.inputs,s=a.length===1?r:jh(a,r);e.compute(bu(t,{hint:s.cacheKey,inputDependencies:["rank"]},[a[0]],s.noopWithEmptyAxes&&s.axes.length===0?Jb:i,s.axes,a[0].dataType,s.keepDims,s.noopWithEmptyAxes),{inputs:[0]})},Yb=(e,t)=>{ur(e.inputs),lr(e,"ReduceLogSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,"value = log(value);"])},e$=(e,t)=>{ur(e.inputs),lr(e,"ReduceL1",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += abs(${r.getByIndices("input_indices")});`,""])},t$=(e,t)=>{ur(e.inputs),lr(e,"ReduceL2",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"])},r$=(e,t)=>{ur(e.inputs),lr(e,"ReduceLogSumExp",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += exp(${r.getByIndices("input_indices")});`,"value = log(value);"])},i$=(e,t)=>{ur(e.inputs),lr(e,"ReduceMax",t,(r,i,a)=>{let s=[];for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&s.push(r.indicesSet("input_indices",o,0));return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = max(value, ${r.getByIndices("input_indices")});`,""]})},a$=(e,t)=>{ur(e.inputs),lr(e,"ReduceMean",t,(r,i,a)=>{let s=1;for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&(s*=e.inputs[0].dims[o]);return["var sum = f32(0);","",`sum += f32(${r.getByIndices("input_indices")});`,`let value = ${i.type.value}(sum / ${s});`]})},n$=(e,t)=>{ur(e.inputs),lr(e,"ReduceMin",t,(r,i,a)=>{let s=[];for(let o=0;o<r.rank;o++)(a.indexOf(o)>=0||a.length===0)&&s.push(`input_indices[${o}] = 0;`);return[`${s.join(`
`)}`,`var value = ${r.getByIndices("input_indices")};`,`value = min(value, ${r.getByIndices("input_indices")});`,""]})},s$=(e,t)=>{ur(e.inputs),lr(e,"ReduceProd",t,(r,i)=>[`var value = ${i.type.storage}(1);`,"",`value *= ${r.getByIndices("input_indices")};`,""])},o$=(e,t)=>{ur(e.inputs),lr(e,"ReduceSum",t,(r,i)=>[`var value = ${i.type.storage}(0);`,"",`value += ${r.getByIndices("input_indices")};`,""])},u$=(e,t)=>{ur(e.inputs),lr(e,"ReduceSumSquare",t,(r,i)=>[`var t = ${i.type.value}(0); var value = ${i.type.value}(0);`,"",`t = ${r.getByIndices("input_indices")}; value += t * t;`,""])},dr=(e,t,r)=>{if(t.length===0)return r;let i=1,a=1;for(let s=0;s<t.length;s++)t.indexOf(s)===-1?i*=e[s]:a*=e[s];return a<32&&i>1024},Wx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?a$(e,t):zx(e,t)},Vx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?e$(e,t):Ax(e,t)},qx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?t$(e,t):Ox(e,t)},jx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?r$(e,t):Rx(e,t)},Lx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?i$(e,t):Bx(e,t)},Gx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?n$(e,t):Nx(e,t)},Fx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?s$(e,t):Mx(e,t)},Hx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?o$(e,t):Dx(e,t)},Kx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?u$(e,t):Px(e,t)},Zx=(e,t)=>{dr(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?Yb(e,t):Ux(e,t)}}),cI=te(()=>{"use strict";$e(),tt(),gf(),oh=e=>{if(!e||e.length===0||e.length>2)throw new Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(e[0].dataType!==1)throw new Error("Invalid input type.")},Qx=(e,t)=>{oh(e.inputs);let r=(i,a,s)=>{let o=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&o.push(`input_indices[${u}] = 0;`);return[`${o.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(bu("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},Xx=(e,t)=>{oh(e.inputs);let r=(i,a,s)=>{let o=[];for(let u=0;u<i.rank;u++)(s.indexOf(u)>=0||s.length===0)&&o.push(`input_indices[${u}] = 0;`);return[`${o.join(`
`)}`,`var value = ${i.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${i.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${i.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",a.setByOffset("global_idx","best_index")]};e.compute(bu("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],r,[t.axis],7,t.keepDims),{inputs:[0]})},Lh=e=>Le(e)}),yf=te(()=>{"use strict";$e(),Ce(),ff(),ze(),l$=(e,t)=>{let r=e[0],i=e[1],a=e[2],s=e[3],o=e[4],u=e[5];if(o&&u)throw new Error("Attention cannot have both past and attention_bias");if(r.dims.length!==3)throw new Error('Input "input" must have 3 dimensions');let d=r.dims[0],p=r.dims[1],m=r.dims[2];if(a.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimensions');if(i.dims.length!==2)throw new Error('Input "weights" is expected to have 2 dimensions');if(i.dims[0]!==m)throw new Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(a.dims[0]!==i.dims[1])throw new Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let f=a.dims[0]/3,g=f,v=g;if(t.qkvHiddenSizes.length>0){if(t.qkvHiddenSizes.length!==3)throw new Error("qkv_hidden_sizes attribute should have 3 elements");for(let S of t.qkvHiddenSizes)if(S%t.numHeads!==0)throw new Error("qkv_hidden_sizes should be divisible by num_heads");f=t.qkvHiddenSizes[0],g=t.qkvHiddenSizes[1],v=t.qkvHiddenSizes[2]}let _=p;if(f!==g)throw new Error("qkv_hidden_sizes first element should be same as the second");if(a.dims[0]!==f+g+v)throw new Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let b=0;if(o){if(g!==v)throw new Error('Input "past" expect k_hidden_size == v_hidden_size');if(o.dims.length!==5)throw new Error('Input "past" must have 5 dimensions');if(o.dims[0]!==2)throw new Error('Input "past" first dimension must be 2');if(o.dims[1]!==d)throw new Error('Input "past" second dimension must be batch_size');if(o.dims[2]!==t.numHeads)throw new Error('Input "past" third dimension must be num_heads');if(o.dims[4]!==g/t.numHeads)throw new Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(b=o.dims[3])}let k=_+b,$=-1,w=0;if(s)throw new Error("Mask not supported");if(o)throw new Error("past is not supported");if(u){if(u.dims.length!==4)throw new Error('Input "attention_bias" must have 4 dimensions');if(u.dims[0]!==d||u.dims[1]!==t.numHeads||u.dims[2]!==p||u.dims[3]!==k)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:d,sequenceLength:p,pastSequenceLength:b,kvSequenceLength:_,totalSequenceLength:k,maxSequenceLength:$,inputHiddenSize:m,hiddenSize:f,vHiddenSize:v,headSize:Math.floor(f/t.numHeads),vHeadSize:Math.floor(v/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:w,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}},ou=(e,t,r)=>t&&e?`
      let total_sequence_length_input = u32(${t.getByOffset("0")});
      let present_sequence_length = max(total_sequence_length_input, uniforms.past_sequence_length);
      let is_subsequent_prompt: bool = sequence_length > 1 && sequence_length != total_sequence_length_input;
      let is_first_prompt: bool = is_subsequent_prompt == false && sequence_length == total_sequence_length_input;
      total_sequence_length = u32(${e?.getByOffset("batchIdx")}) + 1;
      var past_sequence_length: u32 = 0;
      if (is_first_prompt == false) {
        past_sequence_length = total_sequence_length - sequence_length;
      }
       `:`
    ${r?"let past_sequence_length = uniforms.past_sequence_length":""};
    let present_sequence_length = total_sequence_length;
    `,d$=(e,t,r,i,a,s,o,u)=>{let d=Ye(o?1:s),p=64,m=s/d;m<p&&(p=32);let f=Math.ceil(s/d/p),g=[{type:12,data:t},{type:12,data:r},{type:12,data:i},{type:12,data:a},{type:12,data:m},{type:12,data:f}],v=ct(e.dataType,d),_=kt(1,d),b=["type"];o&&b.push("type"),u&&b.push("type");let k=$=>{let w=fe("x",e.dataType,e.dims,d),S=[w],C=o?Z("seq_lens",o.dataType,o.dims):void 0;C&&S.push(C);let I=u?Z("total_sequence_length_input",u.dataType,u.dims):void 0;I&&S.push(I);let z=kt(e.dataType),E=[{name:"batch_size",type:"u32"},{name:"num_heads",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"sequence_length",type:"u32"},{name:"total_sequence_length",type:"u32"},{name:"elements_per_thread",type:"u32"}];return`
  var<workgroup> thread_max: array<f32, ${p}>;
  var<workgroup> thread_sum: array<f32, ${p}>;
  ${$.registerUniforms(E).declareVariables(...S)}
  ${$.mainStart([p,1,1])}
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let sequence_length = uniforms.sequence_length;
    var total_sequence_length = uniforms.total_sequence_length;
    ${ou(C,I,!1)}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${p}) * uniforms.total_sequence_length + local_offset;
    let seq_causal_length = ${o?"u32(past_sequence_length + workgroup_id.y + 1)":"total_sequence_length"};
    var thread_max_vector = ${_}(-3.402823e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      thread_max_vector = max(${_}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(d){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.402823e+38f);
    for (var i = 0u; i < ${p}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${_}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      sum_vector += exp(${_}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(d){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw new Error(`Unsupported components: ${d}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${p}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        x[offset + i] = ${w.type.value}(${z}(1.0) / ${z}(seq_causal_length));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        var f32input = ${_}(x[offset + i]);
        x[offset + i] = ${w.type.value}(exp(f32input - max_value) / sum);
      }
    }
      ${o?`
        for (var total_seq_id: u32 = seq_causal_length; total_seq_id + local_offset < uniforms.total_sequence_length; total_seq_id++) {
          x[offset + total_seq_id] = ${w.type.value}(${z}(0));
        }`:""};
  }`};return{name:"AttentionProbsSoftmax",shaderCache:{hint:`${p};${v};${d}`,inputDependencies:b},getShaderSource:k,getRunData:()=>({outputs:[],dispatchGroup:{x:Math.ceil(s/p),y:a,z:t*r},programUniforms:g})}},p$=(e,t,r,i,a,s,o,u,d)=>{let p=o+s.kvSequenceLength,m=[s.batchSize,s.numHeads,s.sequenceLength,p],f=e>1&&i,g=s.kvNumHeads?s.kvNumHeads:s.numHeads,v=f?[s.batchSize,g,p,s.headSize]:void 0,_=s.nReps?s.nReps:1,b=s.scale===0?1/Math.sqrt(s.headSize):s.scale,k=Ye(s.headSize),$=s.headSize/k,w=12,S={x:Math.ceil(p/w),y:Math.ceil(s.sequenceLength/w),z:s.batchSize*s.numHeads},C=[{type:12,data:s.sequenceLength},{type:12,data:$},{type:12,data:p},{type:12,data:s.numHeads},{type:12,data:s.headSize},{type:1,data:b},{type:12,data:o},{type:12,data:s.kvSequenceLength},{type:12,data:_}],I=f&&i&&G.size(i.dims)>0,z=["type","type"];I&&z.push("type"),a&&z.push("type"),u&&z.push("type"),d&&z.push("type");let E=[{dims:m,dataType:t.dataType,gpuDataType:0}];f&&E.push({dims:v,dataType:t.dataType,gpuDataType:0});let B=U=>{let V=Z("q",t.dataType,t.dims,k),W=Z("key",r.dataType,r.dims,k),J=[V,W];if(I){let H=Z("past_key",i.dataType,i.dims,k);J.push(H)}a&&J.push(Z("attention_bias",a.dataType,a.dims));let D=u?Z("seq_lens",u.dataType,u.dims):void 0;D&&J.push(D);let se=d?Z("total_sequence_length_input",d.dataType,d.dims):void 0;se&&J.push(se);let ue=fe("output",t.dataType,m),F=[ue];f&&F.push(fe("present_key",t.dataType,v,k));let oe=kt(1,k),le=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${w}u;

  var<workgroup> tileQ: array<${V.type.storage}, ${w*w}>;
  var<workgroup> tileK: array<${V.type.storage}, ${w*w}>;
  ${U.registerUniforms(le).declareVariables(...J,...F)}
  ${U.mainStart([w,w,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let kvHeadIdx = ${_===1?"headIdx":"headIdx / uniforms.n_reps"};
    let kv_num_heads = ${_===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let sequence_length = uniforms.M;
    var total_sequence_length = uniforms.N;
    ${ou(D,se,!0)}
    let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx;
    let qOffset = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
    ${I&&f?"let pastKeyOffset = absKvHeadIdx * uniforms.past_sequence_length * uniforms.K;":""};
    let kOffset = absKvHeadIdx * uniforms.kv_sequence_length * uniforms.K;
    ${f?"let presentKeyOffset = absKvHeadIdx * uniforms.N * uniforms.K;":""}
    var value = ${oe}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${I&&f?`
              if (n + local_id.y < past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else if (n + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
                tileK[idx] = key[kOffset + (n + local_id.y - past_sequence_length) * uniforms.K + w + local_id.x];
              }`:`
          if (n + local_id.y < uniforms.kv_sequence_length) {
            tileK[idx] = key[kOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
          }`}
      ${f?`if (n + local_id.y < present_sequence_length) {
        present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];
      }`:""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
          value += ${oe}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    if (global_id.y < uniforms.M && global_id.x < total_sequence_length) {
      let headOffset = workgroup_id.z * uniforms.M * uniforms.N;
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch(k){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw new Error(`Unsupported components: ${k}`)}})()};
        output[outputIdx] = ${ue.type.value} (sum * uniforms.alpha) + ${a?"attention_bias[outputIdx]":"0.0"};
    }
  }`};return{name:"AttentionProbs",shaderCache:{hint:`${k};${a!==void 0};${i!==void 0};${e}`,inputDependencies:z},getRunData:()=>({outputs:E,dispatchGroup:S,programUniforms:C}),getShaderSource:B}},c$=(e,t,r,i,a,s,o=void 0,u=void 0)=>{let d=s+a.kvSequenceLength,p=a.nReps?a.nReps:1,m=a.vHiddenSize*p,f=e>1&&i,g=a.kvNumHeads?a.kvNumHeads:a.numHeads,v=f?[a.batchSize,g,d,a.headSize]:void 0,_=[a.batchSize,a.sequenceLength,m],b=12,k={x:Math.ceil(a.vHeadSize/b),y:Math.ceil(a.sequenceLength/b),z:a.batchSize*a.numHeads},$=[{type:12,data:a.sequenceLength},{type:12,data:d},{type:12,data:a.vHeadSize},{type:12,data:a.numHeads},{type:12,data:a.headSize},{type:12,data:m},{type:12,data:s},{type:12,data:a.kvSequenceLength},{type:12,data:p}],w=f&&i&&G.size(i.dims)>0,S=["type","type"];w&&S.push("type"),o&&S.push("type"),u&&S.push("type");let C=[{dims:_,dataType:t.dataType,gpuDataType:0}];f&&C.push({dims:v,dataType:t.dataType,gpuDataType:0});let I=z=>{let E=Z("probs",t.dataType,t.dims),B=Z("v",r.dataType,r.dims),U=[E,B];w&&U.push(Z("past_value",i.dataType,i.dims));let V=o?Z("seq_lens",o.dataType,o.dims):void 0;o&&U.push(V);let W=u?Z("total_sequence_length_input",u.dataType,u.dims):void 0;u&&U.push(W);let J=[fe("output",t.dataType,_)];f&&J.push(fe("present_value",t.dataType,v));let D=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}];return`
  const TILE_SIZE = ${b}u;
  var<workgroup> tileQ: array<${E.type.value}, ${b*b}>;
  var<workgroup> tileV: array<${E.type.value}, ${b*b}>;
  ${z.registerUniforms(D).declareVariables(...U,...J)}
  ${z.mainStart([b,b,1])}
   let headIdx = workgroup_id.z % uniforms.num_heads;
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let kvHeadIdx = ${p===1?"headIdx":"headIdx / uniforms.n_reps"};
   let kv_num_heads = ${p===1?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
   let m = global_id.y;
   let n = global_id.x;
   let sequence_length = uniforms.M;
   var total_sequence_length = uniforms.K;
   ${ou(V,W,!0)}
   let offsetA = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
   let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx; // kvHeadIdx is relative to the batch
   ${w&&f?"let pastValueOffset = absKvHeadIdx * uniforms.N * uniforms.past_sequence_length + n;":""};
   let vOffset = absKvHeadIdx * uniforms.N * uniforms.kv_sequence_length + n;
   ${f?"let presentValueOffset = absKvHeadIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${E.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${w&&f?`
        if (w + local_id.y < past_sequence_length) {
          tileV[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else if (w + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
          tileV[idx] = v[vOffset + (w + local_id.y - past_sequence_length) * uniforms.N];
        }
      `:`
            if (w + local_id.y < uniforms.kv_sequence_length) {
              tileV[idx] = v[vOffset + (w + local_id.y) * uniforms.N];
            }`}
        ${f?`
            if (w + local_id.y < present_sequence_length) {
          present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileV[idx];
        }`:""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < total_sequence_length; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileV[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + headIdx * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`};return{name:"AttentionScore",shaderCache:{hint:`${i!==void 0};${e}`,inputDependencies:S},getRunData:()=>({outputs:C,dispatchGroup:k,programUniforms:$}),getShaderSource:I}},ao=(e,t,r,i,a,s,o,u,d,p,m=void 0,f=void 0)=>{let g=Math.min(e.outputCount,1+(o?1:0)+(u?1:0)),v=g>1?p.pastSequenceLength:0,_=v+p.kvSequenceLength,b=d&&G.size(d.dims)>0?d:void 0,k=[t,r];g>1&&o&&G.size(o.dims)>0&&k.push(o),b&&k.push(b),m&&k.push(m),f&&k.push(f);let $=e.compute(p$(g,t,r,o,b,p,v,m,f),{inputs:k,outputs:g>1?[-1,1]:[-1]})[0];e.compute(d$($,p.batchSize,p.numHeads,v,p.sequenceLength,_,m,f),{inputs:m&&f?[$,m,f]:[$],outputs:[]});let w=[$,i];g>1&&u&&G.size(u.dims)>0&&w.push(u),m&&w.push(m),f&&w.push(f),e.compute(c$(g,$,i,u,p,v,m,f),{inputs:w,outputs:g>1?[0,2]:[0]})},h$=(e,t)=>{let r=[t.batchSize,t.numHeads,t.sequenceLength,t.headSize],i=t.sequenceLength,a=t.inputHiddenSize,s=t.headSize,o=12,u={x:Math.ceil(t.headSize/o),y:Math.ceil(t.sequenceLength/o),z:t.batchSize*t.numHeads},d=[e.inputs[0],e.inputs[1],e.inputs[2]],p=[{type:12,data:i},{type:12,data:a},{type:12,data:s},{type:12,data:t.numHeads},{type:12,data:t.headSize},{type:12,data:t.hiddenSize},{type:12,data:t.hiddenSize+t.hiddenSize+t.vHiddenSize}],m=f=>{let g=fe("output_q",d[0].dataType,r),v=fe("output_k",d[0].dataType,r),_=fe("output_v",d[0].dataType,r),b=Z("input",d[0].dataType,d[0].dims),k=Z("weight",d[1].dataType,d[1].dims),$=Z("bias",d[2].dataType,d[2].dims),w=b.type.storage,S=[{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}];return`
  const TILE_SIZE = ${o}u;
  var<workgroup> tileInput: array<${w}, ${o*o}>;
  var<workgroup> tileWeightQ: array<${w}, ${o*o}>;
  var<workgroup> tileWeightK: array<${w}, ${o*o}>;
  var<workgroup> tileWeightV: array<${w}, ${o*o}>;
  ${f.registerUniforms(S).declareVariables(b,k,$,g,v,_)}
  ${f.mainStart([o,o,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${w}(0);
    var valueK = ${w}(0);
    var valueV = ${w}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`};return e.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0}],dispatchGroup:u,programUniforms:p}),getShaderSource:m},{inputs:d,outputs:[-1,-1,-1]})},Jx=(e,t)=>{let r=l$(e.inputs,t),[i,a,s]=h$(e,r);return ao(e,i,a,s,e.inputs[4],void 0,void 0,void 0,e.inputs[5],r)}}),hI=te(()=>{"use strict";fr(),$e(),Ce(),tt(),ze(),f$=(e,t)=>{if(!e||e.length!==5)throw new Error("BatchNormalization requires 5 inputs");let r=(i,a,s)=>{let o=a.length;if(o!==i.length)throw new Error(`${s}: num dimensions != ${o}`);a.forEach((u,d)=>{if(u!==i[d])throw new Error(`${s}: dim[${d}] do not match`)})};if(e[0].dims.length>1){let i=t.format==="NHWC"?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,i,"Invalid input scale"),r(e[2].dims,i,"Invalid input B"),r(e[3].dims,i,"Invalid input mean"),r(e[4].dims,i,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")},m$=(e,t)=>{let{epsilon:r,spatial:i,format:a}=t,s=e[0].dims,o=i?Ye(s[s.length-1]):1,u=a==="NHWC"&&s.length>1?o:1,d=G.size(s)/o,p=i,m=p?s.length:s,f=Z("x",e[0].dataType,e[0].dims,o),g=Z("scale",e[1].dataType,e[1].dims,u),v=Z("bias",e[2].dataType,e[2].dims,u),_=Z("inputMean",e[3].dataType,e[3].dims,u),b=Z("inputVar",e[4].dataType,e[4].dims,u),k=fe("y",e[0].dataType,m,o),$=()=>{let S="";if(i)S=`let cOffset = ${s.length===1?"0u":a==="NHWC"?`outputIndices[${s.length-1}] / ${o}`:"outputIndices[1]"};`;else if(a==="NCHW")S=`
            ${k.indicesSet("outputIndices","0","0")}
            let cOffset = ${k.indicesToOffset("outputIndices")};`;else{S=`var cIndices = ${g.type.indices}(0);
                       cIndices[0] = outputIndices[${s.length-1}];`;for(let C=1;C<g.rank;C++)S+=`cIndices[${C}] = outputIndices[${C}];`;S+=`let cOffset = ${g.indicesToOffset("cIndices")};`}return S},w=S=>`
  const epsilon = ${r};
  ${S.registerUniform("outputSize","u32").declareVariables(f,g,v,_,b,k)}
  ${S.mainStart()}
  ${S.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${k.offsetToIndices(`global_idx * ${o}`)};
    ${$()}
    let scale = ${g.getByOffset("cOffset")};
    let bias = ${v.getByOffset("cOffset")};
    let inputMean = ${_.getByOffset("cOffset")};
    let inputVar = ${b.getByOffset("cOffset")};
    let x = ${f.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${k.setByOffset("global_idx","value")}
  }`;return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${i}_${o}`,inputDependencies:p?["rank","type","type","type","type"]:void 0},getShaderSource:w,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p?[{type:12,data:d},..._e(s)]:[{type:12,data:d}]})}},g$=e=>Le(e),Yx=(e,t)=>{let{inputs:r,outputCount:i}=e,a=g$({...t,outputCount:i});if(Ze.webgpu.validateInputContent&&f$(r,a),t.trainingMode)throw new Error("BatchNormalization trainingMode is not supported yet.");e.compute(m$(r,a))}}),fI=te(()=>{"use strict";Ce(),ze(),y$=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![320,640,1280].includes(e[0].dims[2]))throw new Error("number of channels should be 320, 640 or 1280");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},_$=e=>{let t=e[0].dims,r=e[0].dims[2],i=G.size(t)/4,a=e[0].dataType,s=Z("input",a,t,4),o=Z("bias",a,[r],4),u=Z("residual",a,t,4),d=fe("output",a,t,4);return{name:"BiasAdd",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(i/64)}}),getShaderSource:p=>`
  const channels = ${r}u / 4;
  ${p.declareVariables(s,o,u,d)}

  ${p.mainStart()}
    ${p.guardAgainstOutOfBoundsWorkgroupSizes(i)}
    let value = ${s.getByOffset("global_idx")}
      + ${o.getByOffset("global_idx % channels")} + ${u.getByOffset("global_idx")};
    ${d.setByOffset("global_idx","value")}
  }`}},e3=e=>{y$(e.inputs),e.compute(_$(e.inputs))}}),_f=te(()=>{"use strict";$e(),Ce(),tt(),ze(),v$=(e,t,r,i,a,s,o)=>{let u=Math.ceil(t/4),d="";typeof a=="string"?d=`${a}(a)`:d=a("a");let p=Z("inputData",r,[u],4),m=fe("outputData",i,[u],4),f=[{name:"vec_size",type:"u32"}];return o&&f.push(...o),`
      ${e.registerUniforms(f).declareVariables(p,m)}

  ${s??""}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${p.getByOffset("global_idx")};
    ${m.setByOffset("global_idx",d)}
  }`},Ue=(e,t,r,i,a,s=e.dataType,o,u)=>{let d=[{type:12,data:Math.ceil(G.size(e.dims)/4)}];return o&&d.push(...o),{name:t,shaderCache:{hint:a,inputDependencies:["type"]},getShaderSource:p=>v$(p,G.size(e.dims),e.dataType,s,r,i,u),getRunData:p=>({outputs:[{dims:e.dims,dataType:s}],dispatchGroup:{x:Math.ceil(G.size(p[0].dims)/64/4)},programUniforms:d})}},t3=e=>{e.compute(Ue(e.inputs[0],"Abs","abs"))},r3=e=>{e.compute(Ue(e.inputs[0],"Acos","acos"))},i3=e=>{e.compute(Ue(e.inputs[0],"Acosh","acosh"))},a3=e=>{e.compute(Ue(e.inputs[0],"Asin","asin"))},n3=e=>{e.compute(Ue(e.inputs[0],"Asinh","asinh"))},s3=e=>{e.compute(Ue(e.inputs[0],"Atan","atan"))},o3=e=>{e.compute(Ue(e.inputs[0],"Atanh","atanh"))},u3=e=>Le(e),l3=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw new RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(Ue(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},w$=e=>{let t,r,i=e.length>=2&&e[1].data!==0,a=e.length>=3&&e[2].data!==0;switch(e[0].dataType){case 1:t=i?e[1].getFloat32Array()[0]:-34028234663852886e22,r=a?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=i?e[1].getUint16Array()[0]:64511,r=a?e[2].getUint16Array()[0]:31743;break;default:throw new Error("Unsupport data type")}return Le({min:t,max:r})},d3=(e,t)=>{let r=t||w$(e.inputs),i=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"Clip",a=>`clamp(${a}, vec4<${i}>(uniforms.min), vec4<${i}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:i},{name:"max",type:i}]),{inputs:[0]})},p3=e=>{e.compute(Ue(e.inputs[0],"Ceil","ceil"))},c3=e=>{e.compute(Ue(e.inputs[0],"Cos","cos"))},h3=e=>{e.compute(Ue(e.inputs[0],"Cosh","cosh"))},eo=e=>Le(e),f3=(e,t)=>{let r=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"Elu",i=>`elu_vf32(${i})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},gu=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,m3=e=>{let t=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"Erf",r=>`erf_vf32(${r})`,gu(t)))},g3=e=>{e.compute(Ue(e.inputs[0],"Exp","exp"))},y3=e=>{e.compute(Ue(e.inputs[0],"Floor","floor"))},_3=e=>{let t=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"Gelu",r=>`0.5 * ${r} * (1.0 + erf_vf32(${r} * 0.7071067811865475))`,gu(t)))},v3=(e,t)=>{let r=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"LeakyRelu",i=>`select(leaky_relu_alpha_ * ${i}, ${i}, ${i} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},w3=e=>{e.compute(Ue(e.inputs[0],"Not",t=>`!${t}`))},b3=e=>{e.compute(Ue(e.inputs[0],"Neg",t=>`-${t}`))},$3=e=>{e.compute(Ue(e.inputs[0],"Reciprocal",t=>`1.0/${t}`))},x3=e=>{let t=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"Relu",r=>`select(vec4<${t}>(0.0), ${r}, ${r} > vec4<${t}>(0.0))`))},k3=e=>{e.compute(Ue(e.inputs[0],"Sigmoid",t=>`(1.0 / (1.0 + exp(-${t})))`))},S3=e=>Le(e),T3=(e,t)=>{let r=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"HardSigmoid",i=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${i} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},C3=e=>{e.compute(Ue(e.inputs[0],"Sin","sin"))},I3=e=>{e.compute(Ue(e.inputs[0],"Sinh","sinh"))},E3=e=>{e.compute(Ue(e.inputs[0],"Sqrt","sqrt"))},z3=e=>{e.compute(Ue(e.inputs[0],"Tan","tan"))},uh=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,A3=e=>{e.compute(Ue(e.inputs[0],"Tanh",uh))},Gh=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${uh("v")};
}
`,Fh=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,O3=e=>{let t=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"FastGelu",Fh,Gh(t),void 0,e.inputs[0].dataType))},R3=(e,t)=>{let r=kt(e.inputs[0].dataType);return e.compute(Ue(e.inputs[0],"ThresholdedRelu",i=>`select(vec4<${r}>(0.0), ${i}, ${i} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},B3=e=>{e.compute(Ue(e.inputs[0],"Log","log"))},b$=(e,t)=>`
const alpha = vec4<${e}>(${t});
const one = ${e}(1.0);
const zero = ${e}(0.0);

fn quick_gelu_impl(x: vec4<${e}>) -> vec4<${e}> {
  let v = x *alpha;
  var x1 : vec4<${e}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`,$$=e=>`quick_gelu_impl(${e})`,N3=(e,t)=>{let r=kt(e.inputs[0].dataType);e.compute(Ue(e.inputs[0],"QuickGelu",$$,b$(r,t.alpha),t.cacheKey,e.inputs[0].dataType))}}),mI=te(()=>{"use strict";Ce(),ze(),_f(),x$=e=>{if(e[0].dims.length!==3)throw new Error("input should have 3 dimensions");if(![2560,5120,10240].includes(e[0].dims[2]))throw new Error("hidden state should be 2560, 5120 or 10240");if(e[1].dims.length!==1)throw new Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw new Error("last dimension of input and bias are not the same")},k$=e=>{let t=e[0].dims.slice();t[2]=t[2]/2;let r=Z("input",e[0].dataType,e[0].dims,4),i=Z("bias",e[0].dataType,[e[0].dims[2]],4),a=fe("output",e[0].dataType,t,4),s=G.size(t)/4,o=ct(e[0].dataType);return{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)}}),getShaderSource:u=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${e[0].dims[2]/4/2}u;

  ${u.declareVariables(r,i,a)}

  ${gu(o)}

  ${u.mainStart()}
    ${u.guardAgainstOutOfBoundsWorkgroupSizes(s)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${a.setByOffset("global_idx","valueLeft * geluRight")}
  }`}},M3=e=>{x$(e.inputs),e.compute(k$(e.inputs))}}),gI=te(()=>{"use strict";$e(),Ce(),ze(),S$=(e,t,r,i,a,s,o,u,d,p,m,f)=>{let g,v;typeof u=="string"?g=v=(w,S)=>`${u}((${w}),(${S}))`:typeof u=="function"?g=v=u:(g=u.scalar,v=u.vector);let _=fe("outputData",m,i.length,4),b=Z("aData",d,t.length,4),k=Z("bData",p,r.length,4),$;if(a)if(s){let w=G.size(t)===1,S=G.size(r)===1,C=t.length>0&&t[t.length-1]%4===0,I=r.length>0&&r[r.length-1]%4===0;w||S?$=_.setByOffset("global_idx",v(w?`${b.type.value}(${b.getByOffset("0")}.x)`:b.getByOffset("global_idx"),S?`${k.type.value}(${k.getByOffset("0")}.x)`:k.getByOffset("global_idx"))):$=`
            let outputIndices = ${_.offsetToIndices("global_idx * 4u")};
            let offsetA = ${b.broadcastedIndicesToOffset("outputIndices",_)};
            let offsetB = ${k.broadcastedIndicesToOffset("outputIndices",_)};
            ${_.setByOffset("global_idx",v(o||C?b.getByOffset("offsetA / 4u"):`${b.type.value}(${b.getByOffset("offsetA / 4u")}[offsetA % 4u])`,o||I?k.getByOffset("offsetB / 4u"):`${k.type.value}(${k.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else $=_.setByOffset("global_idx",v(b.getByOffset("global_idx"),k.getByOffset("global_idx")));else{if(!s)throw new Error("no necessary to use scalar implementation for element-wise binary op implementation.");let w=(S,C,I="")=>{let z=`aData[indexA${C}][componentA${C}]`,E=`bData[indexB${C}][componentB${C}]`;return`
            let outputIndices${C} = ${_.offsetToIndices(`global_idx * 4u + ${C}u`)};
            let offsetA${C} = ${b.broadcastedIndicesToOffset(`outputIndices${C}`,_)};
            let offsetB${C} = ${k.broadcastedIndicesToOffset(`outputIndices${C}`,_)};
            let indexA${C} = offsetA${C} / 4u;
            let indexB${C} = offsetB${C} / 4u;
            let componentA${C} = offsetA${C} % 4u;
            let componentB${C} = offsetB${C} % 4u;
            ${S}[${C}] = ${I}(${g(z,E)});
          `};m===9?$=`
            var data = vec4<u32>(0);
            ${w("data",0,"u32")}
            ${w("data",1,"u32")}
            ${w("data",2,"u32")}
            ${w("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:$=`
            ${w("outputData[global_idx]",0)}
            ${w("outputData[global_idx]",1)}
            ${w("outputData[global_idx]",2)}
            ${w("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(b,k,_)}

        ${f??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${$}
      }`},T$=(e,t,r,i,a,s,o=r.dataType)=>{let u=r.dims.map(b=>Number(b)??1),d=i.dims.map(b=>Number(b)??1),p=!G.areEqual(u,d),m=u,f=G.size(u),g=!1,v=!1,_=[p];if(p){let b=ua.calcShape(u,d,!1);if(!b)throw new Error("Can't perform binary op on the given tensors");m=b.slice(),f=G.size(m);let k=G.size(u)===1,$=G.size(d)===1,w=u.length>0&&u[u.length-1]%4===0,S=d.length>0&&d[d.length-1]%4===0;_.push(k),_.push($),_.push(w),_.push(S);let C=1;for(let I=1;I<m.length;I++){let z=u[u.length-I],E=d[d.length-I];if(z===E)C*=z;else break}C%4===0?(v=!0,g=!0):(k||$||w||S)&&(g=!0)}else g=!0;return _.push(g),{name:e,shaderCache:{hint:t+_.map(b=>b.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:b=>S$(b,u,d,m,g,p,v,a,r.dataType,i.dataType,o,s),getRunData:()=>({outputs:[{dims:m,dataType:o}],dispatchGroup:{x:Math.ceil(f/64/4)},programUniforms:[{type:12,data:Math.ceil(G.size(m)/4)},..._e(u,d,m)]})}},pr=(e,t,r,i,a,s)=>{e.compute(T$(t,a??"",e.inputs[0],e.inputs[1],r,i,s))},D3=e=>{pr(e,"Add",(t,r)=>`${t}+${r}`)},P3=e=>{pr(e,"Div",(t,r)=>`${t}/${r}`)},U3=e=>{pr(e,"Equal",{scalar:(t,r)=>`u32(${t}==${r})`,vector:(t,r)=>`vec4<u32>(${t}==${r})`},void 0,void 0,9)},W3=e=>{pr(e,"Mul",(t,r)=>`${t}*${r}`)},V3=e=>{let t=Z("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;pr(e,"Pow",{scalar:(r,i)=>`pow_custom(${r},${i})`,vector:(r,i)=>`pow_vector_custom(${r},${i})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${t==="i32"?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},q3=e=>{pr(e,"Sub",(t,r)=>`${t}-${r}`)},j3=e=>{pr(e,"Greater",{scalar:(t,r)=>`u32(${t}>${r})`,vector:(t,r)=>`vec4<u32>(${t}>${r})`},void 0,void 0,9)},L3=e=>{pr(e,"Less",{scalar:(t,r)=>`u32(${t}<${r})`,vector:(t,r)=>`vec4<u32>(${t}<${r})`},void 0,void 0,9)},G3=e=>{pr(e,"GreaterOrEqual",{scalar:(t,r)=>`u32(${t}>=${r})`,vector:(t,r)=>`vec4<u32>(${t}>=${r})`},void 0,void 0,9)},F3=e=>{pr(e,"LessOrEqual",{scalar:(t,r)=>`u32(${t}<=${r})`,vector:(t,r)=>`vec4<u32>(${t}<=${r})`},void 0,void 0,9)}}),yI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),C$=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");let r=0,i=e[r],a=i.dataType,s=i.dims.length;e.forEach((o,u)=>{if(u!==r){if(o.dataType!==a)throw new Error("input tensors should be one type");if(o.dims.length!==s)throw new Error("input tensors should have the same shape");o.dims.forEach((d,p)=>{if(p!==t&&d!==i.dims[p])throw new Error("non concat dimensions must match")})}})},I$=(e,t)=>`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${e}u>(${t});
    for (var i: u32 = 0u; i < ${e}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${e}u;
  }`,E$=(e,t)=>{let r=e.length,i=[];for(let a=0;a<r;++a){let s=t.setByOffset("global_idx",e[a].getByIndices("indices"));r===1?i.push(s):a===0?i.push(`if (inputIndex == ${a}u) { ${s} }`):a===r-1?i.push(`else { ${s} }`):i.push(`else if (inputIndex == ${a}) { ${s} }`)}return i.join(`
`)},z$=(e,t,r,i)=>{let a=G.size(r),s=new Array(e.length),o=new Array(e.length),u=0,d=[],p=[],m=[{type:12,data:a}];for(let b=0;b<e.length;++b)u+=e[b].dims[t],s[b]=u,p.push(e[b].dims.length),o[b]=Z(`input${b}`,i,p[b]),d.push("rank"),m.push({type:12,data:s[b]});for(let b=0;b<e.length;++b)m.push(..._e(e[b].dims));m.push(..._e(r));let f=fe("output",i,r.length),g=f.indicesGet("indices",t),v=Array.from(Array(s.length).keys()).map(b=>`uniforms.sizeInConcatAxis${b}`).join(","),_=b=>`

  ${(()=>{b.registerUniform("outputSize","u32");for(let k=0;k<e.length;k++)b.registerUniform(`sizeInConcatAxis${k}`,"u32");return b.declareVariables(...o,f)})()}

  ${I$(s.length,v)}

  ${b.mainStart()}
    ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${f.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${g});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${s.length}u>(${v});
      ${g} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${E$(o,f)}
  }`;return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:d},getRunData:()=>({outputs:[{dims:r,dataType:i}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:m}),getShaderSource:_}},H3=(e,t)=>{let r=e.inputs,i=r[0].dims,a=G.normalizeAxis(t.axis,i.length);C$(r,a);let s=i.slice();s[a]=r.reduce((u,d)=>u+(d.dims.length>a?d.dims[a]:0),0);let o=r.filter(u=>G.size(u.dims)>0);e.compute(z$(o,a,s,r[0].dataType),{inputs:o})},K3=e=>Le({axis:e.axis})}),Qi=te(()=>{"use strict";$e(),Ce(),Fi=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw new Error(`Unsupported activation ${e.activation}`)}},Hi=(e,t)=>{e.activation==="Clip"?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):e.activation==="HardSigmoid"?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):e.activation==="LeakyRelu"&&t.push({type:1,data:e.alpha})},Ki=(e,t)=>{e.activation==="Clip"?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):e.activation==="HardSigmoid"?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):e.activation==="LeakyRelu"&&t.push({name:"alpha",type:"f32"})},vf=e=>{let t=e?.activation||"";if(t==="HardSigmoid"){let[r,i]=e?.activation_params||[.2,.5];return{activation:t,alpha:r,beta:i}}else if(t==="Clip"){let[r,i]=e?.activation_params||[kx,Sx];return{activation:t,clipMax:i,clipMin:r}}else if(t==="LeakyRelu"){let[r]=e?.activation_params||[.01];return{activation:t,alpha:r}}return{activation:t}}}),wf=te(()=>{"use strict";ft=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw new Error(`${e}-component is not supported.`)}},Z3=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}),_I=te(()=>{"use strict";Q3=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}),$f=te(()=>{"use strict";$e(),Ce(),ze(),Qi(),ro=(e,t,r,i,a)=>{let s=i-r;return`
      ${Array.from({length:r}).map((o,u)=>`
      if (${ge(t.shape,u,t.rank)} != 1) {
        ${t.indicesSet(e,u,ge(a,u+s,i))}
      } else {
        ${t.indicesSet(e,u,0)}
      }`).join("")}
`},bf=(e,t,r,i,a=!1,s)=>{let o=e[0].dims,u=e[1].dims,d=o[o.length-2],p=u[u.length-1],m=o[o.length-1],f=Ye(p),g=Ye(m),v=Ye(d),_=G.size(r)/f/v,b=e.length>2,k=i?i.slice(0,-2):r.slice(0,-2),$=[G.size(k),d,p],w=[{type:12,data:_},{type:12,data:d},{type:12,data:p},{type:12,data:m}];Hi(t,w),w.push(..._e(k,o,u)),b&&w.push(..._e(e[2].dims)),w.push(..._e($));let S=C=>{let I=mf("batch_dims",e[0].dataType,k.length),z=Z("a",e[0].dataType,o.length,g),E=Z("b",e[1].dataType,u.length,f),B=fe("output",e[0].dataType,$.length,f),U=ct(B.type.tensor),V=Fi(t,B.type.value,U),W=[z,E],J="";if(b){let ue=a?f:1;W.push(Z("bias",e[2].dataType,e[2].dims.length,ue)),J=`${a?`value += bias[col / ${ue}];`:`value += ${B.type.value}(bias[row + i]);`}`}let D=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];Ki(t,D);let se=()=>{let ue=`var a_data: ${z.type.value};`;for(let F=0;F<g;F++)ue+=`
              let b_data${F} = b[(b_offset + (k + ${F}) * uniforms.N + col) / ${f}];`;for(let F=0;F<v;F++){ue+=`a_data = a[(a_offset + (row + ${F}) * uniforms.K + k) / ${g}];`;for(let oe=0;oe<g;oe++)ue+=`
            values[${F}] = fma(${E.type.value}(a_data${g===1?"":`[${oe}]`}), b_data${oe}, values[${F}]);
`}return ue};return`
  ${C.registerUniforms(D).registerInternalVariables(I).declareVariables(...W,B)}
  ${C.mainStart()}
    ${C.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${f})) * ${f};
    var index1 = global_idx / (uniforms.N / ${f});
    let stride1 = uniforms.M / ${v};
    let row = (index1 % stride1) * ${v};
    let batch = index1 / stride1;

    ${r.length===2?"":`let batch_indices = ${I.offsetToIndices("batch")};`}

    var a_indices: ${z.type.indices};
    ${ro("a_indices",z,z.rank-2,I.rank,"batch_indices")}
    ${z.indicesSet("a_indices",z.rank-2,0)}
    ${z.indicesSet("a_indices",z.rank-1,0)}
    let a_offset = ${z.indicesToOffset("a_indices")};

    var b_indices: ${E.type.indices};
    ${ro("b_indices",E,E.rank-2,I.rank,"batch_indices")}
    ${E.indicesSet("b_indices",E.rank-2,0)}
    ${E.indicesSet("b_indices",E.rank-1,0)}
    let b_offset = ${E.indicesToOffset("b_indices")};
    var values: array<${B.type.value}, ${v}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${g}) {
      ${se()}
    }
    for (var i = 0u; i < ${v}u; i++) {
      var value = values[i];
      ${J}
      ${V}
      let cur_indices = ${B.type.indices}(batch, row + i, col);
      let offset = ${B.indicesToOffset("cur_indices")};
      ${B.setByOffset(`offset / ${f}`,"value")};
    }
  }
  `};return{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${f};${g};${v};${a}`,inputDependencies:b?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(_/64)},programUniforms:w}),getShaderSource:S}}}),xf=te(()=>{"use strict";$e(),Ce(),ze(),Qi(),$f(),wf(),A$=(e,t)=>e?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${t?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${t?", batchIndices":""});
        `,O$=(e,t)=>e?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${t===3?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${t===3?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`,Hh=(e,t,r="f32",i,a=!1,s=32,o=!1,u=32)=>{let d=t[1]*e[1],p=t[0]*e[0],m=a?d:s,f=a?s:d,g=m/t[0],v=s/t[1];if(!((a&&g===4&&e[1]===4||!a&&(g===3||g===4))&&m%t[0]===0&&s%t[1]===0&&e[0]===4))throw new Error(`If transposeA ${a} is true, innerElementSize ${g} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${g} must be 3 or 4.
  tileAWidth ${m} must be divisible by workgroupSize[0]${t[0]}. tileInner ${s} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${g}<${r}>, ${m/g}>, ${f}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${p/e[0]}>, ${s}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${g};
const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${o?"0":"i32(globalId.z)"};
  ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${d};

  let num_tiles = ${o?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${o?`i32(globalId.z) * ${u}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${v};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${A$(a,i)}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${v}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${i?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${g===3?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${O$(a,g)}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},lh=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,R$=e=>e?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];",Kh=(e,t,r="f32",i,a=!1,s=32,o=!1,u=32,d=!1)=>{let p=e[1]*t[1],m=e[0]*t[0],f=a?p:s,g=a?s:p;if(!(g%t[1]===0&&f%t[0]===0&&s%t[1]===0))throw new Error(`tileAHight ${g} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${f} must be divisible by workgroupSize[0]${t[0]}, tileInner ${s} must be divisible by workgroupSize[1]${t[1]}`);let v=g/t[1],_=f/t[0],b=s/t[1],k=d?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${p};
    let globalColStart = i32(workgroupId.x) * ${m};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${g}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${f}; inputCol = inputCol + ${t[0]}) {
          ${lh(a,i)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${s}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${m}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${i?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${a?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${p};

let tileRowA = i32(localId.y) * ${v};
let tileColA = i32(localId.x) * ${_};
let tileRowB = i32(localId.y) * ${b};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${v}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${_}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${lh(a,i)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${b}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${i?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${R$(a)}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${f}>, ${g}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${m}>, ${s}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${s};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${o?"0":"i32(globalId.z)"};
    ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${o?`${Math.ceil(u/s)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${o?`i32(globalId.z) * ${u}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${k}
  }
`},B$=(e,t,r,i,a=!1)=>{let[s,o,u,d]=i,p=ct(i[0].type.tensor);return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${ft(e,p)} {
      var value = ${ft(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        var aIndices: ${o.type.indices};
        ${ro("aIndices",o,o.rank-2,s.rank,"batchIndices")}
        ${o.indicesSet("aIndices",o.rank-2,"u32(row)")}
        ${o.indicesSet("aIndices",o.rank-1,"u32(colIn)")}
        value = ${o.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${s.type.indices}) -> ${ft(e,p)} {
      var value = ${ft(e,p)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        var bIndices: ${u.type.indices};
        ${ro("bIndices",u,u.rank-2,s.rank,"batchIndices")}
        ${u.indicesSet("bIndices",u.rank-2,"u32(row)")}
        ${u.indicesSet("bIndices",u.rank-1,"u32(colIn)")}
        value = ${u.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${ft(e,p)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${a?"bias[colIn]":`${ft(e,p)}(bias[row])`};`:""}
        ${r}
        ${d.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `},$u=(e,t,r,i,a=!1,s)=>{let o=e[0].dims,u=e[1].dims,d=o.slice(0,-2),p=u.slice(0,-2),m=i?i.slice(0,-2):r.slice(0,-2),f=G.size(m),g=o[o.length-2],v=o[o.length-1],_=u[u.length-1],b=v%4===0&&_%4===0,k=g<=8?[4,1,1]:[4,4,1],$=[8,8,1],w=[Math.ceil(_/$[0]/k[0]),Math.ceil(g/$[1]/k[1]),Math.ceil(f/$[2]/k[2])],S=b?4:1,C=[...d,g,v/S],I=C.length,z=[...p,v,_/S],E=z.length,B=[f,g,_/S],U=[{type:6,data:g},{type:6,data:_},{type:6,data:v}];Hi(t,U),U.push(..._e(m,C,z));let V=["rank","rank"],W=e.length>2;W&&(U.push(..._e(e[2].dims)),V.push("rank")),U.push(..._e(B));let J=D=>{let se=m.length,ue=mf("batchDims",e[0].dataType,se,1),F=ct(e[0].dataType),oe=Z("a",e[0].dataType,I,S),le=Z("b",e[1].dataType,E,S),H=fe("result",e[0].dataType,B.length,S),de=[oe,le];if(W){let Ie=a?S:1;de.push(Z("bias",e[2].dataType,e[2].dims.length,Ie))}let M=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];Ki(t,M);let q=ct(H.type.tensor),R=Fi(t,H.type.value,q),X=B$(S,W,R,[ue,oe,le,H],a);return`
  ${D.registerUniforms(M).registerInternalVariables(ue).declareVariables(...de,H)}
  ${X}
  ${b?Hh(k,$,F,ue):Kh(k,$,F,ue)}
                   `};return{name:"MatMul",shaderCache:{hint:`${k};${t.activation};${b};${a}`,inputDependencies:V},getRunData:()=>({outputs:[{dims:s?s(r):r,dataType:e[0].dataType}],dispatchGroup:{x:w[0],y:w[1],z:w[2]},programUniforms:U}),getShaderSource:J}}}),vI=te(()=>{"use strict";$e(),Ur(),ze(),Qi(),wf(),_I(),xf(),N$=(e,t,r,i,a=!1,s,o=4,u=4,d=4,p="f32")=>{let m=U=>{switch(U){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${p}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw new Error(`innerElementSize ${U} is not supported.`)}},f=U=>{switch(U){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw new Error(`innerElementSize ${U} is not supported.`)}},g=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,v=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,_=e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])",b=e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])",k=e?"row":"col",$=e?"col":"row",w=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${k} / outWidth;
    let outCol = ${k} % outWidth;

    let WRow = ${$} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${$} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${$} % inChannels;
    var resData = ${ft(o,p)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${_} && xCol >= 0 && xCol < ${b}) {
      ${g}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${m(o)}
    }
    return resData;`,S=e?t&&i?`
    let col = colIn * ${o};
    ${w}`:`
    let col = colIn * ${o};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${w}
    }
    return ${ft(o,p)}(0.0);`:i&&r?`
    let col = colIn * ${o};
    ${w}`:`
    let col = colIn * ${o};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${w}
    }
    return ${ft(o,p)}(0.0);`,C=e?i&&r?f(u):`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${f(u)}
    }
    return ${ft(u,p)}(0.0);`:`
    let col = colIn * ${u};
    if (row < uniforms.dim_inner && col < uniforms.dim_a_outer) {
      ${f(u)}
    }
    return ${ft(u,p)}(0.0);`,I=ft(d,p),z=ft(e?o:u,p),E=ft(e?u:o,p),B=Fi(s,I,p);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${z} {
      ${e?S:C}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${E} {
      ${e?C:S}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${I}) {
      let col = colIn * ${d};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${v}
      ${Z3(a)}
      ${B}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`},X3=(e,t,r,i,a,s,o,u,d)=>{let p=t.format==="NHWC",m=p?e[0].dims[3]:e[0].dims[1],f=r[0],g=p?r[2]:r[3],v=p?r[1]:r[2],_=p?r[3]:r[1],b=p&&(m%4===0||m%3===0)&&_%4===0,k=p?_:g*v,$=p?g*v:_,w=[8,8,1],S=i<=8?[4,1,1]:[4,4,1],C=[Math.ceil(k/w[0]/S[0]),Math.ceil($/w[1]/S[1]),Math.ceil(f/w[2]/S[2])];Me("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${C}`);let I=b?p&&m%4!==0?3:4:1,z=w[1]*S[1],E=w[0]*S[0],B=Math.max(w[0]*I,w[1]),U=i%z===0,V=a%E===0,W=s%B===0,J=b?[I,4,4]:[1,1,1],D=[{type:6,data:i},{type:6,data:a},{type:6,data:s},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];Hi(t,D),D.push(..._e(e[0].dims,e[1].dims));let se=["rank","rank"];o&&(D.push(..._e(e[2].dims)),se.push("rank")),D.push(..._e(r));let ue=F=>{let oe=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];Ki(t,oe);let le=b?4:1,H=ct(e[0].dataType),de=`
      fn setOutputAtIndex(flatIndex : i32, value : ${b?`vec4<${H}>`:H}) {
        result[flatIndex] = ${b?`vec4<${H}>`:H}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${b?`vec4<${H}>`:H}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${b?"/ 4":""}, value);
      }`,M=Z("x",e[0].dataType,e[0].dims.length,I===3?1:I),q=Z("w",e[1].dataType,e[1].dims.length,le),R=[M,q],X=fe("result",e[0].dataType,r.length,le);if(o){let Ie=Z("bias",e[2].dataType,e[2].dims.length,le);R.push(Ie),de+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${b?`vec4<${H}>`:H} {
          return bias[coords.${p?"w":"y"}${b?"/ 4":""}];
        }`}return`
        ${Q3("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${F.registerUniforms(oe).declareVariables(...R,X)}
        ${de}
        ${N$(p,U,V,W,o,t,J[0],J[1],J[2],H)}
        ${b?Hh(S,w,H,void 0,!p,B):Kh(S,w,H,void 0,!p,B,!1,void 0,u)}`};return{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${I};${b};${U};${V};${W};${z};${E};${B}`,inputDependencies:se},getRunData:()=>({outputs:[{dims:d?d(r):r,dataType:e[0].dataType}],dispatchGroup:{x:C[0],y:C[1],z:C[2]},programUniforms:D}),getShaderSource:ue}}}),wI=te(()=>{"use strict";$e(),Ur(),Ce(),ze(),Qi(),wf(),M$=e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t},dh=e=>typeof e=="number"?[e,e,e]:e,Fs=(e,t)=>t<=1?e:e+(e-1)*(t-1),D$=(e,t,r,i=1)=>{let a=Fs(t,i);return Math.floor((e[0]*(r-1)-r+a)/2)},ph=(e,t,r,i,a)=>{a==null&&(a=D$(e,t[0],i[0]));let s=[0,0,0,r];for(let o=0;o<3;o++)e[o]+2*a>=t[o]&&(s[o]=Math.trunc((e[o]-t[o]+2*a)/i[o]+1));return s},P$=(e,t,r,i,a,s,o,u,d,p)=>{let m,f,g,v;if(e==="VALID"&&(e=0),typeof e=="number"){m={top:e,bottom:e,left:e,right:e,front:e,back:e};let _=ph([t,r,i,1],[u,d,p],1,[a,s,o],e);f=_[0],g=_[1],v=_[2]}else if(Array.isArray(e)){if(!e.every((b,k,$)=>b===$[0]))throw Error(`Unsupported padding parameter: ${e}`);m={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let _=ph([t,r,i,1],[u,d,p],1,[a,s,o],e[0]);f=_[0],g=_[1],v=_[2]}else if(e==="SAME_UPPER"){f=Math.ceil(t/a),g=Math.ceil(r/s),v=Math.ceil(i/o);let _=(f-1)*a+u-t,b=(g-1)*s+d-r,k=(v-1)*o+p-i,$=Math.floor(_/2),w=_-$,S=Math.floor(b/2),C=b-S,I=Math.floor(k/2),z=k-I;m={top:S,bottom:C,left:I,right:z,front:$,back:w}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:m,outDepth:f,outHeight:g,outWidth:v}},J3=(e,t,r,i,a,s=!1,o="channelsLast")=>{let u,d,p,m,f;if(o==="channelsLast")[u,d,p,m,f]=e;else if(o==="channelsFirst")[u,f,d,p,m]=e;else throw new Error(`Unknown dataFormat ${o}`);let[g,,v,_,b]=t,[k,$,w]=dh(r),[S,C,I]=dh(i),z=Fs(v,S),E=Fs(_,C),B=Fs(b,I),{padInfo:U,outDepth:V,outHeight:W,outWidth:J}=P$(a,d,p,m,k,$,w,z,E,B),D=s?g*f:g,se=[0,0,0,0,0];return o==="channelsFirst"?se=[u,D,V,W,J]:o==="channelsLast"&&(se=[u,V,W,J,D]),{batchSize:u,dataFormat:o,inDepth:d,inHeight:p,inWidth:m,inChannels:f,outDepth:V,outHeight:W,outWidth:J,outChannels:D,padInfo:U,strideDepth:k,strideHeight:$,strideWidth:w,filterDepth:v,filterHeight:_,filterWidth:b,effectiveFilterDepth:z,effectiveFilterHeight:E,effectiveFilterWidth:B,dilationDepth:S,dilationHeight:C,dilationWidth:I,inShape:e,outShape:se,filterShape:t}},Y3=(e,t,r,i,a,s)=>{let o=s==="channelsLast",u=o?e[0].dims[3]:e[0].dims[1],d=!1,p=[64,1,1],m={x:r.map((w,S)=>S)},f=[Math.ceil(M$(m.x.map(w=>r[w]))/p[0]),1,1];Me("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${f}`);let g=d?o&&u%4!==0?3:4:1,v=G.size(r),_=[{type:12,data:v},{type:12,data:i},{type:12,data:a},{type:12,data:t.strides},{type:12,data:t.dilations}];Hi(t,_),_.push(..._e(e[0].dims,e[1].dims));let b=["rank","rank"],k=e.length===3;k&&(_.push(..._e(e[2].dims)),b.push("rank")),_.push(..._e(r));let $=w=>{let S=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:i.length},{name:"pads",type:"u32",length:a.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];Ki(t,S);let C=d?4:1,I=ct(e[0].dataType),z=Z("x",e[0].dataType,e[0].dims.length,g===3?1:g),E=Z("W",e[1].dataType,e[1].dims.length,C),B=[z,E],U=fe("result",e[0].dataType,r.length,C),V="";if(k){let D=Z("bias",e[2].dataType,e[2].dims.length,C);B.push(D),V+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${d?`vec4<${I}>`:I} {
          return bias[${o?ge("coords",4,5):ge("coords",1,5)}${d?"/ 4":""}];
        }`}let W=ft(g,I),J=Fi(t,W,I);return`
            ${V}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${z.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${E.getByIndices("aIndices")};
            }
          ${w.registerUniforms(S).declareVariables(...B,U)}
          ${w.mainStart()}
          ${w.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${U.offsetToIndices("global_idx")};
              let batch = ${ge("coords",0,z.rank)};
              let d2 = ${o?ge("coords",z.rank-1,z.rank):ge("coords",1,z.rank)};
              let xFRCCorner = vec3<u32>(${o?ge("coords",1,z.rank):ge("coords",2,z.rank)},
              ${o?ge("coords",2,z.rank):ge("coords",3,z.rank)},
              ${o?ge("coords",3,z.rank):ge("coords",4,z.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${o?ge("uniforms.x_shape",1,z.rank):ge("uniforms.x_shape",2,z.rank)};
              let xShapeZ = ${o?ge("uniforms.x_shape",2,z.rank):ge("uniforms.x_shape",3,z.rank)};
              let xShapeW = ${o?ge("uniforms.x_shape",3,z.rank):ge("uniforms.x_shape",4,z.rank)};
              let xShapeU = ${o?ge("uniforms.x_shape",4,z.rank):ge("uniforms.x_shape",1,z.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = 0.0;
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${o?`let xValues = vec4<f32>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<f32>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<f32>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${o?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${o?`let xValues = vec2<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${o?`let xValues = vec3<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${k?"value = value + getBiasByOutputCoords(coords)":""};
              ${J}
              result[global_idx] = f32(value);
          }`};return{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${o};${g};${k}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:f[0],y:f[1],z:f[2]},programUniforms:_}),getShaderSource:$}}}),bI=te(()=>{"use strict";$e(),Ce(),ze(),Qi(),ek=(e,t,r,i)=>{let a=e.length>2,s=a?"value += b[output_channel];":"",o=e[0].dims,u=e[1].dims,d=t.format==="NHWC",p=d?r[3]:r[1],m=p/t.group,f=d&&m>=4?Ye(p):1,g=G.size(r)/f,v=[{type:12,data:g},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:m}];Hi(t,v),v.push(..._e(o,[u[0],u[1],u[2],u[3]/f]));let _=a?["rank","rank","rank"]:["rank","rank"];v.push(..._e([r[0],r[1],r[2],r[3]/f]));let b=k=>{let $=fe("output",e[0].dataType,r.length,f),w=ct($.type.tensor),S=Fi(t,$.type.value,w),C=Z("x",e[0].dataType,o.length),I=Z("w",e[1].dataType,u.length,f),z=[C,I];a&&z.push(Z("b",e[2].dataType,e[2].dims,f));let E=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];Ki(t,E);let B=d?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${C.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${I.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${C.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${I.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${k.registerUniforms(E).declareVariables(...z,$)}

  ${k.mainStart()}
    ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${$.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${d?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${d?1:2}], outputIndices[${d?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${f} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${d?2:1}];

    var value: ${$.type.value} = ${$.type.value}(0);
    ${B}
    ${s}
    ${S}
    ${$.setByOffset("global_idx","value")}
  }`};return{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${f}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:v}),getShaderSource:b}},tk=(e,t,r,i)=>{let a=e.length>2,s=Ye(r[3]),o=Ye(r[2]),u=G.size(r)/s/o,d=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/s],p=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/s],m=[r[0],r[1],r[2],r[3]/s],f=[{type:12,data:u},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];Hi(t,f),f.push(..._e(d,p,m));let g=(o-1)*t.strides[1]+p[1],v=_=>{let b=fe("output",e[0].dataType,m.length,s),k=ct(b.type.tensor),$=Fi(t,b.type.value,k),w=Z("x",e[0].dataType,d.length,s),S=Z("w",e[1].dataType,p.length,s),C=[w,S];a&&C.push(Z("b",e[2].dataType,e[2].dims,s));let I=a?"value += b[output_channel];":"",z=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return Ki(t,z),`
  ${_.registerUniforms(z).declareVariables(...C,b)}
  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${o}u;
    let col = (index1 % width1) * ${o}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${w.type.value}, ${g}>;
    var values: array<${b.type.value}, ${o}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${p[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${g}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${w.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${w.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${p[1]}; w_width++) {
          let w_val = ${S.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${o}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${o}u; i++) {
      var value = values[i];
      ${I}
      ${$}
      ${b.set("batch","row","col + i","output_channel","value")};
    }
  }`};return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${s};${o};${g};${p[0]};${p[1]}`,inputDependencies:a?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:f}),getShaderSource:v}}}),$I=te(()=>{"use strict";Ce(),vI(),wI(),xf(),bI(),Qi(),$f(),Jr(),U$=(e,t,r,i,a,s)=>{let o=e[0],u=e.slice(s?1:2,s?3:4),d=u.length,p=t[0],m=t.slice(2).map((g,v)=>g+(g-1)*(r[v]-1)),f=u.map((g,v)=>g+i[v]+i[v+d]).map((g,v)=>Math.floor((g-m[v]+a[v])/a[v]));return f.splice(0,0,o),f.splice(s?3:1,0,p),f},uu=[2,3,1,0],W$=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length>5)throw new Error("greater than 5D is not supported");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[1]*t.group;if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(e.length===3&&(e[2].dims.length!==1||e[1].dims[0]!==e[2].dims[0]))throw new Error("invalid bias");let a=e[0].dims.length-2;if(t.dilations.length!==a)throw new Error(`dilations should be ${a}D`);if(t.strides.length!==a)throw new Error(`strides should be ${a}D`);if(t.pads.length!==a*2)throw new Error(`pads should be ${a*2}D`);if(t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape")},lu=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let s=2;s<t[1].dims.length;++s)r[s-2]===0&&(r[s-2]=t[1].dims[s]);let i=e.pads.slice();wu.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,i,e.format==="NHWC",e.autoPad);let a=Object.assign({},e);return Object.assign(a,{kernelShape:r,pads:i}),a},Zh=e=>{let t=vf(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],a=e.dilations,s=e.group,o=e.kernel_shape,u=e.pads,d=e.strides,p=e.w_is_const();return{autoPad:i,format:r,dilations:a,group:s,kernelShape:o,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},ch=(e,t,r,i)=>{let a=r.format==="NHWC",s=U$(t[0].dims,t[1].dims,r.dilations,r.pads,r.strides,a);if(r.group!==1){let z=[t[0]];if(a){let E=e.kernelCustomData.wT??e.compute(Ut(t[1],uu),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=E),z.push(E)}else z.push(t[1]);t.length===3&&z.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&a&&t[1].dims[0]===r.group&&t[1].dims[1]===1&&r.dilations[0]===1&&r.dilations[1]===1?e.compute(tk(z,r,s,i),{inputs:z}):e.compute(ek(z,r,s,i),{inputs:z});return}let o=t.length===3,u=t[0].dims[a?1:2],d=t[0].dims[a?2:3],p=t[0].dims[a?3:1],m=t[1].dims[2],f=t[1].dims[3],g=s[a?1:2],v=s[a?2:3],_=s[a?3:1],b=a&&m===u&&f===d&&r.pads[0]===0&&r.pads[1]===0;if(b||m===1&&f===1&&r.dilations[0]===1&&r.dilations[1]===1&&r.strides[0]===1&&r.strides[1]===1&&r.pads[0]===0&&r.pads[1]===0){let z=s[0],E,B,U,V=[];if(a){let D=e.kernelCustomData.wT??e.compute(Ut(t[1],uu),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=D),b){let se=u*d*p;E=t[0].reshape([1,z,se]),B=D.reshape([1,se,_]),U=[1,z,_]}else E=t[0].reshape([z,u*d,p]),B=D.reshape([1,p,_]),U=[z,g*v,_];V.push(E),V.push(B)}else E=t[0].reshape([z,p,u*d]),B=t[1].reshape([1,_,p]),U=[z,_,g*v],V.push(B),V.push(E);o&&V.push(t[2]);let W=U[2],J=V[0].dims[V[0].dims.length-1];W<8&&J<8?e.compute(bf(V,r,s,U,a,i),{inputs:V}):e.compute($u(V,r,s,U,a,i),{inputs:V});return}let k=!0,$=e.kernelCustomData.wT??e.compute(Ut(t[1],uu),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=$);let w=[t[0],$];o&&w.push(t[2]);let S=a?g*v:_,C=a?_:g*v,I=m*f*p;e.compute(X3(w,r,s,S,C,I,o,k,i),{inputs:w})},V$=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=[0,t.pads[0],0,t.pads[1]],s=[1].concat(t.strides),o=[1].concat(t.dilations),u=[1].concat(t.kernelShape),d=lu({...t,pads:a,strides:s,dilations:o,kernelShape:u},i);ch(e,i,d,p=>r?[p[0],p[2],p[3]]:[p[0],p[1],p[3]])},q$=(e,t,r)=>{let i=r.format==="NHWC"?"channelsLast":"channelsFirst",a=lu(r,t),s=r.autoPad==="NOTSET"?r.pads:r.autoPad,o=J3(t[0].dims,t[1].dims,r.strides,r.dilations,s,!1,i);e.compute(Y3(t,a,o.outShape,[o.filterDepth,o.filterHeight,o.filterWidth],[o.padInfo.front,o.padInfo.top,o.padInfo.left],i))},Qh=(e,t)=>{if(W$(e.inputs,t),e.inputs[0].dims.length===3)V$(e,t);else if(e.inputs[0].dims.length===5)q$(e,e.inputs,t);else{let r=lu(t,e.inputs);ch(e,e.inputs,r)}}}),xI=te(()=>{"use strict";$e(),Ur(),Ce(),ze(),rk=(e,t,r)=>{let i=e.length>2,a=t.outputShape,s=t.format==="NHWC",o=t.group,u=e[1].dims,d=u[2]/o,p=u[3],m=s?Ye(d):1,f=s?Ye(p):1,g=s?p===1?m:f:1,v=G.size(a)/f,_=[Math.ceil(v/64),1,1];Me("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${_}`);let b=["rank","rank"],k=[t.strides[0],t.strides[1]],$=[t.kernelShape[s?1:2],t.kernelShape[s?2:3]],w=[t.dilations[0],t.dilations[1]],S=[$[0]+(t.dilations[0]<=1?0:(t.kernelShape[s?1:2]-1)*(t.dilations[0]-1)),$[1]+(t.dilations[1]<=1?0:(t.kernelShape[s?2:3]-1)*(t.dilations[1]-1))],C=[S[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),S[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],I=[{type:12,data:v},{type:12,data:k},{type:12,data:$},{type:12,data:w},{type:12,data:S},{type:6,data:C},{type:12,data:d},{type:12,data:p},..._e(e[0].dims,e[1].dims)];i&&(I.push(..._e(e[2].dims)),b.push("rank")),I.push(..._e(a));let z=E=>{let B=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:k.length},{name:"filter_dims",type:"u32",length:$.length},{name:"dilations",type:"u32",length:$.length},{name:"effective_filter_dims",type:"u32",length:S.length},{name:"pads",type:"i32",length:C.length},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],U=ct(e[0].dataType),V=s?1:2,W=s?2:3,J=s?3:1,D=Z("W",e[1].dataType,e[1].dims.length,g),se=Z("Dy",e[0].dataType,e[0].dims.length,m),ue=[se,D];i&&ue.push(Z("bias",e[2].dataType,[a[J]].length,f));let F=fe("result",e[0].dataType,a.length,f),oe=()=>{let H="";if(m===1)H+=`
        let w_offset = ${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)};
        let wValue = ${D.getByOffset(`w_offset / ${g}`)};
        dotProd = dotProd + xValue * wValue;`;else if(p===1)H+=`
          let wValue = ${D.getByOffset(`${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)} / ${g}`)};
          dotProd = dotProd + dot(xValue, wValue);`;else for(let de=0;de<m;de++)H+=`
            let wValue${de} = ${D.getByOffset(`${D.indicesToOffset(`${D.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel + ${de}, wOutChannel)`)} / ${g}`)};
            dotProd = dotProd + xValue[${de}] * wValue${de};`;return H},le=`
            let outputIndices = ${F.offsetToIndices(`global_idx * ${f}`)};
            let batch = ${F.indicesGet("outputIndices",0)};
            let d1 = ${F.indicesGet("outputIndices",J)};
            let r = ${F.indicesGet("outputIndices",V)};
            let c = ${F.indicesGet("outputIndices",W)};
            let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
            let dyRCorner = dyCorner.x;
            let dyCCorner = dyCorner.y;
            let groupId = d1 / uniforms.output_channels_per_group;
            let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
            // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
            // ? = to be determined. : = across all values in that axis.
            var dotProd = ${F.type.value}(0.0);
            var wR: u32 = 0;
            if (uniforms.dilations.x == 1) {
              // Minimum wR >= 0 that satisfies (dyRCorner + wR) % (uniforms.strides.x) == 0
              wR = u32(((dyRCorner + i32(uniforms.strides.x) - 1) / i32(uniforms.strides.x)) * i32(uniforms.strides.x) - dyRCorner);
            }
            for (; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
              if (wR % uniforms.dilations.x != 0) {
                continue;
              }
              let dyR = (${U}(dyRCorner) + ${U}(wR)) / ${U}(uniforms.strides[0]);
              let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
              if (dyR < 0.0 || dyR >= ${U}(uniforms.Dy_shape[${V}]) || fract(dyR) > 0.0 ||
                  wRPerm < 0) {
                continue;
              }
              let idyR: u32 = u32(dyR);
              var wC: u32 = 0;
              if (uniforms.dilations.y == 1) {
                // Minimum wC >= 0 that satisfies (dyCCorner + wC) % (uniforms.strides.y) == 0
                wC = u32(((dyCCorner + i32(uniforms.strides.y) - 1) / i32(uniforms.strides.y)) * i32(uniforms.strides.y) - dyCCorner);
              }

              for (; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
                if (wC % uniforms.dilations.y != 0) {
                  continue;
                }
                let dyC = (${U}(dyCCorner) + ${U}(wC)) / ${U}(uniforms.strides.y);
                let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
                if (dyC < 0.0 || dyC >= ${U}(uniforms.Dy_shape[${W}]) ||
                    fract(dyC) > 0.0 || wCPerm < 0) {
                  continue;
                }
                let idyC: u32 = u32(dyC);
                var inputChannel = groupId * uniforms.input_channels_per_group;
                for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group; d2 = d2 + ${m}) {
                  let xValue = ${s?se.getByOffset(`${se.indicesToOffset(`${se.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${m}`):se.get("batch","inputChannel","idyR","idyC")};
                  ${oe()}
                  inputChannel = inputChannel + ${m};
                }
                wC = wC + uniforms.strides.y - 1;
              }
              wR = wR + uniforms.strides[0] - 1;
            }
            let value = dotProd${i?` + bias[d1 / ${f}]`:""};
            ${F.setByOffset("global_idx","value")};
          `;return`
    ${E.registerUniforms(B).declareVariables(...ue,F)}
      ${E.mainStart()}
      ${E.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
    ${le}}`};return{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};${m}${g}${f}${p===1}`,inputDependencies:b},getRunData:()=>({dispatchGroup:{x:_[0],y:_[1],z:_[2]},outputs:[{dims:r?r(a):a,dataType:e[0].dataType}],programUniforms:I}),getShaderSource:z}}}),kI=te(()=>{"use strict";xI(),Qi(),Jr(),j$=(e,t,r,i,a,s)=>(e-1)*t+r+(i-1)*a+1-s,L$=(e,t,r,i,a)=>{let s=Math.floor(e/2);t==="SAME_UPPER"?(r[i]=s,r[a]=e-s):t==="SAME_LOWER"&&(r[i]=e-s,r[a]=s)},G$=(e,t,r,i,a,s,o,u,d,p)=>{let m=e.length-2,f=p.length===0;d.length<m&&d.push(...Array(m-d.length).fill(0));let g=e[0],v=t[u?3:1]*a;for(let _=0,b=e.length-m-(u?1:0);_<m;++_,++b){let k=e[b],$=f?k*o[_]:p[_],w=j$(k,o[_],s[_],t[b],r[_],$);L$(w,i,s,_,_+m),f&&p.push(o[_]*(k-1)+d[_]+(t[b]-1)*r[_]+1-s[_]-s[_+m])}p.splice(0,0,g),p.splice(u?3:1,0,v)},hh=(e,t)=>{let r=e.kernelShape.slice();if(e.kernelShape.length===0||e.kernelShape.reduce((f,g)=>f*g,1)===0){r.length=0;for(let f=2;f<t[1].dims.length;++f)r.push(t[1].dims[f])}let i=e.format==="NHWC";r.splice(0,0,t[1].dims[0]),r.splice(i?3:1,0,t[1].dims[1]);let a=e.pads.slice(),s=e.outputShape.slice(),o=e.outputPadding.slice(),u=t[0].dims,d=e.dilations.slice();if(d.reduce((f,g)=>f+g,0)===0){let f=t[0].dims.length-2;d=new Array(f).fill(1)}let p=e.strides.slice();if(p.reduce((f,g)=>f+g,0)===0){let f=t[0].dims.length-2;p=new Array(f).fill(1)}G$(u,r,d,e.autoPad,e.group,a,p,i,o,s);let m=Object.assign({},e);return Object.assign(m,{kernelShape:r,pads:a,outputPadding:o,outputShape:s,dilations:d,strides:p}),m},ik=e=>{let t=vf(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][typeof e.autoPad>"u"?0:e.autoPad],a=e.dilations,s=e.group,o=e.kernelShape,u=e.pads,d=e.strides,p=e.wIsConst(),m=e.outputPadding,f=e.outputShape;return{autoPad:i,format:r,dilations:a,group:s,kernelShape:o,outputPadding:m,outputShape:f,pads:u,strides:d,wIsConst:p,...t,cacheKey:`${e.format};${t.activation};`}},F$=(e,t)=>{if(!e||e.length!==2&&e.length!==3)throw new Error("Conv requires 2 or 3 inputs");if(e[0].dims.length!==4&&e[0].dims.length!==3)throw new Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw new Error("filter does not have same dimension as input");let r=e[0].dims[t.format==="NHWC"?e[0].dims.length-1:1],i=e[1].dims[0];if(r!==i)throw new Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let a=e[1].dims[1]*t.group;if(e.length===3&&(e[2].dims.length!==1||e[2].dims[0]!==a))throw new Error("invalid bias");let s=e[0].dims.length-2;if(t.dilations.reduce((o,u)=>o+u,0)>0&&t.dilations.length!==s)throw new Error(`dilations should be ${s}D`);if(t.strides.reduce((o,u)=>o+u,0)>0&&t.strides.length!==s)throw new Error(`strides should be ${s}D`);if(t.pads.reduce((o,u)=>o+u,0)>0&&t.pads.length!==s*2)throw new Error(`pads should be ${s*2}D`);if(t.outputPadding.length!==s&&t.outputPadding.length!==0)throw new Error(`output_padding should be ${s}D`);if(t.kernelShape.reduce((o,u)=>o+u,0)>0&&t.kernelShape.length!==0&&t.kernelShape.length!==e[1].dims.length-2)throw new Error("invalid kernel shape");if(t.outputShape.length!==0&&t.outputShape.length!==e[0].dims.length-2)throw new Error("invalid output shape")},fh=(e,t,r,i)=>{let a=e.kernelCustomData.wT??e.compute(Ut(t[1],[2,3,0,1]),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=a);let s=[t[0],a];t.length===3&&s.push(t[2]),e.compute(rk(s,r,i),{inputs:s})},H$=(e,t)=>{let r=t.format==="NHWC",i=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])];e.inputs.length===3&&i.push(e.inputs[2]);let a=t.kernelShape;(a.length===0||a[0]===0)&&(a=[e.inputs[1].dims[2]]);let s=t.dilations;(s.length===0||s[0]===0)&&(s=[1]);let o=t.strides;(o.length===0||o[0]===0)&&(o=[1]);let u=t.pads;u.length===0&&(u=[0,0]),u=[0,u[0],0,u[1]],o=[1].concat(o),s=[1].concat(s),a=[1].concat(a);let d=t.outputPadding;d=[0].concat(d);let p=hh({...t,pads:u,strides:o,dilations:s,kernelShape:a,outputPadding:d},i);fh(e,i,p,m=>r?[m[0],m[2],m[3]]:[m[0],m[1],m[3]])},ak=(e,t)=>{if(F$(e.inputs,t),e.inputs[0].dims.length===3)H$(e,t);else{let r=hh(t,e.inputs);fh(e,e.inputs,r)}}}),SI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),K$=(e,t,r,i)=>{let a=G.size(t),s=t.length,o=Z("input",e,s),u=fe("output",e,s),d=r.dataType===6?r.getInt32Array()[0]:Number(r.getBigInt64Array()[0]),p=G.normalizeAxis(d,s),m=f=>{let g=` i32(${o.indicesGet("inputIndices","uniforms.axis")}) `,v=ge("uniforms.input_shape","uniforms.axis",s),_=i.reverse?g+(i.exclusive?" + 1":""):"0",b=i.reverse?v:g+(i.exclusive?"":" + 1");return`
                ${f.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(o,u)}
                ${f.mainStart()}
                  ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${u.offsetToIndices("global_idx")};
                  var sum = ${u.type.value}(0);
                  let first : i32 = ${_};
                  let last : i32 = ${b};
                  for (var i : i32 = first; i < last; i++) {
                    ${o.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${o.getByIndices("inputIndices")};
                  }
                  ${u.setByOffset("global_idx","sum")};
                }`};return{name:"CumSum",shaderCache:{hint:i.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:t,dataType:e}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:[{type:12,data:a},{type:12,data:p},..._e(t,t)]}),getShaderSource:m}},nk=(e,t)=>{let r=e.inputs[0].dims,i=e.inputs[0].dataType,a=e.inputs[1];e.compute(K$(i,r,a,t),{inputs:[0]})},sk=e=>{let t=e.exclusive===1,r=e.reverse===1;return Le({exclusive:t,reverse:r})}}),TI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),Z$=e=>{if(!e||e.length!==1)throw new Error("DepthToSpace requires 1 input.");if(e[0].dims.length!==4)throw new Error("DepthToSpace requires 4D input.")},Q$=(e,t,r,i)=>{let a=[];a.push(`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let s=0;s<t;++s)a.push(r.indicesSet("a",e[s],`i[${s}]`));return a.push("return a;}"),a.join(`
`)},X$=(e,t)=>{let r,i,a,s,o,u,d=t.format==="NHWC",p=t.blocksize,m=t.mode==="DCR";d?([r,i,a,s]=e.dims,o=m?[r,i,a,p,p,s/p**2]:[r,i,a,s/p**2,p,p],u=m?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([r,i,a,s]=[e.dims[0],e.dims[2],e.dims[3],e.dims[1]],o=m?[r,p,p,s/p**2,i,a]:[r,s/p**2,p,p,i,a],u=m?[0,3,4,1,5,2]:[0,1,4,2,5,3]);let f=e.reshape(o),g=f.dims.length,v=e.dataType,_=Z("a",v,g),b=fe("output",v,g),k=$=>`
  ${$.registerUniform("output_size","u32").declareVariables(_,b)}

  ${Q$(u,g,_,b)}

  ${$.mainStart()}
    ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${b.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${b.setByOffset("global_idx",_.getByIndices("aIndices"))}
  }`;return{name:"DepthToSpace",shaderCache:{hint:`${e.dims};${t.blocksize};${t.mode}`,inputDependencies:["rank"]},getRunData:$=>{let w=d?[r,i*p,a*p,s/p**2]:[r,s/p**2,i*p,a*p],S=G.size(w),C=f.dims,I=G.sortBasedOnPerm(C,u);return{outputs:[{dims:w,dataType:$[0].dataType}],dispatchGroup:{x:Math.ceil(S/64)},programUniforms:[{type:12,data:S},..._e(C,I)]}},getShaderSource:k}},ok=(e,t)=>{Z$(e.inputs),e.compute(X$(e.inputs[0],t))},uk=e=>Le({blocksize:e.blocksize,mode:e.mode,format:e.format})}),CI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),du="[a-zA-Z]|\\.\\.\\.",Hs="("+du+")+",mh="^"+Hs+"$",J$="("+Hs+",)*"+Hs,Y$="^"+J$+"$",e1=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);r===void 0?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},t1=class{constructor(e,t){this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=new Array,this.outputDims=[];let[r,i]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(Y$)))throw new Error("Invalid LHS term");if(r.split(",").forEach((a,s)=>{let o=e[s].dims.slice();if(!a.match(RegExp(mh)))throw new Error("Invalid LHS term");let u=this.processTerm(a,!0,o,s);this.lhs.push(u)}),i==="")i+=[...this.symbolToInfo.entries()].filter(([a,s])=>s.count===1||a==="...").map(([a])=>a).join("");else if(!i.match(RegExp(Hs)))throw new Error("Invalid RHS");i.match(RegExp(du,"g"))?.forEach(a=>{if(a==="...")this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let s=this.symbolToInfo.get(a);if(s===void 0)throw new Error("Invalid RHS symbol");this.outputDims.push(s.dimValue)}}),this.rhs=this.processTerm(i,!1,this.outputDims)}addSymbol(e,t,r){let i=this.symbolToInfo.get(e);if(i!==void 0){if(i.dimValue!==t&&i.count!==1)throw new Error("Dimension mismatch");i.count++,i.inputIndices.push(r)}else i={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,i)}processTerm(e,t,r,i=-1){let a=r.length,s=!1,o=[],u=0;if(!e.match(RegExp(mh))&&!t&&e!=="")throw new Error("Invalid LHS term");let d=e.match(RegExp(du,"g")),p=new e1(i);return d?.forEach((m,f)=>{if(m==="..."){if(s)throw new Error("Only one ellipsis is allowed per input term");s=!0;let g=a-d.length+1;if(g<0)throw new Error("Ellipsis out of bounds");if(o=r.slice(u,u+g),this.hasEllipsis){if(this.ellipsisDims.length!==o.length||this.ellipsisDims.toString()!==o.toString())throw new Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=o;else throw new Error("Ellipsis must be specified in the LHS");for(let v=0;v<o.length;v++){let _=String.fromCharCode(48+v);p.addSymbol(_,f+v),this.addSymbol(_,r[u++],i)}}else p.addSymbol(m,f+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(m,r[u++],i)}),p}},gh=e=>e+"_max",r1=(e,t,r,i)=>{let a=e.map(p=>p.length).map((p,m)=>Z(`input${m}`,t,p)),s=G.size(i),o=fe("output",t,i.length),u=[...r.symbolToInfo.keys()].filter(p=>!r.rhs.symbolToIndices.has(p)),d=p=>{let m=[],f="var prod = 1.0;",g="var sum = 0.0;",v="sum += prod;",_=[],b=[],k=[],$=[],w=r.symbolToInfo.size===r.rhs.symbolToIndices.size;r.symbolToInfo.forEach((C,I)=>{if(r.rhs.symbolToIndices.has(I)){let z=r.rhs.symbolToIndices.get(I)?.[0];z!==void 0&&r.lhs.forEach((E,B)=>{if(C.inputIndices.includes(B)){let U=E.symbolToIndices.get(I);if(U===void 0)throw new Error("Invalid symbol error");U.forEach(V=>{m.push(`${a[B].indicesSet(`input${B}Indices`,V,o.indicesGet("outputIndices",z))}`)})}})}else r.lhs.forEach((z,E)=>{if(C.inputIndices.includes(E)){let B=z.symbolToIndices.get(I);if(B===void 0)throw new Error("Invalid symbol error");B.forEach(U=>{_.push(`${a[E].indicesSet(`input${E}Indices`,U,`${I}`)}`)}),$.push(`prod *= ${a[E].getByIndices(`input${E}Indices`)};`)}}),b.push(`for(var ${I}: u32 = 0; ${I} < uniforms.${gh(I)}; ${I}++) {`),k.push("}")});let S=w?[...m,`let sum = ${a.map((C,I)=>C.getByIndices(`input${I}Indices`)).join(" * ")};`]:[...m,g,...b,..._,f,...$,v,...k];return`
            ${p.registerUniforms(u.map(C=>({name:`${gh(C)}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...a,o)}

            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${o.offsetToIndices("global_idx")};
            ${a.map((C,I)=>`var input${I}Indices: ${a[I].type.indices};`).join(`
`)}
            ${S.join(`
`)};
            ${o.setByOffset("global_idx","sum")};
          }`};return{name:"Einsum",shaderCache:{hint:r.equation,inputDependencies:e.map(()=>"rank")},getRunData:()=>{let p=u.filter(f=>r.symbolToInfo.has(f)).map(f=>({type:12,data:r.symbolToInfo.get(f)?.dimValue||0}));p.push({type:12,data:s});let m=e.map((f,g)=>[..._e(f)]).reduce((f,g)=>f.concat(g),p);return m.push(..._e(i)),{outputs:[{dims:i,dataType:t}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:m}},getShaderSource:d}},lk=(e,t)=>{let r=new t1(e.inputs,t.equation),i=r.outputDims,a=e.inputs.map((s,o)=>s.dims);e.compute(r1(a,e.inputs[0].dataType,r,i))},dk=e=>{let t=e.equation.replace(/\s+/g,"");return Le({equation:t})}}),II=te(()=>{"use strict";$e(),Ce(),ze(),i1=e=>{if(!e||e.length!==2)throw new Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=r.length<t.length?0:r.length-t.length,a=t.length<r.length?0:t.length-r.length;for(;i<r.length&&a<t.length;++i,++a)if(r[i]!==t[a]&&r[i]!==1&&t[a]!==1)throw new Error("Expand requires shape to be broadcastable to input")},yh=(e,t)=>{let r=e.length-t.length,i=[];for(let a=0;a<r;++a)i.push(e[a]);for(let a=0;a<t.length;++a)i.push(t[a]===1?e[a+r]:t[a]);return i},a1=(e,t)=>e.length>t.length?yh(e,t):yh(t,e),n1=e=>{let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=a1(t,r),a=e[0].dataType,s=a===9||G.size(t)===1,o=a===9||t.length>0&&t[t.length-1]%4===0?4:1,u=s||i.length>0&&i[i.length-1]%4===0?4:1,d=Math.ceil(G.size(i)/u),p=f=>{let g=Z("input",a,t.length,o),v=fe("output",a,i.length,u),_;if(a===9){let b=(k,$,w="")=>`
          let outputIndices${$} = ${v.offsetToIndices(`outputOffset + ${$}u`)};
          let offset${$} = ${g.broadcastedIndicesToOffset(`outputIndices${$}`,v)};
          let index${$} = offset${$} / 4u;
          let component${$} = offset${$} % 4u;
          ${k}[${$}] = ${w}(${g.getByOffset(`index${$}`)}[component${$}]);
        `;_=`
        let outputOffset = global_idx * ${u};
        var data = vec4<u32>(0);
        ${b("data",0,"u32")}
        ${b("data",1,"u32")}
        ${b("data",2,"u32")}
        ${b("data",3,"u32")}
        ${v.setByOffset("global_idx","data")}
      }`}else _=`
        let outputIndices = ${v.offsetToIndices(`global_idx * ${u}`)};
        let inputOffset = ${g.broadcastedIndicesToOffset("outputIndices",v)};
        let data = ${v.type.value}(${g.getByOffset(`inputOffset / ${o}`)});
        ${v.setByOffset("global_idx","data")}
      }`;return`
    ${f.registerUniform("vec_size","u32").declareVariables(g,v)}
    ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${_}`},m=[{type:12,data:d},..._e(t,i)];return{name:"Expand",shaderCache:{hint:`${i.length};${o}${u}`,inputDependencies:["rank"]},getShaderSource:p,getRunData:()=>({outputs:[{dims:i,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:m})}},pk=e=>{i1(e.inputs),e.compute(n1(e.inputs),{inputs:[0]})}}),EI=te(()=>{"use strict";$e(),Ce(),ze(),_f(),s1=e=>{let t=e[0].dataType,r=G.size(e[0].dims),i=G.size(e[1].dims),a=i%4===0,s=o=>{let u=Z("x",t,[1],4),d=Z("bias",t,[1],4),p=fe("y",t,[1],4),m=[{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}],f=v=>`
      let bias${v}_offset: u32 = (global_idx * 4 + ${v}) % uniforms.bias_size;
      let bias${v} = ${d.getByOffset(`bias${v}_offset / 4`)}[bias${v}_offset % 4];`,g=a?`
      let bias = ${d.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${f(0)}${f(1)}${f(2)}${f(3)}
      let bias = ${u.type.value}(bias0, bias1, bias2, bias3);`;return`${o.registerUniforms(m).declareVariables(u,d,p)}

    ${Gh(kt(t))}

    ${o.mainStart(la)}
      ${o.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${u.getByOffset("global_idx")};
      ${g}
      let x_in = x + bias;
      ${p.setByOffset("global_idx",Fh("x_in"))}
    }`};return{name:"FastGeluWithBias",shaderCache:{hint:`${a}`,inputDependencies:["type","type"]},getShaderSource:s,getRunData:o=>({outputs:[{dims:o[0].dims,dataType:o[0].dataType}],programUniforms:[{type:12,data:Math.ceil(r/4)},{type:12,data:i}],dispatchGroup:{x:Math.ceil(r/la/4)}})}},ck=e=>{e.inputs.length<2||G.size(e.inputs[1].dims)===0?O3(e):e.compute(s1(e.inputs))}}),zI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),o1=e=>{if(!e||e.length!==2)throw new Error("Gather requires 2 inputs.")},u1=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=G.normalizeAxis(t.axis,a),o=r.slice(0);o.splice(s,1,...i);let u=r[s],d=e[0].dataType===9?4:1,p=Math.ceil(G.size(o)/d),m=[{type:12,data:p},{type:6,data:u},{type:12,data:s},..._e(e[0].dims,e[1].dims,o)],f=g=>{let v=Z("data",e[0].dataType,e[0].dims.length,d),_=Z("inputIndices",e[1].dataType,e[1].dims.length),b=fe("output",e[0].dataType,o.length,d),k=w=>{let S=i.length,C=`var indicesIndices${w}  = ${_.type.indices}(0);`;for(let I=0;I<S;I++)C+=`${S>1?`indicesIndices${w}[${I}]`:`indicesIndices${w}`} = ${o.length>1?`outputIndices${w}[uniforms.axis + ${I}]`:`outputIndices${w}`};`;C+=`
          var idx${w} = ${_.getByIndices(`indicesIndices${w}`)};
          if (idx${w} < 0) {
            idx${w} = idx${w} + uniforms.axisDimLimit;
          }
          var dataIndices${w} : ${v.type.indices};
        `;for(let I=0,z=0;I<a;I++)I===s?(C+=`${a>1?`dataIndices${w}[${I}]`:`dataIndices${w}`} = u32(idx${w});`,z+=S):(C+=`${a>1?`dataIndices${w}[${I}]`:`dataIndices${w}`} = ${o.length>1?`outputIndices${w}[${z}]`:`outputIndices${w}`};`,z++);return C},$;if(e[0].dataType===9){let w=(S,C,I="")=>`
          let outputIndices${C} = ${b.offsetToIndices(`outputOffset + ${C}u`)};
          ${k(C)};
          let offset${C} = ${v.indicesToOffset(`dataIndices${C}`)};
          let index${C} = offset${C} / 4u;
          let component${C} = offset${C} % 4u;
          ${S}[${C}] = ${I}(${v.getByOffset(`index${C}`)}[component${C}]);
        `;$=`
        let outputOffset = global_idx * ${d};
        var value = vec4<u32>(0);
        ${w("value",0,"u32")}
        ${w("value",1,"u32")}
        ${w("value",2,"u32")}
        ${w("value",3,"u32")}
        ${b.setByOffset("global_idx","value")}
      `}else $=`
      let outputIndices = ${b.offsetToIndices("global_idx")};
      ${k("")};
      let value = ${v.getByIndices("dataIndices")};
      ${b.setByOffset("global_idx","value")};
      `;return`
      ${g.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(v,_,b)}
      ${g.mainStart()}
        ${g.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${$}
      }`};return{name:"Gather",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:o,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:m}),getShaderSource:f}},hk=e=>Le({axis:e.axis}),fk=(e,t)=>{let r=e.inputs;o1(r),e.compute(u1(e.inputs,t))}}),AI=te(()=>{"use strict";$e(),Ce(),ze(),l1=(e,t,r,i,a,s,o,u,d)=>{let p=[{type:12,data:s},{type:12,data:i},{type:12,data:a},{type:12,data:r},{type:12,data:o},{type:12,data:u},{type:12,data:d}],m=[s];p.push(..._e(t.dims,m));let f=g=>{let v=Z("indices_data",t.dataType,t.dims.length),_=fe("input_slice_offsets_data",12,1,1),b=[v,_],k=[{name:"output_size",type:"u32"},{name:"batch_dims",type:"u32"},{name:"input_dims",type:"u32",length:a.length},{name:"sizes_from_slice_dims_data",type:"u32",length:r.length},{name:"num_slices_per_batch",type:"u32"},{name:"input_batch_stride",type:"u32"},{name:"num_slice_dims",type:"u32"}];return`
  ${g.registerUniforms(k).declareVariables(...b)}
  ${g.mainStart()}
    ${g.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let batch_idx = global_idx / uniforms.num_slices_per_batch;
    let base_offset = batch_idx * uniforms.input_batch_stride;

    let slice_indices_base_offset = global_idx * uniforms.num_slice_dims;
    var relative_slice_offset = 0;
    for (var dim_idx = 0u; dim_idx < uniforms.num_slice_dims; dim_idx ++) {
      var index = i32(indices_data[dim_idx + slice_indices_base_offset].x);
      let input_dim_idx = uniforms.batch_dims + dim_idx;
      if (index < 0) {
        ${a.length===1?"index += i32(uniforms.input_dims);":"index += i32(uniforms.input_dims[input_dim_idx]);"}
      }
      ${r.length===1?"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data);":"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data[dim_idx]);"}
    }

    input_slice_offsets_data[global_idx] =  base_offset + u32(relative_slice_offset);
  }`};return e.compute({name:"computeSliceOffsets",shaderCache:{hint:`${a.length}_${r.length}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:m,dataType:e.inputs[1].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:p}),getShaderSource:f},{inputs:[t],outputs:[-1]})[0]},mk=(e,t)=>{let r=e.inputs,i=r[0].dims,a=r[0].dataType,s=r[1].dims,o=s[s.length-1],u=G.sizeToDimension(s,s.length-1),d=G.sizeFromDimension(i,t.batchDims+o),p=G.sizeToDimension(i,t.batchDims),m=G.sizeFromDimension(i,t.batchDims),f=u/p,g=new Array(o),v=d;for(let C=0;C<o;++C)g[o-1-C]=v,v*=i[t.batchDims+o-1-C];let _=l1(e,r[1],g,t.batchDims,i,u,f,m,o),b=t.batchDims+o;if(b>i.length)throw new Error("last dimension of indices must not be larger than rank of input tensor");let k=s.slice(0,-1).concat(i.slice(b)),$=G.size(k),w=[{type:12,data:$},{type:12,data:d},..._e(r[0].dims,_.dims,k)],S=C=>{let I=Z("data",r[0].dataType,r[0].dims.length),z=Z("slice_offsets",12,_.dims.length),E=fe("output",r[0].dataType,k.length);return`
          ${C.registerUniform("output_size","u32").registerUniform("slice_size","u32").declareVariables(I,z,E)}
            ${C.mainStart()}
            ${C.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let slice_offset = slice_offsets[global_idx / uniforms.slice_size];
          output[global_idx] = data[u32(slice_offset) + global_idx % uniforms.slice_size];
        }`};e.compute({name:"GatherND",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:k,dataType:a}],dispatchGroup:{x:Math.ceil($/64)},programUniforms:w}),getShaderSource:S},{inputs:[r[0],_]})},gk=e=>({batchDims:e.batch_dims,cacheKey:""})}),OI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),d1=(e,t)=>{if(e.length<3||e.length>4)throw new Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=G.normalizeAxis(t.quantizeAxis,e[0].dims.length),i=t.blockSize,a=e[0],s=e[2],o=e.length===4?e[3]:void 0;if(s.dims.length!==a.dims.length||!a.dims.map((u,d)=>d===r?Math.ceil(u/i)===s.dims[d]:u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(o){if(o.dataType!==a.dataType)throw new Error("Zero point must have the same data type as the input tensor.");if(o.dims.length!==s.dims.length||!o.dims.map((u,d)=>u===s.dims[d]).reduce((u,d)=>u&&d,!0))throw new Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}},p1=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r.length,s=G.normalizeAxis(t.gatherAxis,a),o=G.normalizeAxis(t.quantizeAxis,a),u=r.slice(0);u.splice(s,1,...i);let d=G.size(u),p=e[2].dataType,m=e[0].dataType===22,f=[{type:12,data:d},{type:12,data:o},{type:12,data:s},{type:12,data:t.blockSize},..._e(...e.map((v,_)=>v.dims),u)],g=v=>{let _=Z("data",e[0].dataType,e[0].dims.length),b=Z("inputIndices",e[1].dataType,e[1].dims.length),k=Z("scales",e[2].dataType,e[2].dims.length),$=e.length>3?Z("zeroPoint",e[3].dataType,e[3].dims.length):void 0,w=fe("output",p,u.length),S=[_,b,k];$&&S.push($);let C=[{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}];return`
        ${v.registerUniforms(C).declareVariables(...S,w)}
        ${v.mainStart()}
        let output_indices = ${w.offsetToIndices("global_idx")};
        var indices_indices = ${b.type.indices}(0);
        ${i.length>1?`
          for (var i: u32 = 0; i < ${i.length}; i++) {
            let index = ${w.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${b.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${w.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${_.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${w.indicesGet("output_indices","i")};
          ${_.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${b.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${r[s]};
        }
        ${_.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${u.length}; i++) {
          let index = ${w.indicesGet("output_indices",`i + ${i.length} - 1`)};
          ${_.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${_.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${_.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${m?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${k.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${k.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${k.getByIndices("scale_indices")};
        ${$?`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${$.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${$.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${m?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`:"var zero_point = 0"};
        let dequantized_data = ${kt(p)}(quantized_data - zero_point) * scale;
        ${w.setByOffset("global_idx","dequantized_data")};
    }`};return{name:"GatherBlockQuantized",shaderCache:{hint:`${t.cacheKey};${e.filter((v,_)=>_!==1).map(v=>v.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:e.length},(v,_)=>"rank")},getRunData:()=>({outputs:[{dims:u,dataType:p}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:f}),getShaderSource:g}},yk=(e,t)=>{let r=e.inputs;d1(r,t),e.compute(p1(e.inputs,t))},_k=e=>Le({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}),RI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),c1=e=>{if(!e||e.length!==2)throw new Error("GatherElements requires 2 inputs.");if(e[0].dims.length<1)throw new Error("GatherElements requires that the data input be rank >= 1.");if(e[0].dims.length!==e[1].dims.length)throw new Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`)},h1=(e,t)=>{let r=e[0].dims,i=e[0].dataType,a=r.length,s=e[1].dims,o=e[1].dataType,u=G.normalizeAxis(t.axis,a),d=r[u],p=s.slice(0),m=G.size(p),f=Z("input",i,a),g=Z("indicesInput",o,s.length),v=fe("output",i,p.length),_=[{type:12,data:m},{type:6,data:d},{type:12,data:u}];return _.push(..._e(r,s,p)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:p,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:_}),getShaderSource:b=>`
      ${b.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(f,g,v)}
      ${b.mainStart()}
      ${b.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${v.offsetToIndices("global_idx")};

      var idx = ${g.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${f.type.indices}(outputIndices);
      ${f.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${f.getByIndices("inputIndices")};

      ${v.setByOffset("global_idx","value")};
  }`}},vk=e=>Le({axis:e.axis}),wk=(e,t)=>{let r=e.inputs;c1(r),e.compute(h1(e.inputs,t))}}),BI=te(()=>{"use strict";$e(),Ce(),ze(),f1=e=>{if(!e)throw new Error("Input is missing");if(e.length<2||e.length>3)throw new Error("Invaid input number.");if(e.length===3&&e[2].dims.length>2)throw new Error("Invalid input shape of C");if(e[0].dataType!==e[1].dataType||e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("Input types are mismatched")},m1=(e,t)=>{let r=e[0].dims.slice(),i=e[1].dims.slice(),[a,s,o]=xx.getShapeOfGemmResult(r,t.transA,i,t.transB,e.length===3?e[2].dims:void 0),u=[a,s];if(!u)throw new Error("Can't use gemm on the given tensors");let d=16,p=Math.ceil(s/d),m=Math.ceil(a/d),f=!0,g=G.size(u),v=[{type:12,data:f?p:g},{type:12,data:a},{type:12,data:s},{type:12,data:o},{type:1,data:t.alpha},{type:1,data:t.beta}],_=["type","type"];e.length===3&&(v.push(..._e(e[2].dims)),_.push("rank")),v.push(..._e(u));let b=$=>{let w="";t.transA&&t.transB?w="value += a[k * uniforms.M + m] * b[n * uniforms.K + k];":t.transA&&!t.transB?w="value += a[k * uniforms.M + m] * b[k * uniforms.N + n];":!t.transA&&t.transB?w="value += a[m * uniforms.K + k] * b[n * uniforms.K + k];":!t.transA&&!t.transB&&(w="value += a[m * uniforms.K + k] * b[k * uniforms.N + n];");let S=t.alpha===1?"":"value *= uniforms.alpha;",C=Z("a",e[0].dataType,e[0].dims),I=Z("b",e[1].dataType,e[1].dims),z=C.type.value,E=null,B=[C,I];e.length===3&&(E=Z("c",e[2].dataType,e[2].dims.length),B.push(E));let U=fe("output",e[0].dataType,u.length);B.push(U);let V=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}];return`
  ${$.registerUniforms(V).declareVariables(...B)}

  ${$.mainStart()}
    ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let m = global_idx / uniforms.N;
    let n = global_idx % uniforms.N;

    var value = ${z}(0);
    for (var k: u32 = 0u; k < uniforms.K; k++) {
      ${w}
    }

    ${S}
    ${E!=null?`let cOffset = ${E.broadcastedIndicesToOffset("vec2(m, n)",U)}; value += ${z}(uniforms.beta) * ${E.getByOffset("cOffset")};`:""}
    output[global_idx] = value;
  }`},k=$=>{let w=Z("a",e[0].dataType,e[0].dims),S=Z("b",e[1].dataType,e[1].dims),C=null,I=[w,S];e.length===3&&(C=Z("c",e[2].dataType,e[2].dims.length),I.push(C));let z=fe("output",e[0].dataType,u.length);I.push(z);let E=[{name:"num_tile_n",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}],B="",U="";t.transA&&t.transB?(U=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[k][local_id.y] * tile_b[local_id.x][k];"):t.transA&&!t.transB?(U=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[k][local_id.y] * tile_b[k][local_id.x];"):!t.transA&&t.transB?(U=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[local_id.y][k] * tile_b[local_id.x][k];"):!t.transA&&!t.transB&&(U=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${w.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${S.type.value}(0);
      }
      `,B="value += tile_a[local_id.y][k] * tile_b[k][local_id.x];");let V=t.alpha===1?"":"value *= uniforms.alpha;";return`
  ${$.registerUniforms(E).declareVariables(...I)}
  var<workgroup> tile_a: array<array<${w.type.storage}, ${d}>, ${d}>;
  var<workgroup> tile_b: array<array<${S.type.storage}, ${d}>, ${d}>;
  ${$.mainStart([d,d,1])}
    let tile_col_start = (workgroup_index % uniforms.num_tile_n) * ${d};
    let tile_row_start = (workgroup_index / uniforms.num_tile_n) * ${d};
    let num_tiles = (uniforms.K - 1) / ${d} + 1;
    var k_start = 0u;
    var value = ${z.type.value}(0);
    for (var t: u32 = 0u; t < num_tiles; t++) {
      ${U}
      k_start = k_start + ${d};
      workgroupBarrier();

      for (var k: u32 = 0u; k < ${d}; k++) {
        ${B}
      }
      workgroupBarrier();
    }

    ${V}
    let m = tile_row_start + local_id.y;
    let n = tile_col_start + local_id.x;
    ${C!=null?`let cOffset = ${C.broadcastedIndicesToOffset("vec2(m, n)",z)}; value += ${z.type.value}(uniforms.beta) * ${C.getByOffset("cOffset")};`:""}
    if (m < uniforms.M && n < uniforms.N) {
      output[m * uniforms.N + n] = value;
    }
  }`};return f?{name:"GemmShared",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:p*m},programUniforms:v}),getShaderSource:k}:{name:"Gemm",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:u,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:v}),getShaderSource:b}},bk=e=>{let t=e.transA,r=e.transB,i=e.alpha,a=e.beta;return{transA:t,transB:r,alpha:i,beta:a,cacheKey:`${e.transA};${e.transB};${e.alpha===1}`}},$k=(e,t)=>{f1(e.inputs),e.compute(m1(e.inputs,t))}}),NI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),[wr,Pr,Pi,Ui]=[0,1,2,3],g1=e=>{if(e[0].dims.length!==4)throw new Error("only 4-D tensor is supported.");if(e[0].dims.length!==e[1].dims.length)throw new Error("input dimensions must be equal to grid dimensions");if(e[0].dims.length-2!==e[1].dims[e[1].dims.length-1])throw new Error(`last dimension of grid must be equal to ${e[0].dims.length-2}`);if(e[0].dims[0]!==e[1].dims[0])throw new Error("grid batch size must match input batch size")},y1=`
  fn gs_get_cubic_coeffs(x: f32) -> vec4<f32> {
    let cubic_alpha = -0.75f;
    let x_abs = abs(x);
    var coeffs: vec4<f32>;
    coeffs[0] = (((cubic_alpha * (x_abs + 1) - 5 * cubic_alpha) * (x_abs + 1) + 8 * cubic_alpha) * (x_abs + 1) - 4 * cubic_alpha);
    coeffs[1] = (((cubic_alpha + 2) * x_abs - (cubic_alpha + 3)) * x_abs * x_abs + 1);
    coeffs[2] = (((cubic_alpha + 2) * (1 - x_abs) - (cubic_alpha + 3)) * (1 - x_abs) * (1 - x_abs) + 1);
    coeffs[3] = (((cubic_alpha * (2 - x_abs) - 5 * cubic_alpha) * (2 - x_abs) + 8 * cubic_alpha) * (2 - x_abs) - 4 * cubic_alpha);
    return coeffs;
  }
`,_1=e=>`
  fn gs_bicubic_interpolate(p: mat4x4<${e}>, x: f32, y: f32) -> ${e} {
    var v: vec4<f32>;
    var coeffs = gs_get_cubic_coeffs(x);
    for (var i = 0; i < 4; i++) {
      v[i] = coeffs[0] * p[i][0] + coeffs[1] * p[i][1] + coeffs[2] * p[i][2] + coeffs[3] * p[i][3];
    }
    coeffs = gs_get_cubic_coeffs(y);
    let pixel = ${e}(coeffs[0] * v[0] + coeffs[1] * v[1] + coeffs[2] * v[2] + coeffs[3] * v[3]);
    return pixel;
  }
`,v1=e=>`
  fn gs_denormalize(n: f32, length: i32) -> f32 {
    ${e.alignCorners===0?`
    // alignCorners: false => [-1, 1] to [-0.5, length - 0.5]
    return ((n + 1.0) * f32(length) - 1.0) / 2.0;
    `:`
    // alignCorners: true => [-1, 1] to [0, length - 1]
    return (n + 1.0) / 2.0 * (f32(length - 1));
    `}
  }
`,w1=e=>`
  ${e.paddingMode==="reflection"?`
      fn gs_reflect(x: i32, x_min: f32, x_max: f32) -> u32 {
        var dx = 0.0;
        var fx = f32(x);
        let range = x_max - x_min;
        if (fx < x_min) {
          dx = x_min - fx;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_min + r;
          } else {
            fx = x_max - r;
          }
        } else if (fx > x_max) {
          dx = fx - x_max;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_max - r;
          } else {
            fx = x_min + r;
          }
        }
        return u32(fx);
      }`:""}
`,b1=(e,t,r)=>`
  fn pixel_at_grid(r: i32, c: i32, H: i32, W: i32, batch: u32, channel: u32, border: vec4<f32>) -> ${t} {
     var pixel = ${t}(0);
     var indices = vec4<u32>(0);
     indices[${wr}] = batch;
     indices[${Pr}] = channel;`+(()=>{switch(r.paddingMode){case"zeros":return`
          if (r >= 0 && r < H && c >=0 && c < W) {
            indices[${Pi}] = u32(r);
            indices[${Ui}] = u32(c);
          }
        `;case"border":return`
          indices[${Pi}] = u32(clamp(r, 0, H - 1));
          indices[${Ui}] = u32(clamp(c, 0, W - 1));
        `;case"reflection":return`
          indices[${Pi}] = gs_reflect(r, border[1], border[3]);
          indices[${Ui}] = gs_reflect(c, border[0], border[2]);
        `;default:throw new Error(`padding mode ${r.paddingMode} is not supported`)}})()+`
    return ${e.getByIndices("indices")};
  }
`,$1=(e,t,r)=>(()=>{switch(r.mode){case"nearest":return`
          let result = pixel_at_grid(i32(round(y)), i32(round(x)), H_in, W_in, indices[${wr}], indices[${Pr}], border);
        `;case"bilinear":return`
          let x1 = i32(floor(x));
          let y1 = i32(floor(y));
          let x2 = x1 + 1;
          let y2 = y1 + 1;

          let p11 = pixel_at_grid(y1, x1, H_in, W_in, indices[${wr}], indices[${Pr}], border);
          let p12 = pixel_at_grid(y1, x2, H_in, W_in, indices[${wr}], indices[${Pr}], border);
          let p21 = pixel_at_grid(y2, x1, H_in, W_in, indices[${wr}], indices[${Pr}], border);
          let p22 = pixel_at_grid(y2, x2, H_in, W_in, indices[${wr}], indices[${Pr}], border);

          let dx2 = ${t}(f32(x2) - x);
          let dx1 = ${t}(x - f32(x1));
          let dy2 = ${t}(f32(y2) - y);
          let dy1 = ${t}(y - f32(y1));
          let result = dy2 * (dx2 * p11 + dx1 * p12) + dy1 * (dx2 * p21 + dx1 * p22);
        `;case"bicubic":return`
          let x0 = i32(floor(x)) - 1;
          let y0 = i32(floor(y)) - 1;
          var p: mat4x4<${t}>;
          for (var h = 0; h < 4; h++) {
            for (var w = 0; w < 4; w++) {
              p[h][w] = pixel_at_grid(h + y0, w + x0, H_in, W_in, indices[${wr}], indices[${Pr}], border);
            }
          }

          let dx = x - f32(x0 + 1);
          let dy = y - f32(y0 + 1);
          let result = gs_bicubic_interpolate(p, dx, dy);
        `;default:throw new Error(`mode ${r.mode} is not supported`)}})()+`${e.setByOffset("global_idx","result")}`,x1=(e,t)=>{let r=Z("x",e[0].dataType,e[0].dims.length),i=[e[1].dims[0],e[1].dims[1],e[1].dims[2]],a=Z("grid",e[1].dataType,i.length,2),s=[e[0].dims[0],e[0].dims[1],e[1].dims[1],e[1].dims[2]];t.format==="NHWC"&&(s=[e[0].dims[0],e[1].dims[1],e[1].dims[2],e[0].dims[3]],[wr,Pr,Pi,Ui]=[0,3,1,2]);let o=fe("output",e[0].dataType,s.length),u=r.type.value,d=G.size(s),p=[{type:12,data:d},..._e(e[0].dims,i,s)],m=f=>`
  ${f.registerUniform("output_size","u32").declareVariables(r,a,o)}
  ${y1}
  ${_1(u)}
  ${v1(t)}
  ${w1(t)}
  ${b1(r,u,t)}

  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let H_in = i32(uniforms.x_shape[${Pi}]);
      let W_in = i32(uniforms.x_shape[${Ui}]);

      ${t.alignCorners===0?`
      let x_min = -0.5;
      let x_max = f32(W_in) - 0.5;
      let y_min = -0.5;
      let y_max = f32(H_in) - 0.5;
      `:`
      let x_min = 0.0;
      let x_max = f32(W_in) - 1.0;
      let y_min = 0.0;
      let y_max = f32(H_in) - 1.0;
      `};
      let border = vec4<f32>(x_min, y_min, x_max, y_max);

      let indices = ${o.offsetToIndices("global_idx")};
      var grid_indices = vec3<u32>(indices[${wr}], indices[${Pi}], indices[${Ui}]);
      let nxy = ${a.getByIndices("grid_indices")};
      var x = gs_denormalize(f32(nxy[0]), W_in);
      var y = gs_denormalize(f32(nxy[1]), H_in);

      ${$1(o,u,t)}
  }`;return{name:"GridSample",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:["type","type"]},getRunData:f=>{let g=G.size(s);return{outputs:[{dims:s,dataType:f[0].dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:p}},getShaderSource:m}},xk=(e,t)=>{g1(e.inputs),e.compute(x1(e.inputs,t))},kk=e=>Le({alignCorners:e.align_corners,mode:e.mode,paddingMode:e.padding_mode,format:e.format})}),Ck=te(()=>{"use strict";$e(),Ce(),tt(),ff(),yf(),ze(),Jr(),Ct=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,k1=(e,t)=>{let r=e[0],i=Ct(e,1),a=Ct(e,2),s=Ct(e,3),o=Ct(e,4),u=Ct(e,5),d=Ct(e,6),p=Ct(e,7);if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let m=r.dims[0],f=r.dims[1],g=r.dims.length===3?r.dims[2]:t.numHeads*r.dims[4],v=f,_=0,b=0,k=Math.floor(g/t.numHeads);if(d&&p&&G.size(d.dims)&&G.size(p.dims)){if(d.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(d.dims[0]!==m||d.dims[1]!==t.numHeads||d.dims[3]!==k)throw new Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(p.dims[0]!==m||p.dims[1]!==t.numHeads||p.dims[3]!==k)throw new Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(d.dims[2]!==p.dims[2])throw new Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(p.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');_=d.dims[2],b=d.dims[2]}else if(d&&G.size(d.dims)||p&&G.size(p.dims))throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let $;if(i&&G.size(i.dims)>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(i.dims[2]!==r.dims[2])throw new Error('Input "query" and "key" shall have same dim 2 (hidden_size)');$=2,v=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==k)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');$=5,v=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==k)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');$=0,v=i.dims[2]}}else{if(r.dims.length!==5)throw new Error('Input "query" is expected to have 5 dimensions when key is empty');if(r.dims[2]!==t.numHeads||r.dims[3]!==3)throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');$=3}if(s&&G.size(s.dims)>0){if(s.dims.length!==1)throw new Error('Input "bias" is expected to have 1 dimension');if(i&&i.dims.length===5&&i.dims[3]===2)throw new Error("bias is not allowed for packed kv.")}let w=_+v,S=0;if(o&&G.size(o.dims)>0){S=8;let E=o.dims;throw E.length===1?E[0]===m?S=1:E[0]===3*m+2&&(S=3):E.length===2&&E[0]===m&&E[1]===w&&(S=5),S===8?new Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)'):new Error("Mask not supported")}let C=!1,I=g;if(a&&G.size(a.dims)>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(v!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');I=a.dims[2]}else{if(v!==a.dims[2])throw new Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');I=a.dims[1]*a.dims[3],C=!0}}let z=!1;if(o&&G.size(o.dims)>0)throw new Error("Key padding mask is not supported");if(u&&G.size(u.dims)>0){if(u.dims.length!==4)throw new Error('Input "attention_bias" is expected to have 4 dimensions');if(u.dims[0]!==m||u.dims[1]!==t.numHeads||u.dims[2]!==f||u.dims[3]!==w)throw new Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:m,sequenceLength:f,pastSequenceLength:_,kvSequenceLength:v,totalSequenceLength:w,maxSequenceLength:b,inputHiddenSize:0,hiddenSize:g,vHiddenSize:I,headSize:k,vHeadSize:Math.floor(I/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:S,scale:t.scale,broadcastResPosBias:z,passPastInKv:C,qkvFormat:$}},Sk=e=>Le({...e}),_h=Le({perm:[0,2,1,3]}),S1=(e,t,r,i,a,s,o)=>{let u=[i,a,s],d=G.size(u),p=[{type:12,data:d},{type:12,data:o},{type:12,data:s}],m=f=>{let g=fe("qkv_with_bias",t.dataType,u),v=Z("qkv",t.dataType,u),_=Z("bias",r.dataType,u),b=[{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}];return`
  ${f.registerUniforms(b).declareVariables(v,_,g)}
  ${f.mainStart()}
    ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`};return e.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:u,dataType:t.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p}),getShaderSource:m},{inputs:[t,r],outputs:[-1]})[0]},to=(e,t,r,i,a,s,o,u)=>{let d=s;if(o&&G.size(o.dims)>0){if(i===1)throw new Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");return d=S1(e,s,o,t,i,r*a,u),d=d.reshape([t,i,r,a]),r===1||i===1?d:e.compute(Ut(d,_h.perm),{inputs:[d],outputs:[-1]})[0]}else return s.dims.length===3&&(d=s.reshape([t,i,r,a])),r===1||i===1?d:e.compute(Ut(d,_h.perm),{inputs:[d],outputs:[-1]})[0]},Tk=(e,t)=>{let r=k1(e.inputs,t),i=e.inputs[0],a=Ct(e.inputs,1),s=Ct(e.inputs,2),o=Ct(e.inputs,3),u=Ct(e.inputs,4),d=Ct(e.inputs,5),p=Ct(e.inputs,6),m=Ct(e.inputs,7);if(i.dims.length===5)throw new Error("Packed QKV is not implemented");if(a?.dims.length===5)throw new Error("Packed KV is not implemented");let f=a&&s&&a.dims.length===4&&s.dims.length===4,g=to(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,i,o,0);if(f)return ao(e,g,a,s,u,void 0,p,m,d,r);if(!a||!s)throw new Error("key and value must be provided");let v=to(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,a,o,r.hiddenSize),_=to(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,s,o,2*r.hiddenSize);ao(e,g,v,_,u,void 0,p,m,d,r)}}),zk=te(()=>{"use strict";$e(),Ce(),tt(),ze(),T1=e=>{if(!e||e.length<1)throw new Error("too few inputs")},C1=(e,t)=>{let r=[],i=t.numOutputs;return e[1].dims[0]>0&&(e[1].getBigInt64Array().forEach(a=>r.push(Number(a))),i=r.length),Le({numOutputs:i,axis:t.axis,splitSizes:r})},I1=e=>`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${e}u; i += 1u ) {
    if (index < ${ge("uniforms.size_in_split_axis","i",e)}) {
        return i;
    }
    }
    return ${e}u;
}`,E1=e=>{let t=e.length,r=[];for(let i=0;i<t;++i){let a=e[i].setByIndices("indices","input[global_idx]");t===1?r.push(a):i===0?r.push(`if (output_number == ${i}u) { ${a} }`):i===t-1?r.push(`else { ${a} }`):r.push(`else if (output_number == ${i}) { ${a} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join(`
`)}
      }`},Xh=(e,t)=>{let r=e[0].dims,i=G.size(r),a=e[0].dataType,s=G.normalizeAxis(t.axis,r.length),o=new Array(t.numOutputs),u=Z("input",a,r.length),d=new Array(t.numOutputs),p=[],m=[],f=0,g=[{type:12,data:i}];for(let _=0;_<t.numOutputs;_++){f+=t.splitSizes[_],d[_]=f;let b=r.slice();b[s]=t.splitSizes[_],m.push(b),o[_]=fe(`output${_}`,a,b.length),p.push({dims:m[_],dataType:e[0].dataType})}g.push({type:12,data:d},..._e(r,...m));let v=_=>`
  ${_.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",d.length).declareVariables(u,...o)}
  ${I1(d.length)}
  ${E1(o)}

  ${_.mainStart()}
    ${_.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${u.offsetToIndices("global_idx")};
    var index = ${u.indicesGet("indices",s)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${ge("uniforms.size_in_split_axis","output_number - 1u",d.length)};
      ${u.indicesSet("indices",s,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`;return{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:v,getRunData:()=>({outputs:p,dispatchGroup:{x:Math.ceil(i/64)},programUniforms:g})}},Ik=(e,t)=>{T1(e.inputs);let r=e.inputs.length===1?t:C1(e.inputs,t);e.compute(Xh(e.inputs,r),{inputs:[0]})},Ek=e=>{let t=e.axis,r=e.splitSizes,i=e.numOutputs<0?r.length:e.numOutputs;if(i!==r.length)throw new Error("numOutputs and splitSizes lengh must be equal");return Le({axis:t,numOutputs:i,splitSizes:r})}}),MI=te(()=>{"use strict";tt(),yf(),Ck(),zk(),Jr(),z1=(e,t)=>{if(t.doRotary)throw new Error("GroupQuerryAttention do_rotary attribute is not supported");if(t.doRotary&&e.length<=7)throw new Error("cos_cache and sin_cache inputs are required if do_rotary is specified");let r=e[0],i=e[1],a=e[2],s=e[3],o=e[4];if(t.localWindowSize!==-1)throw new Error("Local attention is not supported");if(t.softcap!==0)throw new Error("Softcap is not supported");if(t.rotaryInterleaved!==0)throw new Error("Rotary interleaved is not supported");if(t.smoothSoftmax)throw new Error("Smooth softmax is not supported");if(r.dims.length!==3&&r.dims.length!==5)throw new Error("Input query is expected to have 3 or 5 dimensions");let u=!1,d=r.dims[0],p=r.dims[1],m=r.dims.length===3?u?r.dims[2]/3:r.dims[2]:t.numHeads*r.dims[4],f=p,g=0,v=!i||i.dims.length===0,_=Math.floor(v?m/(t.numHeads+2*t.kvNumHeads):m/t.numHeads);v&&(m=_*t.numHeads);let b=s&&s.dims.length!==0,k=o&&o.dims.length!==0;if(b&&s.dims.length===4&&s.dims[0]===d&&s.dims[1]!==t.kvNumHeads&&s.dims[2]===t.kvNumHeads&&s.dims[3]===_)throw new Error("BSNH pastKey/pastValue is not supported");if(b&&k){if(s.dims.length!==4)throw new Error('Input "past_key" is expected to have 4 dimensions');if(o.dims.length!==4)throw new Error('Input "past_value" is expected to have 4 dimensions');g=s.dims[2]}else if(b||k)throw new Error('Input "past_key" and "past_value" shall be both present or both absent');let $=1;if(i&&i.dims.length>0){if(r.dims.length!==3)throw new Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw new Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw new Error('Input "query" and "key" shall have same dim 0 (batch size)');if(i.dims.length===3){if(r.dims[2]%i.dims[2]!==0)throw new Error('Dimension 2 of "query" should be a multiple of "key"');f=i.dims[1]}else if(i.dims.length===5){if(i.dims[2]!==t.numHeads||i.dims[3]!==2||i.dims[4]!==_)throw new Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw new Error('Expect "value" be none when "key" has packed kv format.');f=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==_)throw new Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');f=i.dims[2]}}else{if(r.dims.length!==3&&r.dims.length!==5)throw new Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(r.dims.length===5&&(r.dims[2]!==t.numHeads||r.dims[3]!==3))throw new Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');$=3}let w=0,S=!1,C=t.kvNumHeads?_*t.kvNumHeads:m;if(a&&a.dims.length>0){if(a.dims.length!==3&&a.dims.length!==4)throw new Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw new Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(a.dims.length===3){if(f!==a.dims[1])throw new Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');C=a.dims[2]}else{if(f!==a.dims[2])throw new Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');C=a.dims[1]*a.dims[3],S=!0}}let I=e.length>4?e[5]:void 0;if(I&&I.dims.length!==1&&I.dims[0]!==d)throw new Error('Input "seqlens" is expected to have 1 dimension and the same dim 0 as batch_size');return{batchSize:d,sequenceLength:p,pastSequenceLength:g,kvSequenceLength:f,totalSequenceLength:-1,maxSequenceLength:-1,inputHiddenSize:0,hiddenSize:m,vHiddenSize:C,headSize:_,vHeadSize:Math.floor(C/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:w,scale:t.scale,broadcastResPosBias:!1,passPastInKv:S,qkvFormat:$}},A1=Le({perm:[0,2,1,3]}),vh=(e,t,r)=>{let i=t,a=r.kvNumHeads;return t.dims.length===3&&r.kvSequenceLength!==0&&(i=t.reshape([r.batchSize,r.kvSequenceLength,a,r.headSize]),i=e.compute(Ut(i,A1.perm),{inputs:[i],outputs:[-1]})[0]),i},Ak=(e,t)=>{let r=z1(e.inputs,t);if(e.inputs[0].dims.length===5)throw new Error("Packed QKV is not implemented");if(e.inputs[1]?.dims.length===5)throw new Error("Packed KV is not implemented");let i=e.inputs[0],a=e.inputs[1]&&e.inputs[1].dims.length>0?e.inputs[1]:void 0,s=e.inputs[2]&&e.inputs[2].dims.length>0?e.inputs[2]:void 0,o=e.inputs[3]&&e.inputs[3].dims.length!==0?e.inputs[3]:void 0,u=e.inputs[4]&&e.inputs[4].dims.length!==0?e.inputs[4]:void 0,d=e.inputs.length>4?e.inputs[5]:void 0,p=e.inputs.length>5?e.inputs[6]:void 0,m=r.kvNumHeads?r.kvNumHeads:r.numHeads,f=Le({axis:2,numOutputs:3,splitSizes:[r.numHeads*r.headSize,m*r.headSize,m*r.headSize]}),[g,v,_]=!a&&!s?e.compute(Xh([i],f),{inputs:[i],outputs:[-1,-1,-1]}):[i,a,s],b=to(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,g,void 0,0);ao(e,b,vh(e,v,r),vh(e,_,r),void 0,void 0,o,u,void 0,r,d,p)}}),DI=te(()=>{"use strict";$e(),Ce(),Jr(),ze(),wh=(e,t,r,i,a,s,o,u)=>{let d=Ye(s),p=d===1?"f32":`vec${d}f`,m=d===1?"vec2f":`mat2x${d}f`,f=a*o,g=64;f===1&&(g=256);let v=[a,o,s/d],_=[a,o,2],b=["rank","type","type"],k=[];k.push(..._e(v,_));let $=w=>{let S=Z("x",t.dataType,3,d),C=Z("scale",r.dataType,r.dims),I=Z("bias",i.dataType,i.dims),z=fe("output",1,3,2),E=[S,C,I,z];return`
  var<workgroup> workgroup_shared : array<${m}, ${g}>;
  const workgroup_size = ${g}u;
  ${w.declareVariables(...E)}
  ${w.mainStart(g)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${p}(0);
    var squared_sum = ${p}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${p}(${S.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${m}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${Xr("workgroup_shared[0][0]",d)} / f32(hight * ${d});
      let squared_sum_final = ${Xr("workgroup_shared[0][1]",d)} / f32(hight * ${d});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${u}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`};return e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${d};${u};${g}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:_,dataType:1}],dispatchGroup:{x:f},programUniforms:k}),getShaderSource:$},{inputs:[t,r,i],outputs:[-1]})[0]},O1=(e,t,r)=>{let i=t[0].dims,a=i,s=2,o=i[0],u=i[1],d=G.sizeFromDimension(i,s),p=Ye(d),m=G.size(a)/p,f=wh(e,t[0],t[1],t[2],o,d,u,r.epsilon),g=[o,u,d/p],v=[o,u],_=["type","none"],b=k=>{let $=Z("x",t[0].dataType,g.length,p),w=Z("scale_shift",1,v.length,2),S=fe("output",t[0].dataType,g.length,p),C=[$,w,S];return`
  ${k.registerUniform("output_size","u32").declareVariables(...C)}
  ${k.mainStart()}
  ${k.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${S.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${w.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${$.getByOffset("global_idx")} * ${S.type.value}(scale_shift.x) + ${S.type.value}(scale_shift.y);
      ${S.setByOffset("global_idx","value")};
  }`};e.compute({name:"InstanceNormalization",shaderCache:{hint:`${p}`,inputDependencies:_},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(m/64)},programUniforms:[{type:12,data:m},..._e(g,v,g)]}),getShaderSource:b},{inputs:[t[0],f]})},R1=(e,t,r)=>{let i=t[0].dims,a=i,s=i[0],o=i[i.length-1],u=G.sizeFromDimension(i,1)/o,d=Ye(o),p=G.size(a)/d,m=[{type:12,data:u},{type:12,data:Math.floor(o/d)}],f=["type","type"],g=!1,v=[0,i.length-1];for(let $=0;$<i.length-2;$++)g=g||i[$+1]!==1,v.push($+1);g=g&&i[i.length-1]!==1;let _=g?e.compute(Ut(e.inputs[0],v),{inputs:[e.inputs[0]],outputs:[-1]})[0]:e.inputs[0].reshape(Array.from({length:i.length},($,w)=>i[v[w]])),b=wh(e,_,t[1],t[2],s,u,o,r.epsilon),k=$=>{let w=ct(t[0].dataType),S=d===1?"vec2f":`mat${d}x2f`,C=E=>{let B=E===0?"x":"y",U=d===1?"f32":`vec${d}f`;switch(d){case 1:return`${w}(${U}(scale.${B}))`;case 2:return`vec2<${w}>(${U}(scale[0].${B}, scale[1].${B}))`;case 4:return`vec4<${w}>(${U}(scale[0].${B}, scale[1].${B}, scale[2].${B}, scale[3].${B}))`;default:throw new Error(`Not supported compoents ${d}`)}},I=Z("input",t[0].dataType,t[0].dims,d),z=fe("output",t[0].dataType,a,d);return`
  @group(0) @binding(0) var<storage, read> input : array<${I.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${S}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${z.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${$.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${C(0)}, ${C(1)});
  }`};e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${d}`,inputDependencies:f},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:m}),getShaderSource:k},{inputs:[t[0],b]})},Ok=(e,t)=>{t.format==="NHWC"?R1(e,e.inputs,t):O1(e,e.inputs,t)}}),PI=te(()=>{"use strict";$e(),Ce(),ze(),B1=e=>{if(!e||e.length<2)throw new Error("layerNorm requires at least 2 inputs.")},N1=(e,t,r)=>{let i=t.simplified,a=e[0].dims,s=e[1],o=!i&&e[2],u=a,d=G.normalizeAxis(t.axis,a.length),p=G.sizeToDimension(a,d),m=G.sizeFromDimension(a,d),f=G.size(s.dims),g=o?G.size(o.dims):0;if(f!==m||o&&g!==m)throw new Error(`Size of X.shape()[axis:] == ${m}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${f} and bias size of ${g}`);let v=[];for(let I=0;I<a.length;++I)I<d?v.push(a[I]):v.push(1);let _=Ye(m),b=["type","type"],k=[{type:12,data:p},{type:1,data:m},{type:12,data:Math.floor(m/_)},{type:1,data:t.epsilon}];o&&b.push("type");let $=r>1,w=r>2,S=I=>{let z=ct(e[0].dataType),E=[Z("x",e[0].dataType,e[0].dims,_),Z("scale",s.dataType,s.dims,_)];o&&E.push(Z("bias",o.dataType,o.dims,_)),E.push(fe("output",e[0].dataType,u,_)),$&&E.push(fe("mean_data_output",1,v)),w&&E.push(fe("inv_std_output",1,v));let B=[{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}];return`
  ${I.registerUniforms(B).declareVariables(...E)}
  ${I.mainStart()}
    ${I.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${qh("f32",_)};
    var mean_square_vector = ${qh("f32",_)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${oa(z,_,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${Xr("mean_vector",_)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${Xr("mean_square_vector",_)} / uniforms.norm_size ${i?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${oa(z,_,"x[j + offset]")};
      let f32scale = ${oa(z,_,"scale[j]")};
      output[j + offset] = ${E[0].type.value}((f32input ${i?"":"- mean"}) * inv_std_dev * f32scale
        ${o?`+ ${oa(z,_,"bias[j]")}`:""}
      );
    }

    ${$?"mean_data_output[global_idx] = mean":""};
    ${w?"inv_std_output[global_idx] = inv_std_dev":""};
  }`},C=[{dims:u,dataType:e[0].dataType}];return $&&C.push({dims:v,dataType:1}),w&&C.push({dims:v,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${_};${r};${i}`,inputDependencies:b},getRunData:()=>({outputs:C,dispatchGroup:{x:Math.ceil(p/64)},programUniforms:k}),getShaderSource:S}},Rk=(e,t)=>{B1(e.inputs),e.compute(N1(e.inputs,t,e.outputCount))}}),UI=te(()=>{"use strict";Ce(),$f(),xf(),M1=e=>{if(!e||e.length!==2)throw new Error("MatMul requires 2 inputs.");if(e[0].dims[e[0].dims.length-1]!==e[1].dims[e[1].dims.length-2])throw new Error("shared dimension does not match.")},Bk=e=>{M1(e.inputs);let t=ua.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!t)throw new Error("Can't use matmul on the given tensors");let r=t[t.length-1],i=e.inputs[0].dims[e.inputs[0].dims.length-1];if(r<8&&i<8)e.compute(bf(e.inputs,{activation:""},t));else{let a=t[t.length-2],s=G.size(e.inputs[0].dims.slice(0,-2)),o=G.size(e.inputs[1].dims.slice(0,-2));if(s!==1&&a===1&&o===1){let u=e.inputs[0].reshape([1,s,i]),d=e.inputs[1].reshape([1,i,r]),p=[1,s,r],m=[u,d];e.compute($u(m,{activation:""},t,p),{inputs:m})}else e.compute($u(e.inputs,{activation:""},t))}}}),WI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),D1=(e,t)=>{if(e.length<3||e.length>4)throw new Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],i=r.dims.length;if(r.dims[i-1]!==t.k)throw new Error("The last dim of input shape does not match the k value");let a=Math.floor((t.k+t.blockSize-1)/t.blockSize),s=t.blockSize/8*t.bits,o=e[1];if(!G.areEqual(o.dims,[t.n,a,s]))throw new Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let u=e[2].dims;if(G.size(u)!==t.n*a)throw new Error("scales input size error.");if(e.length===4){let d=e[3].dims,p=t.bits>4?t.n*a:t.n*Math.floor((a+1)/2);if(G.size(d)!==p)throw new Error("zeroPoints input size error.")}},P1=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,o=t.n,u=r.slice(0,i-2),d=G.size(u),p=e[1].dims[2]/4,m=e[0].dataType,f=Ye(t.k),g=Ye(p),v=Ye(o),_=u.concat([a,o]),b=a>1&&o/v%2===0?2:1,k=G.size(_)/v/b,$=64,w=[],S=[d,a,s/f],C=G.convertShape(e[1].dims).slice();C.splice(-1,1,p/g),w.push(..._e(S)),w.push(..._e(C)),w.push(..._e(e[2].dims)),e.length===4&&w.push(..._e(G.convertShape(e[3].dims)));let I=[d,a,o/v];w.push(..._e(I));let z=E=>{let B=S.length,U=Z("a",e[0].dataType,B,f),V=Z("b",12,C.length,g),W=Z("scales",e[2].dataType,e[2].dims.length),J=[U,V,W],D=e.length===4?Z("zero_points",12,e[3].dims.length):void 0;D&&J.push(D);let se=I.length,ue=fe("output",e[0].dataType,se,v),F=ct(e[0].dataType),oe=(()=>{switch(f){case 1:return`array<${F}, 8>`;case 2:return`mat4x2<${F}>`;case 4:return`mat2x4<${F}>`;default:throw new Error(`${f}-component is not supported.`)}})(),le=()=>{let M=`
          // reuse a data
            var input_offset = ${U.indicesToOffset(`${U.type.indices}(batch, row, word_offset)`)};
            var a_data: ${oe};
            for (var j: u32 = 0; j < ${8/f}; j++) {
              a_data[j] = ${U.getByOffset("input_offset")};
              input_offset++;
            }
          `;for(let q=0;q<v*b;q++)M+=`
            b_value = ${g===1?`b${q}_data`:`b${q}_data[i]`};
            b_value_lower = unpack4xU8(b_value & b_mask);
            b_value_upper = unpack4xU8((b_value >> 4) & b_mask);
            b_quantized_values = ${oe}(${Array.from({length:4},(R,X)=>`${F}(b_value_lower[${X}]), ${F}(b_value_upper[${X}])`).join(", ")});
            b_dequantized_values = ${f===1?`${oe}(${Array.from({length:8},(R,X)=>`(b_quantized_values[${X}] - ${D?`zero_point${q}`:"zero_point"}) * scale${q}`).join(", ")});`:`(b_quantized_values - ${oe}(${Array(8).fill(`${D?`zero_point${q}`:"zero_point"}`).join(",")})) * scale${q};`};
            workgroup_shared[local_id.x * ${b} + ${Math.floor(q/v)}]${v>1?`[${q%v}]`:""} += ${Array.from({length:8/f},(R,X)=>`${f===1?`a_data[${X}] * b_dequantized_values[${X}]`:`dot(a_data[${X}], b_dequantized_values[${X}])`}`).join(" + ")};
          `;return M},H=()=>{let M=`
            var col_index = col * ${v};
            ${D?`
            let zero_point_bytes_per_col = (nBlocksPerCol + 1) / 2;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${F}(8);`}
            `;for(let q=0;q<v*b;q++)M+=`
            let scale${q} = ${W.getByOffset("col_index * nBlocksPerCol + block")};
            ${D?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block >> 0x1u);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            zero_point_word = ${D.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${q} = ${F}((zero_point_word) & 0xFu);`:""}
            col_index += 1;`;return M},de=()=>{let M=`col_index = col * ${v};`;for(let q=0;q<v*b;q++)M+=`
            let b${q}_data = ${V.getByIndices(`${V.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return M+=`
            var b_value: u32;
            let b_mask: u32 = 0x0F0F0F0Fu;
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${oe};
            var b_dequantized_values: ${oe};`,M};return`
        var<workgroup> workgroup_shared: array<${ue.type.value}, ${b*$}>;
        ${E.declareVariables(...J,ue)}
        ${E.mainStart([$,1,1])}
          let output_indices = ${ue.offsetToIndices(`(global_idx / ${$}) * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += ${$}) {
            //process one block
            var word_offset: u32 = block * ${t.blockSize/f};
            ${H()}
            for (var word: u32 = 0; word < ${p}; word += ${g}) {
              ${de()}
              for (var i: u32 = 0; i < ${g}; i++) {
                ${le()}
                word_offset += ${8/f};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${b}) {
            var output_value: ${ue.type.value} = ${ue.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < ${$}u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${b};
            }
            ${ue.setByIndices(`${ue.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`};return{name:"MatMulNBits",shaderCache:{hint:`${t.blockSize};${t.bits};${f};${g};${v};${b};${$}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:_,dataType:m}],dispatchGroup:{x:k},programUniforms:w}),getShaderSource:z}},U1=(e,t)=>{let r=e[0].dims,i=r.length,a=r[i-2],s=t.k,o=t.n,u=r.slice(0,i-2),d=G.size(u),p=e[1].dims[2]/4,m=e[0].dataType,f=Ye(t.k),g=Ye(p),v=u.concat([a,o]),_=128,b=o%8===0?8:o%4===0?4:1,k=_/b,$=k*g*8,w=$/f,S=$/t.blockSize,C=G.size(v)/b,I=[],z=[d,a,s/f],E=G.convertShape(e[1].dims).slice();E.splice(-1,1,p/g),I.push(..._e(z)),I.push(..._e(E)),I.push(..._e(e[2].dims)),e.length===4&&I.push(..._e(G.convertShape(e[3].dims)));let B=[d,a,o];I.push(..._e(B));let U=V=>{let W=z.length,J=Z("a",e[0].dataType,W,f),D=Z("b",12,E.length,g),se=Z("scales",e[2].dataType,e[2].dims.length),ue=[J,D,se],F=e.length===4?Z("zero_points",12,e[3].dims.length):void 0;F&&ue.push(F);let oe=B.length,le=fe("output",e[0].dataType,oe),H=ct(e[0].dataType),de=()=>{switch(f){case 1:return`
          let a_data0 = vec4<${H}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${H}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${H}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${H}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw new Error(`${f}-component is not supported.`)}};return`
        var<workgroup> sub_a: array<${J.type.value}, ${w}>;
        var<workgroup> inter_results: array<array<${le.type.value}, ${k}>, ${b}>;
        ${V.declareVariables(...ue,le)}
        ${V.mainStart([k,b,1])}
          let output_indices = ${le.offsetToIndices(`workgroup_index * ${b}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${S} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${w};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${w}; a_offset += ${_})
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${J.getByIndices(`${J.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${J.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${S} + local_id.x;
            ${F?`
            let zero_point_bytes_per_col = (n_blocks_per_col + 1) / 2;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block >> 0x1u);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            let zero_point_word = ${F.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${H}((zero_point_word) & 0xFu);`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${H}(8);`}
            let scale = ${se.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${D.getByIndices(`${D.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${t.blockSize/f};
            for (var i: u32 = 0; i < ${g}; i++) {
              ${de()}
              let b_value = ${g===1?"b_data":"b_data[i]"};
              let b_value_lower = unpack4xU8(b_value & 0x0F0F0F0Fu);
              let b_value_upper = unpack4xU8((b_value >> 4) & 0x0F0F0F0Fu);
              let b_quantized_values = mat2x4<${H}>(${Array.from({length:4},(M,q)=>`${H}(b_value_lower[${q}]), ${H}(b_value_upper[${q}])`).join(", ")});
              let b_dequantized_values = (b_quantized_values - mat2x4<${H}>(${Array(8).fill("zero_point").join(",")})) * scale;
              inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(M,q)=>`${`dot(a_data${q}, b_dequantized_values[${q}])`}`).join(" + ")};
              word_offset += ${8/f};
            }
            workgroupBarrier();
          }

          if (local_idx < ${b}) {
            var output_value: ${le.type.value} = ${le.type.value}(0);
            for (var b = 0u; b < ${k}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${le.setByIndices(`${le.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`};return{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${t.blockSize};${f};${g};${k};${b}`,inputDependencies:Array(e.length).fill("rank")},getRunData:()=>({outputs:[{dims:v,dataType:m}],dispatchGroup:{x:C},programUniforms:I}),getShaderSource:U}},Nk=(e,t)=>{D1(e.inputs,t),t.blockSize===32&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")?e.compute(U1(e.inputs,t)):e.compute(P1(e.inputs,t))},Mk=e=>Le(e)}),VI=te(()=>{"use strict";$e(),Ce(),ze(),W1=e=>{if(!e||e.length<1)throw new Error("Too few inputs");if(e[0].dataType!==1&&e[0].dataType!==10)throw new Error("Input type must be float or float16.");if(e.length>=2){let t=e[0].dims.length*2===e[1].dims[0];if(e.length===4&&(t=e[3].dims[0]*2===e[1].dims[0]),!t)throw new Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}},V1=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
            k = i32(${e.indicesGet("indices",a)}) - ${ge("uniforms.pads",a,r)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${ge("uniforms.x_shape",a,t)})) {
              break;
            }
            offset += k * i32(${ge("uniforms.x_strides",a,t)});
        `;return`
          value = ${e.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${i}
            value = x[offset];
          }
      `},q1=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${ge("uniforms.pads",a,r)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${ge("uniforms.x_shape",a,t)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${ge("uniforms.x_shape",a,t)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${ge("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},j1=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${ge("uniforms.pads",a,r)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${ge("uniforms.x_shape",a,t)})) {
                  k = i32(${ge("uniforms.x_shape",a,t)}) - 1;
                }
                offset += k * i32(${ge("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},L1=(e,t,r)=>{let i="";for(let a=t-1;a>=0;--a)i+=`
                k = i32(${e.indicesGet("indices",a)}) - ${ge("uniforms.pads",a,r)};
                if (k < 0)  {
                  k += i32(${ge("uniforms.x_shape",a,t)}]);
                }
                if (k >= i32(${ge("uniforms.x_shape",a,t)})) {
                  k -= i32(${ge("uniforms.x_shape",a,t)});
                }
                offset += k * i32(${ge("uniforms.x_strides",a,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${i}
              value = x[offset];
          `},G1=(e,t,r)=>{switch(r.mode){case 0:return V1(e,t,r.pads.length);case 1:return q1(e,t,r.pads.length);case 2:return j1(e,t,r.pads.length);case 3:return L1(e,t,r.pads.length);default:throw new Error("Invalid mode")}},F1=(e,t)=>{let r=G.padShape(e[0].dims.slice(),t.pads),i=e[0].dims,a=G.size(r),s=[{type:12,data:a},{type:6,data:t.pads}],o=e.length>=3&&e[2].data;t.mode===0&&s.push({type:o?e[2].dataType:1,data:t.value}),s.push(..._e(e[0].dims,r));let u=["rank"],d=p=>{let m=fe("output",e[0].dataType,r.length),f=Z("x",e[0].dataType,i.length),g=f.type.value,v=G1(m,i.length,t),_=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:t.pads.length}];return t.mode===0&&_.push({name:"constant_value",type:o?g:"f32"}),`
            ${p.registerUniforms(_).declareVariables(f,m)}
            ${p.mainStart()}
            ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${m.offsetToIndices("global_idx")};

            var value = ${g}(0);
            ${v}
            output[global_idx] = value;
        }`};return{name:"Pad",shaderCache:{hint:`${t.mode}${o}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(G.size(r)/64)},programUniforms:s}),getShaderSource:d}},H1=(e,t)=>{if(e.length>1){let r=e[1].getBigInt64Array(),i=e.length>=3&&e[2].data?e[2].dataType===10?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,a=e[0].dims.length,s=new Int32Array(2*a).fill(0);if(e.length>=4){let u=e[3].getBigInt64Array();for(let d=0;d<u.length;d++)s[Number(u[d])]=Number(r[d]),s[Number(u[d])+a]=Number(r[d+u.length])}else r.forEach((u,d)=>s[Number(d)]=Number(u));let o=[];return s.forEach(u=>o.push(u)),{mode:t.mode,value:i,pads:o}}else return t},Dk=(e,t)=>{W1(e.inputs);let r=H1(e.inputs,t);e.compute(F1(e.inputs,r),{inputs:[0]})}}),qI=te(()=>{"use strict";fr(),$e(),Ce(),ze(),Ks=e=>{if(Ze.webgpu.validateInputContent&&(!e||e.length!==1))throw new Error("Pool ops requires 1 input.")},bh=(e,t,r)=>{let i=t.format==="NHWC",a=e.dims.slice();i&&a.splice(1,0,a.pop());let s=Object.hasOwnProperty.call(t,"dilations"),o=t.kernelShape.slice(),u=t.strides.slice(),d=s?t.dilations.slice():[],p=t.pads.slice();wu.adjustPoolAttributes(r,a,o,u,d,p);let m=wu.computePoolOutputShape(r,a,u,d,o,p,t.autoPad),f=Object.assign({},t);s?Object.assign(f,{kernelShape:o,strides:u,pads:p,dilations:d,cacheKey:t.cacheKey}):Object.assign(f,{kernelShape:o,strides:u,pads:p,cacheKey:t.cacheKey});let g=m.slice();return g.push(g.splice(1,1)[0]),[f,i?g:m]},$h=(e,t)=>{let r=t.format==="NHWC",i=G.size(e),a=G.size(t.kernelShape),s=[{type:12,data:i},{type:12,data:a}],o=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let u=t.kernelShape[t.kernelShape.length-1],d=t.strides[t.strides.length-1],p=t.pads[t.pads.length/2-1],m=t.pads[t.pads.length-1],f=!!(p+m);s.push({type:12,data:u},{type:12,data:d},{type:12,data:p},{type:12,data:m}),o.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let g=!1;if(t.kernelShape.length===2){let v=t.kernelShape[t.kernelShape.length-2],_=t.strides[t.strides.length-2],b=t.pads[t.pads.length/2-2],k=t.pads[t.pads.length-2];g=!!(b+k),s.push({type:12,data:v},{type:12,data:_},{type:12,data:b},{type:12,data:k}),o.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[s,o,!0,f,g]}else{if(r)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let u=G.computeStrides(t.kernelShape);s.push({type:12,data:u},{type:12,data:t.pads},{type:12,data:t.strides}),o.push({name:"kernelStrides",type:"u32",length:u.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length});let d=t.pads.reduce((p,m)=>p+m);return[s,o,!!d,!1,!1]}},xh=(e,t,r,i,a,s,o,u,d,p,m,f)=>{let g=a.format==="NHWC",v=t.type.value,_=fe("output",t.type.tensor,i);if(a.kernelShape.length<=2){let b="",k="",$="",w=r-(g?2:1);if(m?b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${w}] = indices[${w}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${w}] < 0 || xIndices[${w}]
                      >= uniforms.x_shape[${w}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`:b=`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${w}] = indices[${w}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${s}
                }`,a.kernelShape.length===2){let S=r-(g?3:2);f?k=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${S}] < 0 || xIndices[${S}] >= uniforms.x_shape[${S}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:k=`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${S}] = indices[${S}] * uniforms.sh - uniforms.phStart + j;
                `,$=`
              }
            `}return`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var value = ${v}(${u});
              var pad = 0;
              ${k}
              ${b}
              ${$}
              ${o}

              output[global_idx] = value;
            }`}else{if(g)throw new Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let b=a.kernelShape.length,k=a.pads.length,$="";return p?$=`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${s}
              }`:$=`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${s}
            `,`
            ${e.registerUniforms(d).declareVariables(t,_)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${_.offsetToIndices("global_idx")};
              var xIndices = ${_.offsetToIndices("global_idx")};

              var offsets: array<u32, ${b}>;

              var value = ${v}(${u});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${b-1}u; j++) {
                  offsets[j] = offset / ${ge("uniforms.kernelStrides","j",b)};
                  offset -= offsets[j] * ${ge("uniforms.kernelStrides","j",b)};
                }
                offsets[${b-1}] = offset;

                isPad = false;
                for (var j = ${r-b}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${ge("uniforms.strides",`j - ${r-b}u`,b)}
                    + offsets[j - ${r-b}u] - ${ge("uniforms.pads","j - 2u",k)};
                  ${$}
              }
              ${o}

              output[global_idx] = value;
            }`}},kh=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,K1=e=>`${kh(e)};${e.countIncludePad}`,Z1=e=>`${kh(e)};${e.storageOrder};${e.dilations}`,Sh=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),Th=(e,t,r,i)=>{let[a,s]=bh(t,i,r),o=Z("x",t.dataType,t.dims.length),u=o.type.value,d="value += x_val;",p="";a.countIncludePad?p+=`value /= ${u}(uniforms.kernelSize);`:p+=`value /= ${u}(i32(uniforms.kernelSize) - pad);`;let[m,f,g,v,_]=$h(s,a);m.push(..._e(t.dims,s));let b=["rank"];return{name:e,shaderCache:{hint:`${i.cacheKey};${g};${v};${_}`,inputDependencies:b},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(G.size(s)/64)},programUniforms:m}),getShaderSource:k=>xh(k,o,t.dims.length,s.length,a,d,p,0,f,g,v,_)}},Pk=e=>{let t=e.count_include_pad!==0,r=Sh(e);if(r.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for AveragePool");let i={countIncludePad:t,...r,cacheKey:""};return{...i,cacheKey:K1(i)}},Uk=(e,t)=>{Ks(e.inputs),e.compute(Th("AveragePool",e.inputs[0],!1,t))},Ch={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},Wk=e=>{let t=e.format;return{format:t,...Ch,cacheKey:t}},Vk=(e,t)=>{Ks(e.inputs),e.compute(Th("GlobalAveragePool",e.inputs[0],!0,t))},Ih=(e,t,r,i)=>{let[a,s]=bh(t,i,r),o=`
      value = max(x_val, value);
    `,u="",d=Z("x",t.dataType,t.dims.length),p=["rank"],[m,f,g,v,_]=$h(s,a);return m.push(..._e(t.dims,s)),{name:e,shaderCache:{hint:`${i.cacheKey};${g};${v};${_}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:s,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(G.size(s)/64)},programUniforms:m}),getShaderSource:b=>xh(b,d,t.dims.length,s.length,a,o,u,t.dataType===10?-65504:-1e5,f,g,v,_)}},qk=(e,t)=>{Ks(e.inputs),e.compute(Ih("MaxPool",e.inputs[0],!1,t))},jk=e=>{let t=e.storage_order,r=e.dilations,i=Sh(e);if(t!==0)throw new Error("column major storage order is not yet supported for MaxPool");if(i.ceilMode!==0)throw new Error("using ceil() in shape computation is not yet supported for MaxPool");let a={storageOrder:t,dilations:r,...i,cacheKey:""};return{...a,cacheKey:Z1(a)}},Lk=e=>{let t=e.format;return{format:t,...Ch,cacheKey:t}},Gk=(e,t)=>{Ks(e.inputs),e.compute(Ih("GlobalMaxPool",e.inputs[0],!0,t))}}),jI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),Q1=(e,t)=>{if(e.length<2||e.length>3)throw new Error("DequantizeLinear requires 2 or 3 inputs.");if(e.length===3&&e[1].dims===e[2].dims)throw new Error("x-scale and x-zero-point must have the same shape.");if(e.length===3&&e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[0].dataType===6&&e.length>2)throw new Error("In the case of dequantizing int32 there is no zero point.");if(e[1].dims.length!==0&&e[1].dims.length!==1&&e[1].dims.length!==e[0].dims.length)throw new Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(e.length>2){if(e[0].dataType!==e[2].dataType)throw new Error("x and x-zero-point must have the same data type.");if(e[1].dims.length!==e[2].dims.length)throw new Error("scale and zero-point inputs must have the same rank.");if(!e[1].dims.map((r,i)=>r===e[2].dims[i]).reduce((r,i)=>r&&i,!0))throw new Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(e[1].dims.length===0||e[1].dims.length===1&&e[1].dims[0]===1)throw new Error("blockSize must be set only for block quantization.");if(!e[1].dims.map((a,s)=>s===t.axis||a===e[0].dims[s]).reduce((a,s)=>a&&s,!0))throw new Error("For block qunatization, scale input shape to match the input shape except for the axis");if(e[1].dims.length!==e[0].dims.length)throw new Error("For block qunatization the scale input rank must be the same as the x rank.");let r=e[0].dims[t.axis],i=e[1].dims[t.axis];if(t.blockSize<Math.ceil(r/i)||t.blockSize>Math.ceil(r/(i-1)-1))throw new Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}},X1=(e,t)=>{let r=G.normalizeAxis(t.axis,e[0].dims.length),i=e[0].dataType,a=i===3,s=e[0].dims,o=e[1].dataType,u=G.size(s),d=i===3||i===2,p=d?[Math.ceil(G.size(e[0].dims)/4)]:e[0].dims,m=e[1].dims,f=e.length>2?e[2]:void 0,g=f?d?[Math.ceil(G.size(f.dims)/4)]:f.dims:void 0,v=m.length===0||m.length===1&&m[0]===1,_=v===!1&&m.length===1,b=Ye(u),k=v&&(!d||b===4),$=k?b:1,w=k&&!d?b:1,S=Z("input",d?12:i,p.length,w),C=Z("scale",o,m.length),I=f?Z("zero_point",d?12:i,g.length):void 0,z=fe("output",o,s.length,$),E=[S,C];I&&E.push(I);let B=[p,m];f&&B.push(g);let U=[{type:12,data:u/$},{type:12,data:r},{type:12,data:t.blockSize},..._e(...B,s)],V=W=>{let J=[{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}];return`
      ${W.registerUniforms(J).declareVariables(...E,z)}
      ${W.mainStart()}
          ${W.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${z.offsetToIndices("global_idx")};

          // Set input x
          ${d?`
            let input = ${S.getByOffset("global_idx / 4")};
            let x_vec = ${a?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${$===1?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${S.getByOffset("global_idx")};`};

          // Set scale input
          ${v?`let scale_value= ${C.getByOffset("0")}`:_?`
            let scale_index = ${z.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${C.getByOffset("scale_index")};`:`
            var scale_indices: ${C.type.indices} = output_indices;
            let index = ${C.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${C.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${C.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${I?v?d?`
                let zero_point_input = ${I.getByOffset("0")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`:`let zero_point_value = ${I.getByOffset("0")}`:_?d?`
                let zero_point_index = ${z.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${I.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`:`
                let zero_point_index = ${z.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${I.getByOffset("zero_point_index")};`:d?`
                let zero_point_offset = ${C.indicesToOffset("scale_indices")};
                let zero_point_input = ${I.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${a?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`:`let zero_point_value = ${I.getByIndices("scale_indices")};`:`let zero_point_value = ${d?a?"i32":"u32":S.type.value}(0);`};
      // Compute and write output
      ${z.setByOffset("global_idx",`${z.type.value}(x_value - zero_point_value) * scale_value`)};
      }`};return{name:"DequantizeLinear",shaderCache:{hint:t.cacheKey,inputDependencies:I?["rank","rank","rank"]:["rank","rank"]},getShaderSource:V,getRunData:()=>({outputs:[{dims:s,dataType:o}],dispatchGroup:{x:Math.ceil(u/$/64),y:1,z:1},programUniforms:U})}},Fk=(e,t)=>{Q1(e.inputs,t),e.compute(X1(e.inputs,t))},Hk=e=>Le({axis:e.axis,blockSize:e.blockSize})}),LI=te(()=>{"use strict";fr(),$e(),ze(),J1=(e,t,r)=>{let i=e===t,a=e<t&&r<0,s=e>t&&r>0;if(i||a||s)throw new Error("Range these inputs' contents are invalid.")},Y1=(e,t,r,i)=>{let a=Math.abs(Math.ceil((t-e)/r)),s=[a],o=a,u=[{type:12,data:o},{type:i,data:e},{type:i,data:r},..._e(s)],d=p=>{let m=fe("output",i,s.length),f=m.type.value,g=[{name:"outputSize",type:"u32"},{name:"start",type:f},{name:"delta",type:f}];return`
        ${p.registerUniforms(g).declareVariables(m)}
        ${p.mainStart()}
        ${p.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${f}(global_idx) * uniforms.delta;
      }`};return{name:"Range",shaderCache:{hint:`${i}`},getShaderSource:d,getRunData:()=>({outputs:[{dims:s,dataType:i}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:u})}},Kk=e=>{let t=0,r=0,i=0;e.inputs[0].dataType===6?(t=e.inputs[0].getInt32Array()[0],r=e.inputs[1].getInt32Array()[0],i=e.inputs[2].getInt32Array()[0]):e.inputs[0].dataType===1&&(t=e.inputs[0].getFloat32Array()[0],r=e.inputs[1].getFloat32Array()[0],i=e.inputs[2].getFloat32Array()[0]),Ze.webgpu.validateInputContent&&J1(t,r,i),e.compute(Y1(t,r,i,e.inputs[0].dataType),{inputs:[]})}}),GI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),e2=(e,t,r,i)=>{if(e!=="none"&&i!=="i32"&&i!=="u32"&&i!=="f32")throw new Error(`Input ${i} is not supported with reduction ${e}.`);let a=`{
                var oldValue = 0;
                loop {
                  let newValueF32 =`,s=`;
                  let newValue = bitcast<i32>(newValueF32);
                  let res = atomicCompareExchangeWeak(&${t}, oldValue, newValue);
                  if res.exchanged {
                    break;
                  }
                  oldValue = res.old_value;
                }
              }`;switch(e){case"none":return`${t}=${r};`;case"add":return i==="i32"||i==="u32"?`atomicAdd(&${t}, bitcast<${i}>(${r}));`:`
              ${a}bitcast<${i}>(oldValue) + (${r})${s}`;case"max":return i==="i32"||i==="u32"?`atomicMax(&${t}, bitcast<${i}>(${r}));`:`
                ${a}max(bitcast<f32>(oldValue), (${r}))${s}`;case"min":return i==="i32"||i==="u32"?`atomicMin(&${t}, bitcast<${i}>(${r}));`:`${a}min(bitcast<${i}>(oldValue), (${r}))${s}`;case"mul":return`${a}(bitcast<${i}>(oldValue) * (${r}))${s}`;default:throw new Error(`Reduction ${e} is not supported.`)}},t2=(e,t)=>{let r=e[0].dims,i=e[1].dims,a=r,s=1,o=Math.ceil(G.size(i)/s),u=i[i.length-1],d=G.sizeFromDimension(r,u),p=[{type:12,data:o},{type:12,data:u},{type:12,data:d},..._e(e[1].dims,e[2].dims,a)],m=f=>{let g=Z("indices",e[1].dataType,e[1].dims.length),v=Z("updates",e[2].dataType,e[2].dims.length,s),_=t.reduction!=="none"&&t.reduction!==""?Tx("output",e[0].dataType,a.length):fe("output",e[0].dataType,a.length,s);return`
      ${f.registerUniform("output_size","u32").registerUniform("last_index_dimension","u32").registerUniform("num_updates_elements","u32").declareVariables(g,v,_)}
      ${f.mainStart()}
        ${f.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
  var hasDuplicates = false;
  if (${t.reduction==="none"}) {
    let n = ${G.size(i)};
    for (var i = 0; i < n; i = i + 1) {
      for (var j = i + 1; j < n; j = j + 1) {
        var index_i = i32(indices[i].x);
        var index_j = i32(indices[j].x);
        if (index_i == index_j) {
          hasDuplicates = true;
          break;
        }
      }
      if (hasDuplicates) {
        break;
      }
    }
  }

  var data_offset = 0u;
  var indices_start = uniforms.last_index_dimension * global_idx;
  if (${t.reduction==="none"} && hasDuplicates) {
    if (global_idx != 0u) {
      return;
    }
    indices_start = 0u;
  }
  let indices_end = indices_start + uniforms.last_index_dimension;
  for (var i = indices_start; i < indices_end; i++) {
    var index = i32(indices[i].x);
    ${e[0].dims.length===1?`
    let element_count_dim = uniforms.output_strides;
    let dim_value = uniforms.output_shape;`:`
    let element_count_dim = uniforms.output_strides[i - indices_start];
    let dim_value = uniforms.output_shape[i - indices_start + uniforms.last_index_dimension];`}
    if (index >= 0) {
      if (index >= i32(dim_value)) {
        index = i32(dim_value - 1);
      }
    } else {
      if (index < -i32(dim_value)) {
        index = 0;
      } else {
        index += i32(dim_value);
      }
    }
    data_offset += u32((u32(index) * element_count_dim));
  }

  for (var i = 0u; i < uniforms.num_updates_elements; i++) {
    let value = updates[uniforms.num_updates_elements * global_idx + i];
    ${e2(t.reduction,"output[data_offset + i]","value",_.type.value)}
  }

      }`};return{name:"ScatterND",shaderCache:{hint:`${t.cacheKey}_${t.reduction}`,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:p}),getShaderSource:m}},Zk=e=>Le({reduction:e.reduction}),Qk=(e,t)=>{e.compute(t2(e.inputs,t),{inputs:[e.inputs[1],e.inputs[2]],outputs:[]})}}),FI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),r2=(e,t)=>{if(e.every(r=>r>0||(()=>{throw new Error("Resize requires scales input values to be positive")})),e.length>0){if(t.mode==="linear"){if(!(e.length===2||e.length===3||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1||e.length===5&&e[0]===1&&e[1]===1))throw new Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if(t.mode==="cubic"&&!(e.length===2||e.length===4&&e[0]===1&&e[1]===1||e.length===4&&e[0]===1&&e[3]===1))throw new Error("Resize requires scales input size to be 2 or 4 for cubic mode")}},i2=(e,t,r)=>{t.every(a=>a>=0&&a<r||(()=>{throw new Error("Resize requires axes input values to be positive and less than rank")}));let i=new Array(r).fill(1);return t.forEach((a,s)=>i[a]=e[s]),i},a2=(e,t,r,i,a,s)=>{let[o,u,d]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],p=e[0].dims.length;if(o>0&&e.length>o&&e[o].dims.length>0)e[o].getFloat32Array().forEach(m=>s.push(m));else if(t.coordinateTransformMode==="tf_crop_and_resize")throw new Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(u>0&&e.length>u&&e[u].dims.length===1&&e[u].dims[0]>0){if(e[u].getFloat32Array().forEach(m=>i.push(m)),i.length!==0&&i.length!==p&&r>=18&&i.length!==t.axes.length)throw new Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");r2(i,t),t.axes.length>0&&i2(i,t.axes,p).forEach((m,f)=>i[f]=m)}if(d>0&&e.length>d&&e[d].dims.length===1&&e[d].dims[0]>0&&(e[d].getBigInt64Array().forEach(m=>a.push(Number(m))),a.length!==0&&a.length!==p&&r>=18&&a.length!==t.axes.length))throw new Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(i.length!==0&&i.length!==t.axes.length)throw new Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(a.length!==0&&a.length!==t.axes.length)throw new Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if(typeof i<"u"&&typeof a<"u"&&i.length>0&&a.length>p)throw new Error("Resize requires only of scales or sizes to be specified")},Eh=(e,t,r,i)=>`
  // The whole part and the fractional part are calculated separately due to inaccuracy of floating
  // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
  // offset-by-one error later in floor().
  let big = (${e}) * (${t});
  let whole = ${i}(big / (${r}));
  let fract = ${i}(big % (${r})) / ${i}(${r});
  return whole + fract;
`,n2=(e,t)=>`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${t} { `+(()=>{switch(e){case"asymmetric":return`
          if (xScale < 1.0 || floor(xScale) != xScale) {
            return ${t}(xResized) / ${t}(xScale);
          } else {
            ${Eh("xResized","lengthOriginal","lengthResized",t)}
          }
        `;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${t}(xResized) + 0.5) / ${t}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${t}(xResized) + 0.5) / ${t}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    ${Eh("xResized","lengthOriginal - 1","lengthResized - 1",t)}
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${t}(roiStart) * ${t}(lengthOriginal - 1) +
                        (${t}(xResized) * ${t}(roiEnd - roiStart) * ${t}(lengthOriginal - 1)) /
                        ${t}(lengthResized - 1);
                  } else {
                    return 0.5 * ${t}(roiStart + roiEnd) * ${t}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${t}xScale * ${t}(lengthResized);
                  const adjustment = ${t}(lengthResized) / outputWidth;
                  const center = ${t}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;case"half_pixel":return`return ((${t}(xResized) + 0.5) / ${t}(xScale)) - 0.5;`;default:throw new Error(`Coordinate transform mode ${e} is not supported`)}})()+"}",s2=(e,t,r)=>`fn getNearestPixelFromOriginal(xOriginal: ${r}, isDownSample: bool) -> ${r} {`+(()=>{switch(e){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";case"simple":default:if(t<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw new Error(`Nearest mode ${e} is not supported`)}})()+"}",o2=(e,t,r)=>{let i=new Array(r).fill(0).concat(new Array(r).fill(1)),a=e.length===0?i:e.slice();return t.length>0?(t.forEach((s,o)=>{i[s]=a[o],i[o+r]=a[t.length+o]}),i):a},u2=(e,t,r,i)=>{let a=[];if(r.length>0)if(i.length>0){if(e.forEach(s=>a.push(s)),Math.max(...i)>e.length)throw new Error("axes is out of bound");i.forEach((s,o)=>a[s]=r[o])}else r.forEach(s=>a.push(s));else{if(t.length===0)throw new Error("Resize requires either scales or sizes.");a=e.map((s,o)=>Math.round(s*t[o]))}return a},l2=(e,t,r)=>{let i=(()=>{switch(r.keepAspectRatioPolicy){case"not_larger":return r.axes.length>0?Math.min(...r.axes.map(s=>t[s]),Number.MAX_VALUE):Math.min(...t,Number.MAX_VALUE);case"not_smaller":return r.axes.length>0?Math.max(...r.axes.map(s=>t[s]),Number.MIN_VALUE):Math.max(...t,Number.MIN_VALUE);default:throw new Error(`Keep aspect ratio policy ${r.keepAspectRatioPolicy} is not supported`)}})();t.fill(1,0,t.length);let a=e.slice();return r.axes.length>0?(r.axes.forEach(s=>t[s]=i),r.axes.forEach(s=>a[s]=Math.round(e[s]*t[s]))):(t.fill(i,0,t.length),a.forEach((s,o)=>a[o]=Math.round(s*t[o]))),a},d2=(e,t,r,i,a)=>`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${e.type.indices}) -> array<${e.type.value}, ${r.length}> {
      var original_indices: array<${e.type.value}, ${r.length}>;
      for (var i:u32 = 0; i < ${r.length}; i++) {
        var output_index = ${e.indicesGet("output_indices","i")};
        var scale = ${ge("uniforms.scales","i",i)};
        var roi_low = ${ge("uniforms.roi","i",a)};
        var roi_hi = ${ge("uniforms.roi",`i + ${t.length}`,a)};
        if (scale == 1.0) {
          original_indices[i] = ${e.type.value}(output_index);
        } else {
          var input_shape_i = ${ge("uniforms.input_shape","i",t.length)};
          var output_shape_i = ${ge("uniforms.output_shape","i",r.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`,p2=(e,t,r,i,a,s,o)=>`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
      var input_indices: ${e.type.indices};
      for (var i:u32 = 0; i < ${i.length}; i++) {
        var output_index = ${t.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${ge("uniforms.scales","i",a)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${ge("uniforms.roi","i",s)};
          var roi_hi = ${ge("uniforms.roi",`i + ${r.length}`,s)};
          var input_shape_i = ${ge("uniforms.input_shape","i",r.length)};
          var output_shape_i = ${ge("uniforms.output_shape","i",i.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${o} || (original_idx >= 0 && original_idx < ${t.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${t.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${e.indicesSet("input_indices","i","input_index")}
      }
      return input_indices;
    }`,c2=(e,t)=>`
    fn checkInputIndices(input_indices: ${e.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${t.length}; i++) {
        var input_index = ${e.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${ge("uniforms.input_shape","i",t.length)}) {
          return false;
        }
      }
      return true;
    }`,zh=(e,t,r,i)=>e.rank>i?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",h2=(e,t,r,i,a)=>{let[s,o,u,d]=r.length===2?[-1,0,1,-1]:[0,2,3,1],p=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${p} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",o,`max(0, min(row, ${r[o]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(col, ${r[u]} - 1))`)};
      ${zh(e,d,s,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${p} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${p} = originalIndices[${o}];
      var col:${p} = originalIndices[${u}];
      ${i?`if (row < 0 || row > (${r[o]} - 1) || col < 0 || col > (${r[u]} - 1)) {
        return ${a};
      }`:""};
      row = max(0, min(row, ${r[o]} - 1));
      col = max(0, min(col, ${r[u]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${d}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${s}])`:"0"};
      var x11: ${p} = getInputValue(batch, channel, row1, col1);
      var x12: ${p} = getInputValue(batch, channel, row1, col2);
      var x21: ${p} = getInputValue(batch, channel, row2, col1);
      var x22: ${p} = getInputValue(batch, channel, row2, col2);
      var dx1: ${p} = abs(row - ${p}(row1));
      var dx2: ${p} = abs(${p}(row2) - row);
      var dy1: ${p} = abs(col - ${p}(col1));
      var dy2: ${p} = abs(${p}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`},f2=(e,t,r,i,a,s,o,u,d,p)=>{let m=r.length===2,f=!0,[g,v]=m?[0,1]:f?[2,3]:[1,2],_=e.type.value,b=k=>{let $=k===g?"row":"col";return`
      fn ${$}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${_} {
        var output_index = ${t.indicesGet("output_indices",k)};
        var originalIdx: ${_} = getOriginalCoordinateFromResizedCoordinate(output_index, ${a[k]},
        ${i[k]}, ${r[k]}, ${s[k]}, ${s[k]} + ${r.length});
        var fractOriginalIdx: ${_} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${u} && (originalIdx < 0 || originalIdx > (${r[k]} - 1))) {
          return ${d};
        }
        var data: array<${_}, 4> = array<${_}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${$}: ${_} = originalIdx + ${_}(i);
          if (${$} < 0 || ${$} >= ${r[k]}) {
            ${p?`coefs[i + 1] = 0.0;
                        continue;`:u?`return ${d};`:`${$} = max(0, min(${$}, ${r[k]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",k,`u32(${$})`)};
          data[i + 1] = ${k===g?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${b(g)};
    ${b(v)};
  fn getCubicInterpolationCoefs(s: ${_}) -> array<${_}, 4> {
    var absS = abs(s);
    var coeffs: array<${_}, 4> = array<${_}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${_} = 1.0 - absS;
    var twoMinusAbsS: ${_} = 2.0 - absS;
    var onePlusAbsS: ${_} = 1.0 + absS;
    coeffs[0] = ((${o} * onePlusAbsS - 5 * ${o}) * onePlusAbsS + 8 * ${o}) * onePlusAbsS - 4 * ${o};
    coeffs[1] = ((${o} + 2) * absS - (${o} + 3)) * absS * absS + 1;
    coeffs[2] = ((${o} + 2) * oneMinusAbsS - (${o} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${o} * twoMinusAbsS - 5 * ${o}) * twoMinusAbsS + 8 * ${o}) * twoMinusAbsS - 4 * ${o};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${_}, 4>, coefs: array<${_}, 4>) -> ${_} {
    var coefsSum: ${_} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${_} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `},m2=(e,t,r,i,a)=>{let[s,o,u,d,p]=r.length===3?[-1,0,1,2,-1]:[0,2,3,4,1],m=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${m} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",o,`max(0, min(depth, ${r[o]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(height, ${r[u]} - 1))`)};
      ${e.indicesSet("input_indices",d,`max(0, min(width, ${r[d]} - 1))`)};
      ${zh(e,p,s,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${m} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${m} = originalIndices[${o}];
      var height:${m} = originalIndices[${u}];
      var width:${m} = originalIndices[${d}];
      ${i?`if (depth < 0 || depth > (${r[o]} - 1) || height < 0 || height > (${r[u]} - 1) || width < 0 || (width > ${r[d]} - 1)) {
      return ${a};
        }`:""};

    depth = max(0, min(depth, ${r[o]} - 1));
      height = max(0, min(height, ${r[u]} - 1));
      width = max(0, min(width, ${r[d]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${p}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${s}])`:"0"};

      var x111: ${m} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${m} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${m} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${m} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${m} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${m} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${m} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${m} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${m} = abs(depth - ${m}(depth1));
      var dx2: ${m} = abs(${m}(depth2) - depth);
      var dy1: ${m} = abs(height - ${m}(height1));
      var dy2: ${m} = abs(${m}(height2) - height);
      var dz1: ${m} = abs(width - ${m}(width1));
      var dz2: ${m} = abs(${m}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`},g2=(e,t,r,i,a,s)=>{let o=e.dims,u=o2(s,t.axes,o.length),d=u2(o,i,a,t.axes),p=i.slice();i.length===0&&(p=o.map((w,S)=>w===0?1:d[S]/w),t.keepAspectRatioPolicy!=="stretch"&&(d=l2(o,p,t)));let m=fe("output",e.dataType,d.length),f=Z("input",e.dataType,o.length),g=G.size(d),v=o.length===d.length&&o.every((w,S)=>w===d[S]),_=t.coordinateTransformMode==="tf_crop_and_resize",b=t.extrapolationValue,k=f.type.value,$=w=>`
      ${v?"":`
      ${n2(t.coordinateTransformMode,k)};
      ${(()=>{switch(t.mode){case"nearest":return`
              ${c2(f,o)};
              ${s2(t.nearestMode,r,k)};
              ${p2(f,m,o,d,p.length,u.length,_)};
              `;case"linear":return`
              ${d2(m,o,d,p.length,u.length)};
              ${(()=>{if(o.length===2||o.length===4)return`${h2(f,m,o,_,b)}`;if(o.length===3||o.length===5)return`${m2(f,m,o,_,b)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(o.length===2||o.length===4)return`${f2(f,m,o,d,p,u,t.cubicCoeffA,_,t.extrapolationValue,t.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${w.registerUniform("output_size","u32").registerUniform("scales","f32",p.length).registerUniform("roi","f32",u.length).declareVariables(f,m)}
      ${w.mainStart()}
        ${w.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${v?"output[global_idx] = input[global_idx];":`
        let output_indices = ${m.offsetToIndices("global_idx")};
        var input_indices: ${f.type.indices};
        ${(()=>{switch(t.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${f.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${t.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${o.length===2||o.length===4?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${t.mode}`)}})()};
`}
      }`;return{name:"Resize",shaderCache:{hint:`${t.cacheKey}|${r}|${p.length>0?t.mode==="cubic"?p:p.length:""}|${a.length>0?a:""}|${u.length>0?u:""}|${v}|${t.mode==="nearest"?o.length:o}`,inputDependencies:["rank"]},getShaderSource:$,getRunData:()=>({outputs:[{dims:d,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:[{type:12,data:g},{type:1,data:p},{type:1,data:u},..._e(o,d)]})}},y2=e=>{let t=e.customDataBuffer;return new Uint32Array(t,t.byteOffset,1)[0]},Xk=(e,t)=>{let r=[],i=[],a=[],s=y2(e);if(t.antialias!==0)throw Error("Only default value (0) for Antialias attribute is supported");a2(e.inputs,t,s,r,i,a),e.compute(g2(e.inputs[0],t,s,r,i,a),{inputs:[0]})},Jk=e=>{let t=e.antialias,r=e.axes,i=e.coordinateTransformMode,a=e.cubicCoeffA,s=e.excludeOutside!==0,o=e.extrapolationValue,u=e.keepAspectRatioPolicy,d=e.mode,p=e.nearestMode===""?"simple":e.nearestMode;return Le({antialias:t,axes:r,coordinateTransformMode:i,cubicCoeffA:a,excludeOutside:s,extrapolationValue:o,keepAspectRatioPolicy:u,mode:d,nearestMode:p})}}),HI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),_2=(e,t)=>{let[r,i,a,s]=e,{numHeads:o,rotaryEmbeddingDim:u}=t;if(r.dims.length!==3&&r.dims.length!==4)throw new Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!G.areEqual(i.dims,[])&&!G.areEqual(i.dims,[1])&&i.dims.length!==2)throw new Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${i.dims.length}`);if(a.dims.length!==2)throw new Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${a.dims.length}`);if(s.dims.length!==2)throw new Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${s.dims.length}`);if(!G.areEqual(a.dims,s.dims))throw new Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(u>0&&o===0)throw new Error("num_heads must be provided if rotary_embedding_dim is specified");let d=r.dims[0],p=r.dims[r.dims.length-2],m=a.dims[0],f=G.sizeFromDimension(r.dims,1)/p,g=u===0?a.dims[1]*2:f/o;if(u>g)throw new Error("rotary_embedding_dim must be less than or equal to head_size");if(i.dims.length===2){if(d!==i.dims[0])throw new Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${i.dims[0]}`);if(p!==i.dims[1])throw new Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${i.dims[1]}`)}if(g/2!==a.dims[1]&&u/2!==a.dims[1])throw new Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${a.dims[1]}`);if(p>m)throw new Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported")},v2=(e,t)=>{let{interleaved:r,numHeads:i,rotaryEmbeddingDim:a,scale:s}=t,o=e[0].dims[0],u=G.sizeFromDimension(e[0].dims,1),d=e[0].dims[e[0].dims.length-2],p=u/d,m=e[2].dims[1],f=a===0?m*2:p/i,g=new Array(o,d,p/f,f-m),v=G.computeStrides(g),_=[{type:1,data:s},{type:12,data:g},{type:12,data:v},...e[0].dims.length===3?new Array({type:12,data:[u,p,f,1]}):[],...e[0].dims.length===4?new Array({type:12,data:[u,f,d*f,1]}):[],..._e(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)],b=k=>{let $=Z("input",e[0].dataType,e[0].dims.length),w=Z("position_ids",e[1].dataType,e[1].dims.length),S=Z("cos_cache",e[2].dataType,e[2].dims.length),C=Z("sin_cache",e[3].dataType,e[3].dims.length),I=fe("output",e[0].dataType,e[0].dims.length);return k.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:g.length},{name:"global_strides",type:"u32",length:v.length},{name:"input_output_strides",type:"u32",length:v.length}]),`
        ${k.declareVariables($,w,S,C,I)}

        ${k.mainStart(la)}
          let half_rotary_emb_dim = uniforms.${S.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${k.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${w.broadcastedIndicesToOffset("bsnh.xy",fe("",w.type.tensor,2))};
            let position_id =
                u32(${w.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${$.getByOffset("i")} * ${S.get("position_id","bsnh[3]")} -
                ${$.getByOffset("j")} * ${C.get("position_id","bsnh[3]")};
            ${I.setByOffset("i","re")}
            let im = ${$.getByOffset("i")} * ${C.get("position_id","bsnh[3]")} +
                ${$.getByOffset("j")} * ${S.get("position_id","bsnh[3]")};
            ${I.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${I.setByOffset("k",$.getByOffset("k"))}
          }
        }`};return{name:"RotaryEmbedding",shaderCache:{hint:Le({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:b,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(G.size(g)/la)},programUniforms:_})}},Yk=(e,t)=>{_2(e.inputs,t),e.compute(v2(e.inputs,t))}}),KI=te(()=>{"use strict";$e(),Ce(),ze(),w2=e=>{if(!e||e.length<3)throw new Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],i=e[2];if(t.dataType!==r.dataType||t.dataType!==i.dataType)throw new Error("All inputs must have the same data type");if(t.dims.length!==3&&t.dims.length!==2)throw new Error("Input must be 2D or 3D");if(r.dims.length!==3&&r.dims.length!==2)throw new Error("Skip must be 2D or 3D");let a=t.dims[t.dims.length-1],s=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==a)throw new Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==s)throw new Error("Skip must have the same sequence length as input");if(i.dims.length!==1)throw new Error("Gamma must be 1D");if(i.dims[i.dims.length-1]!==a)throw new Error("Gamma must have the same hidden size as input");if(e.length>3){let o=e[3];if(o.dims.length!==1)throw new Error("Beta must be 1D");if(o.dims[o.dims.length-1]!==a)throw new Error("Beta must have the same hidden size as input")}if(e.length>4){let o=e[4];if(o.dims.length!==1)throw new Error("Bias must be 1D");if(o.dims[o.dims.length-1]!==a)throw new Error("Bias must have the same hidden size as input")}},b2=(e,t,r,i)=>{let a=t.simplified,s=e[0].dims,o=G.size(s),u=s,d=o,p=s.slice(-1)[0],m=i?s.slice(0,-1).concat(1):[],f=!a&&e.length>3,g=e.length>4,v=i&&r>1,_=i&&r>2,b=r>3,k=64,$=Ye(p),w=[{type:12,data:d},{type:12,data:$},{type:12,data:p},{type:1,data:t.epsilon}],S=I=>{let z=[{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}],E=[Z("x",e[0].dataType,e[0].dims,$),Z("skip",e[1].dataType,e[1].dims,$),Z("gamma",e[2].dataType,e[2].dims,$)];f&&E.push(Z("beta",e[3].dataType,e[3].dims,$)),g&&E.push(Z("bias",e[4].dataType,e[4].dims,$)),E.push(fe("output",e[0].dataType,u,$)),v&&E.push(fe("mean_output",1,m)),_&&E.push(fe("inv_std_output",1,m)),b&&E.push(fe("input_skip_bias_sum",e[0].dataType,u,$));let B=ct(e[0].dataType),U=ct(1,$);return`

      ${I.registerUniforms(z).declareVariables(...E)}
      var<workgroup> sum_shared : array<${U}, ${k}>;
      var<workgroup> sum_squared_shared : array<${U}, ${k}>;

      ${I.mainStart([k,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / ${k};

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / ${k};
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == ${k-1}) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${g?"bias[offset1d + i]":B+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${b?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${oa(B,$,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = ${k};
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${Xr("sum",$)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${Xr("square_sum",$)} / f32(uniforms.hidden_size) ${a?"":"- mean * mean"} + uniforms.epsilon);
        ${v?"mean_output[global_idx] = mean;":""}
        ${_?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${a?"":`- ${B}(mean)`}) *
            ${B}(inv_std_dev) * gamma[offset1d + i]
            ${f?"+ beta[offset1d + i]":""};
        }
      }`},C=[{dims:u,dataType:e[0].dataType}];return r>1&&C.push({dims:m,dataType:1}),r>2&&C.push({dims:m,dataType:1}),r>3&&C.push({dims:s,dataType:e[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${$};${v};${_};${b}`,inputDependencies:e.map((I,z)=>"type")},getShaderSource:S,getRunData:()=>({outputs:C,dispatchGroup:{x:Math.ceil(d/p)},programUniforms:w})}},eS=(e,t)=>{w2(e.inputs);let r=[0];e.outputCount>1&&r.push(-3),e.outputCount>2&&r.push(-3),e.outputCount>3&&r.push(3),e.compute(b2(e.inputs,t,e.outputCount,!1),{outputs:r})}}),ZI=te(()=>{"use strict";$e(),Ce(),tt(),ze(),$2=(e,t)=>{if(!e||e.length<1)throw new Error("too few inputs");if(t.axes.length!==0){if(t.axes.length!==t.starts.length||t.axes.length!==t.ends.length)throw new Error("axes, starts and ends must have the same length")}else if(t.starts.length!==t.ends.length)throw new Error("starts and ends must have the same length");e.slice(1).forEach((r,i)=>{if(e[i+1].dataType!==6&&e[i+1].dataType!==7)throw new Error(`Input ${i} must be an array of int32 or int64`)})},Zs=(e,t)=>{let r=[];if(e.length>t)if(e[t].dataType===7)e[t].getBigInt64Array().forEach(i=>r.push(Number(i)));else if(e[t].dataType===6)e[t].getInt32Array().forEach(i=>r.push(Number(i)));else throw new Error(`Input ${t} must be an array of int32 or int64`);return r},x2=(e,t)=>{if(e.length>1){let r=Zs(e,1),i=Zs(e,2),a=Zs(e,3);return a.length===0&&(a=[...Array(e[0].dims.length).keys()]),Le({starts:r,ends:i,axes:a})}else return t},Ah=(e,t,r,i,a)=>{let s=e;return e<0&&(s+=r[i[t]]),a[t]<0?Math.max(0,Math.min(s,r[i[t]]-1)):Math.max(0,Math.min(s,r[i[t]]))},k2=(e,t,r)=>`fn calculateInputIndices(output_indices: ${t.type.indices}) -> ${e.type.indices} {
          var input_indices: ${e.type.indices};
          var carry = 0u;
          for (var i = ${r.length}; i >= 0; i--) {
            let input_shape_i = ${ge("uniforms.input_shape","i",r.length)};
            let steps_i = ${ge("uniforms.steps","i",r.length)};
            let signs_i = ${ge("uniforms.signs","i",r.length)};
            let starts_i = ${ge("uniforms.starts","i",r.length)};
            var output_index = ${t.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${e.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }`,S2=(e,t)=>{let r=e[0].dims,i=G.size(r),a=t.axes.length>0?G.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],s=Zs(e,4);s.forEach($=>$!==0||(()=>{throw new Error("step cannot be 0")})),s.length===0&&(s=Array(a.length).fill(1));let o=t.starts.map(($,w)=>Ah($,w,r,a,s)),u=t.ends.map(($,w)=>Ah($,w,r,a,s));if(a.length!==o.length||a.length!==u.length)throw new Error("start, ends and axes should have the same number of elements");if(a.length!==r.length)for(let $=0;$<r.length;++$)a.includes($)||(o.splice($,0,0),u.splice($,0,r[$]),s.splice($,0,1));let d=s.map($=>Math.sign($));s.forEach(($,w,S)=>{if($<0){let C=(u[w]-o[w])/$,I=o[w],z=I+C*s[w];o[w]=z,u[w]=I,S[w]=-$}});let p=r.slice(0);a.forEach(($,w)=>{p[$]=Math.ceil((u[$]-o[$])/s[$])});let m={dims:p,dataType:e[0].dataType},f=fe("output",e[0].dataType,p.length),g=Z("input",e[0].dataType,e[0].dims.length),v=G.size(p),_=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:o.length},{name:"signs",type:"i32",length:d.length},{name:"steps",type:"u32",length:s.length}],b=[{type:12,data:v},{type:12,data:o},{type:6,data:d},{type:12,data:s},..._e(e[0].dims,p)],k=$=>`
      ${$.registerUniforms(_).declareVariables(g,f)}
        ${k2(g,f,r)}
        ${$.mainStart()}
          ${$.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${f.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${f.setByOffset("global_idx",g.getByIndices("input_indices"))}
      }`;return{name:"Slice",shaderCache:{hint:`${d.length}_${o.length}_${s.length}`,inputDependencies:["rank"]},getShaderSource:k,getRunData:()=>({outputs:[m],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:b})}},tS=(e,t)=>{$2(e.inputs,t);let r=x2(e.inputs,t);e.compute(S2(e.inputs,r),{inputs:[0]})},rS=e=>{let t=e.starts,r=e.ends,i=e.axes;return Le({starts:t,ends:r,axes:i})}}),QI=te(()=>{"use strict";$e(),Ce(),tt(),Jr(),ze(),T2=e=>{if(!e||e.length!==1)throw new Error("Softmax op requires 1 input.")},C2=(e,t)=>{let r=e.inputs[0],i=r.dims,a=G.size(i),s=i.length,o=G.normalizeAxis(t.axis,s),u=o<i.length-1,d,p=[];u?(p=Array.from({length:s},(E,B)=>B),p[o]=s-1,p[s-1]=o,d=e.compute(Ut(r,p),{inputs:[r],outputs:[-1]})[0]):d=r;let m=d.dims,f=m[s-1],g=a/f,v=Ye(f),_=f/v,b=64;g===1&&(b=256);let k=(E,B)=>B===4?`max(max(${E}.x, ${E}.y), max(${E}.z, ${E}.w))`:B===2?`max(${E}.x, ${E}.y)`:B===3?`max(max(${E}.x, ${E}.y), ${E}.z)`:E,$=Z("x",d.dataType,d.dims,v),w=fe("result",d.dataType,d.dims,v),S=$.type.value,C=ct(d.dataType)==="f32"?`var threadMax = ${S}(-3.402823e+38f);`:`var threadMax = ${S}(-65504.0h);`,I=E=>`
      var<workgroup> rowMaxShared : ${S};
      var<workgroup> rowSumShared : ${S};
      var<workgroup> threadShared : array<${S}, ${b}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${S} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${S}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${E.registerUniform("packedCols","i32").declareVariables($,w)}
      ${E.mainStart(b)}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${b};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${C}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${S}(${k("threadShared[0]",v)});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${S}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${S}(${Xr("threadShared[0]",v)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          let value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          setValue(row, col, row_stride, value);
        }
      }`,z=e.compute({name:"Softmax",shaderCache:{hint:`${v};${b}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:m,dataType:d.dataType}],dispatchGroup:{x:g},programUniforms:[{type:6,data:_}]}),getShaderSource:I},{inputs:[d],outputs:[u?-1:0]})[0];u&&e.compute(Ut(z,p),{inputs:[z]})},iS=(e,t)=>{T2(e.inputs),C2(e,t)},aS=e=>Le({axis:e.axis})}),XI=te(()=>{"use strict";$e(),Ce(),ze(),Oh=e=>Array.from(e.getBigInt64Array(),Number),I2=e=>{if(!e||e.length!==2)throw new Error("Tile requires 2 inputs.");if(e[0].dataType!==1&&e[0].dataType!==10&&e[0].dataType!==6&&e[0].dataType!==12)throw new Error("Tile only support float, float16, int32, and uint32 data types");if(e[1].dataType!==7)throw new Error("Tile `repeats` input should be of int64 data type");if(e[1].dims.length!==1)throw new Error("Tile `repeats` input should be 1-D");if(Oh(e[1]).length!==e[0].dims.length)throw new Error("Tile `repeats` input should have same number of elements as rank of input data tensor")},E2=(e,t)=>{let r=[];for(let i=0;i<e.length;++i)r.push(e[i]*t[i]);return r},z2=(e,t)=>{let r=e[0].dims,i=t??Oh(e[1]),a=E2(r,i),s=G.size(a),o=e[0].dataType,u=Z("input",o,r.length),d=fe("output",o,a.length),p=m=>`
      const inputShape = ${u.indices(...r)};
      ${m.registerUniform("output_size","u32").declareVariables(u,d)}
      ${m.mainStart()}
      ${m.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${d.offsetToIndices("global_idx")};
      var input_indices: ${u.type.indices};
      for (var i = 0; i < ${r.length}; i++) {
        let input_dim_i = ${u.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${d.indicesGet("output_indices","i")}  % input_dim_i;

        ${u.indicesSet("input_indices","i","input_dim_value")}
      }
      ${d.setByOffset("global_idx",u.getByIndices("input_indices"))}
    }`;return{name:"Tile",shaderCache:{hint:`${i}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:[{type:12,data:s},..._e(e[0].dims,a)]}),getShaderSource:p}},nS=e=>{I2(e.inputs),e.compute(z2(e.inputs),{inputs:[0]})}}),JI=te(()=>{"use strict";$e(),Ce(),ze(),A2=(e,t,r,i,a)=>{let s=fe("output_data",a,r.length,4),o=Z("a_data",t[1].dataType,t[1].dims.length,4),u=Z("b_data",t[2].dataType,t[2].dims.length,4),d=Z("c_data",t[0].dataType,t[0].dims.length,4),p,m=(f,g,v)=>`select(${g}, ${f}, ${v})`;if(!i)p=s.setByOffset("global_idx",m(o.getByOffset("global_idx"),u.getByOffset("global_idx"),d.getByOffset("global_idx")));else{let f=(g,v,_="")=>{let b=`a_data[index_a${v}][component_a${v}]`,k=`b_data[index_b${v}][component_b${v}]`,$=`bool(c_data[index_c${v}] & (0xffu << (component_c${v} * 8)))`;return`
            let output_indices${v} = ${s.offsetToIndices(`global_idx * 4u + ${v}u`)};
            let offset_a${v} = ${o.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let offset_b${v} = ${u.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let offset_c${v} = ${d.broadcastedIndicesToOffset(`output_indices${v}`,s)};
            let index_a${v} = offset_a${v} / 4u;
            let index_b${v} = offset_b${v} / 4u;
            let index_c${v} = offset_c${v} / 4u;
            let component_a${v} = offset_a${v} % 4u;
            let component_b${v} = offset_b${v} % 4u;
            let component_c${v} = offset_c${v} % 4u;
            ${g}[${v}] = ${_}(${m(b,k,$)});
          `};a===9?p=`
            var data = vec4<u32>(0);
            ${f("data",0,"u32")}
            ${f("data",1,"u32")}
            ${f("data",2,"u32")}
            ${f("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:p=`
            ${f("output_data[global_idx]",0)}
            ${f("output_data[global_idx]",1)}
            ${f("output_data[global_idx]",2)}
            ${f("output_data[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(d,o,u,s)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${p}
      }`},O2=e=>{let t=e[1].dims,r=e[2].dims,i=e[0].dims,a=e[1].dataType,s=!(G.areEqual(t,r)&&G.areEqual(r,i)),o=t,u=G.size(t);if(s){let p=ua.calcShape(ua.calcShape(t,r,!1),i,!1);if(!p)throw new Error("Can't perform where op on the given tensors");o=p,u=G.size(o)}let d=Math.ceil(u/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:p=>A2(p,e,o,s,a),getRunData:()=>({outputs:[{dims:o,dataType:a}],dispatchGroup:{x:Math.ceil(u/64/4)},programUniforms:[{type:12,data:d},..._e(i,t,r,o)]})}},sS=e=>{e.compute(O2(e.inputs))}}),YI=te(()=>{"use strict";cI(),yf(),hI(),fI(),mI(),gI(),yI(),$I(),kI(),SI(),TI(),CI(),II(),EI(),zI(),AI(),OI(),RI(),BI(),NI(),MI(),DI(),PI(),UI(),WI(),Ck(),VI(),qI(),jI(),LI(),GI(),gf(),FI(),HI(),KI(),ZI(),QI(),zk(),XI(),Jr(),_f(),JI(),oS=new Map([["Abs",[t3]],["Acos",[r3]],["Acosh",[i3]],["Add",[D3]],["ArgMax",[Xx,Lh]],["ArgMin",[Qx,Lh]],["Asin",[a3]],["Asinh",[n3]],["Atan",[s3]],["Atanh",[o3]],["Attention",[Jx]],["AveragePool",[Uk,Pk]],["BatchNormalization",[Yx]],["BiasAdd",[e3]],["BiasSplitGelu",[M3]],["Cast",[l3,u3]],["Ceil",[p3]],["Clip",[d3]],["Concat",[H3,K3]],["Conv",[Qh,Zh]],["ConvTranspose",[ak,ik]],["Cos",[c3]],["Cosh",[h3]],["CumSum",[nk,sk]],["DepthToSpace",[ok,uk]],["DequantizeLinear",[Fk,Hk]],["Div",[P3]],["Einsum",[lk,dk]],["Elu",[f3,eo]],["Equal",[U3]],["Erf",[m3]],["Exp",[g3]],["Expand",[pk]],["FastGelu",[ck]],["Floor",[y3]],["FusedConv",[Qh,Zh]],["Gather",[fk,hk]],["GatherElements",[wk,vk]],["GatherBlockQuantized",[yk,_k]],["GatherND",[mk,gk]],["Gelu",[_3]],["Gemm",[$k,bk]],["GlobalAveragePool",[Vk,Wk]],["GlobalMaxPool",[Gk,Lk]],["Greater",[j3]],["GreaterOrEqual",[G3]],["GridSample",[xk,kk]],["GroupQueryAttention",[Ak]],["HardSigmoid",[T3,S3]],["InstanceNormalization",[Ok]],["LayerNormalization",[Rk]],["LeakyRelu",[v3,eo]],["Less",[L3]],["LessOrEqual",[F3]],["Log",[B3]],["MatMul",[Bk]],["MatMulNBits",[Nk,Mk]],["MaxPool",[qk,jk]],["Mul",[W3]],["MultiHeadAttention",[Tk,Sk]],["Neg",[b3]],["Not",[w3]],["Pad",[Dk]],["Pow",[V3]],["QuickGelu",[N3,eo]],["Range",[Kk]],["Reciprocal",[$3]],["ReduceMin",[Gx]],["ReduceMean",[Wx]],["ReduceMax",[Lx]],["ReduceSum",[Hx]],["ReduceProd",[Fx]],["ReduceL1",[Vx]],["ReduceL2",[qx]],["ReduceLogSum",[Zx]],["ReduceLogSumExp",[jx]],["ReduceSumSquare",[Kx]],["Relu",[x3]],["Resize",[Xk,Jk]],["RotaryEmbedding",[Yk]],["ScatterND",[Qk,Zk]],["Sigmoid",[k3]],["Sin",[C3]],["Sinh",[I3]],["Slice",[tS,rS]],["SkipLayerNormalization",[eS]],["Split",[Ik,Ek]],["Sqrt",[E3]],["Softmax",[iS,aS]],["Sub",[q3]],["Tan",[z3]],["Tanh",[A3]],["ThresholdedRelu",[R3,eo]],["Tile",[nS]],["Transpose",[Ix,Ex]],["Where",[sS]]])}),eE=te(()=>{"use strict";fr(),Ur(),ze(),uS=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,i,a){hr(e.programInfo.name);let s=this.backend.device,o=this.backend.getComputePassEncoder();this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2);let u=[];for(let p of t)u.push({binding:u.length,resource:{buffer:p.buffer}});for(let p of r)u.push({binding:u.length,resource:{buffer:p.buffer}});a&&u.push({binding:u.length,resource:a});let d=s.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:u,label:e.programInfo.name});if(this.backend.sessionStatus==="capturing"){let p={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:d,dispatchGroup:i};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(p)}o.setPipeline(e.computePipeline),o.setBindGroup(0,d),o.dispatchWorkgroups(...i),this.backend.writeTimestamp(this.backend.pendingDispatchNumber*2+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||this.backend.queryType==="at-passes")&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),Gt(e.programInfo.name)}dispose(){}build(e,t){hr(e.name);let r=this.backend.device,i=[];[{feature:"shader-f16",extension:"f16"},{feature:"subgroups",extension:"subgroups"},{feature:"subgroups-f16",extension:"subgroups_f16"}].forEach(p=>{r.features.has(p.feature)&&i.push(`enable ${p.extension};`)});let a=Cx(t,this.backend.device.limits),s=e.getShaderSource(a),o=`${i.join(`
`)}
${a.additionalImplementations}
${s}`,u=r.createShaderModule({code:o,label:e.name});Me("verbose",()=>`[WebGPU] ${e.name} shader code: ${o}`);let d=r.createComputePipeline({compute:{module:u,entryPoint:"main"},layout:"auto",label:e.name});return Gt(e.name),{programInfo:e,computePipeline:d,uniformVariablesInfo:a.variablesInfo}}normalizeDispatchGroupSize(e){let t=typeof e=="number"?e:e.x,r=typeof e=="number"?1:e.y||1,i=typeof e=="number"?1:e.z||1,a=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=a&&r<=a&&i<=a)return[t,r,i];let s=t*r*i,o=Math.ceil(Math.sqrt(s));if(o>a){if(o=Math.ceil(Math.cbrt(s)),o>a)throw new Error("Total dispatch size exceeds WebGPU maximum.");return[o,o,o]}else return[o,o,1]}}}),tE=te(()=>{"use strict";fr(),$e(),Ur(),bx(),dI(),YI(),eE(),R2=(e,t)=>{if(t.length!==e.length)throw new Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let i=0;i<e.length;++i){let a=e[i].dataType;switch(t[i]){case"none":{r.push("");break}case"type":{r.push(`${a}`);break}case"rank":{let s=e[i].dims.length;r.push(`${a};${s}`);break}case"dims":{let s=e[i].dims.join(",");r.push(`${a};${s}`);break}default:throw new Error(`unsupported input dependency: ${t[i]}`)}}return r.join("|")},B2=(e,t,r)=>{let i=e.name;return e.shaderCache?.hint&&(i+="["+e.shaderCache.hint+"]"),i+=":"+r+`:${R2(t,e.shaderCache?.inputDependencies??new Array(t.length).fill("dims"))}`,i},N2=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},M2=class{constructor(e){this.subgroupsSupported=e.features.has("subgroups"),this.subgroupsF16Supported=e.features.has("subgroups");let t=e.limits;!this.subgroupsSupported||!t.minSubgroupSize||!t.maxSubgroupSize?this.subgroupSizeRange=void 0:this.subgroupSizeRange=[t.minSubgroupSize,t.maxSubgroupSize]}},lS=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(this.currentKernelId===null)throw new Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],i={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r},a=s=>t.features.has(s)&&r.push(s)&&!0;a("chromium-experimental-timestamp-query-inside-passes")||a("timestamp-query"),a("shader-f16"),a("subgroups")&&a("subgroups-f16"),this.device=await t.requestDevice(i),this.deviceInfo=new M2(this.device),this.adapterInfo=new N2(t.info||await t.requestAdapterInfo()),this.gpuDataManager=$x(this),this.programManager=new uS(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,cf(e.logLevel,!!e.debug),this.device.onuncapturederror=s=>{s.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${s.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!1}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){typeof this.querySet<"u"&&this.querySet.destroy(),this.gpuDataManager.dispose()}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};this.queryType==="at-passes"&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:this.pendingDispatchNumber*2,endOfPassWriteIndex:this.pendingDispatchNumber*2+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){if(!this.commandEncoder)return;hr(),this.endComputePass();let e;this.queryType!=="none"&&(this.commandEncoder.resolveQuerySet(this.querySet,0,this.pendingDispatchNumber*2,this.queryResolveBuffer,0),e=this.device.createBuffer({size:this.pendingDispatchNumber*2*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,this.pendingDispatchNumber*2*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,this.queryType!=="none"&&e.mapAsync(GPUMapMode.READ).then(()=>{let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let i=0;i<t.length/2;i++){let a=r[i],s=a.kernelId,o=this.kernels.get(s),u=o.kernelType,d=o.kernelName,p=a.programName,m=a.inputTensorViews,f=a.outputTensorViews,g=t[i*2],v=t[i*2+1];typeof this.queryTimeBase>"u"&&(this.queryTimeBase=g);let _=Number(g-this.queryTimeBase),b=Number(v-this.queryTimeBase);if(!Number.isSafeInteger(_)||!Number.isSafeInteger(b))throw new RangeError("incorrect timestamp range");if(this.env.webgpu.profiling?.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:m.map(k=>({dims:k.dims,dataType:ji(k.dataType)})),outputsMetadata:f.map(k=>({dims:k.dims,dataType:ji(k.dataType)})),kernelId:s,kernelType:u,kernelName:d,programName:p,startTime:_,endTime:b});else{let k="";m.forEach((w,S)=>{k+=`input[${S}]: [${w.dims}] | ${ji(w.dataType)}, `});let $="";f.forEach((w,S)=>{$+=`output[${S}]: [${w.dims}] | ${ji(w.dataType)}, `}),console.log(`[profiling] kernel "${s}|${u}|${d}|${p}" ${k}${$}execution time: ${b-_} ns`)}io("GPU",`${p}::${g}::${v}`)}e.unmap(),this.pendingQueries.delete(e)}),Gt()}run(e,t,r,i,a,s){hr(e.name);let o=[];for(let w=0;w<t.length;++w){let S=t[w].data;if(S===0)continue;let C=this.gpuDataManager.get(S);if(!C)throw new Error(`no GPU data for input: ${S}`);o.push(C)}let{outputs:u,dispatchGroup:d,programUniforms:p}=e.getRunData(t),m=r.length===0?u.map((w,S)=>S):r;if(m.length!==u.length)throw new Error(`Output size ${m.length} must be equal to ${u.length}.`);let f=[],g=[];for(let w=0;w<u.length;++w){if(!Number.isInteger(m[w])||m[w]<-3||m[w]>=s)throw new Error(`Invalid output index: ${m[w]}`);if(m[w]===-3)continue;let S=m[w]===-1,C=m[w]===-2,I=S||C?a(u[w].dataType,u[w].dims):i(m[w],u[w].dataType,u[w].dims);if(f.push(I),I.data===0)continue;let z=this.gpuDataManager.get(I.data);if(!z)throw new Error(`no GPU data for output: ${I.data}`);if(S&&this.temporaryData.push(z),C){let E=this.kernelPersistentData.get(this.currentKernelId);E||(E=[],this.kernelPersistentData.set(this.currentKernelId,E)),E.push(z)}g.push(z)}if(o.length!==t.length||g.length!==f.length){if(g.length===0)return Gt(e.name),f;throw new Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}let v;if(p){let w=0,S=[];p.forEach(E=>{let B=typeof E.data=="number"?[E.data]:E.data;if(B.length===0)return;let U=E.type===10?2:4,V,W;E.type===10?(W=B.length>4?16:B.length>2?8:B.length*U,V=B.length>4?16:U*B.length):(W=B.length<=2?B.length*U:16,V=16),w=Math.ceil(w/W)*W,S.push(w);let J=E.type===10?8:4;w+=B.length>4?Math.ceil(B.length/J)*V:B.length*U});let C=16;w=Math.ceil(w/C)*C;let I=new ArrayBuffer(w);p.forEach((E,B)=>{let U=S[B],V=typeof E.data=="number"?[E.data]:E.data;if(E.type===6)new Int32Array(I,U,V.length).set(V);else if(E.type===12)new Uint32Array(I,U,V.length).set(V);else if(E.type===10)new Uint16Array(I,U,V.length).set(V);else if(E.type===1)new Float32Array(I,U,V.length).set(V);else throw new Error(`Unsupported uniform type: ${ji(E.type)}`)});let z=this.gpuDataManager.create(w,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(z.buffer,0,I,0,w),this.gpuDataManager.release(z.id),v={offset:0,size:w,buffer:z.buffer}}let _=this.programManager.normalizeDispatchGroupSize(d),b=_[1]===1&&_[2]===1,k=B2(e,t,b),$=this.programManager.getArtifact(k);if($||($=this.programManager.build(e,_),this.programManager.setArtifact(k,$),Me("info",()=>`[artifact] key: ${k}, programName: ${e.name}`)),p&&$.uniformVariablesInfo){if(p.length!==$.uniformVariablesInfo.length)throw new Error(`Uniform variables count mismatch: expect ${$.uniformVariablesInfo.length}, got ${p.length} in program "${$.programInfo.name}".`);for(let w=0;w<p.length;w++){let S=p[w],C=S.type,I=typeof S.data=="number"?1:S.data.length,[z,E]=$.uniformVariablesInfo[w];if(C!==z||I!==E)throw new Error(`Uniform variable ${w} mismatch: expect type ${z} with size ${E}, got type ${C} with size ${I} in program "${$.programInfo.name}".`)}}if(Me("info",()=>`[ProgramManager] run "${e.name}" (key=${k}) with ${_[0]}x${_[1]}x${_[2]}`),this.queryType!=="none"||this.sessionStatus==="capturing"){let w={kernelId:this.currentKernelId,programName:$.programInfo.name,inputTensorViews:t,outputTensorViews:f};this.pendingKernels.push(w),this.sessionStatus==="capturing"&&this.capturedPendingKernels.get(this.currentSessionId).push(w)}return this.programManager.run($,o,g,_,v),Gt(e.name),f}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,i){let a=oS.get(e);if(!a)throw new Error(`kernel not implemented: ${e}`);let s={kernelType:e,kernelName:i,kernelEntry:a[0],attributes:[a[1],r]};this.kernels.set(t,s)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let r of t)this.gpuDataManager.release(r.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let i=this.kernels.get(e);if(!i)throw new Error(`kernel not created: ${e}`);let a=i.kernelType,s=i.kernelName,o=i.kernelEntry,u=i.attributes;if(this.currentKernelId!==null)throw new Error(`kernel "[${a}] ${s}" is not allowed to be called recursively`);this.currentKernelId=e,u[0]&&(u[1]=u[0](u[1]),u[0]=void 0),Me("info",()=>`[WebGPU] Start to run kernel "[${a}] ${s}"...`);let d=this.env.debug;this.temporaryData=[];try{return d&&this.device.pushErrorScope("validation"),o(t,u[1]),0}catch(p){return r.push(Promise.resolve(`[WebGPU] Kernel "[${a}] ${s}" failed. ${p}`)),1}finally{d&&r.push(this.device.popErrorScope().then(p=>p?`GPU validation error for kernel "[${a}] ${s}": ${p.message}`:null));for(let p of this.temporaryData)this.gpuDataManager.release(p.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,i){let a=this.sessionExternalDataMapping.get(e);a||(a=new Map,this.sessionExternalDataMapping.set(e,a));let s=a.get(t),o=this.gpuDataManager.registerExternalBuffer(r,i,s);return a.set(t,[o,r]),o}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(r=>this.gpuDataManager.unregisterExternalBuffer(r[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw new Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let i=await Vh(this,e,t);return hf(i.buffer,r)}}writeTimestamp(e){this.queryType==="inside-passes"&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){this.queryType="none",(this.env.webgpu.profiling?.mode==="default"||(typeof this.env.trace>"u"?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),this.queryType!=="none"&&typeof this.querySet>"u"&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:this.maxDispatchNumber*2}),this.queryResolveBuffer=this.device.createBuffer({size:this.maxDispatchNumber*2*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){Me("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){Me("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){Me("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let i=0;i<r;i++){let a=this.getComputePassEncoder(),s=e[i];this.writeTimestamp(this.pendingDispatchNumber*2),a.setPipeline(s.computePipeline),a.setBindGroup(0,s.bindGroup),a.dispatchWorkgroups(...s.dispatchGroup),this.writeTimestamp(this.pendingDispatchNumber*2+1),this.pendingDispatchNumber++,this.queryType!=="none"&&this.pendingKernels.push(t[i]),(this.pendingDispatchNumber>=this.maxDispatchNumber||this.queryType==="at-passes")&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onCreateSession(){this.gpuDataManager.onCreateSession()}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}),rE=te(()=>{"use strict";Ur(),D2=1,Rh=()=>D2++,P2=new Map([["float32",32],["float16",16],["int32",32],["uint32",32],["int64",64],["uint64",64],["int8",8],["uint8",8],["int4",4],["uint4",4]]),Bh=(e,t)=>{let r=P2.get(e);if(!r)throw new Error("Unsupported data type.");return t.length>0?Math.ceil(t.reduce((i,a)=>i*a)*r/8):0},Nh=class{constructor(e){this.sessionId=e.sessionId,this.mlContext=e.context,this.mlTensor=e.tensor,this.dataType=e.dataType,this.tensorShape=e.shape}get tensor(){return this.mlTensor}get type(){return this.dataType}get shape(){return this.tensorShape}get byteLength(){return Bh(this.dataType,this.tensorShape)}destroy(){Me("verbose",()=>"[WebNN] TensorWrapper.destroy"),this.mlTensor.destroy()}write(e){this.mlContext.writeTensor(this.mlTensor,e)}async read(e){return e?this.mlContext.readTensor(this.mlTensor,e):this.mlContext.readTensor(this.mlTensor)}canReuseTensor(e,t,r){return this.mlContext===e&&this.dataType===t&&this.tensorShape.length===r.length&&this.tensorShape.every((i,a)=>i===r[a])}},Mh=class{constructor(e,t){this.tensorManager=e,this.wrapper=t}get tensorWrapper(){return this.wrapper}releaseTensor(){this.tensorWrapper&&(this.tensorManager.releaseTensor(this.tensorWrapper),this.wrapper=void 0)}async ensureTensor(e,t,r,i){let a=this.tensorManager.getMLContext(e);if(this.wrapper){if(this.wrapper.canReuseTensor(a,t,r))return this.wrapper.tensor;if(i){if(this.wrapper.byteLength!==Bh(t,r))throw new Error("Unable to copy data to tensor with different size.");this.activeUpload=new Uint8Array(await this.wrapper.read())}this.tensorManager.releaseTensor(this.wrapper)}let s=typeof MLTensorUsage>"u"?void 0:MLTensorUsage.READ|MLTensorUsage.WRITE;return this.wrapper=await this.tensorManager.getCachedTensor(e,t,r,s,!0,!0),i&&this.activeUpload&&(this.wrapper.write(this.activeUpload),this.activeUpload=void 0),this.wrapper.tensor}upload(e){if(this.wrapper)if(e.byteLength===this.wrapper.byteLength){this.wrapper.write(e);return}else Me("verbose",()=>"Data size does not match tensor size. Releasing tensor."),this.releaseTensor();this.activeUpload?this.activeUpload.set(e):this.activeUpload=new Uint8Array(e)}async download(e){if(this.activeUpload)if(e){e instanceof ArrayBuffer?new Uint8Array(e).set(this.activeUpload):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(this.activeUpload);return}else return this.activeUpload.buffer;if(!this.wrapper)throw new Error("Tensor has not been created.");return e?this.wrapper.read(e):this.wrapper.read()}},U2=class{constructor(e){this.backend=e,this.tensorTrackersById=new Map,this.freeTensors=[],this.externalTensors=new Set}getMLContext(e){let t=this.backend.getMLContext(e);if(!t)throw new Error("MLContext not found for session.");return t}reserveTensorId(){let e=Rh();return this.tensorTrackersById.set(e,new Mh(this)),e}releaseTensorId(e){let t=this.tensorTrackersById.get(e);t&&(this.tensorTrackersById.delete(e),t.tensorWrapper&&this.releaseTensor(t.tensorWrapper))}async ensureTensor(e,t,r,i,a){Me("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${t}, dataType: ${r}, shape: ${i}, copyOld: ${a}}`);let s=this.tensorTrackersById.get(t);if(!s)throw new Error("Tensor not found.");return s.ensureTensor(e,r,i,a)}upload(e,t){let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");r.upload(t)}async download(e,t){Me("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t?.byteLength}}`);let r=this.tensorTrackersById.get(e);if(!r)throw new Error("Tensor not found.");return r.download(t)}releaseTensorsForSession(e){for(let t of this.freeTensors)t.sessionId===e&&t.destroy();this.freeTensors=this.freeTensors.filter(t=>t.sessionId!==e)}registerTensor(e,t,r,i){let a=this.getMLContext(e),s=Rh(),o=new Nh({sessionId:e,context:a,tensor:t,dataType:r,shape:i});return this.tensorTrackersById.set(s,new Mh(this,o)),this.externalTensors.add(o),s}async getCachedTensor(e,t,r,i,a,s){let o=this.getMLContext(e);for(let[d,p]of this.freeTensors.entries())if(p.canReuseTensor(o,t,r)){Me("verbose",()=>`[WebNN] Reusing tensor {dataType: ${t}, shape: ${r}}`);let m=this.freeTensors.splice(d,1)[0];return m.sessionId=e,m}Me("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${t}, shape: ${r}}`);let u=await o.createTensor({dataType:t,shape:r,dimensions:r,usage:i,writable:a,readable:s});return new Nh({sessionId:e,context:o,tensor:u,dataType:t,shape:r})}releaseTensor(e){this.externalTensors.has(e)&&this.externalTensors.delete(e),this.freeTensors.push(e)}},dS=(...e)=>new U2(...e)}),iE=te(()=>{"use strict";$e(),Zi(),bx(),rE(),Ur(),pu=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[22,"int4"],[21,"uint4"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),W2=(e,t)=>{if(e===t)return!0;if(e===void 0||t===void 0)return!1;let r=Object.keys(e).sort(),i=Object.keys(t).sort();return r.length===i.length&&r.every((a,s)=>a===i[s]&&e[a]===t[a])},pS=class{constructor(e){this.tensorManager=dS(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,this.mlContextCache=[],this.sessionGraphInputs=new Map,this.temporaryGraphInputs=[],this.temporarySessionTensorIds=new Map,cf(e.logLevel,!!e.debug)}get currentSessionId(){if(this.activeSessionId===void 0)throw new Error("No active session");return this.activeSessionId}onRunStart(e){Me("verbose",()=>`[WebNN] onRunStart {sessionId: ${e}}`),this.activeSessionId=e}onRunEnd(e){Me("verbose",()=>`[WebNN] onRunEnd {sessionId: ${e}}`);let t=this.temporarySessionTensorIds.get(e);if(t){for(let r of t)Me("verbose",()=>`[WebNN] releasing temporary tensor {tensorId: ${r}}`),this.tensorManager.releaseTensorId(r);this.temporarySessionTensorIds.delete(e),this.activeSessionId=void 0}}async createMLContext(e){if(e instanceof GPUDevice){let r=this.mlContextCache.findIndex(i=>i.gpuDevice===e);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext(e);return this.mlContextCache.push({gpuDevice:e,mlContext:i}),i}}else if(e===void 0){let r=this.mlContextCache.findIndex(i=>i.options===void 0&&i.gpuDevice===void 0);if(r!==-1)return this.mlContextCache[r].mlContext;{let i=await navigator.ml.createContext();return this.mlContextCache.push({mlContext:i}),i}}let t=this.mlContextCache.findIndex(r=>W2(r.options,e));if(t!==-1)return this.mlContextCache[t].mlContext;{let r=await navigator.ml.createContext(e);return this.mlContextCache.push({options:e,mlContext:r}),r}}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e),this.temporaryGraphInputs.length>0&&(this.sessionGraphInputs.set(e,this.temporaryGraphInputs),this.temporaryGraphInputs=[])}onReleaseSession(e){this.sessionGraphInputs.delete(e);let t=this.mlContextBySessionId.get(e);if(!t)return;this.tensorManager.releaseTensorsForSession(e),this.mlContextBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);if(r.delete(e),r.size===0){this.sessionIdsByMLContext.delete(t);let i=this.mlContextCache.findIndex(a=>a.mlContext===t);i!==-1&&this.mlContextCache.splice(i,1)}}getMLContext(e){return this.mlContextBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){Me("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,i,a){let s=pu.get(r);if(!s)throw new Error(`Unsupported ONNX data type: ${r}`);return this.tensorManager.ensureTensor(e??this.currentSessionId,t,s,i,a)}async createTemporaryTensor(e,t,r){Me("verbose",()=>`[WebNN] createTemporaryTensor {onnxDataType: ${t}, shape: ${r}}`);let i=pu.get(t);if(!i)throw new Error(`Unsupported ONNX data type: ${t}`);let a=this.tensorManager.reserveTensorId();await this.tensorManager.ensureTensor(e,a,i,r,!1);let s=this.temporarySessionTensorIds.get(e);return s?s.push(a):this.temporarySessionTensorIds.set(e,[a]),a}uploadTensor(e,t){if(!pt().shouldTransferToMLTensor)throw new Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");Me("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return hf(r,t)}}registerMLTensor(e,t,r,i){let a=pu.get(r);if(!a)throw new Error(`Unsupported ONNX data type: ${r}`);let s=this.tensorManager.registerTensor(e,t,a,i);return Me("verbose",()=>`[WebNN] registerMLTensor {tensor: ${t}, dataType: ${a}, dimensions: ${i}} -> {tensorId: ${s}}`),s}registerMLConstant(e,t,r,i,a,s){if(!s)throw new Error("External mounted files are not available.");let o=e;e.startsWith("./")&&(o=e.substring(2));let u=s.get(o);if(!u)throw new Error(`File with name ${o} not found in preloaded files.`);if(t+r>u.byteLength)throw new Error("Out of bounds: data offset and length exceed the external file data size.");let d=u.slice(t,t+r).buffer,p;switch(a.dataType){case"float32":p=new Float32Array(d);break;case"float16":p=new Uint16Array(d);break;case"int32":p=new Int32Array(d);break;case"uint32":p=new Uint32Array(d);break;case"int64":p=new BigInt64Array(d);break;case"uint64":p=new BigUint64Array(d);break;case"int8":p=new Int8Array(d);break;case"int4":case"uint4":case"uint8":p=new Uint8Array(d);break;default:throw new Error(`Unsupported data type: ${a.dataType} in creating WebNN Constant from external data.`)}return Me("verbose",()=>`[WebNN] registerMLConstant {dataType: ${a.dataType}, shape: ${a.shape}}}`),i.constant(a,p)}registerGraphInput(e){this.temporaryGraphInputs.push(e)}isGraphInput(e,t){let r=this.sessionGraphInputs.get(e);return r?r.includes(t):!1}flush(){}}}),cS={};no(cS,{init:()=>hS});aE=te(()=>{"use strict";$e(),tE(),Ur(),Ce(),iE(),cu=class fS{constructor(t,r,i,a){this.module=t,this.dataType=r,this.data=i,this.dims=a}getFloat32Array(){if(this.dataType!==1)throw new Error("Invalid data type");let t=G.size(this.dims);return t===0?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,t)}getBigInt64Array(){if(this.dataType!==7)throw new Error("Invalid data type");let t=G.size(this.dims);return t===0?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,t)}getInt32Array(){if(this.dataType!==6)throw new Error("Invalid data type");let t=G.size(this.dims);return t===0?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,t)}getUint16Array(){if(this.dataType!==10&&this.dataType!==4)throw new Error("Invalid data type");let t=G.size(this.dims);return t===0?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,t)}reshape(t){if(G.size(t)!==G.size(this.dims))throw new Error("Invalid new shape");return new fS(this.module,this.dataType,this.data,t)}},V2=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo,this.deviceInfo=t.deviceInfo;let i=e.PTR_SIZE,a=r/e.PTR_SIZE,s=i===4?"i32":"i64";this.opKernelContext=Number(e.getValue(i*a++,s));let o=Number(e.getValue(i*a++,s));this.outputCount=Number(e.getValue(i*a++,s)),this.customDataOffset=Number(e.getValue(i*a++,"*")),this.customDataSize=Number(e.getValue(i*a++,s));let u=[];for(let d=0;d<o;d++){let p=Number(e.getValue(i*a++,s)),m=Number(e.getValue(i*a++,"*")),f=Number(e.getValue(i*a++,s)),g=[];for(let v=0;v<f;v++)g.push(Number(e.getValue(i*a++,s)));u.push(new cu(e,p,m,g))}this.inputs=u}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}compute(e,t){let r=t?.inputs?.map(o=>typeof o=="number"?this.inputs[o]:o)??this.inputs,i=t?.outputs??[],a=(o,u,d)=>new cu(this.module,u,this.output(o,d),d),s=(o,u)=>{let d=Li(o,u);if(!d)throw new Error(`Unsupported data type: ${o}`);let p=d>0?this.backend.gpuDataManager.create(d).id:0;return new cu(this.module,o,p,u)};return this.backend.run(e,r,i,a,s,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let i=this.module.PTR_SIZE,a=i===4?"i32":"i64",s=this.module.stackAlloc((1+t.length)*i);this.module.setValue(s,t.length,a);for(let o=0;o<t.length;o++)this.module.setValue(s+i*(o+1),t[o],a);return this.module._JsepOutput(this.opKernelContext,e,s)}catch(i){throw new Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${i}`)}finally{this.module.stackRestore(r)}}},hS=async(e,t,r,i)=>{let a=t.jsepInit;if(!a)throw new Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if(e==="webgpu"){let s=new lS;await s.initialize(r,i),a("webgpu",[s,o=>s.alloc(Number(o)),o=>s.free(o),(o,u,d,p=!1)=>{if(p)Me("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${Number(o)}, dst=${Number(u)}, size=${Number(d)}`),s.memcpy(Number(o),Number(u));else{Me("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${Number(o)}, gpuDataId=${Number(u)}, size=${Number(d)}`);let m=t.HEAPU8.subarray(Number(o>>>0),Number(o>>>0)+Number(d));s.upload(Number(u),m)}},async(o,u,d)=>{Me("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${o}, dataOffset=${u}, size=${d}`),await s.download(Number(o),()=>t.HEAPU8.subarray(Number(u)>>>0,Number(u+d)>>>0))},(o,u,d)=>s.createKernel(o,Number(u),d,t.UTF8ToString(t._JsepGetNodeName(Number(u)))),o=>s.releaseKernel(o),(o,u,d,p)=>{Me("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${d}, kernel=${o}, contextDataOffset=${u}`);let m=new V2(t,s,Number(u));return s.computeKernel(Number(o),m,p)},()=>s.captureBegin(),()=>s.captureEnd(),()=>s.replay()])}else{let s=new pS(r);a("webnn",[s,()=>s.reserveTensorId(),o=>s.releaseTensorId(o),async(o,u,d,p,m)=>s.ensureTensor(o,u,d,p,m),(o,u)=>{s.uploadTensor(o,u)},async(o,u)=>s.downloadTensor(o,u)])}}}),mS=te(()=>{"use strict";uI(),lI(),$e(),Zi(),of(),wx(),q2=(e,t)=>{pt()._OrtInit(e,t)!==0&&qe("Can't initialize onnxruntime.")},kf=async e=>{q2(e.wasm.numThreads,vu(e.logLevel))},Sf=async(e,t)=>{{let r=(aE(),yu(cS)).init;if(t==="webgpu"){if(typeof navigator>"u"||!navigator.gpu)throw new Error("WebGPU is not supported in current environment");let i=e.webgpu.adapter;if(i){if(typeof i.limits!="object"||typeof i.features!="object"||typeof i.requestDevice!="function")throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let a=e.webgpu.powerPreference;if(a!==void 0&&a!=="low-power"&&a!=="high-performance")throw new Error(`Invalid powerPreference setting: "${a}"`);let s=e.webgpu.forceFallbackAdapter;if(s!==void 0&&typeof s!="boolean")throw new Error(`Invalid forceFallbackAdapter setting: "${s}"`);if(i=await navigator.gpu.requestAdapter({powerPreference:a,forceFallbackAdapter:s}),!i)throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}await r("webgpu",pt(),e,i)}if(t==="webnn"){if(typeof navigator>"u"||!navigator.ml)throw new Error("WebNN is not supported in current environment");await r("webnn",pt(),e)}}},Zr=new Map,j2=e=>{let t=pt(),r=t.stackSave();try{let i=t.PTR_SIZE,a=t.stackAlloc(2*i);t._OrtGetInputOutputCount(e,a,a+i)!==0&&qe("Can't get session input/output count.");let s=i===4?"i32":"i64";return[Number(t.getValue(a,s)),Number(t.getValue(a+i,s))]}finally{t.stackRestore(r)}},xu=e=>{let t=pt(),r=t._malloc(e.byteLength);if(r===0)throw new Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},Tf=async(e,t)=>{let r,i,a=pt();Array.isArray(e)?[r,i]=e:e.buffer===a.HEAPU8.buffer?[r,i]=[e.byteOffset,e.byteLength]:[r,i]=xu(e);let s=0,o=0,u=0,d=[],p=[],m=[];try{if([o,d]=vx(t),t?.externalData&&a.mountExternalData){let w=[];for(let S of t.externalData){let C=typeof S=="string"?S:S.path;w.push(pf(typeof S=="string"?S:S.data).then(I=>{a.mountExternalData(C,I)}))}await Promise.all(w)}for(let w of t?.executionProviders??[])if((typeof w=="string"?w:w.name)==="webnn"){if(a.shouldTransferToMLTensor=!1,typeof w!="string"){let S=w,C=S?.context,I=S?.gpuDevice,z=S?.deviceType,E=S?.powerPreference;C?a.currentContext=C:I?a.currentContext=await a.jsepCreateMLContext(I):a.currentContext=await a.jsepCreateMLContext({deviceType:z,powerPreference:E})}else a.currentContext=await a.jsepCreateMLContext();break}s=await a._OrtCreateSession(r,i,o),s===0&&qe("Can't create a session."),a.jsepOnCreateSession?.(),a.currentContext&&(a.jsepRegisterMLContext(s,a.currentContext),a.currentContext=void 0,a.shouldTransferToMLTensor=!0);let[f,g]=j2(s),v=!!t?.enableGraphCapture,_=[],b=[],k=[];for(let w=0;w<f;w++){let S=a._OrtGetInputName(s,w);S===0&&qe("Can't get an input name."),p.push(S),_.push(a.UTF8ToString(S))}for(let w=0;w<g;w++){let S=a._OrtGetOutputName(s,w);S===0&&qe("Can't get an output name."),m.push(S);let C=a.UTF8ToString(S);b.push(C);{if(v&&t?.preferredOutputLocation===void 0){k.push("gpu-buffer");continue}let I=typeof t?.preferredOutputLocation=="string"?t.preferredOutputLocation:t?.preferredOutputLocation?.[C]??"cpu";if(I!=="cpu"&&I!=="cpu-pinned"&&I!=="gpu-buffer"&&I!=="ml-tensor")throw new Error(`Not supported preferred output location: ${I}.`);if(v&&I!=="gpu-buffer")throw new Error(`Not supported preferred output location: ${I}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);k.push(I)}}let $=null;return k.some(w=>w==="gpu-buffer"||w==="ml-tensor")&&(u=a._OrtCreateBinding(s),u===0&&qe("Can't create IO binding."),$={handle:u,outputPreferredLocations:k,outputPreferredLocationsEncoded:k.map(w=>Wh(w))}),Zr.set(s,[s,p,m,$,v,!1]),[s,_,b]}catch(f){throw p.forEach(g=>a._OrtFree(g)),m.forEach(g=>a._OrtFree(g)),u!==0&&a._OrtReleaseBinding(u)!==0&&qe("Can't release IO binding."),s!==0&&a._OrtReleaseSession(s)!==0&&qe("Can't release session."),f}finally{a._free(r),o!==0&&a._OrtReleaseSessionOptions(o)!==0&&qe("Can't release session options."),d.forEach(f=>a._free(f)),a.unmountExternalData?.()}},Cf=e=>{let t=pt(),r=Zr.get(e);if(!r)throw new Error(`cannot release session. invalid session id: ${e}`);let[i,a,s,o,u]=r;o&&(u&&t._OrtClearBoundOutputs(o.handle)!==0&&qe("Can't clear bound outputs."),t._OrtReleaseBinding(o.handle)!==0&&qe("Can't release IO binding.")),t.jsepOnReleaseSession?.(e),a.forEach(d=>t._OrtFree(d)),s.forEach(d=>t._OrtFree(d)),t._OrtReleaseSession(i)!==0&&qe("Can't release session."),Zr.delete(e)},Dh=async(e,t,r,i,a,s=!1)=>{if(!e){t.push(0);return}let o=pt(),u=o.PTR_SIZE,d=e[0],p=e[1],m=e[3],f=m,g,v;if(d==="string"&&(m==="gpu-buffer"||m==="ml-tensor"))throw new Error("String tensor is not supported on GPU.");if(s&&m!=="gpu-buffer")throw new Error(`External buffer must be provided for input/output index ${a} when enableGraphCapture is true.`);if(m==="gpu-buffer"){let k=e[2].gpuBuffer;v=Li(sa(d),p);let $=o.jsepRegisterBuffer;if(!$)throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');g=$(i,a,k,v)}else if(m==="ml-tensor"){let k=e[2].mlTensor;v=Li(sa(d),p);let $=o.jsepRegisterMLTensor;if(!$)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');g=$(i,k,sa(d),p)}else{let k=e[2];if(Array.isArray(k)){v=u*k.length,g=o._malloc(v),r.push(g);for(let $=0;$<k.length;$++){if(typeof k[$]!="string")throw new TypeError(`tensor data at index ${$} is not a string`);o.setValue(g+$*u,bt(k[$],r),"*")}}else{let $=o.jsepIsGraphInput;if(d!=="string"&&$){let w=o._OrtGetInputName(i,a),S=o.UTF8ToString(w);if($(i,S)){let C=sa(d);v=Li(C,p),f="ml-tensor";let I=o.jsepCreateTemporaryTensor,z=o.jsepUploadTensor;if(!I||!z)throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');let E=await I(i,C,p);z(E,new Uint8Array(k.buffer,k.byteOffset,k.byteLength)),g=E}else v=k.byteLength,g=o._malloc(v),r.push(g),o.HEAPU8.set(new Uint8Array(k.buffer,k.byteOffset,v),g)}else v=k.byteLength,g=o._malloc(v),r.push(g),o.HEAPU8.set(new Uint8Array(k.buffer,k.byteOffset,v),g)}}let _=o.stackSave(),b=o.stackAlloc(4*p.length);try{p.forEach(($,w)=>o.setValue(b+w*u,$,u===4?"i32":"i64"));let k=o._OrtCreateTensor(sa(d),g,v,b,p.length,Wh(f));k===0&&qe(`Can't create tensor for input/output. session=${i}, index=${a}.`),t.push(k)}finally{o.stackRestore(_)}},If=async(e,t,r,i,a,s)=>{let o=pt(),u=o.PTR_SIZE,d=Zr.get(e);if(!d)throw new Error(`cannot run inference. invalid session id: ${e}`);let p=d[0],m=d[1],f=d[2],g=d[3],v=d[4],_=d[5],b=t.length,k=i.length,$=0,w=[],S=[],C=[],I=[],z=o.stackSave(),E=o.stackAlloc(b*u),B=o.stackAlloc(b*u),U=o.stackAlloc(k*u),V=o.stackAlloc(k*u);try{[$,w]=_x(s);for(let D=0;D<b;D++)await Dh(r[D],S,I,e,t[D],v);for(let D=0;D<k;D++)await Dh(a[D],C,I,e,b+i[D],v);for(let D=0;D<b;D++)o.setValue(E+D*u,S[D],"*"),o.setValue(B+D*u,m[t[D]],"*");for(let D=0;D<k;D++)o.setValue(U+D*u,C[D],"*"),o.setValue(V+D*u,f[i[D]],"*");if(g&&!_){let{handle:D,outputPreferredLocations:se,outputPreferredLocationsEncoded:ue}=g;if(m.length!==b)throw new Error(`input count from feeds (${b}) is expected to be always equal to model's input count (${m.length}).`);for(let F=0;F<b;F++){let oe=t[F];await o._OrtBindInput(D,m[oe],S[F])!==0&&qe(`Can't bind input[${F}] for session=${e}.`)}for(let F=0;F<k;F++){let oe=i[F];a[F]?.[3]?o._OrtBindOutput(D,f[oe],C[F],0)!==0&&qe(`Can't bind pre-allocated output[${F}] for session=${e}.`):o._OrtBindOutput(D,f[oe],0,ue[oe])!==0&&qe(`Can't bind output[${F}] to ${se[F]} for session=${e}.`)}Zr.set(e,[p,m,f,g,v,!0])}o.jsepOnRunStart?.(p);let W;g?W=await o._OrtRunWithBinding(p,g.handle,k,U,$):W=await o._OrtRun(p,B,E,b,V,k,U,$),W!==0&&qe("failed to call OrtRun().");let J=[];for(let D=0;D<k;D++){let se=Number(o.getValue(U+D*u,"*"));if(se===C[D]){J.push(a[D]);continue}let ue=o.stackSave(),F=o.stackAlloc(4*u),oe=!1,le,H=0;try{o._OrtGetTensorData(se,F,F+u,F+2*u,F+3*u)!==0&&qe(`Can't access output tensor data on index ${D}.`);let de=u===4?"i32":"i64",M=Number(o.getValue(F,de));H=o.getValue(F+u,"*");let q=o.getValue(F+u*2,"*"),R=Number(o.getValue(F+u*3,de)),X=[];for(let De=0;De<R;De++)X.push(Number(o.getValue(q+De*u,de)));o._OrtFree(q)!==0&&qe("Can't free memory for tensor dims.");let Ie=X.reduce((De,Ae)=>De*Ae,1);le=ji(M);let Fe=g?.outputPreferredLocations[i[D]];if(le==="string"){if(Fe==="gpu-buffer"||Fe==="ml-tensor")throw new Error("String tensor is not supported on GPU.");let De=[];for(let Ae=0;Ae<Ie;Ae++){let nt=o.getValue(H+Ae*u,"*"),Ge=o.getValue(H+(Ae+1)*u,"*"),kr=Ae===Ie-1?void 0:Ge-nt;De.push(o.UTF8ToString(nt,kr))}J.push([le,X,De,"cpu"])}else if(Fe==="gpu-buffer"&&Ie>0){let De=o.jsepGetBuffer;if(!De)throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let Ae=De(H),nt=Li(M,Ie);if(nt===void 0||!lf(le))throw new Error(`Unsupported data type: ${le}`);oe=!0,J.push([le,X,{gpuBuffer:Ae,download:o.jsepCreateDownloader(Ae,nt,le),dispose:()=>{o._OrtReleaseTensor(se)!==0&&qe("Can't release tensor.")}},"gpu-buffer"])}else if(Fe==="ml-tensor"&&Ie>0){let De=o.jsepEnsureTensor;if(!De)throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');if(Li(M,Ie)===void 0||!df(le))throw new Error(`Unsupported data type: ${le}`);let Ae=await De(e,H,M,X,!1);oe=!0,J.push([le,X,{mlTensor:Ae,download:o.jsepCreateMLTensorDownloader(H,le),dispose:()=>{o.jsepReleaseTensorId(H),o._OrtReleaseTensor(se)}},"ml-tensor"])}else{let De=uf(le),Ae=new De(Ie);new Uint8Array(Ae.buffer,Ae.byteOffset,Ae.byteLength).set(o.HEAPU8.subarray(H,H+Ae.byteLength)),J.push([le,X,Ae,"cpu"])}}finally{o.stackRestore(ue),le==="string"&&H&&o._free(H),oe||o._OrtReleaseTensor(se),o.jsepOnRunEnd?.(p)}}return g&&!v&&(o._OrtClearBoundOutputs(g.handle)!==0&&qe("Can't clear bound outputs."),Zr.set(e,[p,m,f,g,v,!1])),J}finally{o.stackRestore(z),S.forEach(W=>o._OrtReleaseTensor(W)),C.forEach(W=>o._OrtReleaseTensor(W)),I.forEach(W=>o._free(W)),$!==0&&o._OrtReleaseRunOptions($),w.forEach(W=>o._free(W))}},Ef=e=>{let t=pt(),r=Zr.get(e);if(!r)throw new Error("invalid session id");let i=r[0],a=t._OrtEndProfiling(i);a===0&&qe("Can't get an profile file name."),t._OrtFree(a)},zf=e=>{let t=[];for(let r of e){let i=r[2];!Array.isArray(i)&&"buffer"in i&&t.push(i.buffer)}return t}}),xS=te(()=>{"use strict";fr(),mS(),Zi(),nf(),Qr=()=>!!Ze.wasm.proxy&&typeof document<"u",na=!1,Qs=!1,Xs=!1,fu=new Map,Wi=(e,t)=>{let r=fu.get(e);r?r.push(t):fu.set(e,[t])},Vi=()=>{if(na||!Qs||Xs||!jt)throw new Error("worker not ready")},L2=e=>{switch(e.data.type){case"init-wasm":na=!1,e.data.err?(Xs=!0,Ph[1](e.data.err)):(Qs=!0,Ph[0]()),hu&&(URL.revokeObjectURL(hu),hu=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=fu.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out);break}default:}},gS=async()=>{if(!Qs){if(na)throw new Error("multiple calls to 'initWasm()' detected.");if(Xs)throw new Error("previous call to 'initWasm()' failed.");if(na=!0,Qr())return new Promise((e,t)=>{jt?.terminate(),gx().then(([r,i])=>{try{jt=i,jt.onerror=s=>t(s),jt.onmessage=L2,Ph=[e,t];let a={type:"init-wasm",in:Ze};!a.in.wasm.wasmPaths&&(r||br.url?.startsWith("file:"))&&(a.in.wasm.wasmPaths={wasm:new URL("ort-wasm-simd-threaded.jsep.wasm",br.url).href}),jt.postMessage(a),hu=r}catch(a){t(a)}},t)});try{await sf(Ze.wasm),await kf(Ze),Qs=!0}catch(e){throw Xs=!0,e}finally{na=!1}}},yS=async e=>{if(Qr())return Vi(),new Promise((t,r)=>{Wi("init-ep",[t,r]);let i={type:"init-ep",in:{epName:e,env:Ze}};jt.postMessage(i)});await Sf(Ze,e)},_S=async e=>Qr()?(Vi(),new Promise((t,r)=>{Wi("copy-from",[t,r]);let i={type:"copy-from",in:{buffer:e}};jt.postMessage(i,[e.buffer])})):xu(e),vS=async(e,t)=>{if(Qr()){if(t?.preferredOutputLocation)throw new Error('session option "preferredOutputLocation" is not supported for proxy.');return Vi(),new Promise((r,i)=>{Wi("create",[r,i]);let a={type:"create",in:{model:e,options:{...t}}},s=[];e instanceof Uint8Array&&s.push(e.buffer),jt.postMessage(a,s)})}else return Tf(e,t)},wS=async e=>{if(Qr())return Vi(),new Promise((t,r)=>{Wi("release",[t,r]);let i={type:"release",in:e};jt.postMessage(i)});Cf(e)},bS=async(e,t,r,i,a,s)=>{if(Qr()){if(r.some(o=>o[3]!=="cpu"))throw new Error("input tensor on GPU is not supported for proxy.");if(a.some(o=>o))throw new Error("pre-allocated output tensor is not supported for proxy.");return Vi(),new Promise((o,u)=>{Wi("run",[o,u]);let d=r,p={type:"run",in:{sessionId:e,inputIndices:t,inputs:d,outputIndices:i,options:s}};jt.postMessage(p,zf(d))})}else return If(e,t,r,i,a,s)},$S=async e=>{if(Qr())return Vi(),new Promise((t,r)=>{Wi("end-profiling",[t,r]);let i={type:"end-profiling",in:e};jt.postMessage(i)});Ef(e)}}),nE=te(()=>{"use strict";fr(),xS(),$e(),af(),wx(),Uh=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw new Error(`invalid data location: ${e.location} for ${t()}`)}},G2=e=>{switch(e[3]){case"cpu":return new cr(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!lf(t))throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:i,dispose:a}=e[2];return cr.fromGpuBuffer(r,{dataType:t,dims:e[1],download:i,dispose:a})}case"ml-tensor":{let t=e[0];if(!df(t))throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:i,dispose:a}=e[2];return cr.fromMLTensor(r,{dataType:t,dims:e[1],download:i,dispose:a})}default:throw new Error(`invalid data location: ${e[3]}`)}},kS=class{async fetchModelAndCopyToWasmMemory(e){return _S(await pf(e))}async loadModel(e,t){hr();let r;typeof e=="string"?r=await this.fetchModelAndCopyToWasmMemory(e):r=e,[this.sessionId,this.inputNames,this.outputNames]=await vS(r,t),Gt()}async dispose(){return wS(this.sessionId)}async run(e,t,r){hr();let i=[],a=[];Object.entries(e).forEach(f=>{let g=f[0],v=f[1],_=this.inputNames.indexOf(g);if(_===-1)throw new Error(`invalid input '${g}'`);i.push(v),a.push(_)});let s=[],o=[];Object.entries(t).forEach(f=>{let g=f[0],v=f[1],_=this.outputNames.indexOf(g);if(_===-1)throw new Error(`invalid output '${g}'`);s.push(v),o.push(_)});let u=i.map((f,g)=>Uh(f,()=>`input "${this.inputNames[a[g]]}"`)),d=s.map((f,g)=>f?Uh(f,()=>`output "${this.outputNames[o[g]]}"`):null),p=await bS(this.sessionId,a,u,o,d,r),m={};for(let f=0;f<p.length;f++)m[this.outputNames[o[f]]]=s[f]??G2(p[f]);return Gt(),m}startProfiling(){}endProfiling(){$S(this.sessionId)}}}),SS={};no(SS,{OnnxruntimeWebAssemblyBackend:()=>Yh,initializeFlags:()=>Jh,wasmBackend:()=>TS});sE=te(()=>{"use strict";fr(),xS(),nE(),Jh=()=>{if((typeof Ze.wasm.initTimeout!="number"||Ze.wasm.initTimeout<0)&&(Ze.wasm.initTimeout=0),Ze.wasm.simd===!1&&console.warn('Deprecated property "env.wasm.simd" is set to false. non-SIMD build is no longer provided, and this setting will be ignored.'),typeof Ze.wasm.proxy!="boolean"&&(Ze.wasm.proxy=!1),typeof Ze.wasm.trace!="boolean"&&(Ze.wasm.trace=!1),typeof Ze.wasm.numThreads!="number"||!Number.isInteger(Ze.wasm.numThreads)||Ze.wasm.numThreads<=0)if(typeof self<"u"&&!self.crossOriginIsolated)Ze.wasm.numThreads=1;else{let e=typeof navigator>"u"?GC("node:os").cpus().length:navigator.hardwareConcurrency;Ze.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},Yh=class{async init(e){Jh(),await gS(),await yS(e)}async createInferenceSessionHandler(e,t){let r=new kS;return await r.loadModel(e,t),Promise.resolve(r)}},TS=new Yh});fr();fr();fr();oE="1.21.0",uE=dx;{let e=(sE(),yu(SS)).wasmBackend;Gi("webgpu",e,5),Gi("webnn",e,5),Gi("cpu",e,10),Gi("wasm",e,10)}Object.defineProperty(Ze.versions,"web",{value:oE,enumerable:!0});});var E4={};np(E4,{alphamask:()=>C4,applySegmentationMask:()=>I4,preload:()=>k4,removeBackground:()=>S4,removeForeground:()=>T4,segmentForeground:()=>fT});var lE=Object.create,DS=Object.defineProperty,dE=Object.getOwnPropertyDescriptor,PS=Object.getOwnPropertyNames,pE=Object.getPrototypeOf,cE=Object.prototype.hasOwnProperty,Gf=(e,t)=>function(){return t||(0,e[PS(e)[0]])((t={exports:{}}).exports,t),t.exports},hE=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of PS(t))!cE.call(e,a)&&a!==r&&DS(e,a,{get:()=>t[a],enumerable:!(i=dE(t,a))||i.enumerable});return e},Nu=(e,t,r)=>(r=e!=null?lE(pE(e)):{},hE(t||!e||!e.__esModule?DS(r,"default",{value:e,enumerable:!0}):r,e)),fE=Gf({"../../node_modules/.pnpm/iota-array@1.0.0/node_modules/iota-array/iota.js"(e,t){"use strict";function r(i){for(var a=new Array(i),s=0;s<i;++s)a[s]=s;return a}t.exports=r}}),mE=Gf({"../../node_modules/.pnpm/is-buffer@1.1.6/node_modules/is-buffer/index.js"(e,t){t.exports=function(a){return a!=null&&(r(a)||i(a)||!!a._isBuffer)};function r(a){return!!a.constructor&&typeof a.constructor.isBuffer=="function"&&a.constructor.isBuffer(a)}function i(a){return typeof a.readFloatLE=="function"&&typeof a.slice=="function"&&r(a.slice(0,0))}}}),Mu=Gf({"../../node_modules/.pnpm/ndarray@1.0.19/node_modules/ndarray/ndarray.js"(e,t){var r=fE(),i=mE(),a=typeof Float64Array<"u";function s(f,g){return f[0]-g[0]}function o(){var f=this.stride,g=new Array(f.length),v;for(v=0;v<g.length;++v)g[v]=[Math.abs(f[v]),v];g.sort(s);var _=new Array(g.length);for(v=0;v<_.length;++v)_[v]=g[v][1];return _}function u(f,g){var v=["View",g,"d",f].join("");g<0&&(v="View_Nil"+f);var _=f==="generic";if(g===-1){var b="function "+v+"(a){this.data=a;};var proto="+v+".prototype;proto.dtype='"+f+"';proto.index=function(){return -1};proto.size=0;proto.dimension=-1;proto.shape=proto.stride=proto.order=[];proto.lo=proto.hi=proto.transpose=proto.step=function(){return new "+v+"(this.data);};proto.get=proto.set=function(){};proto.pick=function(){return null};return function construct_"+v+"(a){return new "+v+"(a);}",V=new Function(b);return V()}else if(g===0){var b="function "+v+"(a,d) {this.data = a;this.offset = d};var proto="+v+".prototype;proto.dtype='"+f+"';proto.index=function(){return this.offset};proto.dimension=0;proto.size=1;proto.shape=proto.stride=proto.order=[];proto.lo=proto.hi=proto.transpose=proto.step=function "+v+"_copy() {return new "+v+"(this.data,this.offset)};proto.pick=function "+v+"_pick(){return TrivialArray(this.data);};proto.valueOf=proto.get=function "+v+"_get(){return "+(_?"this.data.get(this.offset)":"this.data[this.offset]")+"};proto.set=function "+v+"_set(v){return "+(_?"this.data.set(this.offset,v)":"this.data[this.offset]=v")+"};return function construct_"+v+"(a,b,c,d){return new "+v+"(a,d)}",V=new Function("TrivialArray",b);return V(p[f][0])}var b=["'use strict'"],k=r(g),$=k.map(function(W){return"i"+W}),w="this.offset+"+k.map(function(W){return"this.stride["+W+"]*i"+W}).join("+"),S=k.map(function(W){return"b"+W}).join(","),C=k.map(function(W){return"c"+W}).join(",");b.push("function "+v+"(a,"+S+","+C+",d){this.data=a","this.shape=["+S+"]","this.stride=["+C+"]","this.offset=d|0}","var proto="+v+".prototype","proto.dtype='"+f+"'","proto.dimension="+g),b.push("Object.defineProperty(proto,'size',{get:function "+v+"_size(){return "+k.map(function(W){return"this.shape["+W+"]"}).join("*"),"}})"),g===1?b.push("proto.order=[0]"):(b.push("Object.defineProperty(proto,'order',{get:"),g<4?(b.push("function "+v+"_order(){"),g===2?b.push("return (Math.abs(this.stride[0])>Math.abs(this.stride[1]))?[1,0]:[0,1]}})"):g===3&&b.push("var s0=Math.abs(this.stride[0]),s1=Math.abs(this.stride[1]),s2=Math.abs(this.stride[2]);if(s0>s1){if(s1>s2){return [2,1,0];}else if(s0>s2){return [1,2,0];}else{return [1,0,2];}}else if(s0>s2){return [2,0,1];}else if(s2>s1){return [0,1,2];}else{return [0,2,1];}}})")):b.push("ORDER})")),b.push("proto.set=function "+v+"_set("+$.join(",")+",v){"),_?b.push("return this.data.set("+w+",v)}"):b.push("return this.data["+w+"]=v}"),b.push("proto.get=function "+v+"_get("+$.join(",")+"){"),_?b.push("return this.data.get("+w+")}"):b.push("return this.data["+w+"]}"),b.push("proto.index=function "+v+"_index(",$.join(),"){return "+w+"}"),b.push("proto.hi=function "+v+"_hi("+$.join(",")+"){return new "+v+"(this.data,"+k.map(function(W){return["(typeof i",W,"!=='number'||i",W,"<0)?this.shape[",W,"]:i",W,"|0"].join("")}).join(",")+","+k.map(function(W){return"this.stride["+W+"]"}).join(",")+",this.offset)}");var I=k.map(function(W){return"a"+W+"=this.shape["+W+"]"}),z=k.map(function(W){return"c"+W+"=this.stride["+W+"]"});b.push("proto.lo=function "+v+"_lo("+$.join(",")+"){var b=this.offset,d=0,"+I.join(",")+","+z.join(","));for(var E=0;E<g;++E)b.push("if(typeof i"+E+"==='number'&&i"+E+">=0){d=i"+E+"|0;b+=c"+E+"*d;a"+E+"-=d}");b.push("return new "+v+"(this.data,"+k.map(function(W){return"a"+W}).join(",")+","+k.map(function(W){return"c"+W}).join(",")+",b)}"),b.push("proto.step=function "+v+"_step("+$.join(",")+"){var "+k.map(function(W){return"a"+W+"=this.shape["+W+"]"}).join(",")+","+k.map(function(W){return"b"+W+"=this.stride["+W+"]"}).join(",")+",c=this.offset,d=0,ceil=Math.ceil");for(var E=0;E<g;++E)b.push("if(typeof i"+E+"==='number'){d=i"+E+"|0;if(d<0){c+=b"+E+"*(a"+E+"-1);a"+E+"=ceil(-a"+E+"/d)}else{a"+E+"=ceil(a"+E+"/d)}b"+E+"*=d}");b.push("return new "+v+"(this.data,"+k.map(function(W){return"a"+W}).join(",")+","+k.map(function(W){return"b"+W}).join(",")+",c)}");for(var B=new Array(g),U=new Array(g),E=0;E<g;++E)B[E]="a[i"+E+"]",U[E]="b[i"+E+"]";b.push("proto.transpose=function "+v+"_transpose("+$+"){"+$.map(function(W,J){return W+"=("+W+"===undefined?"+J+":"+W+"|0)"}).join(";"),"var a=this.shape,b=this.stride;return new "+v+"(this.data,"+B.join(",")+","+U.join(",")+",this.offset)}"),b.push("proto.pick=function "+v+"_pick("+$+"){var a=[],b=[],c=this.offset");for(var E=0;E<g;++E)b.push("if(typeof i"+E+"==='number'&&i"+E+">=0){c=(c+this.stride["+E+"]*i"+E+")|0}else{a.push(this.shape["+E+"]);b.push(this.stride["+E+"])}");b.push("var ctor=CTOR_LIST[a.length+1];return ctor(this.data,a,b,c)}"),b.push("return function construct_"+v+"(data,shape,stride,offset){return new "+v+"(data,"+k.map(function(W){return"shape["+W+"]"}).join(",")+","+k.map(function(W){return"stride["+W+"]"}).join(",")+",offset)}");var V=new Function("CTOR_LIST","ORDER",b.join(`
`));return V(p[f],o)}function d(f){if(i(f))return"buffer";if(a)switch(Object.prototype.toString.call(f)){case"[object Float64Array]":return"float64";case"[object Float32Array]":return"float32";case"[object Int8Array]":return"int8";case"[object Int16Array]":return"int16";case"[object Int32Array]":return"int32";case"[object Uint8Array]":return"uint8";case"[object Uint16Array]":return"uint16";case"[object Uint32Array]":return"uint32";case"[object Uint8ClampedArray]":return"uint8_clamped";case"[object BigInt64Array]":return"bigint64";case"[object BigUint64Array]":return"biguint64"}return Array.isArray(f)?"array":"generic"}var p={float32:[],float64:[],int8:[],int16:[],int32:[],uint8:[],uint16:[],uint32:[],array:[],uint8_clamped:[],bigint64:[],biguint64:[],buffer:[],generic:[]};function m(f,g,v,_){if(f===void 0){var C=p.array[0];return C([])}else typeof f=="number"&&(f=[f]);g===void 0&&(g=[f.length]);var b=g.length;if(v===void 0){v=new Array(b);for(var k=b-1,$=1;k>=0;--k)v[k]=$,$*=g[k]}if(_===void 0){_=0;for(var k=0;k<b;++k)v[k]<0&&(_-=(g[k]-1)*v[k])}for(var w=d(f),S=p[w];S.length<=b+1;)S.push(u(w,S.length-1));var C=S[b+1];return C(f,g,v,_)}t.exports=m}}),gE=typeof global=="object"&&global&&global.Object===Object&&global,yE=gE,_E=typeof self=="object"&&self&&self.Object===Object&&self,vE=yE||_E||Function("return this")(),Ff=vE,wE=Ff.Symbol,Tu=wE,US=Object.prototype,bE=US.hasOwnProperty,$E=US.toString,so=Tu?Tu.toStringTag:void 0;function xE(e){var t=bE.call(e,so),r=e[so];try{e[so]=void 0;var i=!0}catch{}var a=$E.call(e);return i&&(t?e[so]=r:delete e[so]),a}var kE=xE,SE=Object.prototype,TE=SE.toString;function CE(e){return TE.call(e)}var IE=CE,EE="[object Null]",zE="[object Undefined]",ES=Tu?Tu.toStringTag:void 0;function AE(e){return e==null?e===void 0?zE:EE:ES&&ES in Object(e)?kE(e):IE(e)}var OE=AE;function RE(e){var t=typeof e;return e!=null&&(t=="object"||t=="function")}var WS=RE,BE="[object AsyncFunction]",NE="[object Function]",ME="[object GeneratorFunction]",DE="[object Proxy]";function PE(e){if(!WS(e))return!1;var t=OE(e);return t==NE||t==ME||t==BE||t==DE}var UE=PE,WE=Ff["__core-js_shared__"],Af=WE,zS=function(){var e=/[^.]+$/.exec(Af&&Af.keys&&Af.keys.IE_PROTO||"");return e?"Symbol(src)_1."+e:""}();function VE(e){return!!zS&&zS in e}var qE=VE,jE=Function.prototype,LE=jE.toString;function GE(e){if(e!=null){try{return LE.call(e)}catch{}try{return e+""}catch{}}return""}var FE=GE,HE=/[\\^$.*+?()[\]{}|]/g,KE=/^\[object .+?Constructor\]$/,ZE=Function.prototype,QE=Object.prototype,XE=ZE.toString,JE=QE.hasOwnProperty,YE=RegExp("^"+XE.call(JE).replace(HE,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");function ez(e){if(!WS(e)||qE(e))return!1;var t=UE(e)?YE:KE;return t.test(FE(e))}var tz=ez;function rz(e,t){return e?.[t]}var iz=rz;function az(e,t){var r=iz(e,t);return tz(r)?r:void 0}var VS=az,nz=VS(Object,"create"),co=nz;function sz(){this.__data__=co?co(null):{},this.size=0}var oz=sz;function uz(e){var t=this.has(e)&&delete this.__data__[e];return this.size-=t?1:0,t}var lz=uz,dz="__lodash_hash_undefined__",pz=Object.prototype,cz=pz.hasOwnProperty;function hz(e){var t=this.__data__;if(co){var r=t[e];return r===dz?void 0:r}return cz.call(t,e)?t[e]:void 0}var fz=hz,mz=Object.prototype,gz=mz.hasOwnProperty;function yz(e){var t=this.__data__;return co?t[e]!==void 0:gz.call(t,e)}var _z=yz,vz="__lodash_hash_undefined__";function wz(e,t){var r=this.__data__;return this.size+=this.has(e)?0:1,r[e]=co&&t===void 0?vz:t,this}var bz=wz;function ga(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}ga.prototype.clear=oz;ga.prototype.delete=lz;ga.prototype.get=fz;ga.prototype.has=_z;ga.prototype.set=bz;var AS=ga;function $z(){this.__data__=[],this.size=0}var xz=$z;function kz(e,t){return e===t||e!==e&&t!==t}var Sz=kz;function Tz(e,t){for(var r=e.length;r--;)if(Sz(e[r][0],t))return r;return-1}var Du=Tz,Cz=Array.prototype,Iz=Cz.splice;function Ez(e){var t=this.__data__,r=Du(t,e);if(r<0)return!1;var i=t.length-1;return r==i?t.pop():Iz.call(t,r,1),--this.size,!0}var zz=Ez;function Az(e){var t=this.__data__,r=Du(t,e);return r<0?void 0:t[r][1]}var Oz=Az;function Rz(e){return Du(this.__data__,e)>-1}var Bz=Rz;function Nz(e,t){var r=this.__data__,i=Du(r,e);return i<0?(++this.size,r.push([e,t])):r[i][1]=t,this}var Mz=Nz;function ya(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}ya.prototype.clear=xz;ya.prototype.delete=zz;ya.prototype.get=Oz;ya.prototype.has=Bz;ya.prototype.set=Mz;var Dz=ya,Pz=VS(Ff,"Map"),Uz=Pz;function Wz(){this.size=0,this.__data__={hash:new AS,map:new(Uz||Dz),string:new AS}}var Vz=Wz;function qz(e){var t=typeof e;return t=="string"||t=="number"||t=="symbol"||t=="boolean"?e!=="__proto__":e===null}var jz=qz;function Lz(e,t){var r=e.__data__;return jz(t)?r[typeof t=="string"?"string":"hash"]:r.map}var Pu=Lz;function Gz(e){var t=Pu(this,e).delete(e);return this.size-=t?1:0,t}var Fz=Gz;function Hz(e){return Pu(this,e).get(e)}var Kz=Hz;function Zz(e){return Pu(this,e).has(e)}var Qz=Zz;function Xz(e,t){var r=Pu(this,e),i=r.size;return r.set(e,t),this.size+=r.size==i?0:1,this}var Jz=Xz;function _a(e){var t=-1,r=e==null?0:e.length;for(this.clear();++t<r;){var i=e[t];this.set(i[0],i[1])}}_a.prototype.clear=Vz;_a.prototype.delete=Fz;_a.prototype.get=Kz;_a.prototype.has=Qz;_a.prototype.set=Jz;var qS=_a,Yz="Expected a function";function Hf(e,t){if(typeof e!="function"||t!=null&&typeof t!="function")throw new TypeError(Yz);var r=function(){var i=arguments,a=t?t.apply(this,i):i[0],s=r.cache;if(s.has(a))return s.get(a);var o=e.apply(this,i);return r.cache=s.set(a,o)||s,o};return r.cache=new(Hf.Cache||qS),r}Hf.Cache=qS;var eA=Hf,Kf=Nu(Mu()),jS=class Bf{constructor(t,r){this.type="application/octet-stream",this.params={},this.type=t,this.params=r}toString(){let t=[];for(let r in this.params){let i=this.params[r];t.push(`${r}=${i}`)}return[this.type,...t].join(";")}static create(t,r){return new Bf(t,r)}isIdentical(t){return this.type===t.type&&this.params===t.params}isEqual(t){return this.type===t.type}static fromString(t){let[r,...i]=t.split(";"),a={};for(let s of i){let[o,u]=s.split("=");a[o.trim()]=u.trim()}return new Bf(r,a)}},Of=Nu(Mu());async function tA(e){let t=jS.fromString(e.type);switch(t.type){case"image/x-alpha8":{let r=parseInt(t.params.width),i=parseInt(t.params.height);return(0,Of.default)(new Uint8Array(await e.arrayBuffer()),[i,r,1])}case"image/x-rgba8":{let r=parseInt(t.params.width),i=parseInt(t.params.height);return(0,Of.default)(new Uint8Array(await e.arrayBuffer()),[i,r,4])}case"application/octet-stream":case"image/png":case"image/jpeg":case"image/jpg":case"image/webp":{let r=await createImageBitmap(e),i=aA(r);return(0,Of.default)(new Uint8Array(i.data),[i.height,i.width,4])}default:throw new Error(`Invalid format: ${t.type} with params: ${t.params}`)}}async function Uu(e,t=.8,r="image/png"){let[i,a,s]=e.shape;switch(r){case"image/x-alpha8":case"image/x-rgba8":{let d=jS.create(r,{width:a.toString(),height:i.toString()});return new Blob([e.data],{type:d.toString()})}case"image/png":case"image/jpeg":case"image/webp":{let d=new ImageData(new Uint8ClampedArray(e.data),a,i);var o=LS(d.width,d.height),u=o.getContext("2d");return u.putImageData(d,0,0),o.convertToBlob({quality:t,type:r})}default:throw new Error(`Invalid format: ${r}`)}}function rA(e){return new RegExp("^(?:[a-z+]+:)?//","i").test(e)}function iA(e,t){return rA(e)?e:new URL(e,t).href}function aA(e){var t=LS(e.width,e.height),r=t.getContext("2d");return r.drawImage(e,0,0),r.getImageData(0,0,t.width,t.height)}function nA(e){if(typeof Uint8Array<"u")return new Uint8Array(e);if(typeof Uint8ClampedArray<"u")return new Uint8ClampedArray(e);if(typeof Uint16Array<"u")return new Uint16Array(e);if(typeof Uint32Array<"u")return new Uint32Array(e);if(typeof Float32Array<"u")return new Float32Array(e);if(typeof Float64Array<"u")return new Float64Array(e);throw new Error("TypedArray not supported")}function Nf(e,t,r,i=!1){let[a,s,o]=e.shape,u=s/t,d=a/r;i&&(u=d=Math.max(u,d)>1?Math.max(u,d):Math.min(u,d));let p=(0,Kf.default)(nA(o*t*r),[r,t,o]);for(let m=0;m<r;m++)for(let f=0;f<t;f++){let g=f*u,v=m*d,_=Math.max(Math.floor(g),0),b=Math.min(Math.ceil(g),s-1),k=Math.max(Math.floor(v),0),$=Math.min(Math.ceil(v),a-1),w=g-_,S=v-k;for(let C=0;C<o;C++){let I=e.get(k,_,C),z=e.get(k,b,C),E=e.get($,_,C),B=e.get($,b,C),U=(1-w)*(1-S)*I+w*(1-S)*z+(1-w)*S*E+w*S*B;p.set(m,f,C,U)}}return p}function sA(e,t=[128,128,128],r=[256,256,256]){var i=e.data;let[a,s,o]=e.shape,u=a*s,d=new Float32Array(3*u);for(let p=0,m=0;p<i.length;p+=4,m+=1)d[m]=(i[p]-t[0])/r[0],d[m+u]=(i[p+1]-t[1])/r[1],d[m+u+u]=(i[p+2]-t[2])/r[2];return(0,Kf.default)(d,[1,3,a,s])}async function ho(e,t){return typeof e=="string"&&(e=iA(e,t.publicPath),e=new URL(e)),e instanceof URL&&(e=await(await fetch(e,{})).blob()),(e instanceof ArrayBuffer||ArrayBuffer.isView(e))&&(e=new Blob([e])),e instanceof Blob&&(e=await tA(e)),e}function oA(e){let t=new Uint8Array(e.data.length);for(let r=0;r<e.data.length;r++)t[r]=e.data[r]*255;return(0,Kf.default)(t,e.shape)}function LS(e,t){let r;if(typeof OffscreenCanvas<"u"?r=new OffscreenCanvas(e,t):r=document.createElement("canvas"),!r)throw new Error("Canvas nor OffscreenCanvas are available in the current context.");return r}var uA=Nu(Mu()),GS=async()=>navigator.gpu===void 0?!1:await navigator.gpu.requestAdapter()!==null,lA=()=>navigator.hardwareConcurrency??4;async function OS(e,t){return URL.createObjectURL(await FS(e,t))}async function FS(e,t){let r=new URL("resources.json",t.publicPath),i=await fetch(r);if(!i.ok)throw new Error("Resource metadata not found. Ensure that the config.publicPath is configured correctly.");let s=(await i.json())[e];if(!s)throw new Error(`Resource ${e} not found. Ensure that the config.publicPath is configured correctly.`);let o=s.chunks,u=0,d=o.map(async f=>{let g=f.offsets[1]-f.offsets[0],v=t.publicPath?new URL(f.name,t.publicPath).toString():f.name,b=await(await fetch(v,t.fetchArgs)).blob();if(g!==b.size)throw new Error(`Failed to fetch ${e} with size ${g} but got ${b.size}`);return t.progress&&(u+=g,t.progress(`fetch:${e}`,u,s.size)),b}),p=await Promise.all(d),m=new Blob(p,{type:s.mime});if(m.size!==s.size)throw new Error(`Failed to fetch ${e} with size ${s.size} but got ${m.size}`);return m}var oo=null,HS=async e=>(oo!==null||(e?oo=(await Promise.resolve().then(()=>(hb(),cb))).default:oo=(await Promise.resolve().then(()=>(IS(),CS))).default),oo);async function dA(e,t){let r=t.device==="gpu"&&await GS(),i=r&&t.proxyToWorker,a=[r?"webgpu":"wasm"],s=await HS(r);t.debug&&(console.debug("	Using WebGPU:",r),console.debug("	Proxy to Worker:",i),s.env.debug=!0,s.env.logLevel="verbose"),s.env.wasm.numThreads=lA(),s.env.wasm.proxy=i;let o=r?"/onnxruntime-web/ort-wasm-simd-threaded.jsep":"/onnxruntime-web/ort-wasm-simd-threaded",u=await OS(`${o}.wasm`,t),d=await OS(`${o}.mjs`,t);s.env.wasm.wasmPaths={mjs:d,wasm:u},t.debug&&console.debug("ort.env.wasm:",s.env.wasm);let p={executionProviders:a,graphOptimizationLevel:"all",executionMode:"parallel",enableCpuMemArena:!0};return await s.InferenceSession.create(e,p).catch(f=>{throw new Error(`Failed to create session: "${f}". Please check if the publicPath is set correctly.`)})}async function pA(e,t,r,i){let a=i.device==="gpu"&&await GS(),s=await HS(a),o={};for(let[p,m]of t)o[p]=new s.Tensor("float32",new Float32Array(m.data),m.shape);let u=await e.run(o,{}),d=[];for(let p of r){let m=u[p],f=m.dims,g=m.data,v=(0,uA.default)(g,f);d.push(v)}return d}var We;(function(e){e.assertEqual=a=>a;function t(a){}e.assertIs=t;function r(a){throw new Error}e.assertNever=r,e.arrayToEnum=a=>{let s={};for(let o of a)s[o]=o;return s},e.getValidEnumValues=a=>{let s=e.objectKeys(a).filter(u=>typeof a[a[u]]!="number"),o={};for(let u of s)o[u]=a[u];return e.objectValues(o)},e.objectValues=a=>e.objectKeys(a).map(function(s){return a[s]}),e.objectKeys=typeof Object.keys=="function"?a=>Object.keys(a):a=>{let s=[];for(let o in a)Object.prototype.hasOwnProperty.call(a,o)&&s.push(o);return s},e.find=(a,s)=>{for(let o of a)if(s(o))return o},e.isInteger=typeof Number.isInteger=="function"?a=>Number.isInteger(a):a=>typeof a=="number"&&isFinite(a)&&Math.floor(a)===a;function i(a,s=" | "){return a.map(o=>typeof o=="string"?`'${o}'`:o).join(s)}e.joinValues=i,e.jsonStringifyReplacer=(a,s)=>typeof s=="bigint"?s.toString():s})(We||(We={}));var Mf;(function(e){e.mergeShapes=(t,r)=>({...t,...r})})(Mf||(Mf={}));var ce=We.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),Vr=e=>{switch(typeof e){case"undefined":return ce.undefined;case"string":return ce.string;case"number":return isNaN(e)?ce.nan:ce.number;case"boolean":return ce.boolean;case"function":return ce.function;case"bigint":return ce.bigint;case"symbol":return ce.symbol;case"object":return Array.isArray(e)?ce.array:e===null?ce.null:e.then&&typeof e.then=="function"&&e.catch&&typeof e.catch=="function"?ce.promise:typeof Map<"u"&&e instanceof Map?ce.map:typeof Set<"u"&&e instanceof Set?ce.set:typeof Date<"u"&&e instanceof Date?ce.date:ce.object;default:return ce.unknown}},ne=We.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]),cA=e=>JSON.stringify(e,null,2).replace(/"([^"]+)":/g,"$1:"),gr=class KS extends Error{get errors(){return this.issues}constructor(t){super(),this.issues=[],this.addIssue=i=>{this.issues=[...this.issues,i]},this.addIssues=(i=[])=>{this.issues=[...this.issues,...i]};let r=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,r):this.__proto__=r,this.name="ZodError",this.issues=t}format(t){let r=t||function(s){return s.message},i={_errors:[]},a=s=>{for(let o of s.issues)if(o.code==="invalid_union")o.unionErrors.map(a);else if(o.code==="invalid_return_type")a(o.returnTypeError);else if(o.code==="invalid_arguments")a(o.argumentsError);else if(o.path.length===0)i._errors.push(r(o));else{let u=i,d=0;for(;d<o.path.length;){let p=o.path[d];d===o.path.length-1?(u[p]=u[p]||{_errors:[]},u[p]._errors.push(r(o))):u[p]=u[p]||{_errors:[]},u=u[p],d++}}};return a(this),i}static assert(t){if(!(t instanceof KS))throw new Error(`Not a ZodError: ${t}`)}toString(){return this.message}get message(){return JSON.stringify(this.issues,We.jsonStringifyReplacer,2)}get isEmpty(){return this.issues.length===0}flatten(t=r=>r.message){let r={},i=[];for(let a of this.issues)a.path.length>0?(r[a.path[0]]=r[a.path[0]]||[],r[a.path[0]].push(t(a))):i.push(t(a));return{formErrors:i,fieldErrors:r}}get formErrors(){return this.flatten()}};gr.create=e=>new gr(e);var ca=(e,t)=>{let r;switch(e.code){case ne.invalid_type:e.received===ce.undefined?r="Required":r=`Expected ${e.expected}, received ${e.received}`;break;case ne.invalid_literal:r=`Invalid literal value, expected ${JSON.stringify(e.expected,We.jsonStringifyReplacer)}`;break;case ne.unrecognized_keys:r=`Unrecognized key(s) in object: ${We.joinValues(e.keys,", ")}`;break;case ne.invalid_union:r="Invalid input";break;case ne.invalid_union_discriminator:r=`Invalid discriminator value. Expected ${We.joinValues(e.options)}`;break;case ne.invalid_enum_value:r=`Invalid enum value. Expected ${We.joinValues(e.options)}, received '${e.received}'`;break;case ne.invalid_arguments:r="Invalid function arguments";break;case ne.invalid_return_type:r="Invalid function return type";break;case ne.invalid_date:r="Invalid date";break;case ne.invalid_string:typeof e.validation=="object"?"includes"in e.validation?(r=`Invalid input: must include "${e.validation.includes}"`,typeof e.validation.position=="number"&&(r=`${r} at one or more positions greater than or equal to ${e.validation.position}`)):"startsWith"in e.validation?r=`Invalid input: must start with "${e.validation.startsWith}"`:"endsWith"in e.validation?r=`Invalid input: must end with "${e.validation.endsWith}"`:We.assertNever(e.validation):e.validation!=="regex"?r=`Invalid ${e.validation}`:r="Invalid";break;case ne.too_small:e.type==="array"?r=`Array must contain ${e.exact?"exactly":e.inclusive?"at least":"more than"} ${e.minimum} element(s)`:e.type==="string"?r=`String must contain ${e.exact?"exactly":e.inclusive?"at least":"over"} ${e.minimum} character(s)`:e.type==="number"?r=`Number must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${e.minimum}`:e.type==="date"?r=`Date must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(e.minimum))}`:r="Invalid input";break;case ne.too_big:e.type==="array"?r=`Array must contain ${e.exact?"exactly":e.inclusive?"at most":"less than"} ${e.maximum} element(s)`:e.type==="string"?r=`String must contain ${e.exact?"exactly":e.inclusive?"at most":"under"} ${e.maximum} character(s)`:e.type==="number"?r=`Number must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:e.type==="bigint"?r=`BigInt must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:e.type==="date"?r=`Date must be ${e.exact?"exactly":e.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(e.maximum))}`:r="Invalid input";break;case ne.custom:r="Invalid input";break;case ne.invalid_intersection_types:r="Intersection results could not be merged";break;case ne.not_multiple_of:r=`Number must be a multiple of ${e.multipleOf}`;break;case ne.not_finite:r="Number must be finite";break;default:r=t.defaultError,We.assertNever(e)}return{message:r}},ZS=ca;function hA(e){ZS=e}function Cu(){return ZS}var Iu=e=>{let{data:t,path:r,errorMaps:i,issueData:a}=e,s=[...r,...a.path||[]],o={...a,path:s};if(a.message!==void 0)return{...a,path:s,message:a.message};let u="",d=i.filter(p=>!!p).slice().reverse();for(let p of d)u=p(o,{data:t,defaultError:u}).message;return{...a,path:s,message:u}},fA=[];function pe(e,t){let r=Cu(),i=Iu({issueData:t,data:e.data,path:e.path,errorMaps:[e.common.contextualErrorMap,e.schemaErrorMap,r,r===ca?void 0:ca].filter(a=>!!a)});e.common.issues.push(i)}var zt=class QS{constructor(){this.value="valid"}dirty(){this.value==="valid"&&(this.value="dirty")}abort(){this.value!=="aborted"&&(this.value="aborted")}static mergeArray(t,r){let i=[];for(let a of r){if(a.status==="aborted")return Se;a.status==="dirty"&&t.dirty(),i.push(a.value)}return{status:t.value,value:i}}static async mergeObjectAsync(t,r){let i=[];for(let a of r){let s=await a.key,o=await a.value;i.push({key:s,value:o})}return QS.mergeObjectSync(t,i)}static mergeObjectSync(t,r){let i={};for(let a of r){let{key:s,value:o}=a;if(s.status==="aborted"||o.status==="aborted")return Se;s.status==="dirty"&&t.dirty(),o.status==="dirty"&&t.dirty(),s.value!=="__proto__"&&(typeof o.value<"u"||a.alwaysSet)&&(i[s.value]=o.value)}return{status:t.value,value:i}}},Se=Object.freeze({status:"aborted"}),pa=e=>({status:"dirty",value:e}),It=e=>({status:"valid",value:e}),Df=e=>e.status==="aborted",Pf=e=>e.status==="dirty",Ji=e=>e.status==="valid",fo=e=>typeof Promise<"u"&&e instanceof Promise;function Eu(e,t,r,i){if(r==="a"&&!i)throw new TypeError("Private accessor was defined without a getter");if(typeof t=="function"?e!==t||!i:!t.has(e))throw new TypeError("Cannot read private member from an object whose class did not declare it");return r==="m"?i:r==="a"?i.call(e):i?i.value:t.get(e)}function XS(e,t,r,i,a){if(i==="m")throw new TypeError("Private method is not writable");if(i==="a"&&!a)throw new TypeError("Private accessor was defined without a setter");if(typeof t=="function"?e!==t||!a:!t.has(e))throw new TypeError("Cannot write private member to an object whose class did not declare it");return i==="a"?a.call(e,r):a?a.value=r:t.set(e,r),r}var ve;(function(e){e.errToObj=t=>typeof t=="string"?{message:t}:t||{},e.toString=t=>typeof t=="string"?t:t?.message})(ve||(ve={}));var uo,lo,xr=class{constructor(e,t,r,i){this._cachedPath=[],this.parent=e,this.data=t,this._path=r,this._key=i}get path(){return this._cachedPath.length||(this._key instanceof Array?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}},RS=(e,t)=>{if(Ji(t))return{success:!0,data:t.value};if(!e.common.issues.length)throw new Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;let r=new gr(e.common.issues);return this._error=r,this._error}}};function Re(e){if(!e)return{};let{errorMap:t,invalid_type_error:r,required_error:i,description:a}=e;if(t&&(r||i))throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);return t?{errorMap:t,description:a}:{errorMap:(o,u)=>{var d,p;let{message:m}=e;return o.code==="invalid_enum_value"?{message:m??u.defaultError}:typeof u.data>"u"?{message:(d=m??i)!==null&&d!==void 0?d:u.defaultError}:o.code!=="invalid_type"?{message:u.defaultError}:{message:(p=m??r)!==null&&p!==void 0?p:u.defaultError}},description:a}}var Be=class{get description(){return this._def.description}_getType(e){return Vr(e.data)}_getOrReturnCtx(e,t){return t||{common:e.parent.common,data:e.data,parsedType:Vr(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new zt,ctx:{common:e.parent.common,data:e.data,parsedType:Vr(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){let t=this._parse(e);if(fo(t))throw new Error("Synchronous parse encountered promise.");return t}_parseAsync(e){let t=this._parse(e);return Promise.resolve(t)}parse(e,t){let r=this.safeParse(e,t);if(r.success)return r.data;throw r.error}safeParse(e,t){var r;let i={common:{issues:[],async:(r=t?.async)!==null&&r!==void 0?r:!1,contextualErrorMap:t?.errorMap},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:Vr(e)},a=this._parseSync({data:e,path:i.path,parent:i});return RS(i,a)}"~validate"(e){var t,r;let i={common:{issues:[],async:!!this["~standard"].async},path:[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:Vr(e)};if(!this["~standard"].async)try{let a=this._parseSync({data:e,path:[],parent:i});return Ji(a)?{value:a.value}:{issues:i.common.issues}}catch(a){!((r=(t=a?.message)===null||t===void 0?void 0:t.toLowerCase())===null||r===void 0)&&r.includes("encountered")&&(this["~standard"].async=!0),i.common={issues:[],async:!0}}return this._parseAsync({data:e,path:[],parent:i}).then(a=>Ji(a)?{value:a.value}:{issues:i.common.issues})}async parseAsync(e,t){let r=await this.safeParseAsync(e,t);if(r.success)return r.data;throw r.error}async safeParseAsync(e,t){let r={common:{issues:[],contextualErrorMap:t?.errorMap,async:!0},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:Vr(e)},i=this._parse({data:e,path:r.path,parent:r}),a=await(fo(i)?i:Promise.resolve(i));return RS(r,a)}refine(e,t){let r=i=>typeof t=="string"||typeof t>"u"?{message:t}:typeof t=="function"?t(i):t;return this._refinement((i,a)=>{let s=e(i),o=()=>a.addIssue({code:ne.custom,...r(i)});return typeof Promise<"u"&&s instanceof Promise?s.then(u=>u?!0:(o(),!1)):s?!0:(o(),!1)})}refinement(e,t){return this._refinement((r,i)=>e(r)?!0:(i.addIssue(typeof t=="function"?t(r,i):t),!1))}_refinement(e){return new yr({schema:this,typeName:ke.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this),this["~standard"]={version:1,vendor:"zod",validate:t=>this["~validate"](t)}}optional(){return $r.create(this,this._def)}nullable(){return ei.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return Yi.create(this)}promise(){return ma.create(this,this._def)}or(e){return bo.create([this,e],this._def)}and(e){return $o.create(this,e,this._def)}transform(e){return new yr({...Re(this._def),schema:this,typeName:ke.ZodEffects,effect:{type:"transform",transform:e}})}default(e){let t=typeof e=="function"?e:()=>e;return new To({...Re(this._def),innerType:this,defaultValue:t,typeName:ke.ZodDefault})}brand(){return new Zf({typeName:ke.ZodBranded,type:this,...Re(this._def)})}catch(e){let t=typeof e=="function"?e:()=>e;return new Co({...Re(this._def),innerType:this,catchValue:t,typeName:ke.ZodCatch})}describe(e){let t=this.constructor;return new t({...this._def,description:e})}pipe(e){return Qf.create(this,e)}readonly(){return Io.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}},mA=/^c[^\s-]{8,}$/i,gA=/^[0-9a-z]+$/,yA=/^[0-9A-HJKMNP-TV-Z]{26}$/i,_A=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,vA=/^[a-z0-9_-]{21}$/i,wA=/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/,bA=/^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,$A=/^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,xA="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$",Rf,kA=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,SA=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,TA=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,CA=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,IA=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,EA=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,JS="((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))",zA=new RegExp(`^${JS}$`);function YS(e){let t="([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d";return e.precision?t=`${t}\\.\\d{${e.precision}}`:e.precision==null&&(t=`${t}(\\.\\d+)?`),t}function AA(e){return new RegExp(`^${YS(e)}$`)}function eT(e){let t=`${JS}T${YS(e)}`,r=[];return r.push(e.local?"Z?":"Z"),e.offset&&r.push("([+-]\\d{2}:?\\d{2})"),t=`${t}(${r.join("|")})`,new RegExp(`^${t}$`)}function OA(e,t){return!!((t==="v4"||!t)&&kA.test(e)||(t==="v6"||!t)&&TA.test(e))}function RA(e,t){if(!wA.test(e))return!1;try{let[r]=e.split("."),i=r.replace(/-/g,"+").replace(/_/g,"/").padEnd(r.length+(4-r.length%4)%4,"="),a=JSON.parse(atob(i));return!(typeof a!="object"||a===null||!a.typ||!a.alg||t&&a.alg!==t)}catch{return!1}}function BA(e,t){return!!((t==="v4"||!t)&&SA.test(e)||(t==="v6"||!t)&&CA.test(e))}var ha=class po extends Be{_parse(t){if(this._def.coerce&&(t.data=String(t.data)),this._getType(t)!==ce.string){let s=this._getOrReturnCtx(t);return pe(s,{code:ne.invalid_type,expected:ce.string,received:s.parsedType}),Se}let i=new zt,a;for(let s of this._def.checks)if(s.kind==="min")t.data.length<s.value&&(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.too_small,minimum:s.value,type:"string",inclusive:!0,exact:!1,message:s.message}),i.dirty());else if(s.kind==="max")t.data.length>s.value&&(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.too_big,maximum:s.value,type:"string",inclusive:!0,exact:!1,message:s.message}),i.dirty());else if(s.kind==="length"){let o=t.data.length>s.value,u=t.data.length<s.value;(o||u)&&(a=this._getOrReturnCtx(t,a),o?pe(a,{code:ne.too_big,maximum:s.value,type:"string",inclusive:!0,exact:!0,message:s.message}):u&&pe(a,{code:ne.too_small,minimum:s.value,type:"string",inclusive:!0,exact:!0,message:s.message}),i.dirty())}else if(s.kind==="email")$A.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"email",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="emoji")Rf||(Rf=new RegExp(xA,"u")),Rf.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"emoji",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="uuid")_A.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"uuid",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="nanoid")vA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"nanoid",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="cuid")mA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"cuid",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="cuid2")gA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"cuid2",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="ulid")yA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"ulid",code:ne.invalid_string,message:s.message}),i.dirty());else if(s.kind==="url")try{new URL(t.data)}catch{a=this._getOrReturnCtx(t,a),pe(a,{validation:"url",code:ne.invalid_string,message:s.message}),i.dirty()}else s.kind==="regex"?(s.regex.lastIndex=0,s.regex.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"regex",code:ne.invalid_string,message:s.message}),i.dirty())):s.kind==="trim"?t.data=t.data.trim():s.kind==="includes"?t.data.includes(s.value,s.position)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:{includes:s.value,position:s.position},message:s.message}),i.dirty()):s.kind==="toLowerCase"?t.data=t.data.toLowerCase():s.kind==="toUpperCase"?t.data=t.data.toUpperCase():s.kind==="startsWith"?t.data.startsWith(s.value)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:{startsWith:s.value},message:s.message}),i.dirty()):s.kind==="endsWith"?t.data.endsWith(s.value)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:{endsWith:s.value},message:s.message}),i.dirty()):s.kind==="datetime"?eT(s).test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:"datetime",message:s.message}),i.dirty()):s.kind==="date"?zA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:"date",message:s.message}),i.dirty()):s.kind==="time"?AA(s).test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.invalid_string,validation:"time",message:s.message}),i.dirty()):s.kind==="duration"?bA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"duration",code:ne.invalid_string,message:s.message}),i.dirty()):s.kind==="ip"?OA(t.data,s.version)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"ip",code:ne.invalid_string,message:s.message}),i.dirty()):s.kind==="jwt"?RA(t.data,s.alg)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"jwt",code:ne.invalid_string,message:s.message}),i.dirty()):s.kind==="cidr"?BA(t.data,s.version)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"cidr",code:ne.invalid_string,message:s.message}),i.dirty()):s.kind==="base64"?IA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"base64",code:ne.invalid_string,message:s.message}),i.dirty()):s.kind==="base64url"?EA.test(t.data)||(a=this._getOrReturnCtx(t,a),pe(a,{validation:"base64url",code:ne.invalid_string,message:s.message}),i.dirty()):We.assertNever(s);return{status:i.value,value:t.data}}_regex(t,r,i){return this.refinement(a=>t.test(a),{validation:r,code:ne.invalid_string,...ve.errToObj(i)})}_addCheck(t){return new po({...this._def,checks:[...this._def.checks,t]})}email(t){return this._addCheck({kind:"email",...ve.errToObj(t)})}url(t){return this._addCheck({kind:"url",...ve.errToObj(t)})}emoji(t){return this._addCheck({kind:"emoji",...ve.errToObj(t)})}uuid(t){return this._addCheck({kind:"uuid",...ve.errToObj(t)})}nanoid(t){return this._addCheck({kind:"nanoid",...ve.errToObj(t)})}cuid(t){return this._addCheck({kind:"cuid",...ve.errToObj(t)})}cuid2(t){return this._addCheck({kind:"cuid2",...ve.errToObj(t)})}ulid(t){return this._addCheck({kind:"ulid",...ve.errToObj(t)})}base64(t){return this._addCheck({kind:"base64",...ve.errToObj(t)})}base64url(t){return this._addCheck({kind:"base64url",...ve.errToObj(t)})}jwt(t){return this._addCheck({kind:"jwt",...ve.errToObj(t)})}ip(t){return this._addCheck({kind:"ip",...ve.errToObj(t)})}cidr(t){return this._addCheck({kind:"cidr",...ve.errToObj(t)})}datetime(t){var r,i;return typeof t=="string"?this._addCheck({kind:"datetime",precision:null,offset:!1,local:!1,message:t}):this._addCheck({kind:"datetime",precision:typeof t?.precision>"u"?null:t?.precision,offset:(r=t?.offset)!==null&&r!==void 0?r:!1,local:(i=t?.local)!==null&&i!==void 0?i:!1,...ve.errToObj(t?.message)})}date(t){return this._addCheck({kind:"date",message:t})}time(t){return typeof t=="string"?this._addCheck({kind:"time",precision:null,message:t}):this._addCheck({kind:"time",precision:typeof t?.precision>"u"?null:t?.precision,...ve.errToObj(t?.message)})}duration(t){return this._addCheck({kind:"duration",...ve.errToObj(t)})}regex(t,r){return this._addCheck({kind:"regex",regex:t,...ve.errToObj(r)})}includes(t,r){return this._addCheck({kind:"includes",value:t,position:r?.position,...ve.errToObj(r?.message)})}startsWith(t,r){return this._addCheck({kind:"startsWith",value:t,...ve.errToObj(r)})}endsWith(t,r){return this._addCheck({kind:"endsWith",value:t,...ve.errToObj(r)})}min(t,r){return this._addCheck({kind:"min",value:t,...ve.errToObj(r)})}max(t,r){return this._addCheck({kind:"max",value:t,...ve.errToObj(r)})}length(t,r){return this._addCheck({kind:"length",value:t,...ve.errToObj(r)})}nonempty(t){return this.min(1,ve.errToObj(t))}trim(){return new po({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new po({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new po({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(t=>t.kind==="datetime")}get isDate(){return!!this._def.checks.find(t=>t.kind==="date")}get isTime(){return!!this._def.checks.find(t=>t.kind==="time")}get isDuration(){return!!this._def.checks.find(t=>t.kind==="duration")}get isEmail(){return!!this._def.checks.find(t=>t.kind==="email")}get isURL(){return!!this._def.checks.find(t=>t.kind==="url")}get isEmoji(){return!!this._def.checks.find(t=>t.kind==="emoji")}get isUUID(){return!!this._def.checks.find(t=>t.kind==="uuid")}get isNANOID(){return!!this._def.checks.find(t=>t.kind==="nanoid")}get isCUID(){return!!this._def.checks.find(t=>t.kind==="cuid")}get isCUID2(){return!!this._def.checks.find(t=>t.kind==="cuid2")}get isULID(){return!!this._def.checks.find(t=>t.kind==="ulid")}get isIP(){return!!this._def.checks.find(t=>t.kind==="ip")}get isCIDR(){return!!this._def.checks.find(t=>t.kind==="cidr")}get isBase64(){return!!this._def.checks.find(t=>t.kind==="base64")}get isBase64url(){return!!this._def.checks.find(t=>t.kind==="base64url")}get minLength(){let t=null;for(let r of this._def.checks)r.kind==="min"&&(t===null||r.value>t)&&(t=r.value);return t}get maxLength(){let t=null;for(let r of this._def.checks)r.kind==="max"&&(t===null||r.value<t)&&(t=r.value);return t}};ha.create=e=>{var t;return new ha({checks:[],typeName:ke.ZodString,coerce:(t=e?.coerce)!==null&&t!==void 0?t:!1,...Re(e)})};function NA(e,t){let r=(e.toString().split(".")[1]||"").length,i=(t.toString().split(".")[1]||"").length,a=r>i?r:i,s=parseInt(e.toFixed(a).replace(".","")),o=parseInt(t.toFixed(a).replace(".",""));return s%o/Math.pow(10,a)}var mo=class Uf extends Be{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(t){if(this._def.coerce&&(t.data=Number(t.data)),this._getType(t)!==ce.number){let s=this._getOrReturnCtx(t);return pe(s,{code:ne.invalid_type,expected:ce.number,received:s.parsedType}),Se}let i,a=new zt;for(let s of this._def.checks)s.kind==="int"?We.isInteger(t.data)||(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.invalid_type,expected:"integer",received:"float",message:s.message}),a.dirty()):s.kind==="min"?(s.inclusive?t.data<s.value:t.data<=s.value)&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.too_small,minimum:s.value,type:"number",inclusive:s.inclusive,exact:!1,message:s.message}),a.dirty()):s.kind==="max"?(s.inclusive?t.data>s.value:t.data>=s.value)&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.too_big,maximum:s.value,type:"number",inclusive:s.inclusive,exact:!1,message:s.message}),a.dirty()):s.kind==="multipleOf"?NA(t.data,s.value)!==0&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.not_multiple_of,multipleOf:s.value,message:s.message}),a.dirty()):s.kind==="finite"?Number.isFinite(t.data)||(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.not_finite,message:s.message}),a.dirty()):We.assertNever(s);return{status:a.value,value:t.data}}gte(t,r){return this.setLimit("min",t,!0,ve.toString(r))}gt(t,r){return this.setLimit("min",t,!1,ve.toString(r))}lte(t,r){return this.setLimit("max",t,!0,ve.toString(r))}lt(t,r){return this.setLimit("max",t,!1,ve.toString(r))}setLimit(t,r,i,a){return new Uf({...this._def,checks:[...this._def.checks,{kind:t,value:r,inclusive:i,message:ve.toString(a)}]})}_addCheck(t){return new Uf({...this._def,checks:[...this._def.checks,t]})}int(t){return this._addCheck({kind:"int",message:ve.toString(t)})}positive(t){return this._addCheck({kind:"min",value:0,inclusive:!1,message:ve.toString(t)})}negative(t){return this._addCheck({kind:"max",value:0,inclusive:!1,message:ve.toString(t)})}nonpositive(t){return this._addCheck({kind:"max",value:0,inclusive:!0,message:ve.toString(t)})}nonnegative(t){return this._addCheck({kind:"min",value:0,inclusive:!0,message:ve.toString(t)})}multipleOf(t,r){return this._addCheck({kind:"multipleOf",value:t,message:ve.toString(r)})}finite(t){return this._addCheck({kind:"finite",message:ve.toString(t)})}safe(t){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:ve.toString(t)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:ve.toString(t)})}get minValue(){let t=null;for(let r of this._def.checks)r.kind==="min"&&(t===null||r.value>t)&&(t=r.value);return t}get maxValue(){let t=null;for(let r of this._def.checks)r.kind==="max"&&(t===null||r.value<t)&&(t=r.value);return t}get isInt(){return!!this._def.checks.find(t=>t.kind==="int"||t.kind==="multipleOf"&&We.isInteger(t.value))}get isFinite(){let t=null,r=null;for(let i of this._def.checks){if(i.kind==="finite"||i.kind==="int"||i.kind==="multipleOf")return!0;i.kind==="min"?(r===null||i.value>r)&&(r=i.value):i.kind==="max"&&(t===null||i.value<t)&&(t=i.value)}return Number.isFinite(r)&&Number.isFinite(t)}};mo.create=e=>new mo({checks:[],typeName:ke.ZodNumber,coerce:e?.coerce||!1,...Re(e)});var go=class Wf extends Be{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(t){if(this._def.coerce)try{t.data=BigInt(t.data)}catch{return this._getInvalidInput(t)}if(this._getType(t)!==ce.bigint)return this._getInvalidInput(t);let i,a=new zt;for(let s of this._def.checks)s.kind==="min"?(s.inclusive?t.data<s.value:t.data<=s.value)&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.too_small,type:"bigint",minimum:s.value,inclusive:s.inclusive,message:s.message}),a.dirty()):s.kind==="max"?(s.inclusive?t.data>s.value:t.data>=s.value)&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.too_big,type:"bigint",maximum:s.value,inclusive:s.inclusive,message:s.message}),a.dirty()):s.kind==="multipleOf"?t.data%s.value!==BigInt(0)&&(i=this._getOrReturnCtx(t,i),pe(i,{code:ne.not_multiple_of,multipleOf:s.value,message:s.message}),a.dirty()):We.assertNever(s);return{status:a.value,value:t.data}}_getInvalidInput(t){let r=this._getOrReturnCtx(t);return pe(r,{code:ne.invalid_type,expected:ce.bigint,received:r.parsedType}),Se}gte(t,r){return this.setLimit("min",t,!0,ve.toString(r))}gt(t,r){return this.setLimit("min",t,!1,ve.toString(r))}lte(t,r){return this.setLimit("max",t,!0,ve.toString(r))}lt(t,r){return this.setLimit("max",t,!1,ve.toString(r))}setLimit(t,r,i,a){return new Wf({...this._def,checks:[...this._def.checks,{kind:t,value:r,inclusive:i,message:ve.toString(a)}]})}_addCheck(t){return new Wf({...this._def,checks:[...this._def.checks,t]})}positive(t){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:ve.toString(t)})}negative(t){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:ve.toString(t)})}nonpositive(t){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:ve.toString(t)})}nonnegative(t){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:ve.toString(t)})}multipleOf(t,r){return this._addCheck({kind:"multipleOf",value:t,message:ve.toString(r)})}get minValue(){let t=null;for(let r of this._def.checks)r.kind==="min"&&(t===null||r.value>t)&&(t=r.value);return t}get maxValue(){let t=null;for(let r of this._def.checks)r.kind==="max"&&(t===null||r.value<t)&&(t=r.value);return t}};go.create=e=>{var t;return new go({checks:[],typeName:ke.ZodBigInt,coerce:(t=e?.coerce)!==null&&t!==void 0?t:!1,...Re(e)})};var yo=class extends Be{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==ce.boolean){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.boolean,received:r.parsedType}),Se}return It(e.data)}};yo.create=e=>new yo({typeName:ke.ZodBoolean,coerce:e?.coerce||!1,...Re(e)});var _o=class tT extends Be{_parse(t){if(this._def.coerce&&(t.data=new Date(t.data)),this._getType(t)!==ce.date){let s=this._getOrReturnCtx(t);return pe(s,{code:ne.invalid_type,expected:ce.date,received:s.parsedType}),Se}if(isNaN(t.data.getTime())){let s=this._getOrReturnCtx(t);return pe(s,{code:ne.invalid_date}),Se}let i=new zt,a;for(let s of this._def.checks)s.kind==="min"?t.data.getTime()<s.value&&(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.too_small,message:s.message,inclusive:!0,exact:!1,minimum:s.value,type:"date"}),i.dirty()):s.kind==="max"?t.data.getTime()>s.value&&(a=this._getOrReturnCtx(t,a),pe(a,{code:ne.too_big,message:s.message,inclusive:!0,exact:!1,maximum:s.value,type:"date"}),i.dirty()):We.assertNever(s);return{status:i.value,value:new Date(t.data.getTime())}}_addCheck(t){return new tT({...this._def,checks:[...this._def.checks,t]})}min(t,r){return this._addCheck({kind:"min",value:t.getTime(),message:ve.toString(r)})}max(t,r){return this._addCheck({kind:"max",value:t.getTime(),message:ve.toString(r)})}get minDate(){let t=null;for(let r of this._def.checks)r.kind==="min"&&(t===null||r.value>t)&&(t=r.value);return t!=null?new Date(t):null}get maxDate(){let t=null;for(let r of this._def.checks)r.kind==="max"&&(t===null||r.value<t)&&(t=r.value);return t!=null?new Date(t):null}};_o.create=e=>new _o({checks:[],coerce:e?.coerce||!1,typeName:ke.ZodDate,...Re(e)});var zu=class extends Be{_parse(e){if(this._getType(e)!==ce.symbol){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.symbol,received:r.parsedType}),Se}return It(e.data)}};zu.create=e=>new zu({typeName:ke.ZodSymbol,...Re(e)});var vo=class extends Be{_parse(e){if(this._getType(e)!==ce.undefined){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.undefined,received:r.parsedType}),Se}return It(e.data)}};vo.create=e=>new vo({typeName:ke.ZodUndefined,...Re(e)});var wo=class extends Be{_parse(e){if(this._getType(e)!==ce.null){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.null,received:r.parsedType}),Se}return It(e.data)}};wo.create=e=>new wo({typeName:ke.ZodNull,...Re(e)});var fa=class extends Be{constructor(){super(...arguments),this._any=!0}_parse(e){return It(e.data)}};fa.create=e=>new fa({typeName:ke.ZodAny,...Re(e)});var Xi=class extends Be{constructor(){super(...arguments),this._unknown=!0}_parse(e){return It(e.data)}};Xi.create=e=>new Xi({typeName:ke.ZodUnknown,...Re(e)});var qr=class extends Be{_parse(e){let t=this._getOrReturnCtx(e);return pe(t,{code:ne.invalid_type,expected:ce.never,received:t.parsedType}),Se}};qr.create=e=>new qr({typeName:ke.ZodNever,...Re(e)});var Au=class extends Be{_parse(e){if(this._getType(e)!==ce.undefined){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.void,received:r.parsedType}),Se}return It(e.data)}};Au.create=e=>new Au({typeName:ke.ZodVoid,...Re(e)});var Yi=class ku extends Be{_parse(t){let{ctx:r,status:i}=this._processInputParams(t),a=this._def;if(r.parsedType!==ce.array)return pe(r,{code:ne.invalid_type,expected:ce.array,received:r.parsedType}),Se;if(a.exactLength!==null){let o=r.data.length>a.exactLength.value,u=r.data.length<a.exactLength.value;(o||u)&&(pe(r,{code:o?ne.too_big:ne.too_small,minimum:u?a.exactLength.value:void 0,maximum:o?a.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:a.exactLength.message}),i.dirty())}if(a.minLength!==null&&r.data.length<a.minLength.value&&(pe(r,{code:ne.too_small,minimum:a.minLength.value,type:"array",inclusive:!0,exact:!1,message:a.minLength.message}),i.dirty()),a.maxLength!==null&&r.data.length>a.maxLength.value&&(pe(r,{code:ne.too_big,maximum:a.maxLength.value,type:"array",inclusive:!0,exact:!1,message:a.maxLength.message}),i.dirty()),r.common.async)return Promise.all([...r.data].map((o,u)=>a.type._parseAsync(new xr(r,o,r.path,u)))).then(o=>zt.mergeArray(i,o));let s=[...r.data].map((o,u)=>a.type._parseSync(new xr(r,o,r.path,u)));return zt.mergeArray(i,s)}get element(){return this._def.type}min(t,r){return new ku({...this._def,minLength:{value:t,message:ve.toString(r)}})}max(t,r){return new ku({...this._def,maxLength:{value:t,message:ve.toString(r)}})}length(t,r){return new ku({...this._def,exactLength:{value:t,message:ve.toString(r)}})}nonempty(t){return this.min(1,t)}};Yi.create=(e,t)=>new Yi({type:e,minLength:null,maxLength:null,exactLength:null,typeName:ke.ZodArray,...Re(t)});function da(e){if(e instanceof Ft){let t={};for(let r in e.shape){let i=e.shape[r];t[r]=$r.create(da(i))}return new Ft({...e._def,shape:()=>t})}else return e instanceof Yi?new Yi({...e._def,type:da(e.element)}):e instanceof $r?$r.create(da(e.unwrap())):e instanceof ei?ei.create(da(e.unwrap())):e instanceof Yr?Yr.create(e.items.map(t=>da(t))):e}var Ft=class mr extends Be{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(this._cached!==null)return this._cached;let t=this._def.shape(),r=We.objectKeys(t);return this._cached={shape:t,keys:r}}_parse(t){if(this._getType(t)!==ce.object){let p=this._getOrReturnCtx(t);return pe(p,{code:ne.invalid_type,expected:ce.object,received:p.parsedType}),Se}let{status:i,ctx:a}=this._processInputParams(t),{shape:s,keys:o}=this._getCached(),u=[];if(!(this._def.catchall instanceof qr&&this._def.unknownKeys==="strip"))for(let p in a.data)o.includes(p)||u.push(p);let d=[];for(let p of o){let m=s[p],f=a.data[p];d.push({key:{status:"valid",value:p},value:m._parse(new xr(a,f,a.path,p)),alwaysSet:p in a.data})}if(this._def.catchall instanceof qr){let p=this._def.unknownKeys;if(p==="passthrough")for(let m of u)d.push({key:{status:"valid",value:m},value:{status:"valid",value:a.data[m]}});else if(p==="strict")u.length>0&&(pe(a,{code:ne.unrecognized_keys,keys:u}),i.dirty());else if(p!=="strip")throw new Error("Internal ZodObject error: invalid unknownKeys value.")}else{let p=this._def.catchall;for(let m of u){let f=a.data[m];d.push({key:{status:"valid",value:m},value:p._parse(new xr(a,f,a.path,m)),alwaysSet:m in a.data})}}return a.common.async?Promise.resolve().then(async()=>{let p=[];for(let m of d){let f=await m.key,g=await m.value;p.push({key:f,value:g,alwaysSet:m.alwaysSet})}return p}).then(p=>zt.mergeObjectSync(i,p)):zt.mergeObjectSync(i,d)}get shape(){return this._def.shape()}strict(t){return ve.errToObj,new mr({...this._def,unknownKeys:"strict",...t!==void 0?{errorMap:(r,i)=>{var a,s,o,u;let d=(o=(s=(a=this._def).errorMap)===null||s===void 0?void 0:s.call(a,r,i).message)!==null&&o!==void 0?o:i.defaultError;return r.code==="unrecognized_keys"?{message:(u=ve.errToObj(t).message)!==null&&u!==void 0?u:d}:{message:d}}}:{}})}strip(){return new mr({...this._def,unknownKeys:"strip"})}passthrough(){return new mr({...this._def,unknownKeys:"passthrough"})}extend(t){return new mr({...this._def,shape:()=>({...this._def.shape(),...t})})}merge(t){return new mr({unknownKeys:t._def.unknownKeys,catchall:t._def.catchall,shape:()=>({...this._def.shape(),...t._def.shape()}),typeName:ke.ZodObject})}setKey(t,r){return this.augment({[t]:r})}catchall(t){return new mr({...this._def,catchall:t})}pick(t){let r={};return We.objectKeys(t).forEach(i=>{t[i]&&this.shape[i]&&(r[i]=this.shape[i])}),new mr({...this._def,shape:()=>r})}omit(t){let r={};return We.objectKeys(this.shape).forEach(i=>{t[i]||(r[i]=this.shape[i])}),new mr({...this._def,shape:()=>r})}deepPartial(){return da(this)}partial(t){let r={};return We.objectKeys(this.shape).forEach(i=>{let a=this.shape[i];t&&!t[i]?r[i]=a:r[i]=a.optional()}),new mr({...this._def,shape:()=>r})}required(t){let r={};return We.objectKeys(this.shape).forEach(i=>{if(t&&!t[i])r[i]=this.shape[i];else{let s=this.shape[i];for(;s instanceof $r;)s=s._def.innerType;r[i]=s}}),new mr({...this._def,shape:()=>r})}keyof(){return oT(We.objectKeys(this.shape))}};Ft.create=(e,t)=>new Ft({shape:()=>e,unknownKeys:"strip",catchall:qr.create(),typeName:ke.ZodObject,...Re(t)});Ft.strictCreate=(e,t)=>new Ft({shape:()=>e,unknownKeys:"strict",catchall:qr.create(),typeName:ke.ZodObject,...Re(t)});Ft.lazycreate=(e,t)=>new Ft({shape:e,unknownKeys:"strip",catchall:qr.create(),typeName:ke.ZodObject,...Re(t)});var bo=class extends Be{_parse(e){let{ctx:t}=this._processInputParams(e),r=this._def.options;function i(a){for(let o of a)if(o.result.status==="valid")return o.result;for(let o of a)if(o.result.status==="dirty")return t.common.issues.push(...o.ctx.common.issues),o.result;let s=a.map(o=>new gr(o.ctx.common.issues));return pe(t,{code:ne.invalid_union,unionErrors:s}),Se}if(t.common.async)return Promise.all(r.map(async a=>{let s={...t,common:{...t.common,issues:[]},parent:null};return{result:await a._parseAsync({data:t.data,path:t.path,parent:s}),ctx:s}})).then(i);{let a,s=[];for(let u of r){let d={...t,common:{...t.common,issues:[]},parent:null},p=u._parseSync({data:t.data,path:t.path,parent:d});if(p.status==="valid")return p;p.status==="dirty"&&!a&&(a={result:p,ctx:d}),d.common.issues.length&&s.push(d.common.issues)}if(a)return t.common.issues.push(...a.ctx.common.issues),a.result;let o=s.map(u=>new gr(u));return pe(t,{code:ne.invalid_union,unionErrors:o}),Se}}get options(){return this._def.options}};bo.create=(e,t)=>new bo({options:e,typeName:ke.ZodUnion,...Re(t)});var Wr=e=>e instanceof xo?Wr(e.schema):e instanceof yr?Wr(e.innerType()):e instanceof ko?[e.value]:e instanceof Eo?e.options:e instanceof So?We.objectValues(e.enum):e instanceof To?Wr(e._def.innerType):e instanceof vo?[void 0]:e instanceof wo?[null]:e instanceof $r?[void 0,...Wr(e.unwrap())]:e instanceof ei?[null,...Wr(e.unwrap())]:e instanceof Zf||e instanceof Io?Wr(e.unwrap()):e instanceof Co?Wr(e._def.innerType):[],rT=class iT extends Be{_parse(t){let{ctx:r}=this._processInputParams(t);if(r.parsedType!==ce.object)return pe(r,{code:ne.invalid_type,expected:ce.object,received:r.parsedType}),Se;let i=this.discriminator,a=r.data[i],s=this.optionsMap.get(a);return s?r.common.async?s._parseAsync({data:r.data,path:r.path,parent:r}):s._parseSync({data:r.data,path:r.path,parent:r}):(pe(r,{code:ne.invalid_union_discriminator,options:Array.from(this.optionsMap.keys()),path:[i]}),Se)}get discriminator(){return this._def.discriminator}get options(){return this._def.options}get optionsMap(){return this._def.optionsMap}static create(t,r,i){let a=new Map;for(let s of r){let o=Wr(s.shape[t]);if(!o.length)throw new Error(`A discriminator value for key \`${t}\` could not be extracted from all schema options`);for(let u of o){if(a.has(u))throw new Error(`Discriminator property ${String(t)} has duplicate value ${String(u)}`);a.set(u,s)}}return new iT({typeName:ke.ZodDiscriminatedUnion,discriminator:t,options:r,optionsMap:a,...Re(i)})}};function Vf(e,t){let r=Vr(e),i=Vr(t);if(e===t)return{valid:!0,data:e};if(r===ce.object&&i===ce.object){let a=We.objectKeys(t),s=We.objectKeys(e).filter(u=>a.indexOf(u)!==-1),o={...e,...t};for(let u of s){let d=Vf(e[u],t[u]);if(!d.valid)return{valid:!1};o[u]=d.data}return{valid:!0,data:o}}else if(r===ce.array&&i===ce.array){if(e.length!==t.length)return{valid:!1};let a=[];for(let s=0;s<e.length;s++){let o=e[s],u=t[s],d=Vf(o,u);if(!d.valid)return{valid:!1};a.push(d.data)}return{valid:!0,data:a}}else return r===ce.date&&i===ce.date&&+e==+t?{valid:!0,data:e}:{valid:!1}}var $o=class extends Be{_parse(e){let{status:t,ctx:r}=this._processInputParams(e),i=(a,s)=>{if(Df(a)||Df(s))return Se;let o=Vf(a.value,s.value);return o.valid?((Pf(a)||Pf(s))&&t.dirty(),{status:t.value,value:o.data}):(pe(r,{code:ne.invalid_intersection_types}),Se)};return r.common.async?Promise.all([this._def.left._parseAsync({data:r.data,path:r.path,parent:r}),this._def.right._parseAsync({data:r.data,path:r.path,parent:r})]).then(([a,s])=>i(a,s)):i(this._def.left._parseSync({data:r.data,path:r.path,parent:r}),this._def.right._parseSync({data:r.data,path:r.path,parent:r}))}};$o.create=(e,t,r)=>new $o({left:e,right:t,typeName:ke.ZodIntersection,...Re(r)});var Yr=class aT extends Be{_parse(t){let{status:r,ctx:i}=this._processInputParams(t);if(i.parsedType!==ce.array)return pe(i,{code:ne.invalid_type,expected:ce.array,received:i.parsedType}),Se;if(i.data.length<this._def.items.length)return pe(i,{code:ne.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),Se;!this._def.rest&&i.data.length>this._def.items.length&&(pe(i,{code:ne.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),r.dirty());let s=[...i.data].map((o,u)=>{let d=this._def.items[u]||this._def.rest;return d?d._parse(new xr(i,o,i.path,u)):null}).filter(o=>!!o);return i.common.async?Promise.all(s).then(o=>zt.mergeArray(r,o)):zt.mergeArray(r,s)}get items(){return this._def.items}rest(t){return new aT({...this._def,rest:t})}};Yr.create=(e,t)=>{if(!Array.isArray(e))throw new Error("You must pass an array of schemas to z.tuple([ ... ])");return new Yr({items:e,typeName:ke.ZodTuple,rest:null,...Re(t)})};var nT=class qf extends Be{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(t){let{status:r,ctx:i}=this._processInputParams(t);if(i.parsedType!==ce.object)return pe(i,{code:ne.invalid_type,expected:ce.object,received:i.parsedType}),Se;let a=[],s=this._def.keyType,o=this._def.valueType;for(let u in i.data)a.push({key:s._parse(new xr(i,u,i.path,u)),value:o._parse(new xr(i,i.data[u],i.path,u)),alwaysSet:u in i.data});return i.common.async?zt.mergeObjectAsync(r,a):zt.mergeObjectSync(r,a)}get element(){return this._def.valueType}static create(t,r,i){return r instanceof Be?new qf({keyType:t,valueType:r,typeName:ke.ZodRecord,...Re(i)}):new qf({keyType:ha.create(),valueType:t,typeName:ke.ZodRecord,...Re(r)})}},Ou=class extends Be{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){let{status:t,ctx:r}=this._processInputParams(e);if(r.parsedType!==ce.map)return pe(r,{code:ne.invalid_type,expected:ce.map,received:r.parsedType}),Se;let i=this._def.keyType,a=this._def.valueType,s=[...r.data.entries()].map(([o,u],d)=>({key:i._parse(new xr(r,o,r.path,[d,"key"])),value:a._parse(new xr(r,u,r.path,[d,"value"]))}));if(r.common.async){let o=new Map;return Promise.resolve().then(async()=>{for(let u of s){let d=await u.key,p=await u.value;if(d.status==="aborted"||p.status==="aborted")return Se;(d.status==="dirty"||p.status==="dirty")&&t.dirty(),o.set(d.value,p.value)}return{status:t.value,value:o}})}else{let o=new Map;for(let u of s){let d=u.key,p=u.value;if(d.status==="aborted"||p.status==="aborted")return Se;(d.status==="dirty"||p.status==="dirty")&&t.dirty(),o.set(d.value,p.value)}return{status:t.value,value:o}}}};Ou.create=(e,t,r)=>new Ou({valueType:t,keyType:e,typeName:ke.ZodMap,...Re(r)});var Ru=class jf extends Be{_parse(t){let{status:r,ctx:i}=this._processInputParams(t);if(i.parsedType!==ce.set)return pe(i,{code:ne.invalid_type,expected:ce.set,received:i.parsedType}),Se;let a=this._def;a.minSize!==null&&i.data.size<a.minSize.value&&(pe(i,{code:ne.too_small,minimum:a.minSize.value,type:"set",inclusive:!0,exact:!1,message:a.minSize.message}),r.dirty()),a.maxSize!==null&&i.data.size>a.maxSize.value&&(pe(i,{code:ne.too_big,maximum:a.maxSize.value,type:"set",inclusive:!0,exact:!1,message:a.maxSize.message}),r.dirty());let s=this._def.valueType;function o(d){let p=new Set;for(let m of d){if(m.status==="aborted")return Se;m.status==="dirty"&&r.dirty(),p.add(m.value)}return{status:r.value,value:p}}let u=[...i.data.values()].map((d,p)=>s._parse(new xr(i,d,i.path,p)));return i.common.async?Promise.all(u).then(d=>o(d)):o(u)}min(t,r){return new jf({...this._def,minSize:{value:t,message:ve.toString(r)}})}max(t,r){return new jf({...this._def,maxSize:{value:t,message:ve.toString(r)}})}size(t,r){return this.min(t,r).max(t,r)}nonempty(t){return this.min(1,t)}};Ru.create=(e,t)=>new Ru({valueType:e,minSize:null,maxSize:null,typeName:ke.ZodSet,...Re(t)});var sT=class Su extends Be{constructor(){super(...arguments),this.validate=this.implement}_parse(t){let{ctx:r}=this._processInputParams(t);if(r.parsedType!==ce.function)return pe(r,{code:ne.invalid_type,expected:ce.function,received:r.parsedType}),Se;function i(u,d){return Iu({data:u,path:r.path,errorMaps:[r.common.contextualErrorMap,r.schemaErrorMap,Cu(),ca].filter(p=>!!p),issueData:{code:ne.invalid_arguments,argumentsError:d}})}function a(u,d){return Iu({data:u,path:r.path,errorMaps:[r.common.contextualErrorMap,r.schemaErrorMap,Cu(),ca].filter(p=>!!p),issueData:{code:ne.invalid_return_type,returnTypeError:d}})}let s={errorMap:r.common.contextualErrorMap},o=r.data;if(this._def.returns instanceof ma){let u=this;return It(async function(...d){let p=new gr([]),m=await u._def.args.parseAsync(d,s).catch(v=>{throw p.addIssue(i(d,v)),p}),f=await Reflect.apply(o,this,m);return await u._def.returns._def.type.parseAsync(f,s).catch(v=>{throw p.addIssue(a(f,v)),p})})}else{let u=this;return It(function(...d){let p=u._def.args.safeParse(d,s);if(!p.success)throw new gr([i(d,p.error)]);let m=Reflect.apply(o,this,p.data),f=u._def.returns.safeParse(m,s);if(!f.success)throw new gr([a(m,f.error)]);return f.data})}}parameters(){return this._def.args}returnType(){return this._def.returns}args(...t){return new Su({...this._def,args:Yr.create(t).rest(Xi.create())})}returns(t){return new Su({...this._def,returns:t})}implement(t){return this.parse(t)}strictImplement(t){return this.parse(t)}static create(t,r,i){return new Su({args:t||Yr.create([]).rest(Xi.create()),returns:r||Xi.create(),typeName:ke.ZodFunction,...Re(i)})}},xo=class extends Be{get schema(){return this._def.getter()}_parse(e){let{ctx:t}=this._processInputParams(e);return this._def.getter()._parse({data:t.data,path:t.path,parent:t})}};xo.create=(e,t)=>new xo({getter:e,typeName:ke.ZodLazy,...Re(t)});var ko=class extends Be{_parse(e){if(e.data!==this._def.value){let t=this._getOrReturnCtx(e);return pe(t,{received:t.data,code:ne.invalid_literal,expected:this._def.value}),Se}return{status:"valid",value:e.data}}get value(){return this._def.value}};ko.create=(e,t)=>new ko({value:e,typeName:ke.ZodLiteral,...Re(t)});function oT(e,t){return new Eo({values:e,typeName:ke.ZodEnum,...Re(t)})}var Eo=class Lf extends Be{constructor(){super(...arguments),uo.set(this,void 0)}_parse(t){if(typeof t.data!="string"){let r=this._getOrReturnCtx(t),i=this._def.values;return pe(r,{expected:We.joinValues(i),received:r.parsedType,code:ne.invalid_type}),Se}if(Eu(this,uo,"f")||XS(this,uo,new Set(this._def.values),"f"),!Eu(this,uo,"f").has(t.data)){let r=this._getOrReturnCtx(t),i=this._def.values;return pe(r,{received:r.data,code:ne.invalid_enum_value,options:i}),Se}return It(t.data)}get options(){return this._def.values}get enum(){let t={};for(let r of this._def.values)t[r]=r;return t}get Values(){let t={};for(let r of this._def.values)t[r]=r;return t}get Enum(){let t={};for(let r of this._def.values)t[r]=r;return t}extract(t,r=this._def){return Lf.create(t,{...this._def,...r})}exclude(t,r=this._def){return Lf.create(this.options.filter(i=>!t.includes(i)),{...this._def,...r})}};uo=new WeakMap;Eo.create=oT;var So=class extends Be{constructor(){super(...arguments),lo.set(this,void 0)}_parse(e){let t=We.getValidEnumValues(this._def.values),r=this._getOrReturnCtx(e);if(r.parsedType!==ce.string&&r.parsedType!==ce.number){let i=We.objectValues(t);return pe(r,{expected:We.joinValues(i),received:r.parsedType,code:ne.invalid_type}),Se}if(Eu(this,lo,"f")||XS(this,lo,new Set(We.getValidEnumValues(this._def.values)),"f"),!Eu(this,lo,"f").has(e.data)){let i=We.objectValues(t);return pe(r,{received:r.data,code:ne.invalid_enum_value,options:i}),Se}return It(e.data)}get enum(){return this._def.values}};lo=new WeakMap;So.create=(e,t)=>new So({values:e,typeName:ke.ZodNativeEnum,...Re(t)});var ma=class extends Be{unwrap(){return this._def.type}_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==ce.promise&&t.common.async===!1)return pe(t,{code:ne.invalid_type,expected:ce.promise,received:t.parsedType}),Se;let r=t.parsedType===ce.promise?t.data:Promise.resolve(t.data);return It(r.then(i=>this._def.type.parseAsync(i,{path:t.path,errorMap:t.common.contextualErrorMap})))}};ma.create=(e,t)=>new ma({type:e,typeName:ke.ZodPromise,...Re(t)});var yr=class extends Be{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===ke.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){let{status:t,ctx:r}=this._processInputParams(e),i=this._def.effect||null,a={addIssue:s=>{pe(r,s),s.fatal?t.abort():t.dirty()},get path(){return r.path}};if(a.addIssue=a.addIssue.bind(a),i.type==="preprocess"){let s=i.transform(r.data,a);if(r.common.async)return Promise.resolve(s).then(async o=>{if(t.value==="aborted")return Se;let u=await this._def.schema._parseAsync({data:o,path:r.path,parent:r});return u.status==="aborted"?Se:u.status==="dirty"||t.value==="dirty"?pa(u.value):u});{if(t.value==="aborted")return Se;let o=this._def.schema._parseSync({data:s,path:r.path,parent:r});return o.status==="aborted"?Se:o.status==="dirty"||t.value==="dirty"?pa(o.value):o}}if(i.type==="refinement"){let s=o=>{let u=i.refinement(o,a);if(r.common.async)return Promise.resolve(u);if(u instanceof Promise)throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return o};if(r.common.async===!1){let o=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});return o.status==="aborted"?Se:(o.status==="dirty"&&t.dirty(),s(o.value),{status:t.value,value:o.value})}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(o=>o.status==="aborted"?Se:(o.status==="dirty"&&t.dirty(),s(o.value).then(()=>({status:t.value,value:o.value}))))}if(i.type==="transform")if(r.common.async===!1){let s=this._def.schema._parseSync({data:r.data,path:r.path,parent:r});if(!Ji(s))return s;let o=i.transform(s.value,a);if(o instanceof Promise)throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:t.value,value:o}}else return this._def.schema._parseAsync({data:r.data,path:r.path,parent:r}).then(s=>Ji(s)?Promise.resolve(i.transform(s.value,a)).then(o=>({status:t.value,value:o})):s);We.assertNever(i)}};yr.create=(e,t,r)=>new yr({schema:e,typeName:ke.ZodEffects,effect:t,...Re(r)});yr.createWithPreprocess=(e,t,r)=>new yr({schema:t,effect:{type:"preprocess",transform:e},typeName:ke.ZodEffects,...Re(r)});var $r=class extends Be{_parse(e){return this._getType(e)===ce.undefined?It(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}};$r.create=(e,t)=>new $r({innerType:e,typeName:ke.ZodOptional,...Re(t)});var ei=class extends Be{_parse(e){return this._getType(e)===ce.null?It(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}};ei.create=(e,t)=>new ei({innerType:e,typeName:ke.ZodNullable,...Re(t)});var To=class extends Be{_parse(e){let{ctx:t}=this._processInputParams(e),r=t.data;return t.parsedType===ce.undefined&&(r=this._def.defaultValue()),this._def.innerType._parse({data:r,path:t.path,parent:t})}removeDefault(){return this._def.innerType}};To.create=(e,t)=>new To({innerType:e,typeName:ke.ZodDefault,defaultValue:typeof t.default=="function"?t.default:()=>t.default,...Re(t)});var Co=class extends Be{_parse(e){let{ctx:t}=this._processInputParams(e),r={...t,common:{...t.common,issues:[]}},i=this._def.innerType._parse({data:r.data,path:r.path,parent:{...r}});return fo(i)?i.then(a=>({status:"valid",value:a.status==="valid"?a.value:this._def.catchValue({get error(){return new gr(r.common.issues)},input:r.data})})):{status:"valid",value:i.status==="valid"?i.value:this._def.catchValue({get error(){return new gr(r.common.issues)},input:r.data})}}removeCatch(){return this._def.innerType}};Co.create=(e,t)=>new Co({innerType:e,typeName:ke.ZodCatch,catchValue:typeof t.catch=="function"?t.catch:()=>t.catch,...Re(t)});var Bu=class extends Be{_parse(e){if(this._getType(e)!==ce.nan){let r=this._getOrReturnCtx(e);return pe(r,{code:ne.invalid_type,expected:ce.nan,received:r.parsedType}),Se}return{status:"valid",value:e.data}}};Bu.create=e=>new Bu({typeName:ke.ZodNaN,...Re(e)});var MA=Symbol("zod_brand"),Zf=class extends Be{_parse(e){let{ctx:t}=this._processInputParams(e),r=t.data;return this._def.type._parse({data:r,path:t.path,parent:t})}unwrap(){return this._def.type}},Qf=class uT extends Be{_parse(t){let{status:r,ctx:i}=this._processInputParams(t);if(i.common.async)return(async()=>{let s=await this._def.in._parseAsync({data:i.data,path:i.path,parent:i});return s.status==="aborted"?Se:s.status==="dirty"?(r.dirty(),pa(s.value)):this._def.out._parseAsync({data:s.value,path:i.path,parent:i})})();{let a=this._def.in._parseSync({data:i.data,path:i.path,parent:i});return a.status==="aborted"?Se:a.status==="dirty"?(r.dirty(),{status:"dirty",value:a.value}):this._def.out._parseSync({data:a.value,path:i.path,parent:i})}}static create(t,r){return new uT({in:t,out:r,typeName:ke.ZodPipeline})}},Io=class extends Be{_parse(e){let t=this._def.innerType._parse(e),r=i=>(Ji(i)&&(i.value=Object.freeze(i.value)),i);return fo(t)?t.then(i=>r(i)):r(t)}unwrap(){return this._def.innerType}};Io.create=(e,t)=>new Io({innerType:e,typeName:ke.ZodReadonly,...Re(t)});function BS(e,t){let r=typeof e=="function"?e(t):typeof e=="string"?{message:e}:e;return typeof r=="string"?{message:r}:r}function lT(e,t={},r){return e?fa.create().superRefine((i,a)=>{var s,o;let u=e(i);if(u instanceof Promise)return u.then(d=>{var p,m;if(!d){let f=BS(t,i),g=(m=(p=f.fatal)!==null&&p!==void 0?p:r)!==null&&m!==void 0?m:!0;a.addIssue({code:"custom",...f,fatal:g})}});if(!u){let d=BS(t,i),p=(o=(s=d.fatal)!==null&&s!==void 0?s:r)!==null&&o!==void 0?o:!0;a.addIssue({code:"custom",...d,fatal:p})}}):fa.create()}var DA={object:Ft.lazycreate},ke;(function(e){e.ZodString="ZodString",e.ZodNumber="ZodNumber",e.ZodNaN="ZodNaN",e.ZodBigInt="ZodBigInt",e.ZodBoolean="ZodBoolean",e.ZodDate="ZodDate",e.ZodSymbol="ZodSymbol",e.ZodUndefined="ZodUndefined",e.ZodNull="ZodNull",e.ZodAny="ZodAny",e.ZodUnknown="ZodUnknown",e.ZodNever="ZodNever",e.ZodVoid="ZodVoid",e.ZodArray="ZodArray",e.ZodObject="ZodObject",e.ZodUnion="ZodUnion",e.ZodDiscriminatedUnion="ZodDiscriminatedUnion",e.ZodIntersection="ZodIntersection",e.ZodTuple="ZodTuple",e.ZodRecord="ZodRecord",e.ZodMap="ZodMap",e.ZodSet="ZodSet",e.ZodFunction="ZodFunction",e.ZodLazy="ZodLazy",e.ZodLiteral="ZodLiteral",e.ZodEnum="ZodEnum",e.ZodEffects="ZodEffects",e.ZodNativeEnum="ZodNativeEnum",e.ZodOptional="ZodOptional",e.ZodNullable="ZodNullable",e.ZodDefault="ZodDefault",e.ZodCatch="ZodCatch",e.ZodPromise="ZodPromise",e.ZodBranded="ZodBranded",e.ZodPipeline="ZodPipeline",e.ZodReadonly="ZodReadonly"})(ke||(ke={}));var PA=(e,t={message:`Input not instance of ${e.name}`})=>lT(r=>r instanceof e,t),dT=ha.create,pT=mo.create,UA=Bu.create,WA=go.create,cT=yo.create,VA=_o.create,qA=zu.create,jA=vo.create,LA=wo.create,GA=fa.create,FA=Xi.create,HA=qr.create,KA=Au.create,ZA=Yi.create,QA=Ft.create,XA=Ft.strictCreate,JA=bo.create,YA=rT.create,e4=$o.create,t4=Yr.create,r4=nT.create,i4=Ou.create,a4=Ru.create,n4=sT.create,s4=xo.create,o4=ko.create,u4=Eo.create,l4=So.create,d4=ma.create,NS=yr.create,p4=$r.create,c4=ei.create,h4=yr.createWithPreprocess,f4=Qf.create,m4=()=>dT().optional(),g4=()=>pT().optional(),y4=()=>cT().optional(),_4={string:e=>ha.create({...e,coerce:!0}),number:e=>mo.create({...e,coerce:!0}),boolean:e=>yo.create({...e,coerce:!0}),bigint:e=>go.create({...e,coerce:!0}),date:e=>_o.create({...e,coerce:!0})},v4=Se,$t=Object.freeze({__proto__:null,defaultErrorMap:ca,setErrorMap:hA,getErrorMap:Cu,makeIssue:Iu,EMPTY_PATH:fA,addIssueToContext:pe,ParseStatus:zt,INVALID:Se,DIRTY:pa,OK:It,isAborted:Df,isDirty:Pf,isValid:Ji,isAsync:fo,get util(){return We},get objectUtil(){return Mf},ZodParsedType:ce,getParsedType:Vr,ZodType:Be,datetimeRegex:eT,ZodString:ha,ZodNumber:mo,ZodBigInt:go,ZodBoolean:yo,ZodDate:_o,ZodSymbol:zu,ZodUndefined:vo,ZodNull:wo,ZodAny:fa,ZodUnknown:Xi,ZodNever:qr,ZodVoid:Au,ZodArray:Yi,ZodObject:Ft,ZodUnion:bo,ZodDiscriminatedUnion:rT,ZodIntersection:$o,ZodTuple:Yr,ZodRecord:nT,ZodMap:Ou,ZodSet:Ru,ZodFunction:sT,ZodLazy:xo,ZodLiteral:ko,ZodEnum:Eo,ZodNativeEnum:So,ZodPromise:ma,ZodEffects:yr,ZodTransformer:yr,ZodOptional:$r,ZodNullable:ei,ZodDefault:To,ZodCatch:Co,ZodNaN:Bu,BRAND:MA,ZodBranded:Zf,ZodPipeline:Qf,ZodReadonly:Io,custom:lT,Schema:Be,ZodSchema:Be,late:DA,get ZodFirstPartyTypeKind(){return ke},coerce:_4,any:GA,array:ZA,bigint:WA,boolean:cT,date:VA,discriminatedUnion:YA,effect:NS,enum:u4,function:n4,instanceof:PA,intersection:e4,lazy:s4,literal:o4,map:i4,nan:UA,nativeEnum:l4,never:HA,null:LA,nullable:c4,number:pT,object:QA,oboolean:y4,onumber:g4,optional:p4,ostring:m4,pipeline:f4,preprocess:h4,promise:d4,record:r4,set:a4,strictObject:XA,string:dT,symbol:qA,transformer:NS,tuple:t4,undefined:jA,union:JA,unknown:FA,void:KA,NEVER:v4,ZodIssueCode:ne,quotelessJson:cA,ZodError:gr}),MS={name:"@imgly/background-removal",version:"1.7.0",description:"Background Removal in the Browser",keywords:["background-removal","client-side","data-privacy","image-segmentation","image-matting","onnx"],repository:{type:"git",url:"git+https://github.com/imgly/background-removal-js.git"},license:"SEE LICENSE IN LICENSE.md",author:{name:"IMG.LY GmbH",email:"support@img.ly",url:"https://img.ly"},bugs:{email:"support@img.ly"},source:"./src/index.ts",main:"./dist/index.cjs",module:"./dist/index.mjs",types:"./dist/src/index.d.ts",exports:{".":{require:"./dist/index.cjs",import:"./dist/index.mjs",types:"./dist/src/index.d.ts"}},homepage:"https://img.ly/showcases/cesdk/web/background-removal",files:["LICENSE.md","README.md","CHANGELOG.md","ThirdPartyLicenses.json","dist/","bin/"],scripts:{start:"pnpm run watch",clean:"npx rimraf dist",test:"true",resources:"node ../../scripts/package-resources.mjs","changelog:create":"node ../../scripts/changelog/changelog-create.mjs","changelog:generate":"node ../../scripts/changelog/changelog-generate.mjs",build:"pnpm run clean && pnpm run types && pnpm run resources && pnpm run changelog:generate && node scripts/build.mjs",types:" npx tsc --declaration --emitDeclarationOnly --declarationDir dist --declarationMap",watch:"pnpm run clean && pnpm run resources && pnpm run changelog:generate && node scripts/watch.mjs","publish:latest":"pnpm publish --tag latest --access public","publish:next":"pnpm publish --tag next --access public","package:pack":"pnpm pack . --pack-destination ../../releases","check:all":"pnpm run check:pretty","check:pretty":"prettier --list-different './src/**/*.{ts,tsx}'",pretty:"prettier --write './src/**/*.{ts,tsx}'"},dependencies:{"lodash-es":"^4.17.21",ndarray:"~1.0.0",zod:"^3.23.8"},peerDependencies:{"onnxruntime-web":"1.21.0"},devDependencies:{"@types/lodash-es":"^4.17.12","@types/ndarray":"~1.0.14","@types/node":"~20.3.0",assert:"~2.0.0",esbuild:"~0.18.0",glob:"~10.3.0","npm-dts":"~1.3.0",process:"~0.11.0","ts-loader":"~9.4.0",tslib:"~2.5.0",typescript:"~5.1.0",util:"~0.12.0",webpack:"~5.85.0","webpack-cli":"~5.1.0"}},w4=$t.object({publicPath:$t.string().optional().describe("The public path to the wasm files and the onnx model.").default("https://staticimgly.com/@imgly/background-removal-data/${PACKAGE_VERSION}/dist/").transform(e=>e.replace("${PACKAGE_NAME}",MS.name).replace("${PACKAGE_VERSION}",MS.version)),debug:$t.boolean().default(!1).describe("Whether to enable debug logging."),rescale:$t.boolean().default(!0).describe("Whether to rescale the image."),device:$t.enum(["cpu","gpu"]).default("cpu").describe("The device to run the model on."),proxyToWorker:$t.boolean().default(!1).describe("Whether to proxy inference to a web worker."),fetchArgs:$t.any().default({}).describe("Arguments to pass to fetch when loading the model."),progress:$t.function().args($t.string(),$t.number(),$t.number()).returns($t.void()).describe("Progress callback.").optional(),model:$t.preprocess(e=>{switch(e){case"large":return"isnet";case"small":return"isnet_quint8";case"medium":return"isnet_fp16";default:return e}},$t.enum(["isnet","isnet_fp16","isnet_quint8"])).default("medium"),output:$t.object({format:$t.enum(["image/png","image/jpeg","image/webp","image/x-rgba8","image/x-alpha8"]).default("image/png"),quality:$t.number().default(.8)}).default({})}).default({}).transform(e=>(e.debug&&console.log("Config:",e),e.debug&&!e.progress&&(e.progress=e.progress??((t,r,i)=>{console.debug(`Downloading ${t}: ${r} of ${i}`)}),crossOriginIsolated||e.debug&&console.debug("Cross-Origin-Isolated is not enabled. Performance will be degraded. Please see  https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer.")),e));function hT(e){return w4.parse(e??{})}var b4=Nu(Mu());async function $4(e){e.debug&&console.debug("Loading model...",e.model);let t=e.model,i=await(await FS(`/models/${t}`,e)).arrayBuffer();return await dA(i,e)}async function x4(e){e=hT(e);let t=await $4(e);return{config:e,session:{base:t}}}async function Xf(e,t,r){let[a,s,o]=e.shape,u=!1,d=Nf(e,1024,1024,u),p=sA(d),m=await pA(r.base,[["input",p]],["output"],t),f=(0,b4.default)(m[0].data,[1024,1024,1]),g=oA(f);return t.rescale?(g=Nf(g,s,a,u),[g,e]):[g,d]}var Wu=eA(x4,e=>JSON.stringify(e));async function k4(e){await Wu(e)}async function S4(e,t){let{config:r,session:i}=await Wu(t);r.progress&&r.progress("compute:decode",0,4);let a=await ho(e,r);r.progress?.("compute:inference",1,4);let[s,o]=await Xf(a,r,i);r.progress?.("compute:mask",2,4);let u=o,[d,p]=u.shape,m=d*p;for(let g=0;g<m;g+=1)u.data[4*g+3]=s.data[g];r.progress?.("compute:encode",3,4);let f=await Uu(u,r.output.quality,r.output.format);return r.progress?.("compute:encode",4,4),f}async function T4(e,t){let{config:r,session:i}=await Wu(t),a=await ho(e,r),[s,o]=await Xf(a,r,i),u=o,[d,p,m]=u.shape,f=d*p;for(let v=0;v<f;v+=1)u.data[4*v+3]=255-s.data[v];return await Uu(u,r.output.quality,r.output.format)}var C4=fT;async function fT(e,t){let{config:r,session:i}=await Wu(t),a=await ho(e,r),[s,o,u]=a.shape,[d,p]=await Xf(a,r,i),m=o*s,f=a;for(let v=0;v<m;v+=1){let _=4*v,b=d.data[v];f.data[_]=255,f.data[_+1]=255,f.data[_+2]=255,f.data[_+3]=b}return await Uu(f,r.output.quality,r.output.format)}async function I4(e,t,r){r=hT(r);let i=await ho(e,r),[a,s,o]=i.shape,u=await ho(t,r),[d,p,m]=u.shape,f=d!==a||p!==s?Nf(u,s,a):u,g=s*a;for(let _=0;_<g;_+=1){let b=o*_,k=m*_;i.data[b+3]=f.data[k+3]}return await Uu(i,r.output.quality,r.output.format)}return wT(E4);})();
/*! Bundled license information:

onnxruntime-web/dist/ort.webgpu.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.21.0
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
  (**
   * @license
   * Copyright 2021 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2020 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2019 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)

onnxruntime-web/dist/ort.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.21.0
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
  (**
   * @license
   * Copyright 2021 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2020 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)
  (**
   * @license
   * Copyright 2019 Google LLC. All Rights Reserved.
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   * =============================================================================
   *)

@imgly/background-removal/dist/index.mjs:
  (*! Bundled license information:
  
  is-buffer/index.js:
    (*!
     * Determine if an object is a Buffer
     *
     * @author   Feross Aboukhadijeh <https://feross.org>
     * @license  MIT
     *)
  *)
*/
